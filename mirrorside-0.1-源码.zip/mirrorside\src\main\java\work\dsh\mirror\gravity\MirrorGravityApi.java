package work.dsh.mirror.gravity;

import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 本模组对 KubeJS 暴露的唯一接口。
 *
 * <pre>
 *   var api = Java.loadClass('work.dsh.mirror.gravity.MirrorGravityApi');
 *   api.apply(entity, 'up', 0.5);   // 重力朝上，强度 0.5 倍（落得慢）
 *   api.clear(entity);              // 恢复原版
 * </pre>
 *
 * <h2>为什么需要本模组</h2>
 * Pondus 的 {@code canChangeGravity} 白名单（{@code pondus:allowed_special}
 * 标签）在本实例上没有生效，非生物实体（下落的方块、掉落物、TNT……）
 * 100% 被拒绝。而脚本层无法绕过：
 * <ul>
 *   <li>调 {@code setBaseGravityDirection} → 被 canChangeGravity 拦</li>
 *   <li>反射写字段 → Rhino 不暴露 {@code getClass()}，拿不到 Class</li>
 * </ul>
 * 本模组用 Java 反射直接写 Pondus 的数据，并**自己实现**它因白名单
 * 而跳过的"速度旋转 + 位置校正"两步（见 {@link PondusBridge}）。
 *
 * <h2>强度缩放</h2>
 * Pondus 把 {@code EntityGravityData.baseGravityStrength} 乘进
 * {@code Entity.getGravity()}。我们直接改这个字段，就能让重力方块
 * 落得慢一些 —— 避免下落太快导致配方判定跳过交界处。
 */
public final class MirrorGravityApi {

    /** entityUUID -> 当前方向（仅用于诊断与清理） */
    private static final Map<UUID, Direction> TRACKED = new ConcurrentHashMap<>();

    private MirrorGravityApi() {
    }

    /**
     * 设定实体的重力方向与强度。
     *
     * @param entity 目标实体
     * @param name   方向名（小写）：down / up / north / south / west / east
     * @param scale  重力强度倍数；1.0 = 原版，0.5 = 一半（落得慢），0 = 不受重力
     * @return 是否成功
     */
    public static boolean apply(Entity entity, String name, double scale) {
        Direction dir = MirrorDir.byNameOrNull(name);
        if (entity == null || dir == null) {
            return false;
        }
        /* 逐步包围"水平速度被清零"的那一步。
         * 顺序：setter 前 → setter 后 → 强度写入后。
         * 三段里哪一段 vx/vz 变 0，责任就在那一段。 */
        PondusBridge.traceApplySteps(entity, "before-setter", dir, false);

        boolean ok = PondusBridge.applyDirection(entity, dir);
        PondusBridge.traceApplySteps(entity, "after-setter", dir, ok);

        if (ok && scale >= 0.0D) {
            PondusBridge.applyGravityScale(entity, scale);
            PondusBridge.traceApplySteps(entity, "after-scale", dir, ok);
        }
        if (ok) {
            TRACKED.put(entity.getUUID(), dir);
        }
        return ok;
    }

    /** 只改方向，强度保持原版 1.0。 */
    public static boolean apply(Entity entity, String name) {
        return apply(entity, name, 1.0D);
    }

    /** 恢复原版：方向 down、强度 1.0。 */
    public static void clear(Entity entity) {
        if (entity == null) {
            return;
        }
        /* ⚠️ 强度必须**无条件**复位，不能跟着 applyDirection 的返回值走。
         * applyDirection 现在会在"方向没变"时提前返回 true 且什么都不写，
         * 若这里再依赖它，强度就会残留 —— 实体回到上界面后仍受缩放重力。 */
        PondusBridge.applyDirection(entity, Direction.DOWN);
        PondusBridge.applyGravityScale(entity, 1.0D);
        TRACKED.remove(entity.getUUID());
        PondusBridge.forget(entity.getUUID());
    }

    /** 当前被管理的实体数量（诊断用）。 */
    public static int trackedCount() {
        return TRACKED.size();
    }

    /** 这个实体是否正被本模组接管（KubeJS 侧刚设置过方向）。 */
    public static boolean isTracked(Entity entity) {
        return entity != null && TRACKED.containsKey(entity.getUUID());
    }

    /** 这个实体当前被设定的方向；未接管则返回 null。 */
    public static Direction trackedDirection(Entity entity) {
        return entity == null ? null : TRACKED.get(entity.getUUID());
    }

    /**
     * 开启/关闭**逐 tick 轨迹记录**（写进游戏日志）。
     * 用于定位"抽搐 / 传送"这类问题：记录每个被接管实体的
     * y、速度、方向、以及本 tick 是否发生过位置校正。
     *
     * 游戏里用 /mirror trace on|off 调用。
     */
    public static void setTrace(boolean on) {
        PondusBridge.setTrace(on);
    }

    public static boolean isTraceOn() {
        return PondusBridge.isTraceOn();
    }

    /**
     * 设置重力分界线（由 KubeJS 侧把 layout.split_y 推过来）。
     *
     * <p>为什么需要：下落的方块与掉落物现在由模组侧 {@link BlockPhysics}
     * 完全接管物理，它必须知道分界在哪才能决定加速度方向。
     * 分界值仍然只有一处真相（mirror_config.js），模组只是接收。
     */
    public static void setSplitY(double y) {
        MirrorGravity.setSplitY(y);
    }

    /** 丢弃已消失实体的记录。 */
    public static void retainOnly(java.util.Set<UUID> alive) {
        TRACKED.keySet().removeIf(id -> !alive.contains(id));
    }

    static void logStatus(org.slf4j.Logger logger) {
        logger.info("[镜维度·重力] Pondus 数据接入: {}",
            PondusBridge.isAvailable() ? "成功" : "失败（非生物实体将无法反转）");
    }
}
