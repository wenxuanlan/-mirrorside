package work.dsh.mirror.gravity;

/**
 * 本模组的物理参数。
 *
 * <p>刻意**不使用** NeoForge 的配置系统（ModConfigSpec 等）：
 * 那些 API 在 1.21.1 各小版本之间有变动，写错就是编译失败。
 * 这里只有几个数值，直接写常量最稳，也便于阅读与调参。
 */
public final class MirrorGravityConfig {

    /** 原版重力加速度（下落的方块与掉落物都是 0.04），仅作参考。 */
    public static final double VANILLA_GRAVITY = 0.04D;

    /* ------------------------------------------------------------------ */
    /* BlockPhysics 接管实体的往复参数                                       */
    /* ------------------------------------------------------------------ */

    /**
     * 下落的方块（沙砾/沙子）的重力加速度（格/tick²）。
     *
     * <p>用户的核心诉求是"**看得清力的变化过程**"——所以刻意远低于原版 0.04。
     *
     * <h2>为什么调得这么小</h2>
     * 用户反馈"速度越来越快，看不出重力加速度的变换过程"。
     * 那说明速度很快就撞上阻尼形成的终端速度，加速段一闪而过。
     * 终端速度 v_t = accel/(1-damping)，把 accel 降到 0.003、
     * damping 保持 0.99 时 v_t ≈ 0.3 格/tick，需要约 40 tick
     * （2 秒）才接近，加速过程因此清晰可见。
     */
    public static final double REBOUND_ACCEL = 0.003D;

    /**
     * 掉落物的重力加速度（格/tick²）。
     * 用户要求"掉落物重力调回正常"，所以用原版量级 0.04。
     */
    public static final double ITEM_ACCEL = 0.04D;

    /** 该实体使用哪个加速度。 */
    public static double accelFor(net.minecraft.world.entity.Entity entity) {
        return (entity instanceof net.minecraft.world.entity.item.FallingBlockEntity)
            ? REBOUND_ACCEL : ITEM_ACCEL;
    }

    /**
     * 沙砾的速度阻尼（每 tick 乘这个系数）。用户要的"略微阻力"。
     *
     * <p>终端速度 v_t = accel / (1 - damping)。
     * 0.003 / (1 - 0.99) = 0.3 格/tick —— 速度缓慢逼近它，
     * 加速过程因此**可见**（这是用户最在意的一点）。
     * 阻尼比 0.995 更明显，收敛更快、更容易看出"趋于稳定"。
     */
    public static final double REBOUND_DAMPING_PER_TICK = 0.99D;

    /**
     * 掉落物的阻尼（比沙砾轻得多）。
     *
     * <p>用户要求掉落物"重力调回正常"——正常的抛物线不该被明显拖慢。
     * 几乎不衰减，只在极端情况下起一点收敛作用。
     */
    public static final double ITEM_DAMPING_PER_TICK = 0.999D;

    /**
     * 速度上限（格/tick）。**只用于下落的方块**，仅作兜底防止失控。
     *
     * <p>用户反馈"加速过程拖长了，但最终速度还是太快看不清"，
     * 所以这里主动压低到 0.12（约每秒 2.4 格）——足够慢、看得清。
     * 它低于终端速度 0.3，于是成为实际生效的速度上限。
     *
     * <p>⚠️ 千万不要把它用在掉落物上：物品投掷初速约 0.4~0.5，
     * 一削抛物线就会压扁（实测踩过）。掉落物已不经过本模组的物理。
     */
    public static final double REBOUND_MAX_SPEED = 0.12D;

    private MirrorGravityConfig() {
    }
}
