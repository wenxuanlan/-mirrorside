package work.dsh.mirror.gravity;

import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;

/**
 * 方向与坐标系换算。
 *
 * 公式取自 GravityChanger / Pondus 的 RotationUtil.vecWorldToPlayer，
 * 保证与 Pondus 内部用的旋转**完全一致** —— 否则我们的补偿会和它的
 * 速度旋转互相打架，表现为实体乱飘。
 */
public final class MirrorDir {

    /**
     * 世界坐标 -> 实体本地坐标（local space）。
     *
     * 本地坐标的含义：实体永远认为"下"是自己 -Y 方向，
     * 重力方向为 DOWN 时本地 == 世界；为 UP 时本地 X/Y 取反。
     */
    public static Vec3 worldToLocal(double x, double y, double z, Direction g) {
        return switch (g) {
            case DOWN -> new Vec3(x, y, z);
            case UP -> new Vec3(-x, -y, z);
            case NORTH -> new Vec3(x, z, -y);
            case SOUTH -> new Vec3(-x, -z, -y);
            case WEST -> new Vec3(-z, x, -y);
            case EAST -> new Vec3(z, -x, -y);
        };
    }

    public static Vec3 worldToLocal(Vec3 v, Direction g) {
        return worldToLocal(v.x, v.y, v.z, g);
    }

    /** 本地坐标 -> 世界坐标（上面那个的逆变换）。 */
    public static Vec3 localToWorld(double x, double y, double z, Direction g) {
        return switch (g) {
            case DOWN -> new Vec3(x, y, z);
            case UP -> new Vec3(-x, -y, z);
            case NORTH -> new Vec3(x, -z, y);
            case SOUTH -> new Vec3(-x, -z, -y);
            case WEST -> new Vec3(y, -z, -x);
            case EAST -> new Vec3(-y, -z, x);
        };
    }

    public static Vec3 localToWorld(Vec3 v, Direction g) {
        return localToWorld(v.x, v.y, v.z, g);
    }

    /** 解析 Pondus 用的方向名（小写），非法返回 null。 */
    public static Direction byNameOrNull(String name) {
        if (name == null) {
            return null;
        }
        String n = name.trim().toLowerCase();
        for (Direction d : Direction.values()) {
            if (d.getName().equals(n)) {
                return d;
            }
        }
        return null;
    }

    private MirrorDir() {
    }
}
