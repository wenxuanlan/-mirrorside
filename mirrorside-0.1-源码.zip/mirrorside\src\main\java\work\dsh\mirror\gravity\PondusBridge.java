package work.dsh.mirror.gravity;

import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 通过**反射**操作 Pondus 的 EntityGravityData。
 *
 * <h2>为什么要用反射</h2>
 * Pondus 没有发布到任何公共 Maven 仓库，拿不到编译期坐标。
 * 反射让本模组能编译而完全不依赖它的 jar —— 它在运行时由 mods/ 提供即可。
 *
 * <h2>为什么要自己实现"换重力方向"的完整流程</h2>
 * Pondus 里换方向要做四件事：
 * <ol>
 *   <li>写 baseGravityDirection</li>
 *   <li>把 base 同步到 currGravityDirection</li>
 *   <li>把实体**速度**从旧方向旋转到新方向</li>
 *   <li>**校正位置**，避免换方向后卡进方块</li>
 * </ol>
 * 后两步在 {@code EntityGravityData.applyGravityDirectionChange} 里，
 * 而它开头也有 {@code if (!canChangeGravity()) return;}。
 * 该白名单（{@code pondus:allowed_special} 标签）在本实例上没有生效，
 * 所以非生物实体会被整段跳过 —— 表现为"方向好像设了，但实体只是
 * 被反复挪来挪去"（实测现象）。
 *
 * 因此本类把 3、4 两步自己实现，不再指望 Pondus 替我们做。
 */
public final class PondusBridge {

    private static final String API_CLASS = "dinner.dev.pondus.api.PondusAPI";

    private static Method getGravityDataMethod;   // PondusAPI.getGravityData(Entity)
    private static Method setBaseDirectionMethod; // EntityGravityData.setBaseGravityDirection(Direction)
    private static Field baseDirectionField;      // EntityGravityData.baseGravityDirection
    private static Field currDirectionField;      // EntityGravityData.currGravityDirection
    private static Field prevDirectionField;      // EntityGravityData.prevGravityDirection
    private static Field baseStrengthField;       // EntityGravityData.baseGravityStrength
    private static Field needsSyncField;          // EntityGravityData.needsSync（服务端要置它才会发同步包）

    private static boolean resolved;
    private static boolean available;

    /** 上一次给这个实体设定的方向，用来判断"方向是否真的变了"。 */
    private static final Map<UUID, Direction> LAST_DIRECTION = new ConcurrentHashMap<>();

    private PondusBridge() {
    }

    private static synchronized boolean resolve() {
        if (resolved) {
            return available;
        }
        resolved = true;
        try {
            Class<?> api = Class.forName(API_CLASS);
            Class<?> dataCls = Class.forName("dinner.dev.pondus.util.EntityGravityData");
            Class<?> entityCls = Class.forName("net.minecraft.world.entity.Entity");

            getGravityDataMethod = api.getMethod("getGravityData", entityCls);

            // Pondus 自己的 setter：它会置 needsSync，从而触发向客户端的同步包。
            // 用它而不是直接写字段，是"客户端不同步"问题的修复关键。
            try {
                Class<?> dirCls = Class.forName("net.minecraft.core.Direction");
                setBaseDirectionMethod = dataCls.getMethod("setBaseGravityDirection", dirCls);
            } catch (Throwable ignored) {
                setBaseDirectionMethod = null;
            }

            baseDirectionField = dataCls.getDeclaredField("baseGravityDirection");
            baseDirectionField.setAccessible(true);

            try {
                currDirectionField = dataCls.getDeclaredField("currGravityDirection");
                currDirectionField.setAccessible(true);
            } catch (NoSuchFieldException ignored) {
                currDirectionField = null;
            }

            try {
                prevDirectionField = dataCls.getDeclaredField("prevGravityDirection");
                prevDirectionField.setAccessible(true);
            } catch (NoSuchFieldException ignored) {
                prevDirectionField = null;
            }

            try {
                baseStrengthField = dataCls.getDeclaredField("baseGravityStrength");
                baseStrengthField.setAccessible(true);
            } catch (NoSuchFieldException ignored) {
                baseStrengthField = null;
            }

            try {
                needsSyncField = dataCls.getDeclaredField("needsSync");
                needsSyncField.setAccessible(true);
            } catch (NoSuchFieldException ignored) {
                needsSyncField = null;
            }

            available = true;
        } catch (Throwable t) {
            available = false;
            MirrorGravity.LOGGER.warn(
                "[镜维度·重力] 未能接上 Pondus（{}）；非生物实体的重力反转将不可用。", t.toString());
        }
        return available;
    }

    public static boolean isAvailable() {
        return resolve();
    }

    public static Direction readDirection(Entity entity) {
        if (!resolve() || entity == null) {
            return null;
        }
        try {
            Object data = getGravityDataMethod.invoke(null, entity);
            if (data == null) {
                return null;
            }
            Object v = baseDirectionField.get(data);
            return v instanceof Direction d ? d : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * 把实体的重力方向设为 {@code dir}，并完成 Pondus 因白名单而跳过的那两步。
     *
     * @return 是否成功
     */
    public static boolean applyDirection(Entity entity, Direction dir) {
        return applyDirection(entity, dir, true);
    }

    /**
     * 把实体的重力方向写进 Pondus。
     *
     * @param syncToClient 是否置 needsSync 触发客户端同步包。
     */
    public static boolean applyDirection(Entity entity, Direction dir, boolean syncToClient) {
        if (!resolve() || entity == null || dir == null) {
            return false;
        }
        try {
            Object data = getGravityDataMethod.invoke(null, entity);
            if (data == null) {
                return false;
            }

            Direction oldDir = readDirection(entity);
            boolean changed = oldDir != dir;

            /* 诊断：把 prev/curr/base 三个方向字段一起打出来。
             *
             * 为什么需要：调用栈已经证明速度是被
             *   EntityGravityData.commonTick → applyGravityChange
             *     → applyGravityDirectionChange
             * 每 tick 旋转清零的。而 applyGravityChange 的门槛是
             * {@code prevGravityDirection != currGravityDirection}。
             * 按字段语义，每次换向末尾都会 prev = curr，不该持续成立 ——
             * 所以必须看清这三个字段在这台机器上的**实际**取值。 */
            if (isWatched(entity) && !entity.level().isClientSide()) {
                logDirectionFields(entity, data, dir, oldDir);
            }

            /* ⚠️ 方向没变就**立刻收工，什么都不写**。
             *
             * 这是"丢出去又瞬移回脚下"的真正元凶：
             * 下面那个兜底分支（!ok 时重写 base 并置 needsSync）在没有 changed
             * 保护的情况下**每 tick 都会执行**，于是：
             *   · 每帧把 baseGravityDirection 重写一遍
             *   · 每帧把 needsSync 置 true → **每帧给客户端发一个方向同步包**
             *   · 客户端每帧收包 → 每帧重演一次 applyGravityDirectionChange()
             *     → 速度被反复旋转，vx 在 +0.275 / -0.264 之间来回翻
             *     → 水平位移净为 0，物品原地不动、看起来被"传送"回玩家脚下
             *
             * 实测证据（同一帧）：
             *   [S] remain=39 vel=(0.275, -0.164, -0.097) dir=down   ← 还正常
             *   [换向] down->up setter=true
             *   [S] remain=37 vel=(0.0,   -0.008,  0.0  ) dir=up     ← 水平分量归零
             *   [C] remain=38 vel=(0.269, -0.2,   -0.095) pondus=down
             *   [C] remain=36 vel=(-0.264, 0.188, -0.094) pondus=up  ← vx 被翻转
             *
             * 生物走的是 Pondus 原装 API，那里本来就有同样的"没变就返回"保护
             * （见墙另一侧的 pushDirection），所以生物从来没出过这个问题。
             * 这里补上，两条路径行为就一致了。 */
            if (!changed) {
                LAST_DIRECTION.put(entity.getUUID(), dir);
                return true;
            }

            Vec3 velBefore = entity.getDeltaMovement();
            double posYBefore = entity.getY();
            boolean usedSetter = false;
            if (setBaseDirectionMethod != null) {
                try {
                    setBaseDirectionMethod.invoke(data, dir);
                    usedSetter = true;
                    /* 登记"换向前的水平速度"，供 tick 之后补回。
                     *
                     * 为什么必须补：Pondus 的 applyGravityDirectionChange 会调
                     * getRealWorldVelocity()，而它在服务端对非玩家实体走的是
                     *   new Vec3(getX()-xo, getY()-yo, getZ()-zo)
                     * 这条分支。换向发生在**实体 tick 内部**（Pondus 注入在
                     * Entity.tick() 上），此刻 xo/yo/zo 还没被本次移动更新，
                     * 于是它算出 (0,0,0) —— 再经 vecWorldToPlayer 写回，
                     * 速度就被整体清零了。实测：
                     *   换向前 vel=(-0.1934, -0.1019, -0.2321) 水平 0.3022
                     *   换向后 vel=( 0.0,     0.0,     0.0   )
                     * 这就是掉落物"丢出去又回到脚下"的唯一原因。
                     *
                     * 只补水平分量：垂直分量由 Pondus 的重力方向掌管，
                     * 不该由我们覆盖。 */
                    if (!entity.level().isClientSide()) {
                        SAVED_HORIZONTAL.put(entity.getUUID(), velBefore);
                    }
                } catch (Throwable ignored) {
                    usedSetter = false;
                }
            }
            Vec3 velAfterSetter = entity.getDeltaMovement();
            double posYAfter = entity.getY();

            /* 方向变化时记录位置与速度的前后值（不受 trace 开关限制）。
             * 用来确认 Pondus 的换向流程有没有做位置校正（setPos 不受碰撞与
             * 插值约束，视觉上就是瞬移）。实测 dY 一直是 0，说明它没有。 */
            if (!entity.level().isClientSide()) {
                double dy = posYAfter - posYBefore;
                MirrorGravity.LOGGER.info(
                    "[镜维度·换向] {} {}->{} setter={} dY={} vel {}({}) -> ({}), pos {} -> {}",
                    entity.getType(), oldDir.getName(), dir.getName(), usedSetter,
                    Math.round(dy * 1000) / 1000.0D,
                    r(velBefore.y), dir.getName(),
                    r(velAfterSetter.y),
                    Math.round(posYBefore * 100) / 100.0D,
                    Math.round(posYAfter * 100) / 100.0D);
            }

            Direction after = readDirection(entity);
            if (after != dir) {
                /* 兜底：setter 没能写进去（白名单拦下或反射失败）。
                 * 只可能在 changed 时走到这里 —— 没变的情况已在上面提前返回，
                 * 否则这里会每 tick 置一次 needsSync，造成每帧方向同步风暴。 */
                baseDirectionField.set(data, dir);
                if (syncToClient && needsSyncField != null) {
                    needsSyncField.setBoolean(data, true);
                }
            }

            /* 对不调用 super.tick() 的实体（FallingBlockEntity）直接写 curr ——
             * 它们的 commonTick() 永不执行，curr 不会从 base 同步。 */
            if (!callsSuperTick(entity) && currDirectionField != null) {
                currDirectionField.set(data, dir);
            }

            LAST_DIRECTION.put(entity.getUUID(), dir);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /* ------------------------------------------------------------------ */
    /* 速度换算：已移除，交给 Pondus                                        */
    /* ------------------------------------------------------------------ */
    /* 本模组曾经自己写过一个 rotateVelocity()（保持世界速度不变地换算本地速度）。
     * **它已被删除**，原因是与 Pondus 重复：
     *
     *   Pondus 的 EntityGravityData.applyGravityDirectionChange() 本来就会做
     *   "旋转速度 + 校正位置"这一整套，而且更完整。它唯一的门槛是开头的
     *   if (!canChangeGravity()) return;
     *
     *   而 canChangeGravity 依赖 pondus:allowed_special 标签 ——
     *   该标签在 Pondus 的 jar 里**放错了目录**
     *   （用了复数的 tags/entity_types/，1.21 要求单数 tags/entity_type/）。
     *   我们用 KubeJS 的 data/ 补了一份正确路径的标签后，
     *   Pondus 自己就能正确处理非生物实体。
     *
     *   如果这里**也**旋转一次速度，就会和 Pondus 互相抵消 ——
     *   表现为方向对了但实体动不起来。实测踩过，不要加回来。
     *
     * 本模组现在只做两件事：
     *   1) 绕过白名单写入方向字段（在标签修复前是必需的；修复后作为兜底）
     *   2) 补上"反方向飞行时的着陆判定"（见 LandingFix）
     */

    /* ------------------------------------------------------------------ */
    /* 判断实体是否会走到 Pondus 的 commonTick()                             */
    /* ------------------------------------------------------------------ */
    /* Pondus 把 commonTick() 注入在 Entity.tick() 的 RETURN 上。
     * 只要某个类重写了 tick() 又**不调用 super.tick()**，那条注入就永不触发，
     * 它的 currGravityDirection 也就永远不会更新。
     *
     * 已知：
     *   · ItemEntity        → 调用了 super.tick()  → normal
     *   · FallingBlockEntity→ **没有**             → 必须我们手动维护
     *
     * 这里用"类名里是否含 FallingBlock"做判断，而不是反射调方法 ——
     * 简单、无副作用，而且这类实体本来就很少。 */
    private static boolean callsSuperTick(Entity entity) {
        String n = entity.getClass().getName();
        return !n.contains("FallingBlockEntity");
    }

    /* ------------------------------------------------------------------ */
    /* 速度换算：已彻底移除，一律交给 Pondus                                  */
    /* ------------------------------------------------------------------ */
    /* 本模组曾经自己写过 rotateVelocity()，**已删除且不要恢复**。
     *
     * 原因：Pondus 的 setBaseGravityDirection() 内部已经调用
     *   EntityGravityData.applyGravityDirectionChange()
     * 那里面就包含"旋转速度 + 校正位置"这一整套。我们再转一次等于转两遍，
     * 两次互为逆变换 → **水平速度被还原、抛物线被破坏**。
     *
     * 实测现象（用户报告）：在下界面丢出物品时，它不做抛物线飞出去，
     * 而是只有垂直方向的重力反转、最后落回脚下。
     * 那正是"双重旋转抵消"的结果。
     *
     * 结论：速度与位置一律由 Pondus 处理，本类只负责"把方向写进去"。
     */

    /* ------------------------------------------------------------------ */
    /* 限速：已移到 LandingFix.tick()（实体 tick 之后执行）                    */
    /* ------------------------------------------------------------------ */
    /* 曾经把 limitSpeed 放在这里（applyDirection 内）。**那样不生效**，因为：
     *   · applyDirection 由 KubeJS 调用，时机在实体 tick **之前**
     *   · 之后实体自己还会 applyGravity() + move()，速度继续变化
     *   · 实测：上限设 0.473，轨迹里却测到 0.503（172 条中有 62 条超标）
     *
     * 现在限速在 EntityTickEvent.Post → LandingFix.tick() 里做，
     * 那是实体 tick **之后**，才是最终生效的速度。 */

    /* 反向阻尼已移到 BlockPhysics —— 那里才是真正接管这些实体物理的地方。
     * 本类现在只负责"把方向写进 Pondus"，不再碰任何速度。 */

    private static String fmt(Vec3 v) {
        return "(" + r(v.x) + "," + r(v.y) + "," + r(v.z) + ")";
    }

    private static double r(double d) {
        return Math.round(d * 1000) / 1000.0D;
    }

    /** 实体短标识：UUID 前 8 位。多实体混在一起时用来区分谁是谁。 */
    private static String tag(Entity entity) {
        return entity.getUUID().toString().substring(0, 8);
    }

    /* ------------------------------------------------------------------ */
    /* 逐 tick 轨迹记录（限时，用于定位"抽搐/传送"）                          */
    /* ------------------------------------------------------------------ */
    /* 开启：游戏里执行 /mirror trace on
     * 关闭：/mirror trace off
     * **只在服务端记录** —— 客户端状态本就不可信，两边都记会互相干扰。 */

    private static volatile boolean traceOn = false;
    private static final Map<UUID, Integer> TRACE_COUNT = new ConcurrentHashMap<>();
    private static final int TRACE_MAX_PER_ENTITY = 200;

    public static void setTrace(boolean on) {
        traceOn = on;
        if (on) {
            TRACE_COUNT.clear();
            MirrorGravity.LOGGER.info("[镜维度·轨迹] 记录已开启（每个实体最多 {} 条）", TRACE_MAX_PER_ENTITY);
        } else {
            MirrorGravity.LOGGER.info("[镜维度·轨迹] 记录已关闭");
        }
    }

    public static boolean isTraceOn() {
        return traceOn;
    }

    /** 每 tick 调用一次，记录被接管实体的状态（仅服务端）。
     *
     * 记录内容刻意做成"能直接看出抽搐来源"：
     *   · y / vy / vx / vz   —— 位置与速度；y 出现大跳 = 被瞬移
     *   · dY                 —— 相对上一 tick 的位移增量
     *   · dir                —— 模组认为的方向
     *   · pondusDir          —— Pondus 里实际记着的 curr 方向（两者不一致就是问题）
     *   · capped             —— 本 tick 是否被限速
     * 采样：每次方向变化都记，另外每 5 tick 记一条。 */
    private static final Map<UUID, Double> TRACE_LAST_Y = new ConcurrentHashMap<>();

    public static void traceTick(Entity entity) {
        if (!traceOn || entity == null) {
            return;
        }
        /* 门槛用"正在重点观察"或"模组已接管"，**不要**用 trackedDirection 的返回值：
         * 修掉"方向没变也下发"之后，applyDirection 会在方向未变时提前返回，
         * 若这里依赖它就会把绝大多数帧都过滤掉，等于没测。 */
        UUID id = entity.getUUID();
        Direction dir = MirrorGravityApi.trackedDirection(entity);
        if (dir == null) {
            dir = readDirection(entity);
        }
        if (dir == null && !WATCH.containsKey(id)) {
            return;
        }
        int n = TRACE_COUNT.merge(id, 1, Integer::sum);
        if (n > TRACE_MAX_PER_ENTITY) {
            return;
        }
        /* ⚠️ 这里**只记服务端**。
         * 客户端有自己的本地预测，混在一起只会互相污染；
         * 客户端的数据由 traceClientItem() 单独记录，两者再用 y 对比。 */
        if (entity.level().isClientSide()) {
            return;
        }

        double y = entity.getY();
        Double prevY = TRACE_LAST_Y.put(id, y);
        double dy = prevY == null ? 0.0D : y - prevY;

        Vec3 v = entity.getDeltaMovement();
        Direction pDir = readDirection(entity);

        /* 服务端大跳 = 权威位置被瞬移，直接打出来。
         * 之前没有这条检测，导致"服务端 dY 全 0"的结论其实只是
         * 没去测 —— 方向变化那几帧之外根本没有采样点。 */
        boolean bigJump = Math.abs(dy) > 0.6D;
        if (!bigJump && n % 5 != 0) {
            return;
        }
        /* 大跳时把"最近的玩家 y"一起打出来。
         * 用户描述是"物品回到我脚下" —— 若物品的 y 恰好等于玩家脚部 y，
         * 说明有东西在把物品对齐到玩家；若只是撞到玻璃，则两者无关。
         * 这一条能把"几何停靠"和"往玩家身上贴"彻底区分开。 */
        String nearPlayer = "";
        if (bigJump) {
            nearPlayer = nearestPlayerY(entity);
        }
        MirrorGravity.LOGGER.info(
            "[镜维度·服务端]{} n={} {} y={} dY={} vy={} vx={} vz={} dir={} pondus={} onGround={}{}",
            bigJump ? "·跳变" : "",
            n, entity.getType(),
            Math.round(y * 1000) / 1000.0D,
            r(dy), r(v.y), r(v.x), r(v.z),
            dir.getName(),
            pDir == null ? "?" : pDir.getName(),
            entity.onGround(),
            nearPlayer);
    }

    /** 最近玩家的脚部 y（找不到返回空串）。用于判断"是否在往玩家身上贴"。 */
    private static String nearestPlayerY(Entity entity) {
        try {
            net.minecraft.server.level.ServerLevel level =
                (net.minecraft.server.level.ServerLevel) entity.level();
            net.minecraft.server.level.ServerPlayer best = null;
            double bestD = Double.MAX_VALUE;
            for (net.minecraft.server.level.ServerPlayer p : level.players()) {
                double d = p.distanceToSqr(entity);
                if (d < bestD) {
                    bestD = d;
                    best = p;
                }
            }
            if (best == null) {
                return "";
            }
            return String.format(" 最近玩家 y=%s 距=%s",
                r(best.getY()), r(Math.sqrt(bestD)));
        } catch (Throwable t) {
            return "";
        }
    }

    /** 记录一次"物品被拾取/移除"。用来区分"被拾取"与"被挪动"。 */
    public static void traceItemEvent(String what, Entity entity) {        if (!traceOn || entity == null) {
            return;
        }
        MirrorGravity.LOGGER.info("[镜维度·物品事件] {} {} 于 ({}, {}, {})",
            what, entity.getType(),
            r(entity.getX()), r(entity.getY()), r(entity.getZ()));
    }

    /**
     * 记录实体**生成瞬间**的速度。
     *
     * 为什么需要：实测发现服务端物品的 vx/vz 在第一条轨迹时已经是 0，
     * 而客户端仍保留水平速度。必须在生成的那一刻取一次速度，
     * 才能判断水平初速是"生成时就没有"还是"随后被某个环节清掉"。
     */
    public static void traceSpawnVelocity(Entity entity) {
        if (!traceOn || entity == null) {
            return;
        }
        String side = entity.level().isClientSide() ? "CLIENT" : "SERVER";
        Vec3 v = entity.getDeltaMovement();
        MirrorGravity.LOGGER.info("[镜维度·生成速度] [{}] {} ({}, {}, {}) vel=({}, {}, {})",
            side, entity.getType(),
            r(entity.getX()), r(entity.getY()), r(entity.getZ()),
            r(v.x), r(v.y), r(v.z));

        /* 服务端：把"玩家视线方向"与"实际抛出方向"放在一起比较。
         *
         * 用户报告"丢出去的方向和准心对不上"。要判断是参考系问题还是别的，
         * 必须同时知道两件事：
         *   · 玩家看向哪（世界坐标的视线向量）
         *   · 物品实际被赋予了哪个速度
         * 两者水平分量的夹角就是要找的偏差。 */
        if (!entity.level().isClientSide()) {
            logThrowVsLook(entity, v);
        }

        /* 两端都登记逐帧观察。
         * 实测发现服务端物品的速度是 0、客户端却是 0.25 —— 要定位差异，
         * 必须两端都有同一套逐帧数据，否则只能看到一半。 */
        WATCH.put(entity.getUUID(), 40);
    }

    /**
     * 比较"玩家视线方向"与"物品初速方向"。
     *
     * <p>水平面上用 atan2(z, x) 求两个向量的方位角，差值即偏差角。
     * 偏差为 0 说明方向一致；接近 ±90° 说明参考系被旋转了 90°；
     * 接近 180° 说明被镜像/反向。
     */
    private static void logThrowVsLook(Entity entity, Vec3 throwVel) {
        try {
            net.minecraft.server.level.ServerLevel level =
                (net.minecraft.server.level.ServerLevel) entity.level();
            net.minecraft.server.level.ServerPlayer best = null;
            double bestD = Double.MAX_VALUE;
            for (net.minecraft.server.level.ServerPlayer p : level.players()) {
                double d = p.distanceToSqr(entity);
                if (d < bestD) {
                    bestD = d;
                    best = p;
                }
            }
            if (best == null || bestD > 64.0D) {
                return;
            }
            Vec3 look = best.getLookAngle();
            double lookDeg = Math.toDegrees(Math.atan2(look.z, look.x));
            double throwDeg = Math.toDegrees(Math.atan2(throwVel.z, throwVel.x));
            double diff = throwDeg - lookDeg;
            while (diff > 180.0D) {
                diff -= 360.0D;
            }
            while (diff < -180.0D) {
                diff += 360.0D;
            }
            MirrorGravity.LOGGER.info(
                "[镜维度·准心对比] [{}] 视线=({}, {}, {}) 方位={}° | 初速=({}, {}, {}) 方位={}° | 偏差={}°{}",
                tag(entity),
                r(look.x), r(look.y), r(look.z), Math.round(lookDeg),
                r(throwVel.x), r(throwVel.y), r(throwVel.z), Math.round(throwDeg),
                Math.round(diff),
                Math.abs(diff) < 15.0D ? "" : "  ← 方向不一致");
        } catch (Throwable t) {
            MirrorGravity.LOGGER.debug("[镜维度·准心对比] 失败: {}", t.toString());
        }
    }

    /** entityUUID -> 还剩多少 tick 需要逐帧观察 */
    private static final Map<UUID, Integer> WATCH = new ConcurrentHashMap<>();

    /** 逐帧观察用的 tick 前快照：UUID -> [velX, velY, velZ, posY] */
    private static final Map<UUID, double[]> PRE_SNAP = new ConcurrentHashMap<>();

    private static final int WATCH_LOG_MAX = 200;

    /**
     * 实体 tick **之前**采样（仅服务端、仅被逐帧观察的实体）。
     *
     * <p>与 {@link #traceWatchTick}（tick 之后）配对使用，格式刻意做成
     * 一行读完即可定位"速度在哪一步消失"。
     */
    public static void tracePreTick(Entity entity) {
        if (entity == null || entity.level().isClientSide()) {
            return;
        }
        UUID id = entity.getUUID();
        if (!WATCH.containsKey(id)) {
            return;
        }
        Vec3 v = entity.getDeltaMovement();
        PRE_SNAP.put(id, new double[] { v.x, v.y, v.z, entity.getY() });

        int n = WATCH_LOG_COUNT.merge(id, 1, Integer::sum);
        if (n > WATCH_LOG_MAX) {
            return;
        }
        MirrorGravity.LOGGER.info(
            "[镜维度·tick前] [{}] {} n={} y={} vel=({}, {}, {}) dir={}{}",
            tag(entity), entity.getType(), n,
            r(entity.getY()), r(v.x), r(v.y), r(v.z),
            dirNameOf(entity), itemOwnerInfo(entity));
    }

    /** entityUUID -> 已经打了多少条逐帧日志（与 WATCH 的剩余计数分开，互不干扰） */
    private static final Map<UUID, Integer> WATCH_LOG_COUNT = new ConcurrentHashMap<>();

    /**
     * 物品的"归属与距离"信息。
     *
     * <p>用来一刀切开两种完全不同的现象：
     * <ul>
     *   <li>物品 y 正好等于玩家 y → 有代码在把它对齐到玩家身上</li>
     *   <li>物品离玩家很近且主人是玩家 → 只是走到物品上把它捡了</li>
     * </ul>
     * 用户描述是"丢出去然后传送回脚下"，这两种原因修法完全不同。
     */
    private static String itemOwnerInfo(Entity entity) {
        try {
            if (!(entity instanceof net.minecraft.world.entity.item.ItemEntity item)) {
                return "";
            }
            net.minecraft.server.level.ServerLevel level =
                (net.minecraft.server.level.ServerLevel) entity.level();
            net.minecraft.server.level.ServerPlayer best = null;
            double bestD = Double.MAX_VALUE;
            for (net.minecraft.server.level.ServerPlayer p : level.players()) {
                double d = p.distanceToSqr(entity);
                if (d < bestD) {
                    bestD = d;
                    best = p;
                }
            }
            /* 只在**被限制拾取**时读 target（字段是 private，用公开访问器）。
             * 记录它的意义：若物品只能被某人拾取，说明它刚被丢出不久。 */
            String owner;
            try {
                owner = String.valueOf(item.getOwner());
            } catch (Throwable ignored) {
                owner = "?";
            }
            String throwerTag = item.getPersistentData().contains("Thrower")
                ? item.getPersistentData().getUUID("Thrower").toString().substring(0, 8) : "-";
            String near = best == null ? "无玩家"
                : String.format("玩家y=%s 距=%s", r(best.getY()), r(Math.sqrt(bestD)));
            return String.format(" owner=%s thrower=%s %s", owner, throwerTag, near);
        } catch (Throwable t) {
            return "";
        }
    }

    private static String dirNameOf(Entity entity) {
        Direction d = readDirection(entity);
        return d == null ? "?" : d.getName();
    }

    /**
     * 下落方块的**自动**轨迹记录（不需要手动开 trace）。
     *
     * 为什么：排查"抽搐"必须拿到逐 tick 数据，但每次都要求用户
     * 手动执行 /mirror trace on 太容易漏。这里对下落的方块自动记录
     * **每个实体前 60 tick**（足以覆盖一个完整往复），不会刷屏。
     */
    private static final Map<UUID, Integer> AUTO_WATCH = new ConcurrentHashMap<>();
    private static final int AUTO_WATCH_TICKS = 60;

    /** 登记一个需要自动观察的实体（下落的方块）。 */
    public static void autoWatch(Entity entity) {
        if (entity == null || entity.level().isClientSide()) {
            return;
        }
        AUTO_WATCH.putIfAbsent(entity.getUUID(), AUTO_WATCH_TICKS);
    }

    public static void traceAutoTick(Entity entity) {
        if (entity == null || entity.level().isClientSide()) {
            return;
        }
        UUID id = entity.getUUID();
        Integer left = AUTO_WATCH.get(id);
        if (left == null) {
            return;
        }
        if (left <= 0) {
            AUTO_WATCH.remove(id);
            return;
        }
        AUTO_WATCH.put(id, left - 1);

        Vec3 v = entity.getDeltaMovement();
        Direction pDir = readDirection(entity);
        MirrorGravity.LOGGER.info(
            "[镜维度·自动轨迹] remain={} {} y={} vy={} vx={} vz={} pondus={}",
            left, entity.getType(),
            Math.round(entity.getY() * 1000) / 1000.0D,
            r(v.y), r(v.x), r(v.z),
            pDir == null ? "?" : pDir.getName());
    }

    /** 读回当前生效的 rotateVelocity 与位置校正开关，供诊断。 */
    public static String describeConfig() {
        StringBuilder sb = new StringBuilder();
        sb.append(describeRotationDefaults());
        try {
            Class<?> c = Class.forName("dinner.dev.pondus.Pondus");
            java.lang.reflect.Field f = c.getField("config");
            Object cfg = f.get(null);
            if (cfg != null) {
                java.lang.reflect.Field ap = cfg.getClass()
                    .getField("adjustPositionAfterChangingGravity");
                sb.append(" adjustPosition=").append(ap.get(cfg));
            }
        } catch (Throwable t) {
            sb.append(" adjustPosition=?");
        }
        return sb.toString();
    }

    /* ------------------------------------------------------------------ */
    /* 客户端侧的逐 tick 记录（排查"传送"是否来自两端不同步）                  */
    /* ------------------------------------------------------------------ */
    /* 实测确认服务端 dY=0（Pondus 没有做位置校正），所以"传送"只能来自客户端。
     * 这份记录只在客户端打，用来与服务端轨迹逐 tick 对照：
     *   · 两端 y 差越大 → 越可能是同步/预测问题
     *   · 客户端 y 出现大跳 → 它按自己的预测走，随后被服务端拉回 */

    private static final Map<UUID, Integer> CLIENT_TRACE = new ConcurrentHashMap<>();
    private static final int CLIENT_TRACE_MAX = 80;

    /** 客户端侧：记录每个被追踪实体的上一 tick 位置，用来发现"位置跳变" */
    private static final Map<UUID, Double> CLIENT_LAST_Y = new ConcurrentHashMap<>();

    public static void traceClientItem(Entity entity) {
        if (entity == null || !entity.level().isClientSide()) {
            return;
        }
        UUID id = entity.getUUID();
        double y = entity.getY();

        /* 每次都算 Δy（不受采样间隔影响）——"传送"就是相邻 tick 的 Δy 异常大。
         * 采样只在每 5 tick 打一条，但 Δy 是逐 tick 累积的，
         * 所以只要出现大跳就一定会被打印出来。 */
        Double prev = CLIENT_LAST_Y.put(id, y);
        double dy = prev == null ? 0.0D : y - prev;

        int n = CLIENT_TRACE.merge(id, 1, Integer::sum);
        if (n > CLIENT_TRACE_MAX) {
            return;
        }
        // 逐 tick 都检查大跳；正常情况下每 5 tick 打一条
        boolean bigJump = Math.abs(dy) > 0.6D;
        if (!bigJump && n % 5 != 0) {
            return;
        }
        Vec3 v = entity.getDeltaMovement();
        Direction d = readDirection(entity);
        MirrorGravity.LOGGER.info(
            "[镜维度·客户端]{} n={} {} y={} dY={} vy={} dir={}",
            bigJump ? "·跳变" : "",
            n, entity.getType(),
            Math.round(y * 1000) / 1000.0D,
            r(dy), r(v.y), d == null ? "?" : d.getName());
    }

    /**
     * 生成后前若干 tick 的逐帧速度记录。
     *
     * 目的：定位"水平速度在哪一帧被清零"。
     * 如果清零发生在**方向第一次写入的那一帧**，说明是 Pondus 的
     * applyGravityDirectionChange（旋转速度）造成的；
     * 如果生成第一帧就已经是 0，说明初速根本没传过来。
     */
    public static void traceWatchTick(Entity entity) {
        if (entity == null) {
            return;
        }
        UUID id = entity.getUUID();
        Integer left = WATCH.get(id);
        if (left == null) {
            return;
        }
        if (left <= 0) {
            WATCH.remove(id);
            return;
        }
        WATCH.put(id, left - 1);

        Vec3 v = entity.getDeltaMovement();
        Direction pDir = readDirection(entity);
        /* 与 tick 前的快照拼成一行：before -> after。
         * 服务端速度归零发生在 tick 内还是 tick 外，看这一行就够了。 */
        double[] pre = PRE_SNAP.get(id);
        String cmp = pre == null ? ""
            : String.format(" | tick前 vel=(%s, %s, %s) y=%s",
                r4(pre[0]), r4(pre[1]), r4(pre[2]), r4(pre[3]));
        MirrorGravity.LOGGER.info(
            "[镜维度·逐帧] [{}] {} remain={} {} y={} vel=({}, {}, {}) pondus={}{}{}",
            entity.level().isClientSide() ? "C" : "S",
            tag(entity), left, entity.getType(),
            r4(entity.getY()),
            r4(v.x), r4(v.y), r4(v.z),
            pDir == null ? "?" : pDir.getName(),
            cmp,
            /* ⚠️ 关键对比：位置是**增加**还是**减少**。
             * 实测出现过"y 上升但 vy 为负"的组合 —— 那是位置被直接写入
             * （而不是靠速度积分）才会有的现象，必须单独标出来。 */
            pre == null ? "" : (entity.getY() > pre[3] ? " ⬆上升" : ""));
    }

    /* ------------------------------------------------------------------ */
    /* 位置校正：已废弃（保留说明，不要重新加回来）                            */
    /* ------------------------------------------------------------------ */
    /* 曾经有一个 nudgeOutOfBlocks()：换方向后如果实体与方块重叠，
     * 就沿着新重力方向的反方向把它推开最多 1 格。
     *
     * **它已被删除**，因为它是"抽搐 / 传送感"的直接来源：
     *   · entity.setPos() 绕过碰撞检测与插值，直接改坐标 → 视觉上就是瞬移
     *   · 实体贴着地面/玻璃时，包围盒与方块的"重叠"判定非常容易成立，
     *     于是它几乎每 tick 都在微调位置 → 抽搐
     *   · 它还在客户端也跑了一遍，与服务端权威位置互相推翻
     *     （日志里两个线程的 y 差了 1 格以上）
     *
     * 现在换方向只做一件事：换算速度（rotateVelocity），且只在服务端做。
     * 位置交给原版的 move() / 碰撞系统处理 —— 那才是"平滑"的来源。 */

    /**
     * 设置重力强度倍数。
     *
     * Pondus 在 {@code EntityMixin.injected} 里做
     * {@code getGravity() * getGravityStrength()}，
     * 所以改这个字段就能直接改变实体受到的重力大小。
     * 用来让重力方块落得慢一些，避免下坠太快导致配方判定跳过交界处。
     *
     * @param scale 1.0 = 原版；0.5 = 一半；0 = 不受重力
     */
    public static boolean applyGravityScale(Entity entity, double scale) {
        if (!resolve() || entity == null || baseStrengthField == null) {
            return false;
        }
        try {
            Object data = getGravityDataMethod.invoke(null, entity);
            if (data == null) {
                return false;
            }
            baseStrengthField.set(data, scale);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 实体消失后清掉记录。 */
    public static void forget(UUID id) {
        LAST_DIRECTION.remove(id);
        SAVED_HORIZONTAL.remove(id);
    }

    /* ------------------------------------------------------------------ */
    /* 换向时被 Pondus 清零的水平速度：存档 + 补回                            */
    /* ------------------------------------------------------------------ */
    /* Pondus 的 applyGravityDirectionChange 在服务端会算出 (0,0,0) 的"换向前
     * 世界速度"（原因见 applyDirection 里的注释），于是把实体的速度整体清零。
     * 垂直分量随后会被重力重新建立，但**水平分量再也回不来了** ——
     * 表现为掉落物失去抛物线、原地升起、停在玩家脚下。
     *
     * 换向发生在实体 tick 内部，而移动已经用换向前的速度跑完了，
     * 所以在此处把水平分量补回是安全的：它恢复的正是本该保留的那部分动量。 */

    private static final Map<UUID, Vec3> SAVED_HORIZONTAL = new ConcurrentHashMap<>();

    /**
     * 实体 tick **之后**调用：如果换向把水平速度清成了 0，就把它补回。
     *
     * <p>必须放在 tick 之后 —— 换向本身发生在 tick 内部，tick 之前补会被覆盖。
     */
    public static void restoreHorizontalIfLost(Entity entity) {
        if (entity == null || entity.level().isClientSide()) {
            return;
        }
        Vec3 saved = SAVED_HORIZONTAL.remove(entity.getUUID());
        if (saved == null) {
            return;
        }
        double savedH = Math.hypot(saved.x, saved.z);
        if (savedH < 1.0E-4D) {
            return;   // 换向前本来就没有水平速度，不必补
        }
        Vec3 now = entity.getDeltaMovement();
        double nowH = Math.hypot(now.x, now.z);
        if (nowH > savedH * 0.5D) {
            return;   // 没被清掉（或只轻微衰减），不要干预
        }
        /* 补回时必须**按新参考系**写回，而不是照抄换向前的值。
         *
         * Pondus 在 up/down 之间换向时用的变换是
         *     (x, y, z) -> (-x, -y, z)
         * 也就是 **X 取反、Y 取反、Z 不变**。
         *
         * 症状完全对应（用户实测）：
         *   朝北/朝南丢 → 正常   （只涉及 Z，变换下不变）
         *   朝东丢 → 飞到西边
         *   朝西丢 → 飞到东边   （X 被取反）
         *
         * 所以这里 X 要取反、Z 保持原值；Y 用 Pondus 算出来的（垂直方向
         * 归它管，我们不该覆盖）。 */
        double fixedX = -saved.x;
        double fixedZ = saved.z;
        Vec3 fixed = new Vec3(fixedX, now.y, fixedZ);
        entity.setDeltaMovement(fixed);

        /* ⚠️ 必须把修正后的速度**主动同步给客户端**。
         *
         * 为什么：服务端的 EntityTracker（ServerEntity.sendChanges）会在
         * 本 tick 稍后发出速度包，但那时 deltaMovement 已被 Pondus 旋转过 ——
         * 客户端拿到的是**旋转前**的值，于是它自己再旋转一次，
         * 结果与服务端符号相反。
         *
         * 实测（同一 tick）：
         *   服务端 vel=(-0.2896, -0.0078, 0.0208)
         *   客户端 vel=(+0.2837, +0.0545, 0.0203)   ← x/y 反号，即镜像
         * 客户端于是朝相反方向飞，视觉上就是"传送到别处"。
         *
         * 这里补发一个权威速度包，把修正值直接交给客户端。 */
        syncMotion(entity, fixed);

        MirrorGravity.LOGGER.info(
            "[镜维度·补回水平速度] [{}] {} 水平 {} -> {}（垂直保留 {}）",
            tag(entity), entity.getType(),
            Math.round(nowH * 10000) / 10000.0D,
            Math.round(savedH * 10000) / 10000.0D,
            Math.round(now.y * 10000) / 10000.0D);
    }

    /** 把实体的速度广播给追踪它的玩家（覆盖服务端先前发出的旋转前速度）。 */
    private static void syncMotion(Entity entity, Vec3 vel) {
        try {
            if (!(entity.level() instanceof net.minecraft.server.level.ServerLevel level)) {
                return;
            }
            var packet = new net.minecraft.network.protocol.game
                .ClientboundSetEntityMotionPacket(entity);
            for (net.minecraft.server.level.ServerPlayer p : level.players()) {
                if (p.distanceToSqr(entity) < 4096.0D) {
                    p.connection.send(packet);
                }
            }
        } catch (Throwable t) {
            MirrorGravity.LOGGER.debug("[镜维度·补回] 速度同步失败: {}", t.toString());
        }
    }

    /** 方向字段诊断：UUID -> 已打印次数 */
    private static final Map<UUID, Integer> FIELD_LOG = new ConcurrentHashMap<>();

    private static final int FIELD_LOG_MAX = 12;

    /**
     * 打印 Pondus 里三个方向字段的实际取值。
     *
     * <p>目的：{@code applyGravityChange()} 每 tick 都在旋转速度，说明
     * {@code prevGravityDirection != currGravityDirection} 每 tick 都成立。
     * 但按字段语义这是不可能的（换向末尾会 prev = curr）。所以要看真实值，
     * 判断到底是哪个字段在被悄悄改写。
     */
    private static void logDirectionFields(Entity entity, Object data, Direction want, Direction base) {
        UUID id = entity.getUUID();
        int n = FIELD_LOG.merge(id, 1, Integer::sum);
        if (n > FIELD_LOG_MAX) {
            return;
        }
        String prev = "<n/a>";
        String curr = "<n/a>";
        try {
            if (prevDirectionField != null) {
                Object v = prevDirectionField.get(data);
                prev = v instanceof Direction d ? d.getName() : String.valueOf(v);
            }
            if (currDirectionField != null) {
                Object v = currDirectionField.get(data);
                curr = v instanceof Direction d ? d.getName() : String.valueOf(v);
            }
        } catch (Throwable ignored) {
            // 读取失败就保持 <n/a>
        }
        MirrorGravity.LOGGER.info(
            "[镜维度·方向字段] [{}] n={} base={} prev={} curr={} 请求={} → prev!=curr ? {}",
            tag(entity), n,
            base == null ? "null" : base.getName(),
            prev, curr, want.getName(),
            prev.equals(curr) ? "否（不该换向）" : "是（会旋转速度）");
    }

    /**
     * 这个实体是不是"我们关心的"（KubeJS 刚给它推过方向，或正在逐帧观察）。
     *
     * <p>给 {@link SetVelocityProbe} 当过滤器用 —— 速度探针必须只盯这些实体，
     * 否则原版每 tick 给成千上万个实体写速度，日志会彻底淹没。
     */
    public static boolean isWatched(Entity entity) {
        if (entity == null) {
            return false;
        }
        UUID id = entity.getUUID();
        return WATCH.containsKey(id) || LAST_DIRECTION.containsKey(id);
    }

    /* ------------------------------------------------------------------ */
    /* 逐步包围：换向管线每一段的完整速度                                     */
    /* ------------------------------------------------------------------ */
    /* 背景：实测服务端掉落物的 vx/vz 在换向那一帧后被清成 0，而客户端没有，
     * 于是两端从第一帧就发散，表现为"丢出去又瞬移回脚下"。
     *
     * 换向管线只有三步：setter 前 → setter 后 → 强度写入后。
     * 这里逐步打**完整三分量**（旧日志只打了 Y，恰好漏掉了出问题的水平分量），
     * 哪一步 vx/vz 变 0，责任就在那一步。 */

    private static final Map<UUID, String> APPLY_STAGE = new ConcurrentHashMap<>();

    public static void traceApplySteps(Entity entity, String stage, Direction dir, boolean ok) {
        if (entity == null || entity.level().isClientSide()) {
            return;
        }
        if (!traceOn && !WATCH.containsKey(entity.getUUID())) {
            return;
        }
        Vec3 v = entity.getDeltaMovement();
        String prevStage = APPLY_STAGE.put(entity.getUUID(), stage);
        MirrorGravity.LOGGER.info(
            "[镜维度·换向步骤] [{}] {} {} ok={} dir={} vel4=({}, {}, {}) y4={} 上一步={}",
            tag(entity), entity.getType(), stage, ok,
            dir == null ? "?" : dir.getName(),
            r4(v.x), r4(v.y), r4(v.z), r4(entity.getY()),
            prevStage == null ? "-" : prevStage);
    }

    /** 四位小数。判断"是不是精确的 0"必须看这个精度。 */
    private static double r4(double d) {
        return Math.round(d * 10000) / 10000.0D;
    }

    /* ------------------------------------------------------------------ */
    /* 修复 Pondus 的"旋转参数默认值"不生效问题                              */
    /* ------------------------------------------------------------------ */
    /* ⚠️ 这是一个**上游 bug**，不是我们的用法问题。
     *
     * Pondus 的初始化链：
     *     PondusNeoForge.<init>() → Pondus.init()      // 注册配置、读文件
     *     configHolder.registerSaveListener(cfg -> updateDefault());  // 只在"保存配置"时刷新
     *
     * 而 RotationParameters 的默认值是**编译期写死**的：
     *     public static RotationParameters defaultParam =
     *         new RotationParameters(true, true, 500);
     *                              ^^^^ rotateVelocity = true
     *
     * **updateDefault() 在启动时从不被调用** —— 既不在 init() 里，
     * 也不在 FMLCommonSetupEvent 里。结果就是：
     *     · 无论 config/pondus.json 里 worldVelocity 改成什么，都没人读
     *     · 旋转速度永远是 true → 换重力时速度被强行旋转
     *       （Pondus 自己的注释也承认这"会让物体看起来急转弯"）
     *     · 表现：丢出去的物品水平速度被转没、只做垂直运动、
     *       客户端与服务端位置持续不一致 → 抽搐
     *
     * 这里由本模组主动调一次 updateDefault()，让配置真正生效。 */

    private static Method updateDefaultMethod;
    private static boolean updateDefaultResolved;
    private static boolean updateDefaultOk;

    /** 让 Pondus 的 RotationParameters 默认值从配置刷新一次。 */
    public static boolean refreshRotationDefaults() {
        if (!updateDefaultResolved) {
            updateDefaultResolved = true;
            try {
                Class<?> rp = Class.forName("dinner.dev.pondus.api.RotationParameters");
                updateDefaultMethod = rp.getMethod("updateDefault");
                updateDefaultOk = true;
            } catch (Throwable t) {
                updateDefaultOk = false;
                MirrorGravity.LOGGER.warn(
                    "[镜维度·重力] 无法刷新 Pondus 旋转参数（{}）；换重力时速度会被旋转。", t.toString());
            }
        }
        if (!updateDefaultOk) {
            return false;
        }
        try {
            updateDefaultMethod.invoke(null);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 读回当前生效的 rotateVelocity，供诊断确认修复是否成功。 */
    public static String describeRotationDefaults() {
        try {
            Class<?> rp = Class.forName("dinner.dev.pondus.api.RotationParameters");
            Method getDefault = rp.getMethod("getDefault");
            Object def = getDefault.invoke(null);
            Method rv = rp.getMethod("rotateVelocity");
            Method rt = rp.getMethod("rotationTimeMS");
            return "rotateVelocity=" + rv.invoke(def) + " rotationTimeMS=" + rt.invoke(def);
        } catch (Throwable t) {
            return "读取失败: " + t;
        }
    }
}
