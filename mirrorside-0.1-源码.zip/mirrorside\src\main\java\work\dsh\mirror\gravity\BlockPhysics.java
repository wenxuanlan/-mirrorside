package work.dsh.mirror.gravity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 下落的方块 / 掉落物的重力往复物理。
 *
 * <h2>核心原则：一律在世界坐标里思考</h2>
 * 这是踩了非常多坑之后才理清的一条铁律。
 *
 * <p>实体的 {@code deltaMovement} 存的是**本地坐标**（Pondus 约定：
 * 本地 -Y 永远是实体的"下"），而 {@code Entity.move()} 会按重力方向
 * 把它换算到世界坐标。所以如果我直接往 {@code deltaMovement} 上加
 * "向上的加速度"，在方向为 UP 时它会变成世界**向下** ——
 * 实测数据就是：
 * <pre>
 *   dir=up  netAccel=+0.04（本地向上）  但世界坐标 y 在下降
 * </pre>
 *
 * <p>因此本类的做法是：
 * <ol>
 *   <li>把本地速度换算成世界速度</li>
 *   <li>在**世界坐标**里做全部物理（加速度、阻尼、限速、落地判断）</li>
 *   <li>再换算回本地坐标写回</li>
 * </ol>
 * 这样系统对方向完全不敏感，永远不会出现"方向一反、运动就错"。
 *
 * <h2>方向只负责两件事</h2>
 * 物理不再依赖方向，但方向仍然要写对，因为：
 * <ul>
 *   <li>Pondus 的 {@code move()} 靠它做本地→世界换算（我们要与之一致）</li>
 *   <li>Pondus 的渲染 mixin 靠它决定**实体动画的朝向**</li>
 * </ul>
 *
 * <h2>只在服务端施力</h2>
 * 客户端只接收同步。两端同时演算必然发散（实测 y 差过 1 格）。
 */
public final class BlockPhysics {

    private static final Map<UUID, Integer> STILL_TICKS = new ConcurrentHashMap<>();
    private static final Map<UUID, Double> LAST_Y = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> PHYS_TRACE = new ConcurrentHashMap<>();
    /** entityUUID -> 当前所处的半区（带迟滞，避免在分界线上反复翻向） */
    private static final Map<UUID, Boolean> HALF = new ConcurrentHashMap<>();

    private static final double STILL_EPS = 0.002D;
    private static final int STILL_NEEDED = 3;

    private static final boolean TRACE_PHYSICS = true;
    private static final int PHYS_TRACE_MAX = 40;

    /**
     * 方向迟滞带半径（格）。
     *
     * <p>⚠️ 为什么必须有它：没有迟滞时，实体在分界线上下一微抖就翻向，
     * 表现为"在交界处快速抽搐"（用户报告）。带内维持原方向，
     * 于是重力成为**恢复力**，实体被推向带中心并稳定下来。
     *
     * <p>数值要与沙砾的往复幅度相称：太小挡不住抖动，
     * 太大则两个反转点靠得太近、看不出往复。
     */
    private static final double DIR_HYSTERESIS = 0.75D;

    private BlockPhysics() {
    }

    /**
     * 每 tick 调用一次。
     *
     * @param entity 目标实体（下落的方块 / 掉落物）
     * @param splitY 重力分界：y > splitY 朝下，y <= splitY 朝上
     */
    public static void tick(Entity entity, double splitY) {
        try {
            if (entity == null) {
                return;
            }
            boolean client = entity.level().isClientSide();
            UUID id = entity.getUUID();

            // 尽力关掉 Pondus 的原版重力（若不生效，下面会在世界坐标里抵消）
            PondusBridge.applyGravityScale(entity, 0.0D);

            /* 当前半区：带迟滞。
             * 一旦离开分界超过 DIR_HYSTERESIS 才切换，避免线上抖动。 */
            boolean above = HALF.computeIfAbsent(id, k -> entity.getY() > splitY);
            if (above && entity.getY() < splitY - DIR_HYSTERESIS) {
                above = false;
                HALF.put(id, false);
            } else if (!above && entity.getY() > splitY + DIR_HYSTERESIS) {
                above = true;
                HALF.put(id, true);
            }

            /* ⚠️⚠️ 正常重力（above）时，模组**完全不碰这个实体**。
             *
             * 为什么：用户报告"沙砾在上界面正常下落时会有传送样式的回弹"。
             * 那正是这里引起的 —— 我为了沙砾的往复物理，在**上侧也在改它的
             * 速度**（加速度 / 阻尼 / 速度上限），把原版平滑的下落搞出了
             * 台阶感。
             *
             * 正常下落本来就该由原版处理（原版自己会把方块放回世界），
             * 模组只在**反重力**这一原版覆盖不到的场景介入。
             * 这样上侧行为与"没有本模组"时完全一致。 */
            if (above) {
                if (client) {
                    PondusBridge.applyDirection(entity, Direction.DOWN, true);
                } else {
                    // 服务端也把方向写回 DOWN（若有残留），但不动速度
                    PondusBridge.applyDirection(entity, Direction.DOWN, true);
                    STILL_TICKS.remove(id);
                }
                return;
            }

            /* 方向 = 真实的重力方向（此处必为 UP）。
             * 它决定 Pondus 的坐标换算基准，也决定渲染动画的朝向。 */
            Direction dir = Direction.UP;
            PondusBridge.applyDirection(entity, dir, true);

            if (client) {
                return;   // 客户端只设方向（供渲染），物理由服务端同步
            }

            /* ---- 1) 本地 -> 世界 ---- */
            Vec3 world = MirrorDir.localToWorld(entity.getDeltaMovement(), dir);

            /* ---- 2) 世界坐标里做物理 ---- */
            double g = MirrorGravityConfig.accelFor(entity);

            // 抵消原版重力（作用在世界 -Y）：实测 applyGravityScale(0)
            // 不生效、getGravity() 仍是 0.04，所以直接减掉，再叠加目标方向量。
            double vanillaGravity = entity.getGravity();
            double desired = g;          // 反重力：世界向上
            double accelY = -vanillaGravity + desired;

            world = world.add(0.0D, accelY, 0.0D);

            // 阻尼 + 兜底上限（只用于沙砾的反重力往复）
            world = world.scale(MirrorGravityConfig.REBOUND_DAMPING_PER_TICK);
            double max = MirrorGravityConfig.REBOUND_MAX_SPEED;
            if (max > 0.0D && world.length() > max) {
                world = world.scale(max / world.length());
            }

            if (TRACE_PHYSICS) {
                int tn = PHYS_TRACE.merge(id, 1, Integer::sum);
                if (tn <= PHYS_TRACE_MAX) {
                    MirrorGravity.LOGGER.info(
                        "[镜维度·物理] n={} y={} half={} dir={} worldVy={} accelY={} vanillaG={}",
                        tn,
                        Math.round(entity.getY() * 1000) / 1000.0D,
                        above ? "above" : "below", dir.getName(),
                        r4(world.y), r4(accelY), r4(vanillaGravity));
                }
            }

            /* ---- 3) 世界 -> 本地，写回 ---- */
            entity.setDeltaMovement(MirrorDir.worldToLocal(world, dir));

            /* 着陆补丁：只有反重力（朝上飞）时才需要 ——
             * 那种情况下原版的 onGround() 永远为 false，方块放不回去，
             * 最终会走 spawnAtLocation 变成掉落物。
             * 正常下落一律交给原版（本节开头 already returned）。 */
            if (entity instanceof FallingBlockEntity fb) {
                handleLanding(fb, false);
            }
        } catch (Throwable t) {
            // 物理接管失败不影响其它逻辑
        }
    }

    /**
     * 着陆判定：真正停住且前方有方块时，把方块放回世界。
     *
     * <p>原版 {@code onGround()} 只查**脚下方块**，重力反转后实体朝上飞时
     * 脚下是空的 → 永远不会"落地" → 等 {@code time > 600} 后
     * {@code spawnAtLocation} 掉成物品。用户明确要求
     * "落在玻璃上应该变成方块，而不是掉落物"，所以这里自己判定。
     */
    private static void handleLanding(FallingBlockEntity fb, boolean above) {
        UUID id = fb.getUUID();
        double y = fb.getY();
        Double prev = LAST_Y.put(id, y);
        boolean still = prev != null && Math.abs(y - prev) < STILL_EPS;
        int n = still ? STILL_TICKS.merge(id, 1, Integer::sum) : 0;
        if (!still) {
            STILL_TICKS.put(id, 0);
        }
        if (n < STILL_NEEDED) {
            return;   // 还在动
        }

        BlockPos here = fb.blockPosition();
        BlockPos ground = above ? here.below() : here.above();
        if (fb.level().noCollision(fb, new AABB(ground))) {
            return;   // 前方是空的，只是暂时停住
        }

        place(fb, here);
    }

    /** 把方块放回世界；放不下也只丢弃，**绝不生成掉落物**。 */
    private static void place(FallingBlockEntity fb, BlockPos pos) {
        try {
            BlockState state = fb.getBlockState();
            if (!state.isAir() && fb.level().getBlockState(pos).canBeReplaced()) {
                fb.level().setBlock(pos, state, 3);
                MirrorGravity.LOGGER.info("[镜维度·沙砾] 着陆成功，变回方块 {} 于 y={}",
                    state.getBlock(), pos.getY());
            } else {
                MirrorGravity.LOGGER.info("[镜维度·沙砾] 落点被占，直接丢弃（不生成掉落物）y={}",
                    pos.getY());
            }
            fb.discard();
            forget(fb.getUUID());
        } catch (Throwable t) {
            MirrorGravity.LOGGER.debug("[镜维度·沙砾] 着陆处理失败: {}", t.toString());
        }
    }

    private static void forget(UUID id) {
        LAST_Y.remove(id);
        STILL_TICKS.remove(id);
        PHYS_TRACE.remove(id);
    }

    public static void onRemoved(Entity entity) {
        if (entity != null) {
            forget(entity.getUUID());
        }
    }

    private static double r4(double d) {
        return Math.round(d * 10000) / 10000.0D;
    }
}
