package work.dsh.mirror.gravity.mixin;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import work.dsh.mirror.gravity.SetVelocityProbe;

/**
 * 拦截 {@code Entity.setDeltaMovement(Vec3)}，把"水平速度被清成 0"的调用栈抓下来。
 *
 * <h2>为什么必须用 mixin</h2>
 * 这个写入点是原版 {@code Entity.move()} 里的碰撞处理，没有任何事件能观测到它。
 * 排查过程中已经排除了 Pondus、本模组、同步三条路线，只剩下"直接在写入点取证"。
 *
 * <h2>注入点选择</h2>
 * 用 {@code @Inject(at = @At("TAIL"))} 而不是 {@code @At("HEAD")}：
 * 我们要看的是**写入之后**的最终值。如果原版在同一帧里先写一个非零值、
 * 再写一个零值，只有 TAIL 才会记录到后者。
 *
 * <p>探针内部自带过滤器（只处理 KubeJS 推过方向的实体）与打印上限，
 * 所以这个 mixin 常驻也不会刷屏。
 *
 * <h2>为什么 remap = false</h2>
 * NeoForge 1.21 在运行时**直接使用官方（Mojang）名称**，
 * {@code setDeltaMovement} 就是运行时的真实方法名，不存在混淆名需要映射。
 * 打开 remap 反而会让注解处理器去找一份并不存在的混淆表，
 * 编译期直接报 "Unable to locate obfuscation mapping"。
 */
@Mixin(Entity.class)
public abstract class EntitySetDeltaMovementMixin {

    @Inject(
        method = "setDeltaMovement(Lnet/minecraft/world/phys/Vec3;)V",
        at = @At("TAIL"),
        remap = false)
    private void mirrorgravity$probeSetDeltaMovement(Vec3 movement, CallbackInfo ci) {
        try {
            SetVelocityProbe.afterSet((Entity) (Object) this, movement);
        } catch (Throwable ignored) {
            // 探针绝不能影响游戏逻辑
        }
    }
}
