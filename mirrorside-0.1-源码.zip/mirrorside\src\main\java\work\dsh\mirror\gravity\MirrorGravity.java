package work.dsh.mirror.gravity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * 镜维度 · 重力补丁模组。
 *
 * <p>本模组独立于 KubeJS 脚本：它只提供"把某个实体的重力方向改对"的能力，
 * 至于什么时候、对哪个实体用哪个方向，全部由 KubeJS 侧的
 * <code>mirror_setting.js</code> 决定。两边的接口是 {@link MirrorGravityApi}。
 *
 * <p>负责的实体：下落的方块（沙砾/沙子/混凝土粉末）、掉落物，
 * 以及任何 Pondus 白名单没放行的非生物实体。
 * 生物 / 玩家 / 弹射物 / 矿车 仍由 Pondus 自己负责。
 */
@Mod(MirrorGravity.MOD_ID)
public class MirrorGravity {

    public static final String MOD_ID = "mirrorgravity";
    public static final Logger LOGGER = LoggerFactory.getLogger("MirrorGravity");

    /** 清理周期（tick）。20 秒清一次即可。 */
    private static final int CLEANUP_INTERVAL = 400;

    private int tickCounter = 0;

    public MirrorGravity(IEventBus modBus) {
        MirrorGravityApi.logStatus(LOGGER);

        // ⚠️ 必须在这里修一次 Pondus 的旋转参数：
        // 它的 updateDefault() 在启动时从不被调用，导致 config/pondus.json
        // 里的 worldVelocity 等设置完全无效（详见 PondusBridge 注释）。
        boolean ok = PondusBridge.refreshRotationDefaults();
        LOGGER.info("[镜维度·重力] Pondus 旋转参数刷新: {}，当前 {}",
            ok ? "成功" : "失败", PondusBridge.describeConfig());

        NeoForge.EVENT_BUS.addListener(this::onEntityTick);
        NeoForge.EVENT_BUS.addListener(this::onEntityTickPre);
        NeoForge.EVENT_BUS.addListener(this::onServerTick);
        NeoForge.EVENT_BUS.addListener(this::onItemPickup);
        NeoForge.EVENT_BUS.addListener(this::onEntityJoin);

        LOGGER.info("[镜维度·重力] 已加载：非生物实体（下落的方块、掉落物等）将支持重力方向反转。");
    }

    /**
     * 实体 tick 后处理下落的方块的"着陆"。
     *
     * 原版的 onGround() 只看脚下方块，反转重力后实体朝上飞、
     * 撞到天花板也不会被判定为落地，最终会变成掉落物。
     * 这里补上这个判定（见 {@link LandingFix}）。
     */
    /**
     * 实体 tick **之前**采样一次（仅服务端、仅被观察的实体）。
     *
     * <p>为什么需要：实测发现服务端物品的 {@code deltaMovement} 在飞行途中
     * 是 0，而客户端还保留 0.25 —— 两端从第一帧就发散。要定位"是谁把速度
     * 清成 0"，必须知道清零发生在实体 tick **之前**（= 被别的代码在 tick 外
     * 改的）还是 **之中**（= 原版 move()/碰撞干的）。
     *
     * <p>Pre/Post 一对比就能把这两种原因分开。
     */
    private void onEntityTickPre(EntityTickEvent.Pre event) {
        try {
            PondusBridge.tracePreTick(event.getEntity());
        } catch (Throwable t) {
            LOGGER.debug("[镜维度·重力] 前置轨迹失败: {}", t.toString());
        }
    }

    private void onEntityTick(EntityTickEvent.Post event) {
        Entity e = event.getEntity();

        /* 下落的方块 / 掉落物：**完全由 BlockPhysics 接管**。
         *
         * 为什么不再交给 Pondus：这些实体不调用 super.tick()，
         * Pondus 的 commonTick() 对它们永不执行，处于"半失效"状态；
         * 而它又在两端各自演算，导致持续发散（实测两端 y 差过 1 格）。
         * BlockPhysics 关掉 Pondus 重力、固定方向为 DOWN（使坐标旋转成为
         * 恒等变换），自己施加加速度与阻尼，只在服务端算 —— 天然一致。 */
        if (e instanceof FallingBlockEntity fb) {
            try {
                PondusBridge.autoWatch(fb);
                /* 参照线用"下界面黑色玻璃上沿"，而不是 layout 的 y=0。
                 *
                 * 原因：黑色玻璃是**实体方块**，占 y=-1 与 y=-2。
                 * 沙砾落在它顶面时约在 y=-1.0，若按 y=0 判断仍属"上侧"
                 * → 受向下重力 → 会继续往负坐标沉，最后被原版超时
                 * 判定成掉落物（用户报告的现象）。 */
                BlockPhysics.tick(fb, splitY() + FALLING_REF_OFFSET);
                PondusBridge.traceAutoTick(fb);
            } catch (Throwable t) {
                LOGGER.debug("[镜维度·重力] 下落的方块处理失败: {}", t.toString());
            }
            return;
        }

        /* 掉落物 / TNT / 末影之眼等非生物实体：**模组完全不接管**。
         *
         * 它们由 KubeJS 的迟滞逻辑推方向、物理交给原版 + Pondus 的
         * move() 旋转 —— 那是用户确认过"稳定、抛物线正常、动画正确反转、
         * 不回到脚下"的形态。
         *
         * 早先模组也曾自己处理它们，结果引入"交界处抽搐 / 幅度过大 /
         * 偶尔传送 / 回脚下"等退化。所以这里彻底让路，
         * 模组只负责下落的方块（见上面那个分支）。 */

        // 其它被接管的实体（生物等仍走 Pondus）
        try {
            /* ⚠️ 必须在实体 tick **之后**补回水平速度。
             *
             * 换向是 Pondus 注入在 Entity.tick() 上执行的，它会把速度整体
             * 清零（原因见 PondusBridge.applyDirection 的注释）。移动此时
             * 已经用换向前的速度跑完，所以这里补回的正是本该保留的动量。
             * 放在 tick 之前补会被随后的换向再次覆盖。 */
            PondusBridge.restoreHorizontalIfLost(e);

            PondusBridge.traceTick(e);
            PondusBridge.traceWatchTick(e);
            PondusBridge.traceClientItem(e);   // 客户端侧记录，用于两端对比
        } catch (Throwable t) {
            LOGGER.debug("[镜维度·重力] 轨迹记录失败: {}", t.toString());
        }
    }

    /**
     * 重力分界线。由 KubeJS 侧在启动后通过 {@link MirrorGravityApi#setSplitY}
     * 推过来；未设置时退回 0（与设定文件一致）。
     */
    static volatile double SPLIT_Y = 0.0D;

    static double splitY() {
        return SPLIT_Y;
    }

    /**
     * 下落的方块的参照线相对分界的偏移（格）。
     *
     * <p>分界 y=0，但黑色玻璃占 y=-1/-2。沙砾落在这层玻璃顶面时约在
     * y=-1.0，仍属"上侧"→ 受向下重力 → 继续往负坐标沉 → 最终被原版
     * 超时判定成掉落物。把参照线下移 1 格后，沙砾一碰到下界面就进入
     * "下侧"、受向上重力，被压在玻璃面上停住，从而变回方块。
     */
    static final double FALLING_REF_OFFSET = -1.0D;

    /* ------------------------------------------------------------------ */
    /* 掉落物的方向处理：已移除（回退给 KubeJS + Pondus）                      */
    /* ------------------------------------------------------------------ */
    /* 这里曾经由模组给掉落物翻方向并加迟滞（ITEM_HALF / ITEM_DEAD_ZONE）。
     * **已删除，不要恢复**：
     *   · 模组自己处理时出现"交界处抽搐 / 往复幅度过大 / 偶尔传送 /
     *     下界面丢出回到脚下"等退化；
     *   · 交给 KubeJS 的迟滞 + Pondus 的物理时，这些现象都没有 ——
     *     那是用户明确确认过的稳定形态。
     * 所以非生物实体里**只有下落的方块**归模组管，其余一律走老路。 */

    static void setSplitY(double y) {
        SPLIT_Y = y;
        LOGGER.info("[镜维度·重力] 重力分界已设为 y={}", y);
    }

    /**
     * 记录物品被拾取/移除的事件。
     *
     * 为什么需要：用户报告"物品丢出去后回到脚下"。有两种完全不同的原因：
     *   1) 被玩家拾取（正常）——物品进背包
     *   2) 位置被代码挪动（bug）——物品还在世界上
     * 这个监听器能把两者区分开：只有真拾取才会触发 ItemEntityPickupEvent。
     */
    private void onItemPickup(net.neoforged.neoforge.event.entity.player.ItemEntityPickupEvent.Post event) {
        try {
            PondusBridge.traceItemEvent("被拾取", event.getItemEntity());
        } catch (Throwable t) {
            LOGGER.debug("[镜维度·重力] 拾取记录失败: {}", t.toString());
        }
    }

    /**
     * 记录物品的生成（用来观察它从哪来、是否被重复生成）。
     *
     * ⚠️ 这里连**生成瞬间的速度**一起记下来。
     * 实测发现：服务端物品的 vx/vz 在第一条轨迹时就已经是 0，
     * 而客户端仍保留水平速度 —— 说明水平初速在生成的第一个 tick 内就被清掉了。
     * 记录生成瞬间的速度，才能判断"是被我们改的"还是"生成时就没有"。
     */
    private void onEntityJoin(net.neoforged.neoforge.event.entity.EntityJoinLevelEvent event) {
        try {
            Entity e = event.getEntity();
            PondusBridge.traceItemEvent(event.loadedFromDisk() ? "读档加入" : "新生成", e);
            PondusBridge.traceSpawnVelocity(e);
        } catch (Throwable t) {
            LOGGER.debug("[镜维度·重力] 生成记录失败: {}", t.toString());
        }
    }

    /** 定期清理已经消失的实体记录。 */
    private void onServerTick(ServerTickEvent.Post event) {
        tickCounter++;

        /* 启动后不久再刷新一次 Pondus 旋转参数。
         * 构造函数里的那次可能太早 —— 那时 Pondus 的 config 可能还没赋值，
         * updateDefault() 会读到 null。这里在服务器真正跑起来之后再补一次。 */
        if (tickCounter == 20 || tickCounter == 40) {
            boolean ok = PondusBridge.refreshRotationDefaults();
            LOGGER.info("[镜维度·重力] 运行时刷新 Pondus 旋转参数: {}，当前 {}",
                ok ? "成功" : "失败", PondusBridge.describeConfig());
        }

        if (tickCounter % CLEANUP_INTERVAL != 0) {
            return;
        }
        try {
            Set<UUID> alive = new HashSet<>();
            for (ServerLevel level : event.getServer().getAllLevels()) {
                level.getEntities().getAll().forEach(e -> alive.add(e.getUUID()));
            }
            MirrorGravityApi.retainOnly(alive);
        } catch (Throwable t) {
            LOGGER.debug("[镜维度·重力] 实体记录清理失败: {}", t.toString());
        }
    }
}
