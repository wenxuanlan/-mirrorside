package work.dsh.mirror.gravity;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 「是谁把速度清成 0」的取证探针。
 *
 * <h2>为什么需要它</h2>
 * 实测现象：掉落物在交界处换向后，服务端的 {@code deltaMovement} 被写成
 * {@code (0, -0.0078, 0)} —— 水平分量精确归零，垂直分量恰好等于
 * {@code 0.04 × 0.2}（缩放后的重力）。而同一帧位置还向上跳了 0.258 格。
 *
 * 已经排除的嫌疑：
 * <ul>
 *   <li>Pondus 的 setter —— 「换向步骤」三次采样显示速度前后完全不变</li>
 *   <li>Pondus 的 {@code applyGravityDirectionChange} —— 只在 prev≠curr 时触发，
 *       而日志显示每个物品只触发一次</li>
 *   <li>本模组的 BlockPhysics —— 写入点被 {@code instanceof FallingBlockEntity} 挡住</li>
 *   <li>同步问题 —— 服务端与客户端读到的值**完全一致**，不是两端发散</li>
 *   <li>Pondus 的 {@code PondusAPI.setWorldVelocity} —— 我们从未调用</li>
 * </ul>
 *
 * 剩下唯一的取法就是：在写入的那一刻把调用栈抓下来。
 * 本类由 {@link work.dsh.mirror.gravity.mixin.EntitySetDeltaMovementMixin} 调用。
 *
 * <h2>只对"我们关心的实体"生效</h2>
 * 判定条件是"这个实体被 KubeJS 推过方向"（见 {@link PondusBridge#isWatched}）。
 * 否则原版每 tick 都会给无数实体写速度，日志会被淹没。
 */
public final class SetVelocityProbe {

    private SetVelocityProbe() {
    }

    /** 每个实体上一次被写入的水平速度，用来判断"这次是不是被清成了 0"。 */
    private static final Map<UUID, Double> LAST_H = new ConcurrentHashMap<>();

    /** 每个实体已经打印过多少次，防止刷屏。 */
    private static final Map<UUID, Integer> PRINTED = new ConcurrentHashMap<>();

    private static final int MAX_PRINT = 3;

    /**
     * 由 mixin 在 {@code Entity.setDeltaMovement} 之后调用。
     *
     * @param entity 目标实体
     * @param newV   写入后的值
     */
    public static void afterSet(Entity entity, Vec3 newV) {
        if (entity == null || newV == null) {
            return;
        }
        if (!PondusBridge.isWatched(entity)) {
            return;
        }
        double h = Math.hypot(newV.x, newV.z);
        Double prev = LAST_H.put(entity.getUUID(), h);
        if (prev == null || prev <= 0.0D || h > 0.0D) {
            return;   // 只关心"从非 0 变成 0"这一刻
        }
        UUID id = entity.getUUID();
        int n = PRINTED.merge(id, 1, Integer::sum);
        if (n > MAX_PRINT) {
            return;
        }
        MirrorGravity.LOGGER.warn(
            "[镜维度·速度归零] [{}] {} {} 水平速度 {} -> 0，新值=({}, {}, {}) 调用栈：",
            entity.getUUID().toString().substring(0, 8),
            entity.level().isClientSide() ? "CLIENT" : "SERVER",
            entity.getType(),
            Math.round(prev * 10000) / 10000.0D,
            Math.round(newV.x * 10000) / 10000.0D,
            Math.round(newV.y * 10000) / 10000.0D,
            Math.round(newV.z * 10000) / 10000.0D);
        StackTraceElement[] st = Thread.currentThread().getStackTrace();
        for (int i = 0; i < st.length && i < 22; i++) {
            MirrorGravity.LOGGER.warn("[镜维度·速度归零]     at {}", st[i]);
        }
    }
}
