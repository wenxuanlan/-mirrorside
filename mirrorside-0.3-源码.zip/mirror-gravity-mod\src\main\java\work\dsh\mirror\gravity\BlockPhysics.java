package work.dsh.mirror.gravity;

import work.dsh.mirror.gravity.internal.Failures;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import work.dsh.mirror.gravity.internal.DirectionWriter;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 下落的方块 / 掉落物的重力往复物理。
 *
 * <h2>核心原则：一律在世界坐标里思考</h2>
 * 这是踩了非常多坑之后才理清的一条铁律。
 *
 * <p>实体的 {@code deltaMovement} 存的是**本地坐标**（Pondus 约定：
 * 本地 -Y 永远是实体的"下"），而 {@code Entity.move()} 会按重力方向
 * 把它换算到世界坐标。所以如果我直接往 {@code deltaMovement} 上加
 * "向上的加速度"，在方向为 UP 时它会变成世界**向下** ——
 * 实测数据就是：
 * <pre>
 *   dir=up  netAccel=+0.04（本地向上）  但世界坐标 y 在下降
 * </pre>
 *
 * <p>因此本类的做法是：
 * <ol>
 *   <li>把本地速度换算成世界速度</li>
 *   <li>在**世界坐标**里做全部物理（加速度、阻尼、限速、落地判断）</li>
 *   <li>再换算回本地坐标写回</li>
 * </ol>
 * 这样系统对方向完全不敏感，永远不会出现"方向一反、运动就错"。
 *
 * <h2>方向只负责两件事</h2>
 * 物理不再依赖方向，但方向仍然要写对，因为：
 * <ul>
 *   <li>Pondus 的 {@code move()} 靠它做本地→世界换算（我们要与之一致）</li>
 *   <li>Pondus 的渲染 mixin 靠它决定**实体动画的朝向**</li>
 * </ul>
 *
 * <h2>只在服务端施力</h2>
 * 客户端只接收同步。两端同时演算必然发散（实测 y 差过 1 格）。
 */
public final class BlockPhysics {

    /** 停稳判定用的上一位移与连续停稳 tick 数（着陆补丁）。 */
    private static final Map<UUID, Integer> STILL_TICKS = new ConcurrentHashMap<>();
    private static final Map<UUID, Double> LAST_Y = new ConcurrentHashMap<>();
    /** entityUUID -> 当前所处的半区（带迟滞，避免在分界线上反复翻向） */
    private static final Map<UUID, Boolean> HALF = new ConcurrentHashMap<>();

    private static final double STILL_EPS = 0.002D;
    private static final int STILL_NEEDED = 3;

    /**
     * 方向迟滞带半径（格）。
     *
     * <p>⚠️ 为什么必须有它：没有迟滞时，实体在分界线上下一微抖就翻向，
     * 表现为"在交界处快速抽搐"（用户报告）。带内维持原方向，
     * 于是重力成为**恢复力**，实体被推向带中心并稳定下来。
     *
     * <p>数值要与沙砾的往复幅度相称：太小挡不住抖动，
     * 太大则两个反转点靠得太近、看不出往复。
     *
     * <p>⚠️ 这个默认值必须与 KubeJS 侧 {@code gravity.falling_hysteresis} 相等
     * （脚本加载时会把配置值推过来，这里只是"推送之前"的兜底）。
     * 0.3 之前两边分别是 1.0（配置）与 0.75（这里）——
     * {@code tools-build/check-param-parity.mjs} 现在会直接报错，
     * 所以统一到配置的 1.0。
     */
    private static final double DIR_HYSTERESIS_DEFAULT = 1.0D;

    /**
     * 方向迟滞带半径（格），可由 KubeJS 侧覆盖。
     *
     * <p>它同时决定两件事：
     * <ul>
     *   <li><b>防抖</b>：带内维持原方向，避免在分界线上快速抽搐</li>
     *   <li><b>摆幅</b>：实体要越过 {@code splitY ± band} 才反向，
     *       所以带越宽、往复越远</li>
     * </ul>
     *
     * <p>实测 band=0.75 时沙砾只在 y≈-2.31 ~ -0.63 之间摆动，
     * 上折点距 y=0 还差 0.63 格。用户希望摆幅能明显越过原始分界线，
     * 所以把它开放给脚本调。
     */
    private static volatile double DIR_HYSTERESIS = DIR_HYSTERESIS_DEFAULT;

    /** 供 KubeJS 调整迟滞带（见 {@link MirrorGravityApi#setHysteresis}）。 */
    public static void setHysteresis(double band) {
        if (band <= 0.0D) {
            return;   // 0 带会让实体在分界线上疯狂抽搐，直接拒绝
        }
        DIR_HYSTERESIS = band;
        MirrorGravity.LOGGER.info("[镜维度·重力] 下落方块迟滞带已设为 {} 格", band);
    }

    private BlockPhysics() {
    }

    /**
     * 每 tick 调用一次。
     *
     * @param entity 目标实体（下落的方块 / 掉落物）
     * @param splitY 重力分界：y > splitY 朝下，y <= splitY 朝上
     */
    public static void tick(Entity entity, double splitY) {
        try {
            if (entity == null) {
                return;
            }
            boolean client = entity.level().isClientSide();
            UUID id = entity.getUUID();

            /* 首次见到这个方块时，把 Pondus 的原版重力关掉。
             *
             * ⚠️ 只在"首次"写：这是个**反射写字段**的操作
             * （PondusReflect.writeBaseStrength → Field.set）。
             * 曾经写成每 tick 无条件调用 —— 下落方块存在多少 tick 就写多少次，
             * 而强度一旦设成 0 就不会自己变回去，重复写纯属浪费。
             * 用 HALF 是否已存在来判断"是否首次"（同一个 id 的 HALF 只在这里建）。 */
            if (!HALF.containsKey(id)) {
                DirectionWriter.applyScale(entity, 0.0D);
            }

            /* 当前半区：带迟滞。
             * 一旦离开分界超过 DIR_HYSTERESIS 才切换，避免线上抖动。 */
            boolean above = HALF.computeIfAbsent(id, k -> entity.getY() > splitY);
            if (above && entity.getY() < splitY - DIR_HYSTERESIS) {
                above = false;
                HALF.put(id, false);
            } else if (!above && entity.getY() > splitY + DIR_HYSTERESIS) {
                above = true;
                HALF.put(id, true);
            }

            /* ⚠️⚠️ 正常重力（above）时，模组**完全不碰这个实体**。
             *
             * 为什么：用户报告"沙砾在上界面正常下落时会有传送样式的回弹"。
             * 那正是这里引起的 —— 我为了沙砾的往复物理，在**上侧也在改它的
             * 速度**（加速度 / 阻尼 / 速度上限），把原版平滑的下落搞出了
             * 台阶感。
             *
             * 正常下落本来就该由原版处理（原版自己会把方块放回世界），
             * 模组只在**反重力**这一原版覆盖不到的场景介入。
             * 这样上侧行为与"没有本模组"时完全一致。 */
            if (above) {
                if (client) {
                    DirectionWriter.apply(entity, Direction.DOWN, true);
                } else {
                    // 服务端也把方向写回 DOWN（若有残留），但不动速度
                    DirectionWriter.apply(entity, Direction.DOWN, true);
                    STILL_TICKS.remove(id);
                }
                /* 诊断：上侧（正常下落）时逐 tick 记录状态。
                 * 用户报告"沙砾/沙子往正坐标落下的动画消失了"，
                 * 而这一段本该完全交给原版 —— 所以要确认方向是否真的被写成 DOWN、
                 * 速度是否由原版正常建立。 */
                logFall(id, entity, true);
                return;
            }

            /* 方向 = 真实的重力方向（此处必为 UP）。
             * 它决定 Pondus 的坐标换算基准，也决定渲染动画的朝向。 */
            Direction dir = Direction.UP;
            DirectionWriter.apply(entity, dir, true);

            if (client) {
                return;   // 客户端只设方向（供渲染），物理由服务端同步
            }

            /* ---- 1) 本地 -> 世界 ---- */
            Vec3 world = MirrorDir.localToWorld(entity.getDeltaMovement(), dir);

            /* ---- 2) 世界坐标里做物理 ---- */
            double g = MirrorGravityConfig.accelFor(entity);

            // 抵消原版重力（作用在世界 -Y）：实测 applyGravityScale(0)
            // 不生效、getGravity() 仍是 0.04，所以直接减掉，再叠加目标方向量。
            double vanillaGravity = entity.getGravity();
            double desired = g;          // 反重力：世界向上
            double accelY = -vanillaGravity + desired;

            world = world.add(0.0D, accelY, 0.0D);

            // 阻尼 + 兜底上限（只用于沙砾的反重力往复）
            world = world.scale(MirrorGravityConfig.REBOUND_DAMPING_PER_TICK);
            double max = MirrorGravityConfig.REBOUND_MAX_SPEED;
            if (max > 0.0D && world.length() > max) {
                world = world.scale(max / world.length());
            }

            /* ---- 3) 世界 -> 本地，写回 ----
             * ⚠️ 这一行是反重力物理真正生效的地方，删掉整个往复就没了。 */
            entity.setDeltaMovement(MirrorDir.worldToLocal(world, dir));

            /* 只有反重力（朝上飞）时才需要着陆补丁 ——
             * 那种情况下原版的 onGround() 永远为 false，方块放不回去，
             * 最终会走 spawnAtLocation 变成掉落物。
             * 正常下落一律交给原版（本节开头已经 return）。 */
            if (entity instanceof FallingBlockEntity fb) {
                handleLanding(fb, false);
            }
        } catch (Throwable t) {
            Failures.note("BlockPhysics.apply", t);
            // 物理接管失败不影响其它逻辑
        }
    }

    /**
     * 着陆判定：真正停住且前方有方块时，把方块放回世界。
     *
     * <p>原版 {@code onGround()} 只查**脚下方块**，重力反转后实体朝上飞时
     * 脚下是空的 → 永远不会"落地" → 等 {@code time > 600} 后
     * {@code spawnAtLocation} 掉成物品。用户明确要求
     * "落在玻璃上应该变成方块，而不是掉落物"，所以这里自己判定。
     */
    private static void handleLanding(FallingBlockEntity fb, boolean above) {
        UUID id = fb.getUUID();
        double y = fb.getY();
        Double prev = LAST_Y.put(id, y);
        boolean still = prev != null && Math.abs(y - prev) < STILL_EPS;
        int n = still ? STILL_TICKS.merge(id, 1, Integer::sum) : 0;
        if (!still) {
            STILL_TICKS.put(id, 0);
        }
        if (n < STILL_NEEDED) {
            return;   // 还在动
        }

        BlockPos here = fb.blockPosition();
        BlockPos ground = above ? here.below() : here.above();
        if (fb.level().noCollision(fb, new AABB(ground))) {
            return;   // 前方是空的，只是暂时停住
        }

        place(fb, here);
    }

    /** 把方块放回世界；放不下也只丢弃，**绝不生成掉落物**。 */
    private static void place(FallingBlockEntity fb, BlockPos pos) {
        try {
            BlockState state = fb.getBlockState();
            if (!state.isAir() && fb.level().getBlockState(pos).canBeReplaced()) {
                fb.level().setBlock(pos, state, 3);
                MirrorGravity.LOGGER.info("[镜维度·沙砾] 着陆成功，变回方块 {} 于 y={}",
                    state.getBlock(), pos.getY());
            } else {
                MirrorGravity.LOGGER.info("[镜维度·沙砾] 落点被占，直接丢弃（不生成掉落物）y={}",
                    pos.getY());
            }
            fb.discard();
            forget(fb.getUUID());
        } catch (Throwable t) {
            MirrorGravity.LOGGER.debug("[镜维度·沙砾] 着陆处理失败: {}", t.toString());
        }
    }

    private static void forget(UUID id) {
        LAST_Y.remove(id);
        STILL_TICKS.remove(id);
        HALF.remove(id);
        FALL_LOG_N.remove(id);
    }

    /* ------------------------------------------------------------------ */
    /* 上侧（正常下落）诊断                                                  */
    /* ------------------------------------------------------------------ */
    /* 用户报告"沙砾/沙子往正坐标落下的动画消失了"。
     * 上侧本该**完全交给原版**（本类不施力），所以要么方向没被写成 DOWN
     * （导致 Pondus 的渲染旋转把方块转过来）、要么速度没由原版建立。
     * 这里每个实体记有限条，把方向与速度一起打出来。 */

    private static final Map<UUID, Integer> FALL_LOG_N = new ConcurrentHashMap<>();

    private static final int FALL_LOG_MAX = 12;

    private static void logFall(UUID id, Entity entity, boolean above) {
        int n = FALL_LOG_N.merge(id, 1, Integer::sum);
        if (n > FALL_LOG_MAX) {
            return;
        }
        try {
            Direction d = PondusReflect.direction(entity);
            Vec3 v = entity.getDeltaMovement();
            double[] p = new double[3];
            PondusReflect.readPosition(entity, p);
            MirrorGravity.LOGGER.info(
                "[镜维度·下落{}] [{}] t={} above={} dir={} pos=({}, {}, {}) vy={} 盒Y=[{}..{}]",
                n, entity.level().isClientSide() ? "C" : "S",
                entity.level().getGameTime(), above,
                d == null ? "null" : d.getName(),
                r4(p[0]), r4(p[1]), r4(p[2]), r4(v.y),
                r4(entity.getBoundingBox().minY), r4(entity.getBoundingBox().maxY));
        } catch (Throwable ignored) {
            Failures.note("BlockPhysics.logFall", ignored);
            // 诊断绝不影响主流程
        }
    }

    private static double r4(double v) {
        return Math.round(v * 10000) / 10000.0D;
    }

    /**
     * 丢弃已消失实体的记录。
     *
     * <p>本类的记录都以实体 UUID 为键。下落方块通常很快落地并被
     * {@code forget} 清掉，但方块卡住、或实体被其它方式移除时不会 —
     * 所以还需要按"是否仍然存活"做一次兜底清理，避免表随实体总数增长。
     */
    public static void retainOnly(java.util.Set<UUID> alive) {
        LAST_Y.keySet().removeIf(id -> !alive.contains(id));
        STILL_TICKS.keySet().removeIf(id -> !alive.contains(id));
        HALF.keySet().removeIf(id -> !alive.contains(id));
    }
}
