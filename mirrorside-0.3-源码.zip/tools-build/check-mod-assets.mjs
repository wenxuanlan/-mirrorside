/** 校验模组资源 JSON 与 PNG（用 Node 显式按 UTF-8 读，避免 shell 编码干扰）。 */
import { readFileSync, existsSync } from 'node:fs';

const BASE = 'D:/DSHwork/MC镜维度/mirror-gravity-mod/src/main/resources/assets/mirrorgravity/';
/* 数据包那一侧（掉落表等）与 assets 平级，别用相对路径去拼 ——
 * 从 BASE 往上要退两层才到 resources/，少退一层就会去找一个不存在的
 * assets/data/... 目录（这次就是这么栽的）。 */
const DATA = 'D:/DSHwork/MC镜维度/mirror-gravity-mod/src/main/resources/data/mirrorgravity/';
const files = [
  'blockstates/mirror_portal.json',
  'models/block/mirror_portal.json',
  'lang/zh_cn.json',
  'lang/en_us.json',
  'textures/block/mirror_portal.png.mcmeta',
  'sounds.json',
  /* 波粒块（0.3 新增）：方块状态 / 方块模型 / 物品模型 / 纹理。
   * 少任何一个，游戏里的表现都是"紫黑方块"或"missing model"，且日志不一定报错。 */
  'blockstates/wave_particle_block.json',
  'models/block/wave_particle_block.json',
  'models/item/wave_particle_block.json',
  'textures/block/wave_particle_block.png',
  /* 波粒子（道具）：物品模型 + 物品贴图。
   * 少任何一个，游戏里显示的都是紫黑格（missing model）。 */
  'models/item/wave_particle.json',
  'textures/item/wave_particle.png',
  /* 波粒链的两级中间材料（波 = 腐肉式撕裂块，粒 = 重锤核心式方块） */
  'models/item/wave.json',
  'models/item/particle.json',
  'textures/item/wave.png',
  'textures/item/particle.png',
  /* 传送门物品形态（0.3 批次八）：物品模型 + 物品贴图 + 掉落表。
   * 少了模型或贴图 = 创造栏里紫黑格；少了掉落表 = 破坏后什么都不掉。 */
  'models/item/mirror_portal.json',
  'textures/item/mirror_portal.png',
];

let bad = 0;
for (const f of files) {
  const p = BASE + f;
  if (!existsSync(p)) {
    console.log('  ✗ 缺失 ' + f);
    bad++;
    continue;
  }
  if (f.endsWith('.png')) {
    /* PNG 只做头部校验：签名 + IHDR 宽高。纹理是脚本生成的，
     * 尺寸写错不会崩游戏，但会静默变成"被拉伸/被裁剪"的贴图。 */
    const buf = readFileSync(p);
    const sigOk = buf.length > 24 && buf.readUInt32BE(0) === 0x89504e47 && buf.readUInt32BE(4) === 0x0d0a1a0a;
    const w = buf.readUInt32BE(16);
    const h = buf.readUInt32BE(20);
    if (!sigOk) {
      console.log('  ✗ ' + f + ' 不是合法 PNG');
      bad++;
    } else {
      console.log('  ✓ ' + f + `  ${w}x${h}  ${buf.length}B`);
      if (w !== h) {
        console.log('  · 提示：' + f + ' 不是正方形（方块贴图通常用 16/32/64 的正方形）');
      }
    }
    continue;
  }
  try {
    const o = JSON.parse(readFileSync(p, 'utf8'));
    const keys = Object.keys(o).join(', ');
    console.log('  ✓ ' + f + '   keys=' + (keys.length > 60 ? keys.slice(0, 60) + '…' : keys));
  } catch (e) {
    console.log('  ✗ ' + f + ' : ' + e.message);
    bad++;
  }
}

/* 方块状态文件里那个空字符串键是原版规范（"没有属性"的方块就这么写），
 * PowerShell 5.1 的 ConvertFrom-Json 会误报，这里单独确认一次。 */
const bs = JSON.parse(readFileSync(BASE + 'blockstates/mirror_portal.json', 'utf8'));
const variantKeys = Object.keys(bs.variants);
console.log('  · blockstate 变体键 = [' + variantKeys.map((k) => JSON.stringify(k)).join(', ')
  + ']，模型 = ' + bs.variants[variantKeys[0]].model);

/* 波粒块的方块模型必须是"六面同纹理"的全方块：它的贴图是脚本生成的粉紫渐变，
 * 一旦被误写成 cube（缺 down/up 会引用不存在的贴图），游戏里会看到紫黑格。 */
const wpModel = JSON.parse(readFileSync(BASE + 'models/block/wave_particle_block.json', 'utf8'));
if (wpModel.parent !== 'minecraft:block/cube_all' || wpModel.textures?.all !== 'mirrorgravity:block/wave_particle_block') {
  console.log('  ✗ wave_particle_block 的方块模型应为 cube_all + textures.all=mirrorgravity:block/wave_particle_block');
  bad++;
}

/* 中文语言文件：确认没有解码失败留下的替换字符 */
const zh = readFileSync(BASE + 'lang/zh_cn.json', 'utf8');
const replacement = (zh.match(/\uFFFD/g) || []).length;
console.log('  · zh_cn.json 替换字符数 = ' + replacement + '（应为 0）');
if (replacement > 0) bad++;

/* 语言文件必须给方块与物品各一条 —— 缺任何一条，游戏里显示的都是原始 id。 */
for (const key of ['block.mirrorgravity.wave_particle_block', 'item.mirrorgravity.wave_particle_block',
  'item.mirrorgravity.wave_particle', 'item.mirrorgravity.wave', 'item.mirrorgravity.particle']) {
  if (!zh.includes(key)) {
    console.log('  ✗ zh_cn.json 缺少 ' + key);
    bad++;
  }
}

/* 波粒子/波/粒都是物品（不是方块）：物品模型必须是 item/generated + layer0，
 * 写成方块模型（cube_all）在物品栏里会渲染成一张方片。 */
for (const [name] of [['wave_particle'], ['wave'], ['particle'], ['mirror_portal']]) {
  const p = BASE + 'models/item/' + name + '.json';
  const m = JSON.parse(readFileSync(p, 'utf8'));
  if (m.parent !== 'minecraft:item/generated'
    || m.textures?.layer0 !== 'mirrorgravity:item/' + name) {
    console.log('  ✗ ' + name + ' 的物品模型应为 item/generated + layer0=mirrorgravity:item/' + name);
    bad++;
  }
}

/* 传送门物品（0.3 批次八）三件事一起查：
 *   ① 物品贴图必须是 16×16（静态图标，不是方块那张 16×768 的动画图 ——
 *      把动画贴图当图标用，物品栏里会显示成一堆条纹）；
 *   ② 中英语言文件都要有 item.mirrorgravity.mirror_portal
 *      （缺了显示原始 id，不是崩溃但也算没做完）；
 *   ③ 掉落表必须指向 mirrorgravity:mirror_portal 本身。
 * 另外从 Java 源码里确认**真的注册了物品形态并放进了创造栏** ——
 * 资源齐全但没注册，表现同样是"创造栏里找不到"。 */
{
  const itemPng = BASE + 'textures/item/mirror_portal.png';
  const b = readFileSync(itemPng);
  const w = b.readUInt32BE(16);
  const h = b.readUInt32BE(20);
  if (w !== 16 || h !== 16) {
    console.log(`  ✗ textures/item/mirror_portal.png 应为 16x16 静态图标，实际 ${w}x${h}`);
    bad++;
  } else {
    console.log(`  ✓ 传送门物品图标 16x16 ${b.length}B（静态；方块那张是动画图）`);
  }
  for (const [lang, file] of [['zh_cn', 'lang/zh_cn.json'], ['en_us', 'lang/en_us.json']]) {
    const txt = readFileSync(BASE + file, 'utf8');
    if (!txt.includes('item.mirrorgravity.mirror_portal')) {
      console.log(`  ✗ ${file} 缺少 item.mirrorgravity.mirror_portal（${lang}）`);
      bad++;
    }
  }
  const lootPath = DATA + 'loot_table/blocks/mirror_portal.json';
  if (!existsSync(lootPath)) {
    console.log('  ✗ 缺掉落表 data/mirrorgravity/loot_table/blocks/mirror_portal.json');
    bad++;
  }
  const loot = existsSync(lootPath) ? JSON.parse(readFileSync(lootPath, 'utf8')) : { pools: [] };
  const names = (loot.pools || []).flatMap((p) => (p.entries || []).map((e) => e.name));
  if (!names.includes('mirrorgravity:mirror_portal')) {
    console.log('  ✗ 传送门掉落表没有指向 mirrorgravity:mirror_portal');
    bad++;
  } else {
    console.log('  ✓ 传送门物品：模型 / 图标 / 中英语言 / 掉落表四件齐');
  }

  const java = readFileSync('D:/DSHwork/MC镜维度/mirror-gravity-mod/src/main/java/work/dsh/mirror/gravity/MirrorBlocks.java', 'utf8');
  /* ⚠️ 只看非注释行：本项目踩过三次"注释里出现代码 → 文本断言假警报"
   *   （见开发日志批次七的教训）。 */
  const codeOnly = java.split(/\r?\n/)
    .filter((l) => !/^\s*(\*|\/\/|\/\*)/.test(l)).join('\n');
  if (!/MIRROR_PORTAL_ITEM\s*=\s*[\s\S]{0,80}registerSimpleBlockItem\(\s*"mirror_portal"/.test(codeOnly)) {
    console.log('  ✗ MirrorBlocks.java 没有给 MIRROR_PORTAL 注册物品形态（创造栏里取不出来）');
    bad++;
  }
  if (!/displayItems[\s\S]{0,400}MIRROR_PORTAL_ITEM\.get\(\)/.test(codeOnly)) {
    console.log('  ✗ MirrorBlocks.java 的创造栏 displayItems 里没有 MIRROR_PORTAL_ITEM');
    bad++;
  }
}

/* 传送门是**动画贴图**：PNG 高度 = 16 × 帧数，mcmeta 的 frames 必须与之一致。
 * 这三者（PNG 高度 / frames 列表 / frametime）任何一处对不上，游戏里的表现是
 * 贴图被纵向压成一堆条纹、或者只显示第一帧 —— 而且不报任何错。
 * 2026-09-26 把帧数从 32 改成 48，就是靠这条确认三处同步改到了。 */
{
  const portalPng = readFileSync(BASE + 'textures/block/mirror_portal.png');
  const ph = portalPng.readUInt32BE(20);
  const anim = JSON.parse(readFileSync(BASE + 'textures/block/mirror_portal.png.mcmeta', 'utf8')).animation || {};
  const frames = anim.frames || [];
  const n = ph / 16;
  console.log(`  · 传送门动画：PNG 高 ${ph} → ${n} 帧，mcmeta frames ${frames.length} 条，`
    + `frametime=${anim.frametime}，interpolate=${anim.interpolate}`);
  if (!Number.isInteger(n) || n < 2) {
    console.log('  ✗ 传送门 PNG 高度不是 16 的整数倍，算不出帧数（贴图会显示错乱）');
    bad++;
  } else if (frames.length !== n) {
    console.log(`  ✗ mcmeta 的 frames=${frames.length} 与 PNG 的 ${n} 帧不一致 —— 动画会错帧`);
    bad++;
  } else if (!(anim.frametime >= 1)) {
    console.log('  ✗ mcmeta 缺 frametime（或小于 1）');
    bad++;
  } else if (anim.interpolate !== true) {
    console.log('  · 提示：动画没开 interpolate，帧与帧之间会有台阶感');
  } else {
    console.log('  ✓ 传送门动画三处一致（PNG 帧数 / frames / frametime + interpolate）');
  }

  /* 镜面方块的三张贴图（侧面/顶面/底面）都要在，而且模型必须引用到。
   * 少一张的表现是紫黑格或裸模型 —— 同样是"不报错但看得出不对"。 */
  const surfModel = JSON.parse(readFileSync(BASE + 'models/block/mirror_surface.json', 'utf8'));
  const used = Object.values(surfModel.textures || {});
  for (const s of ['side', 'top', 'bottom']) {
    const rel = `textures/block/mirror_surface_${s}.png`;
    if (!existsSync(BASE + rel)) {
      console.log('  ✗ 缺 ' + rel);
      bad++;
      continue;
    }
    const b = readFileSync(BASE + rel);
    const w = b.readUInt32BE(16);
    const h = b.readUInt32BE(20);
    if (w !== 16 || h !== 16) {
      console.log(`  ✗ ${rel} 应为 16x16（方块贴图），实际 ${w}x${h}`);
      bad++;
    }
    if (!used.includes('mirrorgravity:block/mirror_surface_' + s)) {
      console.log(`  ✗ models/block/mirror_surface.json 没有引用 mirror_surface_${s}`);
      bad++;
    }
  }
}

/* ------------------------------------------------------------------ */
/* JEI 数据：@mapped 的配方必须**逐落点**写出具体产物                     */
/* ------------------------------------------------------------------ */
/* 用户 2026-09-27 报："在 JEI 里看，树苗没有写入产物一栏"。
 * 根因是导出时只给了一条"落点一组 + 产物一组"的通用条目 —— JEI 里两个槽都在
 * 轮播，看不出"橡树叶 → 橡树苗"的对应，产物那一栏也就等于没写清。
 * 现在导出按 map 表逐落点展开 + 一条标签兜底，下面把这件事钉死。 */
{
  const CONFIG = 'D:/DSHwork/MC镜维度/.minecraft/versions/镜维度/kubejs/startup_scripts/mirror_config.js';
  const cfg = new Function(readFileSync(CONFIG, 'utf8')
    .replace(/^\s*global\.MIRROR_CONFIG\s*=\s*MIRROR_CONFIG\s*;?\s*$/m, '')
    + '\n; return MIRROR_CONFIG;')();
  const list = cfg.gravityBlockRecipes.list;
  const mapped = list.filter((r) => String(r.output) === '@mapped');
  if (mapped.length === 0) {
    console.log('\n  · 没有 @mapped 配方（JUMP：这一节是给"脚手架 → 树苗"写的）');
  } else {
    const jei = JSON.parse(readFileSync(
      'D:/DSHwork/MC镜维度/mirror-gravity-mod/src/main/resources/gravity_recipes.json', 'utf8')).recipes;
    const obs = JSON.parse(readFileSync(
      'D:/DSHwork/MC镜维度/mirror-gravity-mod/src/main/resources/observation_recipes.json', 'utf8')).recipes;
    console.log('\n=== JEI 数据：@mapped 逐落点展开 ===');
    let jbad = 0;
    for (const r of mapped) {
      const map = r.map ?? {};
      const leaves = Object.keys(map);
      for (const leaf of leaves) {
        const want = String(map[leaf]);
        const hit = jei.find((x) => x.input === r.input && Array.isArray(x.on)
          && x.on.length === 1 && x.on[0] === leaf);
        if (!hit) {
          jbad++; console.log(`  ✗ JEI 里缺少 "${r.input} + ${leaf}" 这一条`);
          continue;
        }
        if (!Array.isArray(hit.outputs) || hit.outputs.length !== 1 || hit.outputs[0] !== want) {
          jbad++;
          console.log(`  ✗ JEI 条目 ${leaf} 的产物应为 ${want}，实际 ${JSON.stringify(hit.outputs)}`
            + '（这就是"产物一栏空着/看不出是什么"的那类问题）');
        }
        const o = obs.find((x) => Array.isArray(x.below) && x.below.length === 1 && x.below[0] === leaf
          && Array.isArray(x.inputs) && x.inputs[0] === r.input);
        if (!o || !Array.isArray(o.outputs) || o.outputs[0] !== want) {
          jbad++;
          console.log(`  ✗ 观测 JEI 条目 ${leaf} 缺少具体产物 ${want}`);
        }
      }
      console.log(`  · ${r.input}：${leaves.length} 种落点逐个一条`);
      /* 兜底条目：落点写标签、产物写 fallback_pool（JEI 侧展开成成员） */
      const fb = (r.fallback_pool != null) ? String(r.fallback_pool) : null;
      if (fb == null) {
        jbad++; console.log(`  ✗ ${r.input} 没有 fallback_pool —— 模组树叶在 JEI 里搜不到`);
      } else {
        const g = jei.find((x) => x.input === r.input && String(x.output) === '@mapped'
          && Array.isArray(x.outputs) && x.outputs.includes(fb));
        if (!g) {
          jbad++;
          console.log(`  ✗ JEI 里缺少"落点写标签 + 产物 ${fb}"的兜底条目`);
        } else if (!Array.isArray(g.on) || !g.on.some((t) => String(t).startsWith('#'))) {
          jbad++;
          console.log('  ✗ 兜底条目的落点应当写标签（这样模组树叶才会被展开进来）');
        }
      }
    }
    /* 反向断言：JEI 里不许再出现"产物是 @mapped 占位符"的条目 */
    const placeholder = jei.filter((x) => Array.isArray(x.outputs)
      && x.outputs.some((o) => String(o).startsWith('@')));
    if (placeholder.length > 0) {
      jbad++;
      console.log('  ✗ JEI 里有 ' + placeholder.length + ' 条的产物还是 @ 占位符（JEI 画不出来）');
    }
    if (jbad === 0) {
      console.log('  ✓ 每条 @mapped 配方都按落点展开成了具体产物（含标签兜底条目）');
    } else {
      bad += jbad;
    }
  }
}

console.log(bad === 0 ? '\n✓ 资源全部合法' : `\n✗ ${bad} 个问题`);
if (bad > 0) process.exitCode = 1;
