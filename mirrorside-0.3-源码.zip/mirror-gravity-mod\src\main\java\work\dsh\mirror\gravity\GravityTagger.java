package work.dsh.mirror.gravity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 「重力方块化」机制层：把被波粒子标记过的方块按原版的规则弄下来。
 *
 * <h2>复刻的是原版哪一段</h2>
 * 1.21.1 的 {@code FallingBlock}（沙子/沙砾/混凝土粉末的统一实现）只做三件事：
 * <pre>
 *   onPlace / updateShape → level.scheduleTick(pos, this, 2)          // 邻居一变就排一次 tick
 *   tick()               → if (isFree(below) &amp;&amp; y &gt;= minBuildHeight)
 *                              FallingBlockEntity.fall(level, pos, state)
 *   isFree(state)        → 空气 || 火 || 液体 || canBeReplaced()
 * </pre>
 * 我们拿不到那个方块 tick（它按"坐标上的方块类型"派发，任意方块排了也会被丢掉），
 * 所以等价地自己做一遍：<b>邻居更新时排队 → 2 tick 后判定 → 交给同一个
 * {@code FallingBlockEntity.fall(...)}</b>。
 * 判定条件直接用原版的 {@link FallingBlock#isFree}，不自己重写谓词 ——
 * 否则"沙子能落、我们标记的方块不能落"这种差异迟早会出现。
 *
 * <h2>触发时机（三条入口，覆盖原版全部路径）</h2>
 * <ul>
 *   <li><b>右键标记时</b> —— 立刻排一次队（可能就是悬空的，得马上掉）</li>
 *   <li><b>邻居更新</b>（NeoForge 的 {@code BlockEvent.NeighborNotifyEvent}）——
 *       对应原版的 {@code updateShape}：支撑被拆掉、旁边放了水……</li>
 *   <li><b>区块加载</b>（{@code ChunkEvent.Load}）—— 区块没加载时支撑被拆掉，
 *       重新加载后必须补一次判定，否则那一格会永远悬在空中</li>
 * </ul>
 *
 * <h2>性能取舍</h2>
 * 邻居更新事件非常频繁，所以处理函数只做两件事：确认是服务端、然后在
 * 一张小哈希表里查 7 个坐标（被改的方块自己 + 6 个邻居）。
 * 表里没有就直接返回，不分配任何对象。
 */
public final class GravityTagger {

    private GravityTagger() {
    }

    /** 待判定的坐标 → 到期游戏刻。按维度分开存（同一个坐标在不同维度互不相干）。 */
    private static final Map<ResourceKey<Level>, Map<Long, Integer>> PENDING = new ConcurrentHashMap<>();

    /* ------------------------------------------------------------------ 对外入口 */

    /**
     * 给一个方块加上重力特性。
     *
     * @return 拒绝原因（{@link #validate} 的返回值），成功返回 {@code null}
     */
    public static String tag(ServerLevel level, BlockPos pos) {
        String reject = validate(level, pos);
        if (reject != null) {
            return reject;
        }
        BlockState state = level.getBlockState(pos);
        GravityTagData.get(level).put(pos, state);
        schedule(level, pos);
        /* 改造是**低频的玩家动作**（一个方块一次），所以这里打一行 INFO：
         * 排查"配方为什么没反应"时，第一件要知道的就是"这个方块到底被改造没有"。
         * 之前没有这行日志，只能靠猜 —— 实测就为此多绕了一圈。 */
        MirrorGravity.LOGGER.info("[镜维度·波粒子] 已改造 {} @ {}（本维度现有 {} 个待落）",
            state.getBlock().getName().getString(), pos, GravityTagData.get(level).size());
        return null;
    }

    /**
     * 这一格能不能被改造。客户端也会调用（用于手臂摆动的预判），所以只读。
     *
     * @return 拒绝原因代码，可以时返回 {@code null}
     */
    public static String validate(Level level, BlockPos pos) {
        if (!WaveParticleSettings.enabled()) {
            return "disabled";
        }
        if (pos.getY() < level.getMinBuildHeight() || pos.getY() >= level.getMaxBuildHeight()) {
            return "out_of_world";
        }
        BlockState state = level.getBlockState(pos);
        if (state.isAir() || state.liquid()) {
            return "not_solid";
        }
        /* 硬度 -1 = 挖不动（基岩/传送门/命令方块……）。原版 getDestroyProgress 对 -1
         * 直接返回 0，所以拿这个当"不可破坏"的判据比维护一张黑名单可靠。
         * ⚠️ 默认**放开**（用户要求"让它也能对挖不动的方块生效"）：基岩这类方块
         * 平时挖不掉，但一样可以被推下去 —— 在创造模式里这是很有意思的玩法。
         * 想恢复"只对可破坏方块生效"，把 waveParticle.allow_unbreakable 改成 false。 */
        if (!WaveParticleSettings.allowUnbreakable() && state.getDestroySpeed(level, pos) < 0.0F) {
            return "unbreakable";
        }
        if (state.hasBlockEntity() && !WaveParticleSettings.allowBlockEntities()) {
            /* 带方块实体的方块（箱子/熔炉……）默认不给：下落实体虽然能带
             * blockData，但中途被打掉时掉落的是"空箱子"，箱子里的东西会没。 */
            return "block_entity";
        }
        if (amount(level) >= WaveParticleSettings.maxTagsPerLevel()) {
            return "full";
        }
        if (level instanceof ServerLevel serverLevel
            && GravityTagData.get(serverLevel).contains(pos.asLong())) {
            return "already";
        }
        return null;
    }

    /** 已标记数量（诊断与上限判定用）。 */
    public static int amount(Level level) {
        return level instanceof ServerLevel serverLevel ? GravityTagData.get(serverLevel).size() : 0;
    }

    /* ------------------------------------------------------------------ 触发入口 */

    /**
     * 邻居更新。{@code event.getPos()} 是**引发了更新**的那一格，
     * 所以真正可能失去支撑的是它自己和它的 6 个邻居。
     *
     * <p>{@link GravityTagData#contains} 命中才 continue，绝大多数更新事件
     * 在这里就返回了。
     */
    public static void onNeighborChanged(ServerLevel level, BlockPos changedPos) {
        GravityTagData data = GravityTagData.get(level);
        /* ⚠️ 这条路径每次方块更新都会走（非常频繁），所以**不能** snapshot()，
         * 只用 contains 做常数级查表；表是空的时候连查都不查。
         * 用 MutableBlockPos 是为了不在热路径上分配 6 个 BlockPos。 */
        if (data.size() == 0) {
            return;
        }
        if (data.contains(changedPos.asLong())) {
            schedule(level, changedPos);
        }
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        for (Direction direction : Direction.values()) {
            cursor.setWithOffset(changedPos, direction);
            if (data.contains(cursor.asLong())) {
                schedule(level, cursor.immutable());
            }
        }
    }

    /** 方块被破坏：标记顺手清掉（不清也不会有脏数据，见 GravityTagData 的说明）。 */
    public static void onBlockBroken(ServerLevel level, BlockPos pos) {
        GravityTagData.get(level).remove(pos.asLong());
    }

    /** 区块加载：把落在这一区块里的标记全部补一次判定。 */
    public static void onChunkLoad(ServerLevel level, ChunkPos chunk) {
        Map<Long, BlockState> tags = GravityTagData.get(level).snapshot();
        if (tags.isEmpty()) {
            return;
        }
        for (Long key : tags.keySet()) {
            BlockPos pos = BlockPos.of(key);
            if (pos.getX() >> 4 == chunk.x && pos.getZ() >> 4 == chunk.z) {
                schedule(level, pos);
            }
        }
    }

    /**
     * 服务端每 tick：处理到期的判定。
     *
     * <p>只有"排过队"的坐标会被处理，队列通常在几个刻内就清空了 ——
     * 这里不是每 tick 扫全表。
     */
    public static void tick(MinecraftServer server) {
        if (PENDING.isEmpty()) {
            return;
        }
        for (Map.Entry<ResourceKey<Level>, Map<Long, Integer>> entry : PENDING.entrySet()) {
            ServerLevel level = server.getLevel(entry.getKey());
            Map<Long, Integer> queue = entry.getValue();
            if (level == null) {
                queue.clear();
                continue;
            }
            long now = level.getGameTime();
            List<Long> due = null;
            Iterator<Map.Entry<Long, Integer>> it = queue.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<Long, Integer> pending = it.next();
                if (pending.getValue() <= now) {
                    if (due == null) {
                        due = new ArrayList<>(4);
                    }
                    due.add(pending.getKey());
                    it.remove();
                }
            }
            if (due != null) {
                for (Long key : due) {
                    try {
                        checkAndFall(level, BlockPos.of(key));
                    } catch (Throwable t) {
                        work.dsh.mirror.gravity.internal.Failures.note("wave_particle", t);
                    }
                }
            }
        }
        /* 空掉的维度别一直留着 map。 */
        PENDING.entrySet().removeIf(e -> e.getValue().isEmpty());
    }

    /* ------------------------------------------------------------------ 内部 */

    private static void schedule(ServerLevel level, BlockPos pos) {
        PENDING.computeIfAbsent(level.dimension(), k -> new HashMap<>())
            .put(pos.asLong(), (int) (level.getGameTime() + WaveParticleSettings.fallDelayTicks()));
    }

    /**
     * 判定一格：还该不该保持原样？该掉就掉。
     *
     * <p>「只生效一次」：一旦交出去变成下落实体，标记立刻删掉，
     * 落地后的方块就是普通方块（用户选的行为）。
     */
    private static void checkAndFall(ServerLevel level, BlockPos pos) {
        GravityTagData data = GravityTagData.get(level);
        BlockState tagged = data.stateAt(pos.asLong());
        if (tagged == null) {
            return;
        }
        BlockState current = level.getBlockState(pos);
        if (!current.equals(tagged)) {
            /* 这一格已经换成别的方块（被挖了、被替换了）—— 标记作废。 */
            data.remove(pos.asLong());
            return;
        }
        if (pos.getY() < level.getMinBuildHeight()) {
            data.remove(pos.asLong());
            return;
        }
        if (!FallingBlock.isFree(level.getBlockState(pos.below()))) {
            return;                       // 还撑着，继续等下一次邻居更新
        }

        /* ★ 先把方块实体的 NBT 抓出来 —— 必须在 fall() **之前**：
         * fall() 把原位置换成空气，方块实体当场销毁，之后就再也读不到。
         *
         * 抓到后交给下落实体的 blockData：原版在落地放回方块时会把这段 NBT
         * 写进新的方块实体（FallingBlockEntity#tick 的落地分支），所以箱子里的东西、
         * 刷怪笼里的怪、试炼刷怪笼的奖励表都能原样保留。
         * 万一它中途变成掉落物，则由 FallingBlockDropMixin 给掉落物补
         * minecraft:block_entity_data 组件 —— 捡起来再摆回去内容物仍在。
         *
         * ⚠️⚠️ 必须用 saveWithId，**不能**用 saveWithoutMetadata。
         *   物品组件 minecraft:block_entity_data 的编码器是
         *   CustomData.CODEC_WITH_ID，它的校验条件是
         *       tag.contains("id", 8)     // 8 = TAG_String
         *   不满足就抛 "Missing id for entity in: {...}"。
         *   而 saveWithoutMetadata 恰恰**不含 id**（saveWithId = 它 + saveId）。
         *   实测后果（2026-09-26 用户报的崩溃）：捡起那个箱子后，
         *   玩家存档时 ItemStack.save 直接抛 IllegalStateException，
         *   整个存档流程崩掉 —— 因为带组件的物品**根本没法序列化**。
         *   落地路径不受影响（那边只是把键并进方块实体，多一个 id 无害），
         *   所以这一处一改，两条路都对。 */
        net.minecraft.nbt.CompoundTag beData = null;
        net.minecraft.world.level.block.entity.BlockEntity be = level.getBlockEntity(pos);
        if (be != null) {
            try {
                beData = be.saveWithId(level.registryAccess());
            } catch (Throwable t) {
                work.dsh.mirror.gravity.internal.Failures.note("wave_particle", t);
            }
        }

        data.remove(pos.asLong());        // 只生效一次

        /* ★ 改造期间必须**压掉容器内容物的掉落**（见 ContainerDropGuard）：
         * fall() 内部用 setBlock(空气) 清空原位，会触发 ChestBlock/BarrelBlock
         * 的 onRemove → Containers.dropContentsOnDestroy → 内容物当场爆一地，
         * 而我们又把同一段 NBT 存进了下落实体 ⇒ 落地后箱子里还有一份 ⇒ 刷物品。
         *
         * ⚠️ 只有 beData != null（真抓到了 NBT）才开这个开关：
         *    没抓到还压掉，内容物就凭空没了 —— 比刷物品更糟。 */
        boolean guard = (beData != null);
        if (guard) {
            work.dsh.mirror.gravity.internal.ContainerDropGuard.begin();
        }
        try {
            FallingBlockEntity entity = FallingBlockEntity.fall(level, pos, tagged);
            if (beData != null && entity != null) {
                entity.blockData = beData;
            }
        } finally {
            if (guard) {
                work.dsh.mirror.gravity.internal.ContainerDropGuard.end();
            }
        }
    }
}
