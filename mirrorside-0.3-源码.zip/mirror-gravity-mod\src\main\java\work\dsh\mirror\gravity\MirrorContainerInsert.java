package work.dsh.mirror.gravity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.DecoratedPotBlockEntity;
import org.jetbrains.annotations.Nullable;

/**
 * 镜维度 · 「让落下来的方块把物品放进容器」的机制。
 *
 * <h2>用途（设定里那两条配方）</h2>
 * <pre>
 *   可疑的沙砾 / 可疑的沙子 —— 重力切换 4 次 + 落在陶罐上
 *     → 变成煤炭块，同时往陶罐里塞一个"刷子刷出来的物品"
 * </pre>
 *
 * <h2>判定规则：照抄原版往陶罐里放物品的那一段</h2>
 * {@code DecoratedPotBlock#useItemOn} 里的条件是：
 * <pre>
 *   held 非空 &amp;&amp; ( 罐子是空的
 *                || 罐子里是同一种物品（含组件相同） &amp;&amp; 数量 &lt; 该物品的最大堆叠 )
 * </pre>
 * 放入之后原版还做三件事，这里一并照做，观感才与"自己用手放进去"一致：
 * <ol>
 *   <li>{@code wobble(POSITIVE)} —— 罐子晃一下</li>
 *   <li>播 {@code DECORATED_POT_INSERT}，音高随装入比例变化
 *       （{@code 0.7 + 0.5 × 装入比例}）</li>
 *   <li>在罐口打 7 个 {@code DUST_PLUME} 粒子</li>
 * </ol>
 *
 * <h2>为什么做成"任意容器"而不是只认陶罐</h2>
 * 模组这边只依赖 {@link Container} 这个原版接口，所以箱子、漏斗、木桶……
 * 任何实现了它的方块实体会自动可用；陶罐只是其中被 {@code ContainerSingleItem}
 * 特化的那一种。规则统一为：
 * <pre>
 *   先在已有同类物品的槽位里叠加，再找空槽位；都没有就失败
 * </pre>
 * 对单槽的陶罐来说，这与原版规则完全等价。
 *
 * <h2>接口</h2>
 * KubeJS 侧通过 {@link MirrorGravityApi#canInsertIntoContainer} 先问
 * "装得下吗"，再决定要不要把下落的方块换成产物 —— 先问后做，
 * 容器满了就不会白扔一个物品进去。
 */
public final class MirrorContainerInsert {

    private MirrorContainerInsert() {
    }

    /**
     * 把 ID 解析成物品堆。支持两种写法：
     *
     * <ul>
     *   <li>纯物品 ID：{@code minecraft:oak_sapling} —— 按 {@code count} 造普通物品堆</li>
     *   <li><b>物品堆 JSON</b>（以 <code>{</code> 开头）：原版 {@link ItemStack#CODEC} 的形态，
     *       例如山羊角要指定乐器：
     *       <pre>{"id":"minecraft:goat_horn","count":1,
     *  "components":{"minecraft:instrument":"minecraft:ponder_goat_horn"}}</pre>
     *       写这条是为了"骨块 → 山羊角（8 种随机之一）"那个配方 ——
     *       8 种山羊角是**同一个物品 + 不同的乐器组件**，只给物品 ID 是表达不出来的。</li>
     * </ul>
     *
     * @return 解析失败返回 {@link ItemStack#EMPTY}
     */
    public static ItemStack resolveStack(String itemId, int count) {
        return resolveStack(itemId, count, null);
    }

    /**
     * 带注册表访问的版本。
     *
     * <p>⚠️ {@code components} 里只要有**注册表项**（例如
     * {@code minecraft:instrument} = 山羊角乐器），就**必须**用
     * {@link net.minecraft.resources.RegistryOps} 解析 —— 裸的
     * {@link com.mojang.serialization.JsonOps} 没有注册表查找能力，
     * 整条规格书会直接解析失败。实测就栽在这里：
     * 骨块→山羊角的 8 条候选全部"物品堆 JSON 解析失败"，
     * 而把规格书里唯一"特殊"的东西去掉（组件）就能过。
     *
     * @param registries 注册表访问（一般传 {@code serverLevel.registryAccess()}）；
     *                   为 null 时退化为纯 JSON 解析（只能处理不含注册表组件的规格书）
     */
    public static ItemStack resolveStack(String itemId, int count,
                                         @Nullable HolderLookup.Provider registries) {
        if (itemId == null || itemId.isBlank()) {
            return ItemStack.EMPTY;
        }
        String spec = itemId.trim();
        if (spec.startsWith("{")) {
            return resolveFromJson(spec, registries);
        }
        ResourceLocation rl = ResourceLocation.tryParse(spec);
        if (rl == null) {
            MirrorGravity.LOGGER.warn("[镜维度·容器] 物品 ID 非法: {}", itemId);
            return ItemStack.EMPTY;
        }
        net.minecraft.world.item.Item item = BuiltInRegistries.ITEM.get(rl);
        if (item == null || item == Items.AIR) {
            MirrorGravity.LOGGER.warn("[镜维度·容器] 找不到物品: {}", itemId);
            return ItemStack.EMPTY;
        }
        return new ItemStack(item, Math.max(1, count));
    }

    /**
     * 解析物品堆 JSON。用原版 {@link ItemStack#CODEC} + {@code JsonOps}，
     * 不自己拼 NBT —— 组件的格式随版本变，跟着原版编解码走最省事。
     *
     * <p>解析不出来就返回空堆并打一条 warning：调用方会把"没掉落"当成失败处理，
     * 不会出现"东西凭空没了"。
     *
     * <p>（{@link #resolveStack} 才是对外的入口：它两种形态都认，
     * 纯物品 id 与物品堆 JSON 都会转到这里。）
     */
    private static ItemStack resolveFromJson(String spec, @Nullable HolderLookup.Provider registries) {
        try {
            com.google.gson.JsonElement json = com.google.gson.JsonParser.parseString(spec);
            normalizeNumbers(json);
            /* ⚠️ 有注册表就一定要用 RegistryOps：组件里可能引用注册表项
             * （乐器、附魔、药水效果……），裸 JsonOps 解析不了。 */
            com.mojang.serialization.DynamicOps<com.google.gson.JsonElement> ops =
                (registries != null)
                    ? net.minecraft.resources.RegistryOps.create(com.mojang.serialization.JsonOps.INSTANCE, registries)
                    : com.mojang.serialization.JsonOps.INSTANCE;
            com.mojang.serialization.DataResult<ItemStack> result =
                ItemStack.CODEC.parse(ops, json);
            ItemStack stack = result.result().orElse(ItemStack.EMPTY);
            if (stack.isEmpty()) {
                /* 把真正的原因打出来 —— 之前只写"解析失败"，排查时还得自己猜。 */
                MirrorGravity.LOGGER.warn("[镜维度·容器] 物品堆 JSON 解析失败: {}　（原因: {}；注册表{}）",
                    spec,
                    result.error().map(com.mojang.serialization.DataResult.Error::message).orElse("未知"),
                    registries != null ? "可用" : "**不可用**（含注册表组件的规格书必然失败）");
            }
            return stack;
        } catch (Throwable t) {
            MirrorGravity.LOGGER.warn("[镜维度·容器] 物品堆 JSON 不是合法 JSON: {} ({})",
                spec, t.toString());
            return ItemStack.EMPTY;
        }
    }

    /**
     * 把物品堆 JSON 里的数值字段归一化：{@code count} 取整。
     *
     * <h2>为什么需要</h2>
     * 脚本侧（Rhino）序列化对象时会把整数写成 {@code 1.0}，而
     * {@link ItemStack#CODEC} 的 {@code count} 是 int ⇒ 解析直接失败。
     * 实测症状：骨块→山羊角那条配方**触发了 7 次、每次都"生成失败"**，
     * 方块一直在往复、什么都不掉，日志里只有一行
     * {@code {"id":"minecraft:goat_horn","count":1.0,...}}。
     *
     * <p>脚本侧已经改成手工拼整数了，这里再兜一道：任何来源的规格书都能吃。
     */
    private static void normalizeNumbers(com.google.gson.JsonElement json) {
        if (json == null || !json.isJsonObject()) {
            return;
        }
        com.google.gson.JsonObject obj = json.getAsJsonObject();
        com.google.gson.JsonElement count = obj.get("count");
        if (count != null && count.isJsonPrimitive()
            && count.getAsJsonPrimitive().isNumber()) {
            obj.addProperty("count", (int) count.getAsDouble());
        }
    }

    /** 目标位置上有没有可用的容器方块实体。 */
    @Nullable
    public static Container containerAt(ServerLevel level, BlockPos pos) {
        if (level == null || pos == null) {
            return null;
        }
        BlockEntity be = level.getBlockEntity(pos);
        return (be instanceof Container container) ? container : null;
    }

    /**
     * 找能放下这一堆的槽位：先找同类可叠加的，再找空槽。
     *
     * @return 槽位序号；放不下返回 -1
     */
    private static int findSlot(Container container, ItemStack stack) {
        int size = container.getContainerSize();
        for (int i = 0; i < size; i++) {
            ItemStack slot = container.getItem(i);
            if (slot.isEmpty()) {
                return i;
            }
            if (ItemStack.isSameItemSameComponents(slot, stack)
                && slot.getCount() < Math.min(slot.getMaxStackSize(), container.getMaxStackSize())) {
                return i;
            }
        }
        return -1;
    }

    /** 装得下吗（不做任何修改）。KubeJS 用它决定要不要触发配方。 */
    public static boolean canInsert(ServerLevel level, BlockPos pos, ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        Container container = containerAt(level, pos);
        return container != null && findSlot(container, stack) >= 0;
    }

    /**
     * 真的放进去，并做出与原版一致的反馈。
     *
     * @return 是否成功放入
     */
    public static boolean insert(ServerLevel level, BlockPos pos, ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        Container container = containerAt(level, pos);
        if (container == null) {
            return false;
        }
        int slot = findSlot(container, stack);
        if (slot < 0) {
            /* 装不下：陶罐会晃一下并播"放不进去"的音效（原版行为）。 */
            if (container instanceof DecoratedPotBlockEntity pot) {
                pot.wobble(DecoratedPotBlockEntity.WobbleStyle.NEGATIVE);
                level.playSound(null, pos, SoundEvents.DECORATED_POT_INSERT_FAIL,
                    SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return false;
        }

        ItemStack existing = container.getItem(slot);
        ItemStack after;
        if (existing.isEmpty()) {
            after = stack.copy();
            container.setItem(slot, after);
        } else {
            existing.grow(stack.getCount());
            after = existing;
            container.setItem(slot, existing);   // 显式回写，兼容不跟踪就地修改的实现
        }
        container.setChanged();

        if (container instanceof DecoratedPotBlockEntity pot) {
            pot.wobble(DecoratedPotBlockEntity.WobbleStyle.POSITIVE);
            float fill = after.getCount() / (float) Math.max(1, after.getMaxStackSize());
            level.playSound(null, pos, SoundEvents.DECORATED_POT_INSERT,
                SoundSource.BLOCKS, 1.0F, 0.7F + 0.5F * fill);
            level.sendParticles(ParticleTypes.DUST_PLUME,
                pos.getX() + 0.5D, pos.getY() + 1.2D, pos.getZ() + 0.5D,
                7, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        return true;
    }
}
