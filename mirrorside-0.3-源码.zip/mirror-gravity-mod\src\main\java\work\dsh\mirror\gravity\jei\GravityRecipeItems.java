package work.dsh.mirror.gravity.jei;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import work.dsh.mirror.gravity.MirrorGravity;

import java.util.ArrayList;
import java.util.List;

/**
 * 「配置里写的落点 / 产物」→「JEI 槽位能画的物品堆」。
 *
 * <h2>为什么要单独一层</h2>
 * 配置里的落点与产物有两种写法：
 * <pre>
 *   minecraft:black_stained_glass   具体方块
 *   #c:storage_blocks               方块**标签**（NeoForge 通用标签、原版标签都行）
 * </pre>
 * 标签是这套设定里最重要的表达："铁砧落在**任意**矿物块/金属块上"。
 * 早先的做法是把标签写成一句文字（"落在矿物块上"），于是
 * <b>JEI 搜不到这条配方</b> —— JEI 只索引真实物品。
 *
 * <p>现在把标签在**展示时**展开成它包含的所有方块（转成物品形式），
 * 全塞进同一个槽位：JEI 会在槽内循环显示，并且**每个**成员都能搜到这条配方。
 *
 * <h2>为什么在 setRecipe 里解析、而不是启动时解析一次</h2>
 * 标签内容是数据包加载后才确定的（NeoForge 与其它模组的标签都在数据包里）。
 * 版面绘制发生在世界/数据包就绪之后，这时解析必然拿得到；
 * 顺带还能跟着 {@code /reload} 更新，不会留一份过期快照。
 */
final class GravityRecipeItems {

    private GravityRecipeItems() {
    }

    /** 解析一组写法（ID 或 {@code #标签}），按原顺序展开、去重。 */
    static List<ItemStack> resolveAll(List<String> specs, int count) {
        List<ItemStack> out = new ArrayList<>();
        if (specs == null) {
            return out;
        }
        for (String spec : specs) {
            for (ItemStack stack : resolveOne(spec)) {
                if (count > 1) {
                    stack.setCount(Math.min(count, stack.getMaxStackSize()));
                }
                // 去重：一个方块既可能被具体列出、又可能同时属于某个列出的标签
                boolean dup = false;
                for (ItemStack seen : out) {
                    if (ItemStack.isSameItemSameComponents(seen, stack)) {
                        dup = true;
                        break;
                    }
                }
                if (!dup) {
                    out.add(stack);
                }
            }
        }
        return out;
    }

    /** 解析单个写法：{@code #标签} 展开成标签内全部方块，否则就是那一个物品。 */
    static List<ItemStack> resolveOne(String spec) {
        if (spec == null || spec.isBlank()) {
            return List.of();
        }
        String s = spec.trim();
        if (s.startsWith("#")) {
            return resolveTag(s.substring(1));
        }
        ItemLike item = lookupItem(s);
        return item == null ? List.of() : List.of(new ItemStack(item));
    }

    /**
     * 方块标签 → 物品堆列表。
     *
     * <p>用**方块**注册表查标签（配置里写的都是方块，例如
     * {@code #minecraft:leaves}、{@code #c:storage_blocks}），再经
     * {@code Block#asItem} 转成物品形式 —— 这样 JEI 的槽位画的是方块物品，
     * 与玩家背包里的东西是同一个。
     * 少数方块没有对应物品（空气、火、绊线一类）会被自动跳过。
     */
    private static List<ItemStack> resolveTag(String rawTag) {
        List<ItemStack> out = new ArrayList<>();
        ResourceLocation rl = ResourceLocation.tryParse(rawTag);
        if (rl == null) {
            MirrorGravity.LOGGER.debug("[镜维度·JEI] 标签 ID 非法: #{}", rawTag);
            return out;
        }
        try {
            TagKey<Block> key = TagKey.create(Registries.BLOCK, rl);
            for (Holder<Block> holder : BuiltInRegistries.BLOCK.getTagOrEmpty(key)) {
                Block block = holder.value();
                if (block == null) {
                    continue;
                }
                var item = block.asItem();
                if (item == null || item == Items.AIR) {
                    continue;
                }
                out.add(new ItemStack(item));
            }
            if (out.isEmpty()) {
                MirrorGravity.LOGGER.debug(
                    "[镜维度·JEI] 方块标签 #{} 里没有可展示的物品（标签不存在？）", rawTag);
            }
            return out;
        } catch (Throwable t) {
            MirrorGravity.LOGGER.debug("[镜维度·JEI] 解析标签 #{} 失败: {}", rawTag, t.toString());
            return out;
        }
    }

    /** 注册表查询，任何异常都吞掉并返回 null（展示功能不该影响游戏）。 */
    private static ItemLike lookupItem(String id) {
        if (id == null) {
            return null;
        }
        try {
            ResourceLocation rl = ResourceLocation.tryParse(id);
            if (rl == null) {
                return null;
            }
            var item = BuiltInRegistries.ITEM.get(rl);
            // get() 找不到时返回 AIR，这里要显式排除
            if (item == null || item == Items.AIR) {
                MirrorGravity.LOGGER.debug("[镜维度·JEI] 找不到物品 {}，该槽位留空", id);
                return null;
            }
            return item;
        } catch (Throwable t) {
            return null;
        }
    }
}
