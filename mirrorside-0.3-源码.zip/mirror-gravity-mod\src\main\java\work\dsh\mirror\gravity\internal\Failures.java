package work.dsh.mirror.gravity.internal;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 镜维度 · **静默失败收集器**（0.3 新增）。
 *
 * <h2>为什么需要它</h2>
 * 本模组（以及配套脚本）里有大量"兜底 catch"：物理接管失败不能影响主流程、
 * 诊断失败不能影响渲染、反射写字段失败还有别的路子……这些兜底是对的，
 * 但它们同时会把**真正的 bug** 一起吞掉。
 *
 * <p>本项目已经因此踩过两次大坑（都在脚本侧，症状一模一样：
 * "配置写了却没反应，而日志一片正常"）。模组侧有 10 处同类兜底，
 * 任何一处将来都可能变成第三次。
 *
 * <h2>怎么做</h2>
 * 不能简单地在每个 catch 里打日志 —— 有些在每 tick / 每实体的热路径上，会刷屏。
 * 所以这里只做两件事：
 * <ol>
 *   <li><b>计数</b>：每类失败累加一个数（几乎零成本）；</li>
 *   <li><b>留现场</b>：每类只留前 {@link #KEEP} 条，并且**每条只打一次 WARN 日志**。</li>
 * </ol>
 * 于是"静默失败"变成可观测的：{@code /mirror diag} 会把这个读数打出来
 * （脚本侧同名的收集器在 {@code mirror_n0_foundation.js}，两边一起显示）。
 *
 * <p>用法：{@code catch (Throwable t) { Failures.note("BlockPhysics.tick", t); }}
 * —— 加这一行**不改变任何控制流**。
 */
public final class Failures {

    /** 每类最多保留几条现场（与脚本侧 FAIL_KEEP 保持一致）。 */
    private static final int KEEP = 3;

    private static final Map<String, AtomicInteger> COUNTS = new ConcurrentHashMap<>();
    private static final Map<String, List<String>> SAMPLES = new ConcurrentHashMap<>();

    private Failures() {
    }

    /**
     * 记一次"被吞掉的失败"。
     *
     * @param tag 出问题的位置（建议 {@code 类名.方法名}），同时用作分类键
     * @param t   被吞掉的异常（可为 null）
     */
    public static void note(String tag, Throwable t) {
        try {
            String key = (tag == null || tag.isEmpty()) ? "unknown" : tag;
            int n = COUNTS.computeIfAbsent(key, k -> new AtomicInteger()).incrementAndGet();
            String msg = describe(t);
            if (n <= KEEP) {
                SAMPLES.computeIfAbsent(key, k -> new ArrayList<>()).add(msg);
            }
            /* 只在第一次出现时打一条 WARN —— 既能看到原因，又不会刷屏。 */
            if (n == 1) {
                work.dsh.mirror.gravity.MirrorGravity.LOGGER.warn(
                    "[镜维度·失败] {}: {}（这一类只提示一次，完整计数见 /mirror diag）",
                    key, msg);
            }
        } catch (Throwable ignored) {
            // 收集器自己绝不能把主流程弄挂
        }
    }

    /** 失败总数（所有类别相加）。 */
    public static int total() {
        int sum = 0;
        for (AtomicInteger v : COUNTS.values()) {
            sum += v.get();
        }
        return sum;
    }

    /**
     * 一行摘要 + 现场明细，给 {@code /mirror diag} 用。
     *
     * @return 例如 {@code "合计 2（BlockPhysics.tick=2）"}；无失败时返回 {@code "合计 0"}
     */
    public static String report() {
        StringBuilder sb = new StringBuilder();
        int total = total();
        sb.append("合计 ").append(total);
        if (total == 0) {
            return sb.toString();
        }
        /* 按类名排序，读数稳定可比 */
        Map<String, Integer> sorted = new LinkedHashMap<>();
        COUNTS.entrySet().stream()
            .sorted(Map.Entry.comparingByKey())
            .forEach(e -> sorted.put(e.getKey(), e.getValue().get()));
        sb.append('（');
        boolean first = true;
        for (Map.Entry<String, Integer> e : sorted.entrySet()) {
            if (!first) {
                sb.append("，");
            }
            sb.append(e.getKey()).append('=').append(e.getValue());
            first = false;
        }
        sb.append('）');
        for (Map.Entry<String, List<String>> e : SAMPLES.entrySet()) {
            sb.append('\n').append("      ").append(e.getKey()).append(": ");
            sb.append(String.join(" | ", e.getValue()));
        }
        return sb.toString();
    }

    /** 清空计数（重新加载脚本后想从零观察时用）。 */
    public static void reset() {
        COUNTS.clear();
        SAMPLES.clear();
    }

    private static String describe(Throwable t) {
        if (t == null) {
            return "(null)";
        }
        String m = t.getMessage();
        String s = t.getClass().getSimpleName() + (m == null ? "" : (": " + m));
        return s.length() > 160 ? s.substring(0, 160) : s;
    }
}
