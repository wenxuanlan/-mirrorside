package work.dsh.mirror.gravity.internal;

/**
 * "正在把方块改造成下落实体"的开关（给 mixin 用）。
 *
 * <h2>它解决什么问题</h2>
 * {@code FallingBlockEntity.fall(level, pos, state)} 内部用
 * {@code level.setBlock(pos, 空气, 3)} 把原位清空 —— 这一步会触发
 * {@code Block#onRemove}，而原版**箱子与木桶**在 {@code onRemove} 里调了
 * {@code Containers.dropContentsOnDestroy(...)}：内容物**当场爆一地**。
 *
 * <p>我们同时又把这段方块实体 NBT 存进了下落实体的 {@code blockData}
 * （落地会原样写回去），于是就成了：地上掉一份、落地后的箱子里还有一份 ——
 * 等于刷物品。用户实测报的就是这个。
 *
 * <h2>为什么用"开关 + mixin"而不是别的办法</h2>
 * <ul>
 *   <li>不能改调用顺序：{@code fall()} 里那次 setBlock 是原版写死的。</li>
 *   <li>不能整体禁掉 {@code dropContentsOnDestroy}：玩家正常挖箱子
 *       必须照旧掉内容物，那是原版行为。</li>
 *   <li>所以只在**我们自己那一次 fall()** 期间把这条掉落压掉，
 *       范围最小、语义最清楚。</li>
 * </ul>
 *
 * <h2>⚠️ 只有"确实抓到了 NBT"才允许打开</h2>
 * 打开开关等于"内容物不会掉在地上" —— 如果 NBT 没抓到（读方块实体抛异常、
 * 或者方块实体类型不被支持），再压掉就是**东西凭空消失**，比刷物品更糟。
 * 所以 {@code GravityTagger} 只在抓取成功时才 {@link #begin()}，
 * 抓不到就让原版照常掉。
 *
 * <h2>线程</h2>
 * 只在服务端主线程上使用（方块改造都发生在服务端 tick 里），
 * 所以用一个普通静态字段 + 重入计数即可，不需要加锁。
 */
public final class ContainerDropGuard {

    /** 重入计数：将来若出现嵌套调用（一个改造触发另一个），也不会提前关掉。 */
    private static int depth = 0;

    private ContainerDropGuard() {
    }

    /** 进入"正在改造"区间。必须与 {@link #end()} 配对（用 try/finally）。 */
    public static void begin() {
        depth++;
    }

    /** 离开"正在改造"区间。 */
    public static void end() {
        if (depth > 0) {
            depth--;
        }
    }

    /** 现在是否处于"正在改造"区间。 */
    public static boolean active() {
        return depth > 0;
    }
}
