#!/usr/bin/env node
/**
 * 读取「结构方块保存的 .nbt」并打印内容 —— 尺寸、调色板、以及**逐块坐标**。
 *
 * ── 为什么需要它 ─────────────────────────────────────────────────────────────
 * 用户用结构方块做多方块结构（例如 boli1「波粒观测」），我要据此写机制代码，
 * 就必须知道：它多大、用了哪些方块、**每个方块落在哪个坐标**、
 * 结构原点和玩家摆放时的朝向是什么关系。这些光靠听描述会错。
 *
 * 小结构（几百字节）直接逐块打印；大结构只打印统计 + 每层的方块数，
 * 免得刷屏（涂色结构 spinning_colors 那种 5000+ 格的）。
 *
 * 用法：
 *   node tools-build/inspect-structure.mjs <结构.nbt 路径> [--all]
 *   node tools-build/inspect-structure.mjs            # 不带参数时列出存档里所有结构
 * 退出码：读失败非 0。
 */
import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { join } from 'node:path';

const SAVES = 'D:\\DSHwork\\MC镜维度\\.minecraft\\versions\\镜维度\\saves';

/* ------------------------------------------------------------------ NBT 读取 */

class R {
  constructor(b) { this.b = b; this.i = 0; }
  u1() { return this.b[this.i++]; }
  i1() { return this.b.readInt8(this.i++); }
  i2() { const v = this.b.readInt16BE(this.i); this.i += 2; return v; }
  i4() { const v = this.b.readInt32BE(this.i); this.i += 4; return v; }
  i8() { const v = this.b.readBigInt64BE(this.i); this.i += 8; return v; }
  f4() { const v = this.b.readFloatBE(this.i); this.i += 4; return v; }
  f8() { const v = this.b.readDoubleBE(this.i); this.i += 8; return v; }
  str() { const n = this.b.readUInt16BE(this.i); this.i += 2; const s = this.b.toString('utf8', this.i, this.i + n); this.i += n; return s; }
  bytes(n) { const s = this.b.subarray(this.i, this.i + n); this.i += n; return s; }
}

function payload(r, t) {
  switch (t) {
    case 1: return r.i1();
    case 2: return r.i2();
    case 3: return r.i4();
    case 4: return r.i8();
    case 5: return r.f4();
    case 6: return r.f8();
    case 7: { const n = r.i4(); return r.bytes(n); }
    case 8: return r.str();
    case 9: { const it = r.u1(); const n = r.i4(); const o = []; for (let k = 0; k < n; k++) o.push(payload(r, it)); return o; }
    case 10: { const o = {}; for (;;) { const tt = r.u1(); if (tt === 0) break; const nm = r.str(); o[nm] = payload(r, tt); } return o; }
    case 11: { const n = r.i4(); const o = []; for (let k = 0; k < n; k++) o.push(r.i4()); return o; }
    case 12: { const n = r.i4(); const o = []; for (let k = 0; k < n; k++) o.push(r.i8()); return o; }
    default: throw new Error('未知 NBT 类型 ' + t);
  }
}

function readNbt(path) {
  const raw = readFileSync(path);
  // 结构文件是 gzip 压缩的；极少数情况下是裸 NBT
  const buf = (raw[0] === 0x1f && raw[1] === 0x8b) ? gunzipSync(raw) : raw;
  const r = new R(buf);
  const t = r.u1();
  if (t !== 10) throw new Error('根标签不是 Compound（类型 ' + t + '）');
  r.str();                       // 根名字，通常空
  return payload(r, 10);
}

/* ------------------------------------------------------------------ 报告 */

function listStructures() {
  const out = [];
  for (const save of readdirSync(SAVES)) {
    const dir = join(SAVES, save, 'generated');
    if (!existsSync(dir)) continue;
    const walk = (d, rel) => {
      for (const e of readdirSync(d)) {
        const p = join(d, e);
        if (statSync(p).isDirectory()) walk(p, rel + e + '/');
        else if (e.endsWith('.nbt')) out.push({ save, rel: rel + e, path: p, size: statSync(p).size });
      }
    };
    walk(dir, '');
  }
  return out;
}

const args = process.argv.slice(2);
const target = args.find((a) => !a.startsWith('--'));
const showAll = args.includes('--all');

if (!target) {
  console.log('存档里的结构文件：');
  for (const s of listStructures()) {
    console.log(`  ${s.save.padEnd(14)} ${s.rel.padEnd(50)} ${s.size}B`);
  }
  console.log('\n用法：node tools-build/inspect-structure.mjs "<上面的路径>" [--all]');
  process.exit(0);
}

const path = existsSync(target) ? target : (listStructures().find((s) => s.rel.includes(target)) ?? {}).path;
if (!path || !existsSync(path)) {
  console.error('找不到结构文件: ' + target);
  process.exit(1);
}

const nbt = readNbt(path);
const size = nbt.size;
const palette = nbt.palette ?? [];
const blocks = nbt.blocks ?? [];
console.log(`结构: ${path}`);
console.log(`  尺寸: ${size[0]} × ${size[1]} × ${size[2]}   方块条目: ${blocks.length}`);
console.log(`  DataVersion: ${nbt.DataVersion}`);
console.log(`  实体: ${(nbt.entities ?? []).length}   调色板: ${palette.length} 项`);

const nameOf = (b) => {
  const p = palette[b.state] ?? {};
  return p.Name + (Object.keys(p).length > 1
    ? '[' + Object.entries(p).filter(([k]) => k !== 'Name').map(([k, v]) => `${k}=${v}`).join(',') + ']'
    : '');
};

/* 去重统计 */
const counts = new Map();
for (const b of blocks) counts.set(nameOf(b), (counts.get(nameOf(b)) ?? 0) + 1);
console.log('\n  调色板用量：');
for (const [n, c] of [...counts.entries()].sort((a, b) => b[1] - a[1])) {
  console.log(`    ${String(c).padStart(5)}  ${n}`);
}

/* 逐层统计（y 是结构内坐标，0 起） */
console.log('\n  逐层（y = 结构内坐标，0 是最底层）：');
for (let y = 0; y < size[1]; y++) {
  const layer = blocks.filter((b) => b.pos[1] === y);
  const solid = layer.filter((b) => !nameOf(b).endsWith('minecraft:air'));
  console.log(`    y=${String(y).padStart(3)}  条目 ${String(layer.length).padStart(4)}  非空气 ${String(solid.length).padStart(4)}`
    + (solid.length && solid.length <= 12 ? '   ' + solid.map((b) => `(${b.pos[0]},${b.pos[2]})${nameOf(b).replace('minecraft:', '')}`).join(' ') : ''));
}

/* 小结构：逐块列出非空气方块 */
const solidAll = blocks.filter((b) => !nameOf(b).endsWith('minecraft:air'));
if (solidAll.length <= 200 || showAll) {
  console.log('\n  非空气方块（逐块）：');
  for (const b of solidAll.sort((a, b) => a.pos[1] - b.pos[1] || a.pos[0] - b.pos[0] || a.pos[2] - b.pos[2])) {
    console.log(`    (${String(b.pos[0]).padStart(3)},${String(b.pos[1]).padStart(3)},${String(b.pos[2]).padStart(3)})  ${nameOf(b)}`);
  }
} else {
  console.log(`\n  （非空气方块 ${solidAll.length} 个，太多不逐块列出；加 --all 强制列出）`);
}
