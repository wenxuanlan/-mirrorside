#!/usr/bin/env node
/**
 * 镜维度 · 波粒观测自检
 * =====================================================================
 * 这个机制有**三份必须一致**的东西，且每一份漂移了都不会报错：
 *
 *   A. mirror_config.js 的 observation.pattern（结构的唯一真相）
 *   B. MirrorObservation.java 里那份**兜底结构**（脚本没推送时用）
 *      —— 漂移的表现是"推送失败时结构和配置不一样"，极难发现
 *   C. 脚本调用的模组 API（MG.observationProbe 之类）
 *      —— 方法名写错的表现是"右键没反应"，日志里只有一行 undefined
 *
 * 另外还要核对：
 *   D. 结构里的方块 id 在版本 jar 里真的存在
 *   E. 配色族表与 jar 一致（16 种颜色一个不少），且族是按后缀分的
 *   F. 专用配方齐全（用户点名的 4 条），产物 id 存在
 *
 * 退出码：全过 0，否则 1。
 */
import { readFileSync, existsSync } from 'node:fs';

const ROOT = 'D:\\DSHwork\\MC镜维度';
const CFG = ROOT + '\\.minecraft\\versions\\镜维度\\kubejs\\startup_scripts\\mirror_config.js';
const N10 = ROOT + '\\.minecraft\\versions\\镜维度\\kubejs\\server_scripts\\mirror_n10_observation.js';
const N3 = ROOT + '\\.minecraft\\versions\\镜维度\\kubejs\\server_scripts\\mirror_n3_recipes.js';
const JAVA = ROOT + '\\mirror-gravity-mod\\src\\main\\java\\work\\dsh\\mirror\\gravity\\MirrorObservation.java';
const API = ROOT + '\\mirror-gravity-mod\\src\\main\\java\\work\\dsh\\mirror\\gravity\\MirrorGravityApi.java';
const JAR = ROOT + '\\.minecraft\\versions\\镜维度\\镜维度.jar';

let bad = 0;
const ok = (m) => console.log('  ✓ ' + m);
const fail = (m) => { bad++; console.log('  ✗ ' + m); };

/* 读 zip 中央目录，列出条目名（与 derive-gravity-recipes.mjs 同一套判据）。 */
function zipNames(path) {
  const buf = readFileSync(path);
  let eocd = -1;
  const from = Math.max(0, buf.length - 66000);
  for (let i = buf.length - 22; i >= from; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd === -1) throw new Error('不是合法 zip: ' + path);
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const names = [];
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) break;
    const n = buf.readUInt16LE(p + 28);
    const e = buf.readUInt16LE(p + 30);
    const c = buf.readUInt16LE(p + 32);
    names.push(buf.toString('utf8', p + 46, p + 46 + n));
    p += 46 + n + e + c;
  }
  return names;
}

/* 配置：整份跑一遍（与 check-param-parity.mjs 同样的读法）。 */
const cfg = new Function(
  readFileSync(CFG, 'utf8').replace(/^\s*(const|let)\s+/gm, 'var ') + '\n; return MIRROR_CONFIG;')();
const OBS = cfg.observation;
if (OBS == null) {
  console.error('✗ mirror_config.js 里没有 observation 段');
  process.exit(1);
}

console.log('=== A. 结构定义（配置）===');

/* pattern：'3,3,5,1,1,2|格子...' */
const segs = String(OBS.pattern).split('|');
const head = segs[0].split(',').map((s) => parseInt(s.trim(), 10));
if (head.length < 6) fail('头段应写 包围盒sx,sy,sz,靶心tx,ty,tz，实得 ' + segs[0]);
const [sx, sy, sz, tx, ty, tz] = head;
console.log(`  包围盒 ${sx}×${sy}×${sz}，靶心 (${tx},${ty},${tz})`);
if (tx < 0 || tx >= sx || ty < 0 || ty >= sy || tz < 0 || tz >= sz) {
  fail('靶心不在包围盒里');
}
if (!(sx === 3 && sy === 3 && sz === 5)) {
  fail(`包围盒应为 3×3×5（boli1 的实测尺寸），实得 ${sx}×${sy}×${sz}`);
}

const cfgCells = [];
for (let i = 1; i < segs.length; i++) {
  const f = segs[i].split(',');
  if (f.length !== 4) { fail('格子应写 x,y,z,方块id：' + segs[i]); continue; }
  cfgCells.push({
    x: parseInt(f[0], 10), y: parseInt(f[1], 10), z: parseInt(f[2], 10),
    id: f[3].trim(),
    dx: parseInt(f[0], 10) - tx, dy: parseInt(f[1], 10) - ty, dz: parseInt(f[2], 10) - tz,
  });
}
console.log(`  结构内共 ${cfgCells.length} 格（boli1.nbt 里非空气方块应为 21 格）`);
if (cfgCells.length !== 21) fail(`结构格数应为 21，实得 ${cfgCells.length}`);

/* 每一格的坐标必须在包围盒内 */
for (const c of cfgCells) {
  if (c.x < 0 || c.x >= sx || c.y < 0 || c.y >= sy || c.z < 0 || c.z >= sz) {
    fail(`格子 (${c.x},${c.y},${c.z}) 超出包围盒`);
  }
}

/* 按方块种类数一遍 —— 这是从 boli1.nbt 实测出来的构成，改结构必然要动这里 */
const byId = {};
for (const c of cfgCells) byId[c.id] = (byId[c.id] || 0) + 1;
const EXPECT = {
  'mirrorgravity:wave_particle_block': 4,
  'minecraft:verdant_froglight': 8,
  'minecraft:budding_amethyst': 8,
  'minecraft:small_amethyst_bud': 1,
};
for (const id in EXPECT) {
  const got = byId[id] || 0;
  if (got === EXPECT[id]) ok(`${id} × ${got}`);
  else fail(`${id} 应为 ${EXPECT[id]} 个，实得 ${got}`);
}
for (const id in byId) {
  if (EXPECT[id] === undefined) fail(`结构里出现了 boli1 里没有的方块: ${id} × ${byId[id]}`);
}

/* 靶心与靶心正下方**不**在结构里：前者放要观测的方块，后者放"接触面" */
const cellSet = new Set(cfgCells.map((c) => c.x + ',' + c.y + ',' + c.z));
if (cellSet.has(`${tx},${ty},${tz}`)) fail('靶心那一格不该写进结构（它要放被观测的方块）');
if (cellSet.has(`${tx},${ty - 1},${tz}`)) fail('靶心正下方那一格不该写进结构（放什么都行）');
ok('靶心与靶心正下方都不受结构约束');

/* 唯一不对称的那一格：小块紫水晶芽。四向旋转匹配的前提就是"整座一起转" */
const budOffset = (() => {
  const c = cfgCells.find((one) => one.id === 'minecraft:small_amethyst_bud');
  return c ? [c.dx, c.dy, c.dz] : null;
})();
function rot(dx, dz, k) {
  switch (k & 3) {
    case 1: return [dz, -dx];
    case 2: return [-dx, -dz];
    case 3: return [-dz, dx];
    default: return [dx, dz];
  }
}
if (budOffset == null) {
  fail('结构里没有小块紫水晶芽 —— 那它就不是 boli1 了');
} else {
  /* ⚠️ 早先这条写错了：先算出"旋转后的像集"，再拿像集去查像集 ——
   *    当然是 21/21 全中，于是每次都报"结构是旋转对称的"。
   *    正确做法是拿旋转后的格子去查**原结构**。 */
  const orig = new Set(cfgCells.map((c) => c.dx + ',' + c.dy + ',' + c.dz));
  const sym = [];
  for (let k = 1; k <= 3; k++) {
    let on = 0;
    for (const c of cfgCells) {
      const [rx, rz] = rot(c.dx, c.dz, k);
      if (orig.has(rx + ',' + c.dy + ',' + rz)) on++;
    }
    sym.push(`${k * 90}°: ${on}/${cfgCells.length}`);
  }
  console.log('  旋转后仍落在原结构上的格子数 —— ' + sym.join('，'));
  const anySymmetric = [1, 2, 3].some((k) => {
    let on = 0;
    for (const c of cfgCells) {
      const [rx, rz] = rot(c.dx, c.dz, k);
      if (orig.has(rx + ',' + c.dy + ',' + rz)) on++;
    }
    return on === cfgCells.length;
  });
  if (anySymmetric) {
    fail('存在某个朝向与原结构完全重合 —— 那"只转一半也能匹配"，与设计要求不符');
  } else {
    ok('任何非零朝向都与原结构不重合（不对称）—— 旋转过的结构必须整座一起转');
  }
}

console.log('\n=== B. 模组兜底结构 ≡ 配置 ===');
if (!existsSync(JAVA)) {
  fail('找不到 MirrorObservation.java');
} else {
  const java = readFileSync(JAVA, 'utf8');
  const from = java.indexOf('private static Plot defaultPlot()');
  const to = java.indexOf('/** 波粒块本身');
  const body = (from >= 0 && to > from) ? java.slice(from, to) : '';
  const re = /add\(cells,\s*(-?\d+),\s*(-?\d+),\s*(-?\d+),\s*"([^"]+)"\)/g;
  const javaCells = [];
  let m;
  while ((m = re.exec(body)) !== null) {
    javaCells.push({ dx: +m[1], dy: +m[2], dz: +m[3], id: m[4] });
  }
  console.log(`  Java 兜底结构 ${javaCells.length} 格，配置 ${cfgCells.length} 格`);
  const key = (c) => `${c.dx},${c.dy},${c.dz},${c.id}`;
  const a = new Set(cfgCells.map(key));
  const b = new Set(javaCells.map(key));
  if (a.size !== b.size) {
    fail(`两边格数不同：配置 ${a.size} / Java ${b.size}`);
  } else {
    const onlyCfg = [...a].filter((k) => !b.has(k));
    const onlyJava = [...b].filter((k) => !a.has(k));
    if (onlyCfg.length || onlyJava.length) {
      fail('两边格子对不上：只在配置里 ' + JSON.stringify(onlyCfg)
        + '；只在 Java 里 ' + JSON.stringify(onlyJava));
    } else {
      ok(`兜底结构与配置逐格一致（${a.size} 格，相对靶心的偏移完全相同）`);
    }
  }
}

console.log('\n=== C. 脚本调用的模组 API 都存在 ===');
{
  const apiSrc = readFileSync(API, 'utf8');
  const names = new Set();
  for (const f of [N10, N3]) {
    const src = readFileSync(f, 'utf8');
    const re = /MG(?:_API)?\.([A-Za-z_][A-Za-z0-9_]*)\s*\(/g;
    let m;
    while ((m = re.exec(src)) !== null) names.add(m[1]);
  }
  const sorted = [...names].sort();
  for (const n of sorted) {
    if (new RegExp('static\\s+[\\w.<>\\[\\]]+\\s+' + n + '\\s*\\(').test(apiSrc)) {
      ok('MirrorGravityApi.' + n + ' 存在');
    } else {
      fail('脚本调用了 MirrorGravityApi.' + n + '，但模组里没有这个方法（右键会直接没反应）');
    }
  }
  /* 波粒观测那几个是必须有的 —— 单独点名，免得方法被改名后这里悄悄放过 */
  for (const must of ['setObservationPattern', 'setObservationColorFamilies',
    'observationProbe', 'blockTagsAt', 'applyObservation', 'describeObservationResult']) {
    if (!sorted.includes(must)) {
      fail('脚本没有再调用 ' + must + '？它是波粒观测的关键口子，去掉就等于机制没了');
    }
  }
  /* n3 必须导出 observationAction（产物语义只有一份） */
  const n3src = readFileSync(N3, 'utf8');
  if (/observationAction\s*:/.test(n3src)) ok('n3 导出了 observationAction（产物语义只维护一份）');
  else fail('n3 没有导出 observationAction —— 观测会拿不到产物');
}

console.log('\n=== D. 结构里的方块在 jar 里存在 ===');
if (!existsSync(JAR)) {
  fail('找不到版本 jar: ' + JAR);
} else {
  const blocks = new Set(zipNames(JAR)
    .filter((n) => n.startsWith('assets/minecraft/blockstates/') && n.endsWith('.json'))
    .map((n) => n.slice('assets/minecraft/blockstates/'.length, -'.json'.length)));
  for (const id of Object.keys(byId)) {
    const ns = id.split(':')[0];
    const path = id.split(':')[1];
    if (ns === 'minecraft') {
      if (blocks.has(path)) ok(id + ' 存在于 jar');
      else fail(id + ' 在 jar 里找不到（id 写错了？）');
    } else {
      /* 模组自己的方块不在版本 jar 里，只能确认它确实是我们注册的 */
      if (path === 'wave_particle_block') ok(id + '（模组方块，跳过 jar 核对）');
      else fail('未知命名空间的方块: ' + id);
    }
  }
}

console.log('\n=== E. 配色族表 ≡ jar ===');
{
  const fam = OBS.color_family_members;
  const csv = String(OBS.color_families_csv || '');
  if (fam == null || typeof fam !== 'object') {
    fail('配置里没有 color_family_members（生成区没写进去？跑 gen-color-families.mjs --write）');
  } else {
    const blocks = new Set(zipNames(JAR)
      .filter((n) => n.startsWith('assets/minecraft/blockstates/') && n.endsWith('.json'))
      .map((n) => n.slice('assets/minecraft/blockstates/'.length, -'.json'.length)));
    let families = 0;
    let members = 0;
    let problems = 0;
    for (const name of Object.keys(fam)) {
      const ids = fam[name] || [];
      families++;
      members += ids.length;
      if (ids.length !== 16) {
        fail(`族 ${name} 有 ${ids.length} 种颜色（应为 16）`);
        problems++;
      }
      for (const id of ids) {
        const path = String(id).replace('minecraft:', '');
        if (!blocks.has(path)) {
          fail(`族 ${name} 里的 ${id} 在 jar 里不存在`);
          problems++;
        }
      }
      /* 族名必须是"后缀"：族里每个 id 都得以 _族名 结尾。
       * 这一条挡住"把旗帜和墙旗混进一族"这类错误。 */
      const suffix = '_' + name;
      for (const id of ids) {
        if (!String(id).endsWith(suffix)) {
          fail(`族 ${name} 里混进了不属于这个后缀的方块: ${id}`);
          problems++;
        }
      }
    }
    if (problems === 0) ok(`${families} 个族 × 16 种颜色 = ${members} 个方块，全部与 jar 一致`);
    console.log(`  推送串长度 ${csv.length} 字符，含 ${(csv.match(/=/g) || []).length} 个族`);
    if ((csv.match(/=/g) || []).length !== families) {
      fail('color_families_csv 的族数与 color_family_members 不一致（生成区写坏了？）');
    }
    if (families < 10) fail(`只有 ${families} 个族 —— 原版"染色方块"远不止这些，后缀表是不是被删了？`);
  }
}

console.log('\n=== F. 专用配方（用户点名的那几条）===');
{
  const recipes = OBS.recipes || [];
  console.log(`  专用配方 ${recipes.length} 条`);
  const lines = recipes.map((r) => `${r.input} → ${r.entity ? r.entity + '(实体)' : r.output}${r.drop ? ' (掉落物)' : ''}`);
  for (const l of lines) console.log('    · ' + l);

  const need = [
    ['minecraft:ice', 'minecraft:blue_ice'],
    ['#minecraft:wool', 'minecraft:cobweb'],
    ['minecraft:soul_sand', 'minecraft:nether_wart'],
  ];
  for (const [input, output] of need) {
    if (recipes.some((r) => String(r.input) === input && String(r.output) === output)) {
      ok(`${input} → ${output} 在`);
    } else {
      fail(`缺配方：${input} → ${output}（用户点名要的）`);
    }
  }
  if (recipes.some((r) => String(r.input) === 'minecraft:cake' && String(r.entity) === 'minecraft:allay')) {
    ok('minecraft:cake → minecraft:allay（实体）在');
  } else {
    fail('缺配方：蛋糕 → 悦灵（实体）');
  }

  /* 灵魂沙那条必须是"掉落物"：下界疣既是方块（作物）又是物品，
   * 不写 drop 的话玩家拿到的是地里那棵作物，与"下界疣"的直觉不符。 */
  const wart = recipes.find((r) => String(r.input) === 'minecraft:soul_sand');
  if (wart && wart.drop !== true) {
    fail('灵魂沙 → 下界疣 应当写 drop: true（不然会在地上种一棵作物）');
  }

  /* 产物存在性：方块查 jar，物品查 jar 的 models/item */
  const items = new Set(zipNames(JAR)
    .filter((n) => n.startsWith('assets/minecraft/models/item/') && n.endsWith('.json'))
    .map((n) => n.slice('assets/minecraft/models/item/'.length, -'.json'.length)));
  const blocks = new Set(zipNames(JAR)
    .filter((n) => n.startsWith('assets/minecraft/blockstates/') && n.endsWith('.json'))
    .map((n) => n.slice('assets/minecraft/blockstates/'.length, -'.json'.length)));
  for (const r of recipes) {
    if (r.output == null) continue;
    const path = String(r.output).replace('minecraft:', '');
    if (!blocks.has(path) && !items.has(path)) {
      fail(`配方 ${r.id} 的产物 ${r.output} 既不是方块也不是物品`);
    }
  }
  ok('所有产物的 id 都能在 jar 里找到（方块或物品）');

  /* 每个配方都要有 id：日志与排查全靠它 */
  for (const r of recipes) {
    if (r.id == null) fail('有专用配方没写 id（排查时会说不出是哪一条）');
  }
}

console.log('\n=== G. 脚本与配置的接线 ===');
{
  const src = readFileSync(N10, 'utf8');
  const musts = [
    ['BlockEvents.rightClicked', '右键事件'],
    ['setObservationPattern', '推送结构'],
    ['setObservationColorFamilies', '推送配色族'],
    ['observationProbe', '结构探针'],
    ['applyObservation', '落世界'],
    ['ensureGravityIndex', '引力配方懒加载（脚本按文件名顺序加载，n10 在 n3 前面）'],
    ['observationAction', '复用引力配方的产物语义'],
    ['recolor', '染色方块兜底'],
  ];
  for (const [needle, what] of musts) {
    if (src.includes(needle)) ok(`${what}：${needle}`);
    else fail(`脚本里找不到 ${what}（${needle}）`);
  }
  /* 预筛必须存在：望远镜是原版道具，随手点别处不该走完整判定，
   * 也不该弹提示（no_wave_blocks 要静默）。 */
  if (src.includes('no_wave_blocks')) ok('静默处理"随手点别处"（no_wave_blocks）');
  else fail('脚本没有区分"随手点别处"与"结构不完整" —— 望远镜点哪都会弹提示');
  /* 整数不能交给 Rhino 序列化（血泪教训：count 变成 1.0 → 物品堆解析全失败） */
  if (/JSON\.stringify\(\s*\{/.test(src)) {
    fail('脚本里用 JSON.stringify 序列化对象了 —— Rhino 会把整数写成 1.0，'
      + '模组的 ItemStack 解析要求 count 是 int');
  } else {
    ok('动作描述是手工拼 JSON（不把整数交给 Rhino 序列化）');
  }
}

console.log('\n=== H. 容器：改造时不许爆内容物、变成掉落物要带 NBT ===');
{
  /* 这两条是用户实测报出来的**真 bug**，各自都有"看起来完全正常"的错法：
   *   1) 改造成下落实体时内容物爆一地（fall() 里的 setBlock 触发 onRemove
   *      → Containers.dropContentsOnDestroy），落地后又写回 NBT ⇒ 刷物品
   *   2) 掉落物没带 NBT —— 因为 mixin 注到了 spawnAtLocation 的**单参**重载上，
   *      而原版走的是 ItemLike → (ItemLike,int) → (ItemStack,float)，恰恰跳过它
   * 所以这两条要钉死在脚本里，谁改回去都会当场红。 */
  const tagger = readFileSync(ROOT + '\\mirror-gravity-mod\\src\\main\\java\\work\\dsh\\mirror\\gravity\\GravityTagger.java', 'utf8');
  const dropMixin = readFileSync(ROOT + '\\mirror-gravity-mod\\src\\main\\java\\work\\dsh\\mirror\\gravity\\mixin\\FallingBlockDropMixin.java', 'utf8');
  const guardPath = ROOT + '\\mirror-gravity-mod\\src\\main\\java\\work\\dsh\\mirror\\gravity\\internal\\ContainerDropGuard.java';
  const containerMixinPath = ROOT + '\\mirror-gravity-mod\\src\\main\\java\\work\\dsh\\mirror\\gravity\\mixin\\ContainersDropMixin.java';

  /* (1) NBT 必须在 fall() 之前抓，而且必须用 saveWithId。
   * ⚠️ 用 lastIndexOf：类头注释里也出现过 "FallingBlockEntity.fall(level, pos, state)"，
   *    用 indexOf 会拿注释里的那一处去比，得到假警报（本文件第一版就是这么错的）。
   * ⚠️ saveWithoutMetadata 是**错的**：它不含 id，而物品组件
   *    minecraft:block_entity_data 的编码器 CustomData.CODEC_WITH_ID 要求
   *    tag.contains("id", 8)。2026-09-26 用户就是捡起这种箱子后存档崩溃：
   *    "Saving entity NBT / Missing id for entity in: {Items:[...]}"。 */
  const iSave = tagger.lastIndexOf('saveWithId(');
  const iFall = tagger.lastIndexOf('FallingBlockEntity.fall(');
  /* ⚠️ 只认"真的调用了"（带点号与括号）。注释里也会出现 saveWithoutMetadata ——
   *    那正是"为什么不能用它"的说明，不能因此报错（本文件第一版就是这么假警报的）。 */
  if (/\.saveWithoutMetadata\s*\(/.test(tagger)) {
    fail('GravityTagger 里又用回了 saveWithoutMetadata —— 它不含 id，'
      + '塞进 block_entity_data 组件后物品**无法序列化**，玩家存档时会崩'
      + '（"Missing id for entity in: ..."）');
  } else if (iSave < 0 || iFall < 0) {
    fail('GravityTagger 里找不到 saveWithId 或 FallingBlockEntity.fall（改结构了？）');
  } else if (iSave > iFall) {
    fail('抓方块实体 NBT 的代码排在 fall() **之后** —— fall() 一执行方块实体就销毁，'
      + '再也读不到，内容物必丢');
  } else {
    ok('抓 NBT 在 fall() 之前，且用的是 saveWithId（带 id，组件才合法）');
  }

  /* (2) 改造期间必须开守卫，而且只在抓到 NBT 时开 */
  if (!tagger.includes('ContainerDropGuard.begin()') || !tagger.includes('ContainerDropGuard.end()')) {
    fail('GravityTagger 没有用 ContainerDropGuard 把 fall() 包起来 —— '
      + '箱子/木桶的内容物会在下落那一刻爆一地，落地后箱子里又有一份（刷物品）');
  } else if (!/guard\s*=\s*\(beData\s*!=\s*null\)/.test(tagger)) {
    fail('守卫的开关条件不是"确实抓到了 NBT" —— 抓不到还压掉内容物，东西会凭空消失');
  } else if (!/finally\s*\{/.test(tagger)) {
    fail('守卫没有放在 try/finally 里 —— fall() 抛异常时守卫会一直开着，之后所有容器掉落都被压掉');
  } else {
    ok('改造期间压掉容器内容物掉落，且只在抓到 NBT 时才压（try/finally 保证恢复）');
  }

  if (!existsSync(guardPath)) {
    fail('找不到 internal/ContainerDropGuard.java（守卫本体）');
  } else {
    ok('守卫本体存在');
  }

  if (!existsSync(containerMixinPath)) {
    fail('找不到 mixin/ContainersDropMixin.java —— 内容物掉落的压制没有实现');
  } else {
    const src = readFileSync(containerMixinPath, 'utf8');
    if (!src.includes('dropContentsOnDestroy')) {
      fail('ContainersDropMixin 没有挂 dropContentsOnDestroy（原版箱子/木桶掉内容物的入口）');
    } else if (!/require\s*=\s*1/.test(src)) {
      fail('ContainersDropMixin 的注入点没有 require=1');
    } else {
      ok('ContainersDropMixin 挂在原版 dropContentsOnDestroy 上，require=1');
    }
  }

  /* (3) 掉落物 NBT：必须挂在**带 float 的那个重载**上 */
  if (!/spawnAtLocation\(Lnet\/minecraft\/world\/item\/ItemStack;F\)/.test(dropMixin)) {
    fail('FallingBlockDropMixin 没有挂在 spawnAtLocation(ItemStack, float) 上 —— '
      + '原版下落实体走的是 ItemLike → (ItemLike,int) → (ItemStack,float) 这条链，'
      + '**跳过**单参的 spawnAtLocation(ItemStack)，所以挂单参等于永远不会被调用'
      + '（表现：箱子挖成掉落物再摆出来，内容物没了）');
  } else if (!dropMixin.includes('BLOCK_ENTITY_DATA')) {
    fail('FallingBlockDropMixin 没有写 block_entity_data 组件');
  } else if (!/contains\(\s*"id"\s*,\s*8\s*\)/.test(dropMixin)) {
    fail('FallingBlockDropMixin 写组件前没有校验 tag.contains("id", 8) —— '
      + '少了这一道，一旦上游给的标签缺 id，就会写出一个**无法序列化**的物品，'
      + '玩家一存档就崩（CODEC_WITH_ID 的校验条件就是它）');
  } else {
    ok('掉落物补 block_entity_data：挂在真正的落点重载上，且写前校验了 id');
  }

  /* (4) 已经坏在存档里的组件要能自愈（登录时修） */
  const repairPath = ROOT + '\\mirror-gravity-mod\\src\\main\\java\\work\\dsh\\mirror\\gravity\\MirrorItemRepair.java';
  if (!existsSync(repairPath)) {
    fail('找不到 MirrorItemRepair.java —— 存档里已存在的非法组件没人修，'
      + '玩家每次存档都会继续崩');
  } else {
    const rep = readFileSync(repairPath, 'utf8');
    if (!rep.includes('PlayerLoggedInEvent')) {
      fail('MirrorItemRepair 没有挂在登录事件上（本项目不要每 tick 轮询）');
    } else if (!/contains\(\s*"id"\s*,\s*8\s*\)/.test(rep)) {
      fail('MirrorItemRepair 的判据与 CODEC_WITH_ID 不一致（应当检查 contains("id", 8)）');
    } else if (!rep.includes('BLOCK_ENTITY_TYPE')) {
      fail('MirrorItemRepair 没有按注册表推断方块实体类型（不能靠"物品 id = 方块实体 id"猜，'
        + '墙上的告示牌/旗帜就不是）');
    } else {
      ok('登录时自愈：非法组件按注册表补 id，修不了的移除（绝不留给存档去崩）');
    }
  }

  /* (5) 掉落物必须同时带 container 组件。
   * 只有 block_entity_data 的话，摆下去时 BlockItem.place 的第二步
   * （updateBlockEntityComponents → applyImplicitComponents）会拿**物品的
   * container 组件**整份覆盖方块实体的内容物 —— 缺了它，第一步刚恢复的内容物
   * 当场被清空。用户实测的原话就是"摆出来后，里面是空的"。 */
  if (!dropMixin.includes('ItemContainerContents')) {
    fail('FallingBlockDropMixin 没有设置 container 组件 —— 摆下去时内容物会被 '
      + 'applyImplicitComponents 用空的 container 覆盖掉（"摆出来是空的"）');
  } else if (!/DataComponents\.CONTAINER/.test(dropMixin)) {
    fail('FallingBlockDropMixin 里没有 DataComponents.CONTAINER');
  } else if (!dropMixin.includes('CUSTOM_NAME') || !dropMixin.includes('LOCK')) {
    fail('FallingBlockDropMixin 没有搬 CUSTOM_NAME / LOCK —— applyImplicitComponents 会用'
      + '组件里的这两项覆盖方块实体，缺了就把箱子改的名字与锁清掉');
  } else {
    ok('掉落物同时带 block_entity_data + container + 名字/锁（摆下去内容物与名字都在）');
  }
}

console.log('\n=== I. 用户的三条新要求（羊毛+锁链 / 不要聊天提示 / JEI 可查）===');
{
  /* (1) 羊毛 → 蜘蛛网 必须要求**下方放锁链**（用户要求），
   *     同时羊毛的同族随机换色必须继续生效 —— 两者靠"专用配方先判 on 条件"
   *     共存：下方没锁链时专用配方不命中，自动落到换色兜底。
   *     ⚠️ 如果哪天有人把 on 去掉，羊毛就再也不会随机换色了（被专用配方全吃掉），
   *        所以这里同时钉 on 与"换色兜底存在"两件事。 */
  const wool = (OBS.recipes || []).find((r) => String(r.input) === '#minecraft:wool');
  if (wool == null) {
    fail('配置里找不到羊毛→蜘蛛网那条专用配方');
  } else if (String(wool.on) !== 'minecraft:chain') {
    fail(`羊毛→蜘蛛网 的 on 应为 'minecraft:chain'（用户要求下方放锁链），实得 ${wool.on}`);
  } else {
    ok('羊毛→蜘蛛网 要求下方是锁链');
  }
  const n10src0 = readFileSync(N10, 'utf8');
  if (!/recolor/.test(n10src0) || !/familyOf\[/.test(n10src0)) {
    fail('脚本里没有"染色方块随机换色"的兜底逻辑 —— 羊毛就没法再随机换色了');
  } else {
    ok('随机换色兜底仍在（羊毛不加锁链时走这条）');
  }

  /* (2) 加工过程不许给聊天栏提示（用户明确要求删掉） */
  const banned = [
    ['player.tell', '聊天栏消息'],
    ['Text.', '聊天栏文本构造'],
    ['notify_success', '成功提示开关'],
    ['notify_failure', '失败提示开关'],
  ];
  let chatty = 0;
  for (const [needle, what] of banned) {
    if (n10src0.includes(needle)) {
      fail(`n10 里还有 ${what}（${needle}）—— 用户要求删掉聊天栏提示`);
      chatty++;
    }
  }
  const cfgText = readFileSync(CFG, 'utf8');
  const obsIdx = cfgText.indexOf('MIRROR_CONFIG.observation');
  const obsBlock = obsIdx >= 0 ? cfgText.slice(obsIdx, obsIdx + 6000) : '';
  for (const key of ['notify_success', 'notify_failure']) {
    if (obsBlock.includes(key)) {
      fail(`配置 observation 段里还留着 ${key} —— 那是死配置（脚本已经不读了）`);
      chatty++;
    }
  }
  if (chatty === 0) ok('加工不给聊天栏提示：脚本里没有 tell/Text，配置里也没有提示开关');

  /* (3) 加载期校验不许把"注册表还没就绪"当成"规格书写错了"。
   * 用户报"进世界后 kjs 报错"，查出来是 8 条假警报：脚本在**服务器注册表可用之前**
   * 加载，带注册表组件的规格书（山羊角的 minecraft:instrument）那时必然解析失败，
   * 于是加载日志里刷出一串 ERROR，而配方其实是好的。 */
  const apiSrc = readFileSync(API, 'utf8');
  if (!/registries == null && spec\.contains\("\\"components\\""\)/.test(apiSrc)) {
    fail('validateStackSpec 里没有"注册表未就绪就放行含组件规格书"的分支 —— '
      + '加载期会刷出假 ERROR（"进世界后 kjs 报错"就是这么来的）');
  } else {
    ok('加载期校验不会把"注册表未就绪"误判成"规格书写错"（含组件的规格书改由运行时校验）');
  }

  /* (3) JEI：观测配方要能在 JEI 里查，且左侧工作方块是波粒块 */
  const obsJei = ROOT + '\\mirror-gravity-mod\\src\\main\\resources\\observation_recipes.json';
  if (!existsSync(obsJei)) {
    fail('没有 observation_recipes.json（跑 node tools/sync-jei-recipes.mjs 生成）');
  } else {
    const jei = JSON.parse(readFileSync(obsJei, 'utf8'));
    const rs = Array.isArray(jei.recipes) ? jei.recipes : [];
    console.log(`  JEI 观测配方 ${rs.length} 条`);
    const labels = rs.map((r) => String(r.label));
    for (const need of ['ice_to_blue_ice', 'wool_to_cobwall'.replace('cobwall', 'cobweb'),
      'soul_sand_to_nether_wart', 'cake_to_allay']) {
      if (labels.includes(need)) ok(`JEI 里有专用配方 ${need}`);
      else fail(`JEI 数据里缺专用配方 ${need}`);
    }
    const recolors = rs.filter((r) => String(r.label).startsWith('recolor:'));
    if (recolors.length !== 13) {
      fail(`JEI 里随机换色条目应为 13 条（13 个族），实得 ${recolors.length}`);
    } else if (recolors.some((r) => (r.inputs || []).length !== 16 || (r.outputs || []).length !== 16)) {
      fail('JEI 里换色条目的输入或产物不是 16 种颜色');
    } else {
      ok('JEI 里有 13 条随机换色（每族 16 种颜色，输入=产物=该族）');
    }
    /* 实体产物的"刷怪蛋"必须真的存在，否则 JEI 那一格是空的 */
    const egg = rs.find((r) => String(r.label) === 'cake_to_allay');
    if (egg != null) {
      const eggId = String((egg.outputs || [])[0] || '');
      const items = new Set(zipNames(JAR)
        .filter((n) => n.startsWith('assets/minecraft/models/item/') && n.endsWith('.json'))
        .map((n) => n.slice('assets/minecraft/models/item/'.length, -'.json'.length)));
      if (items.has(eggId.replace('minecraft:', ''))) {
        ok(`实体产物用刷怪蛋展示：${eggId}（jar 里存在）`);
      } else {
        fail(`JEI 里实体产物写成了 ${eggId}，但 jar 里没有这个物品 —— 槽位会是空的`);
      }
    }
    /* 需要"下方方块"的条目必须带 below，否则玩家不知道要垫什么 */
    const belowMissing = rs.filter((r) => r.belowRequired === true
      && (!Array.isArray(r.below) || r.below.length === 0));
    if (belowMissing.length > 0) {
      fail(`有 ${belowMissing.length} 条标了 belowRequired 却没有 below 内容`);
    } else {
      ok(`需要下方方块的 ${rs.filter((r) => r.belowRequired === true).length} 条都带上了 below`);
    }
  }

  /* 模组侧：分类、数据、催化剂三处接线 */
  const plugin = readFileSync(ROOT + '\\mirror-gravity-mod\\src\\main\\java\\work\\dsh\\mirror\\gravity\\jei\\GravityJeiPlugin.java', 'utf8');
  const categoryPath = ROOT + '\\mirror-gravity-mod\\src\\main\\java\\work\\dsh\\mirror\\gravity\\jei\\ObservationRecipeCategory.java';
  if (!plugin.includes('ObservationRecipeCategory')) {
    fail('GravityJeiPlugin 没有注册波粒观测分类');
  } else if (!plugin.includes('WAVE_PARTICLE_BLOCK_ITEM')) {
    fail('GravityJeiPlugin 没有把**波粒块**登记为观测分类的催化剂 —— '
      + '用户要求"左侧的工作方块就写成波粒块"');
  } else if (!plugin.includes('ObservationRecipeData.load()')) {
    fail('GravityJeiPlugin 没有加载 observation_recipes.json');
  } else {
    ok('JEI 插件：注册了观测分类、加载了观测数据、催化剂是波粒块');
  }
  if (!existsSync(categoryPath)) {
    fail('找不到 ObservationRecipeCategory.java');
  } else {
    const cat = readFileSync(categoryPath, 'utf8');
    if (!cat.includes('波粒观测')) fail('观测分类的标题不是「波粒观测」');
    else if (!cat.includes('WAVE_PARTICLE_BLOCK_ITEM')) fail('观测分类的工作方块不是波粒块');
    else if (!cat.includes('GravityRecipeItems.resolveAll')) {
      fail('观测分类没有用 GravityRecipeItems 解析标签 —— 写标签的配方在 JEI 里会是空槽');
    } else {
      ok('观测分类版面：左侧波粒块、标签展开、下方条件槽都在');
    }
  }
}

console.log('\n' + (bad === 0 ? '✓ 波粒观测自检全部通过' : `✗ ${bad} 项不合格`));
if (bad > 0) process.exit(1);
