﻿@echo off
chcp 65001 >nul
REM =====================================================================
REM  镜维度 · 一键生成数据包
REM  读取 kubejs\config\mirror_dimension.json，重新生成三份维度 JSON。
REM  改完配置后双击本文件，然后在游戏里「退出世界重新进入」生效。
REM =====================================================================
setlocal
set "HERE=%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo [错误] 找不到 node。请安装 Node.js，或手动编辑 kubejs\data 下的 JSON。
  pause
  exit /b 1
)

node "%HERE%generate-mirror-pack.mjs" %*
set "CODE=%ERRORLEVEL%"

echo.
if "%CODE%"=="0" (
  echo 生成完成。记得在游戏里退出世界再重新进入。
) else (
  echo 生成失败，请按上面的提示修改 kubejs\config\mirror_dimension.json。
)

echo %CMDCMDLINE% | find /i "/c" >nul
if not errorlevel 1 pause
exit /b %CODE%
