// =====================================================================
// 镜维度 · 进入音效（紫水晶钟声 + 多抽头回响）
// =====================================================================
// 只做一件事：发出"你穿过镜面了"的提示音，并给它一段悠长的余韵。
//
// 为什么单独一个模块：
//   1) 余韵是**多抽头延迟**（multi-tap delay）—— 同一个音效在不同延迟上
//      以递减音量重复播放。这需要一个每 tick 推进的队列，
//      不适合挤在 mirror_server.js 的指令层里。
//   2) 音效 ID 与声道（SoundSource）的解析各有一个坑（见下），集中在这里。
//
// ---------------------------------------------------------------------
// ⚠️ 踩坑记录（实测，别改回去）
// ---------------------------------------------------------------------
// 1) `SoundEvents` **不是 KubeJS 的全局绑定**。
//    直接写 SoundEvents.AMETHYST_BLOCK_CHIME 会 ReferenceError。
//    要么 Java.loadClass('net.minecraft.sounds.SoundEvents')，
//    要么像本模块一样用
//        SoundEvent.createVariableRangeEvent(ResourceLocation)
//    —— 这和原版 SoundEvents 内部注册音效时用的是同一个调用
//       （SoundEvents.register() 里就是 createVariableRangeEvent），
//       所以两者完全等价，还少一次类加载。
//
// 2) `playSound(..., 'ambient', ...)` **永远不会成功**。
//    第 6 个参数是 SoundSource **枚举**，Rhino 不做字符串→枚举的自动转换，
//    重载消歧失败后抛 TypeError。
//
// 3) 上面第 2 条之所以"看不出来"，是因为原来把它包在一个**空 catch** 里：
//        try { player.level.playSound(..., 'ambient', ...); } catch (err) {}
//    结果是「聊天栏提示正常、音效永远没有、日志一个字都没有」。
//    => 本模块的 Java 调用**报错必留痕**，失败会打印
//       [镜维度·音效] 播放失败（第 N 次）…，看到就说明参数又写错了。
//
// ⚠️ 所有 try 块内只用 var（Rhino 对 try 里的 const/let 会抛
//    InternalError: TypeError: redeclaration of var xxx）
// =====================================================================

const MirrorEcho = (() => {

  const MD = global.MirrorDimension;
  const N0 = MD.modules.n0;
  const N1 = MD.modules.n1;
  if (N0 === undefined || !N0.ready || N1 === undefined || !N1.ready) {
    console.error('[镜维度] 依赖模块未就绪，进入音效模块未启用。');
    return { ready: false };
  }

  const cfg = N0.cfg;
  const S = cfg.sound != null ? cfg.sound : {};
  const ENTER = S.enter != null ? S.enter : {};

  /* 用 tryLoadClass：拿不到就降级成"没有音效"，而不是让整个文件加载失败
   *（那会连带 modules.n7 都不存在，调用方只能看到一个 undefined）。 */
  const SoundEventCls = N0.tryLoadClass('net.minecraft.sounds.SoundEvent');
  const SoundSourceCls = N0.tryLoadClass('net.minecraft.sounds.SoundSource');
  const ResourceLocationCls = N0.tryLoadClass('net.minecraft.resources.ResourceLocation');

  const classesOk = SoundEventCls != null
    && SoundSourceCls != null
    && ResourceLocationCls != null;

  if (!classesOk) {
    console.error('[镜维度·音效] 音效相关的原版类加载失败，进入提示音不会响。');
  }

  const DEFAULT_EVENT = 'minecraft:block.amethyst_block.chime';
  const DEFAULT_SOURCE = 'blocks';

  /* 声道 → 原版"音乐和声音"设置里的滑块名。
   * 用途：/mirror sound 会直接告诉玩家该去拉哪一根滑块 ——
   * "声音太小"时第一个该确认的就是这个滑块是不是被拉低了。 */
  const SOURCE_ZH = {
    master: '主音量', music: '音乐', records: '唱片机/音符盒', weather: '天气',
    blocks: '方块', hostile: '敌对生物', neutral: '友好生物', players: '玩家',
    ambient: '环境', voice: '语音',
  };

  function sourceKey() {
    return String(ENTER.source != null ? ENTER.source : DEFAULT_SOURCE)
      .trim().toLowerCase();
  }

  function sourceLabel() {
    var k = sourceKey();
    return SOURCE_ZH[k] != null ? SOURCE_ZH[k] : k;
  }

  /* ------------------------------------------------------------------ */
  /* 音效事件 / 声道（各解析一次，之后走缓存）                             */
  /* ------------------------------------------------------------------ */

  let cachedEvent = null;
  let eventFailed = false;

  /** 返回 SoundEvent；解析失败返回 null（并只报一次错）。 */
  function eventOf() {
    if (cachedEvent != null) return cachedEvent;
    if (eventFailed || !classesOk) return null;
    try {
      var spec = ENTER.event != null ? ENTER.event : DEFAULT_EVENT;
      var loc = ResourceLocationCls.parse(String(spec));
      cachedEvent = SoundEventCls.createVariableRangeEvent(loc);
      return cachedEvent;
    } catch (err) {
      eventFailed = true;
      console.error('[镜维度·音效] 音效事件解析失败（配置 sound.enter.event = '
        + ENTER.event + '）: ' + err);
      return null;
    }
  }

  let cachedSource = null;

  /** 返回 SoundSource 枚举；失败返回 null。
   *  ⚠️ 绝不把字符串直接传进 playSound —— 见文件头踩坑 2。 */
  function sourceOf() {
    if (cachedSource != null) return cachedSource;
    if (!classesOk) return null;
    try {
      var key = String(ENTER.source != null ? ENTER.source : DEFAULT_SOURCE)
        .trim().toUpperCase();
      var got = SoundSourceCls[key];
      cachedSource = got != null ? got : SoundSourceCls.BLOCKS;
      return cachedSource;
    } catch (err) {
      console.error('[镜维度·音效] 声道解析失败: ' + err);
      return null;
    }
  }

  /** 配置里读出来的数：非数字一律退回默认值（配置写错不该让音效炸掉）。 */
  function num(value, dflt) {
    var n = Number(value);
    return isNaN(n) ? dflt : n;
  }

  /* ------------------------------------------------------------------ */
  /* 响度：只能靠"叠几份"，不能靠调大 volume                              */
  /* ------------------------------------------------------------------ */
  /* ⚠️ 这一条是查过原版源码才敢写的（1.21.1，SoundEngine.play）：
   *
   *     float f  = soundInstance.getVolume();                        // 我们传进去的音量
   *     float f1 = Math.max(f, 1.0F) * sound.getAttenuationDistance();// 决定传播距离
   *     float f2 = Mth.clamp(f * 分类音量, 0.0F, 1.0F);               // ← 最终增益，夹到 1.0
   *
   *   结论：**volume 写 2.4 和写 1.0 一样响**（f2 被夹到 1.0）；
   *   volume > 1 唯一的实际效果是把可听半径从 16 格拉到 volume×16 格
   *   （f1 = max(f, 1.0) × 衰减距离）。
   *   更糟的是，volume > 1 之后"方块"滑块要拉到 1/volume 以下才开始起作用，
   *   等于把玩家的音量控制权架空了。
   *
   *   ⇒ 想更响只有一条路：**同一时刻播多份**。
   *     每一份是独立的声道，在混音阶段相加，不受那个 clamp 限制。
   *     这就是下面的 stack。 */

  const MAX_STACK = 8;
  const DEFAULT_STACK = 3;

  /** 起始叠加层数：优先用调用方给的临时值，否则用配置，最后夹到 1 ~ 8。 */
  function stackCount(override) {
    var n = Math.round(num(override, 0));
    if (!(n > 0)) n = Math.round(num(ENTER.stack, DEFAULT_STACK));
    if (!(n > 0)) n = 1;
    return Math.max(1, Math.min(MAX_STACK, n));
  }

  /** 单份拷贝的音量：夹到 [0, 1]（>1 无意义，见上）。 */
  function baseVolume() {
    var v = num(ENTER.volume, 0.95);
    if (v < 0) v = 0;
    if (v > 1) v = 1;
    return v;
  }

  /* ------------------------------------------------------------------ */
  /* 播放                                                                */
  /* ------------------------------------------------------------------ */

  let playFailures = 0;
  const MAX_FAIL_LOGS = 3;

  /**
   * 放一声。
   *
   * @param level ServerLevel（服务端调用会自动广播给附近玩家）
   * @param vol   音量（0 直接跳过）
   * @param pitch 音高，夹到 [0.5, 2.0]（原版的合理范围）
   */
  function play(level, x, y, z, vol, pitch) {
    if (level == null) return false;
    if (vol <= 0) return true;
    var ev = eventOf();
    var src = sourceOf();
    if (ev == null || src == null) return false;
    var p = Math.max(0.5, Math.min(2.0, pitch));
    try {
      /* 签名（1.21.1）：Level#playSound(Player except, double x, double y, double z,
       *                              SoundEvent, SoundSource, float volume, float pitch)
       * except = null → 附近所有玩家都听得到。 */
      level.playSound(null, x, y, z, ev, src, vol, p);
      return true;
    } catch (err) {
      playFailures++;
      if (playFailures <= MAX_FAIL_LOGS) {
        console.error('[镜维度·音效] 播放失败（第 ' + playFailures + ' 次）: ' + err);
      }
      return false;
    }
  }

  /* ------------------------------------------------------------------ */
  /* 回响队列                                                            */
  /* ------------------------------------------------------------------ */
  /* 起始叠加 + 主音立刻播；余韵按 taps 里的延迟排进队列，
   * 由下面的 ServerEvents.tick 到点播放。
   * 用 tick 队列而不是 server.scheduleInTicks：
   *   1) 队列的长度可以直接查（/mirror sound 会报）；
   *   2) 不依赖 KubeJS 的调度器在这版里的具体签名。 */

  const pending = [];
  const MAX_PENDING = 512;

  /** 在 (x,y,z) 附近抖一点位置，让同时播的几份有不同的声像。 */
  function offset(base, amount, ratio) {
    if (!(amount > 0)) return base;
    return base + (Math.random() * 2 - 1) * amount * ratio;
  }

  /**
   * 播放"进入镜维度"的提示音（起始叠加 + 全部余韵抽头）。
   *
   * @param stackOverride 可选的叠加层数（1 ~ 8）。只影响这一次调用，
   *                      用于 /mirror sound 5 这种"先听听几层合适"的试音。
   * @returns 是否至少有一份真的播出去了（false 时看日志 [镜维度·音效]）
   */
  function cue(level, x, y, z, stackOverride) {
    if (S.enabled === false || level == null) return false;

    var baseVol = baseVolume();
    var basePitch = num(ENTER.pitch, 1.2);
    var jitter = num(ENTER.pitch_jitter, 0.02);
    var spread = num(ENTER.spread, 0.6);
    var stackJitter = num(ENTER.stack_jitter, 0.03);
    var stack = stackCount(stackOverride);
    var taps = ENTER.taps != null ? ENTER.taps : [];

    /* ---- 起始叠加：同时播 stack 份 ----
     * 这是唯一能真正变响的手段（原因见上面"响度"一节）。
     * 层与层之间给一点音高差，否则完全同相会变成一个怪音。 */
    var ok = false;
    for (var k = 0; k < stack; k++) {
      var sp = basePitch;
      if (stackJitter > 0) sp += (Math.random() * 2 - 1) * stackJitter;
      if (play(level, offset(x, spread, 1), offset(y, spread, 0.5), offset(z, spread, 1),
        baseVol, sp)) {
        ok = true;
      }
    }

    /* ---- 余韵抽头 ---- */
    var now = N1.now();
    for (var i = 0; i < taps.length; i++) {
      var tap = taps[i];
      if (tap == null || tap.length < 2) continue;
      var delay = num(tap[0], 0);
      if (delay <= 0) continue;              // 0 延迟的抽头用 stack 表达，不用这里排
      var vol = baseVol * num(tap[1], 0);
      if (vol <= 0.002) continue;            // 小到听不见的抽头直接不排

      /* 音高抖动：让叠加的几层不完全是同一个音，避免听成"一个更响的音"。
       * 位置抖动：原版按方位做声像，抖一点就有立体声宽度。 */
      var pitch = basePitch + num(tap[2], 0);
      if (jitter > 0) pitch += (Math.random() * 2 - 1) * jitter;

      pending.push({
        at: now + Math.round(delay),
        level: level,
        x: offset(x, spread, 1),
        y: offset(y, spread, 0.5),
        z: offset(z, spread, 1),
        vol: vol,
        pitch: pitch,
      });
    }

    /* 兜底：配置里把 taps 写多到离谱时，只保留最近的一部分，
     * 不让队列无限增长（玩家反复进出的极端情况下）。 */
    if (pending.length > MAX_PENDING) {
      pending.splice(0, pending.length - MAX_PENDING);
    }
    return ok;
  }

  /** 以玩家当前位置为声源播放。stackOverride 见 cue()。 */
  function cueFor(player, stackOverride) {
    if (player == null) return false;
    return cue(player.level, player.x, player.y, player.z, stackOverride);
  }

  ServerEvents.tick(event => {
    if (pending.length === 0) return;
    var now = N1.now();
    /* 原地压缩数组：到点的播掉，没到点的前移。
     * 这里不用 filter/splice —— 显式循环在 Rhino 里最不容易出意外。 */
    var w = 0;
    for (var r = 0; r < pending.length; r++) {
      var e = pending[r];
      if (e.at <= now) {
        play(e.level, e.x, e.y, e.z, e.vol, e.pitch);
      } else {
        pending[w] = e;
        w++;
      }
    }
    pending.length = w;
  });

  /* ------------------------------------------------------------------ */
  /* 对外导出                                                            */
  /* ------------------------------------------------------------------ */

  const api = {
    ready: true,
    /* cue 只在本文件内被 cueFor 调用；pendingCount / failures 从没有任何调用者
     * （0.3 契约收紧时摘掉 —— 要排查音效时看日志里的"播放失败（第 N 次）"即可）。 */
    cueFor: cueFor,
    /** 生效的叠加层数（把 /mirror sound N 的临时值算进去，供指令回显）。 */
    stackOf: stackCount,
    info: function () {
      return {
        enabled: S.enabled !== false,
        event: String(ENTER.event != null ? ENTER.event : DEFAULT_EVENT),
        source: sourceKey(),
        sourceZh: sourceLabel(),
        /** 注意：这是单份拷贝的音量，脚本会夹到 1（>1 无效） */
        volume: baseVolume(),
        stack: stackCount(0),
        maxStack: MAX_STACK,
        pitch: num(ENTER.pitch, 1.2),
        taps: (ENTER.taps != null ? ENTER.taps : []).length,
        classesOk: classesOk,
      };
    },
  };

  global.MirrorDimension.modules.n7 = api;

  const soundInfo = api.info();
  console.info('[镜维度·音效] 进入提示音已就绪 — ' + soundInfo.event
    + '（声道 ' + soundInfo.source + '，滑块「' + soundInfo.sourceZh + '」'
    + '，单份音量 ' + soundInfo.volume
    + '，起始叠加 ' + soundInfo.stack + ' 层'
    + '，运行时回响抽头 ' + soundInfo.taps + ' 个'
    + (soundInfo.taps === 0 ? '（回响已烘焙进音频文件）' : '')
    + '，' + (soundInfo.enabled ? '已启用' : '**配置里关掉了**') + '）');

  return api;
})();
