import dev.latvian.mods.rhino.Context;
import dev.latvian.mods.rhino.ContextFactory;
import dev.latvian.mods.rhino.Scriptable;

/**
 * KubeJS 的 Rhino 分支：**try 块内 const/let** 专项探针（第 3 组）。
 *
 * <p>为什么要单开一个探针：第 1 组（RhinoScopeProbe）的用例 C 写成了
 * <pre>function f() { try { const c = 3; } catch (e) {} return 1; }</pre>
 * 结论记成了「函数内（含嵌套块）的 const/let → 正常」—— **这个结论是错的**。
 * 真相是：那行 const **确实抛了异常**，只是被它自己的 {@code catch (e) {}}
 * 吞掉了，而 {@code c} 又没被使用，所以外面完全看不出来。
 *
 * <p>真实事故（本探针就是为了它）：配方引擎的
 * <pre>function stateKeyOf(entity) {
 *   ...
 *   try { const col = columnKeyOf(...); if (col != null) return col; } catch (err2) {}
 *   return entityKey(entity);
 * }</pre>
 * 每次调用都抛 {@code InternalError: TypeError: redeclaration of var col}，
 * 被自己的 catch 吞掉后**静默退回按实体计数** —— 于是
 * 「切换次数按竖列累计」这个机制彻底失效，脚手架每次重生进度都归零，
 * 三条脚手架配方（蜘蛛网 / 树苗 / 地狱疣）一起失灵。
 * 而其它 44 条配方全部正常、KubeJS 加载显示 0 errors、日志里一个字都没有 ——
 * 表现与"落点方块摆错位置"完全一样，这就是它藏了这么久的原因。
 *
 * <p>修复：把 try 块里的 {@code const} 改成 {@code var}（见 lint 规则）。
 *
 * <p>怎么跑（不需要启动游戏）：
 * <pre>
 *   $rhino = "&lt;实例&gt;\mods\[犀牛] rhino-2101.2.7-build.85.jar"
 *   &amp; javac -encoding UTF-8 -cp $rhino RhinoTryProbe.java
 *   &amp; java "-Dfile.encoding=UTF-8" -cp "$rhino;." RhinoTryProbe
 * </pre>
 * 退出码 0 = 全部符合预期。
 */
public class RhinoTryProbe {

    static int failures = 0;

    /** 跑一段脚本；抛出的异常原样返回成字符串，方便看清"到底抛没抛"。 */
    static String run(String src) {
        Context cx = new ContextFactory().enter();
        try {
            Scriptable scope = cx.initStandardObjects();
            return cx.toString(cx.evaluateString(scope, src, "probe", 1, null));
        } catch (Throwable t) {
            return "THROW(" + t.getClass().getSimpleName() + ": " + t.getMessage() + ")";
        }
    }

    static void expect(String label, String src, String want) {
        String got = run(src);
        boolean ok = want.equals(got);
        if (!ok) failures++;
        System.out.println("  " + (ok ? "OK  " : "FAIL") + "  " + label);
        System.out.println("          得到: " + got);
        if (!ok) System.out.println("          期望: " + want);
    }

    public static void main(String[] args) {
        System.out.println("=== 1) 异常不再被吞：try 里 const 到底抛不抛 ===");
        /* 关键：catch 把异常**当返回值**抛出来，而不是 {} 空吞。 */
        expect("try 内 const，异常原样暴露",
            "function f() { try { const c = 3; return 'ok=' + c; }"
                + " catch (e) { return 'CAUGHT(' + e + ')'; } } f();",
            "CAUGHT(InternalError: TypeError: redeclaration of var c. (probe#1))");

        System.out.println();
        System.out.println("=== 2) 第 1 组探针为什么会误判「正常」===");
        /* 同一段代码，只是 catch 里什么都不做 —— 于是"看不出抛过"。 */
        expect("try 内 const + 空 catch（异常被吞，看不出问题）",
            "function f() { try { const c = 3; } catch (e) {} return 'ok'; } f();",
            "ok");

        System.out.println();
        System.out.println("=== 3) 事故原型的三种写法（值都要用上）===");
        /* const：抛 → 被自己的 catch 吞 → 静默走 fallback（事故现场） */
        expect("const 写在 try 里（事故原型 → 静默退回 fallback）",
            "function stateKeyOf(e) {"
                + " try { const col = 'col:' + e; if (col != null) return col; } catch (err2) {}"
                + " return 'entity:' + e; } stateKeyOf(7);",
            "entity:7");
        /* var：正常 */
        expect("var 写在 try 里（修复后 → 拿到正确的键）",
            "function stateKeyOf(e) {"
                + " try { var col = 'col:' + e; if (col != null) return col; } catch (err2) {}"
                + " return 'entity:' + e; } stateKeyOf(7);",
            "col:7");
        /* let：也正常 —— 坏掉的只有 const */
        expect("let 写在 try 里（同样是好的）",
            "function stateKeyOf(e) {"
                + " try { let col = 'col:' + e; if (col != null) return col; } catch (err2) {}"
                + " return 'entity:' + e; } stateKeyOf(7);",
            "col:7");

        System.out.println();
        System.out.println("=== 4) 同一 try 里两次 const：第一个就炸 ===");
        expect("两次 const（第一次就抛）",
            "function f() { try { const a = 1; const b = 2; return a + b; }"
                + " catch (e) { return 'CAUGHT(' + e + ')'; } } f();",
            "CAUGHT(InternalError: TypeError: redeclaration of var a. (probe#1))");

        System.out.println();
        System.out.println("=== 5) 对照：函数顶层 / if 块内的 const（这些是好的）===");
        expect("函数顶层 const", "function f() { const a = 1; return a; } f();", "1");
        expect("if 块内 const（值被使用）",
            "function f() { if (true) { const a = 2; return a; } return 0; } f();", "2");

        System.out.println();
        System.out.println(failures == 0
            ? "✓ 全部符合预期（结论：try 块内 const/let 不可用，必须写 var）"
            : ("✗ " + failures + " 项与预期不符 —— Rhino 行为变了，请重新核对 lint 规则"));
        if (failures != 0) System.exit(1);
    }
}
