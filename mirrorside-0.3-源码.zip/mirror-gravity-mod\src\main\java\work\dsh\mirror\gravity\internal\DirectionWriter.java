package work.dsh.mirror.gravity.internal;

import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import work.dsh.mirror.gravity.MirrorGravity;
import work.dsh.mirror.gravity.PondusReflect;

/**
 * 把重力方向写进 Pondus。
 *
 * <h2>为什么要绕开 Pondus 的白名单</h2>
 * Pondus 的换向流程入口有 {@code if (!canChangeGravity()) return;} 保护，
 * 而那个白名单依赖 {@code pondus:allowed_special} 标签。该标签在本实例上
 * **从未生效**（Pondus 自己的 jar 用了复数目录名 {@code tags/entity_types/}，
 * 而 1.21 要求单数 {@code tags/entity_type/}），所以所有非生物实体
 * （下落的方块、掉落物、TNT……）都会被整段跳过。
 *
 * <p>本类直接往方向字段写入，绕过白名单。脚本层试过两种替代方案都不行：
 * <ul>
 *   <li>直接调 setBaseGravityDirection → 被 canChangeGravity 拦住</li>
 *   <li>反射写 baseGravityDirection 字段 → Rhino 不暴露 getClass()，拿不到 Class</li>
 * </ul>
 * 所以只能在 Java 这一层处理。
 *
 * <h2>不在这里做的事情</h2>
 * <b>速度换算一律交给 Pondus</b>。本类曾经自己写过一个 rotateVelocity()，
 * 已删除且不要恢复：Pondus 的 setter 内部已经会调
 * {@code applyGravityDirectionChange()}，那里就包含"旋转速度 + 校正位置"。
 * 我们再转一次等于转两遍，两次互为逆变换 → 水平速度被还原、抛物线被破坏。
 * 实测症状：物品不做抛物线，只有垂直方向反转，最后落回脚下。
 *
 * <p>速度的例外只有一处：Pondus 在服务端会把速度**清零**（见
 * {@link VelocityFix}），那部分由它负责补回。
 */
public final class DirectionWriter {

    private DirectionWriter() {
    }

    /**
     * 设定实体的重力方向。
     *
     * @param entity       目标实体
     * @param dir          目标方向
     * @param syncToClient 是否置 needsSync 以触发客户端同步
     * @return 是否成功（方向已按下发值生效）
     */
    public static boolean apply(Entity entity, Direction dir, boolean syncToClient) {
        if (entity == null || dir == null || !PondusReflect.resolve()) {
            return false;
        }

        Object data = PondusReflect.gravityDataOf(entity);
        if (data == null) {
            return false;
        }

        try {
            boolean changed = PondusReflect.direction(entity) != dir;

            /* ⚠️ 方向没变就**立刻收工，什么都不写**。
             *
             * 这是"丢出去又瞬移回脚下"的元凶之一：
             * 下面的兜底分支（方向未变时重写 base 并置 needsSync）在没有
             * changed 保护的情况下**每 tick 都会执行**，于是：
             *   · 每帧把 baseGravityDirection 重写一遍
             *   · 每帧把 needsSync 置 true → 每帧给客户端发一个方向同步包
             *   · 客户端每帧收包 → 每帧重演一次 applyGravityDirectionChange()
             *     → 速度被反复旋转，vx 在 +0.275 / -0.264 之间来回翻
             *     → 水平位移净为 0，物品原地不动、看起来被"传送"回玩家脚下
             *
             * 实测证据（同一帧）：
             *   [S] 速度 (0.275, -0.164, -0.097) dir=down    ← 还正常
             *   [换向] down->up setter=true
             *   [S] 速度 (0.0,   -0.008,  0.0  ) dir=up      ← 水平分量归零
             *   [C] 速度 (-0.264, 0.188, -0.094) pondus=up   ← vx 被翻转
             *
             * 生物走 Pondus 原装 API，那里本来就有同样的"没变就返回"保护，
             * 所以生物从来没出过这个问题。这里补上，两条路径行为才一致。 */
            if (!changed) {
                return true;
            }

            /* 记录换向前的速度，供 VelocityFix 在 tick 之后补回水平分量。
             * 必须在调用 setter **之前**取 —— setter 会把速度清零。 */
            if (!entity.level().isClientSide()) {
                VelocityFix.save(entity);
            }

            boolean usedSetter = PondusReflect.invokeSetBaseDirection(data, dir);

            Direction after = PondusReflect.direction(entity);
            if (after != dir) {
                /* 兜底：setter 没能写进去（反射失败）。
                 * 只可能在 changed 时走到这里 —— 没变的情况已提前返回，
                 * 否则这里会每 tick 置一次 needsSync，造成每帧同步风暴。 */
                boolean wrote = PondusReflect.writeBaseDirection(data, dir);
                if (wrote && syncToClient) {
                    PondusReflect.markNeedsSync(data);
                }
                if (!wrote) {
                    MirrorGravity.LOGGER.warn(
                        "[镜维度·重力] 无法写入重力方向（实体 {}，方向 {}）",
                        entity.getType(), dir.getName());
                    return false;
                }
            } else if (!usedSetter && syncToClient) {
                // setter 不可用但字段写成功了，仍需手动置同步位
                PondusReflect.markNeedsSync(data);
            }

            /* 对不调用 super.tick() 的实体（FallingBlockEntity）直接写 curr ——
             * 它们的 commonTick() 永不执行，curr 不会从 base 同步过来。 */
            if (!PondusReflect.callsSuperTick(entity)) {
                PondusReflect.writeCurrDirection(data, dir);
            }

            return true;
        } catch (Throwable t) {
            MirrorGravity.LOGGER.debug("[镜维度·重力] 写入方向失败: {}", t.toString());
            return false;
        }
    }

    /**
     * 设定实体的重力强度倍数。
     *
     * <p>⚠️ 实测：这个字段**对掉落物无效**。KubeJS 侧的
     * {@code falling_gravity_scale = 0.2} 一路写进了 Pondus 的
     * {@code baseGravityStrength} 且读回确认是 0.2，但
     * {@code entity.getGravity()} 仍返回 0.04，用位置二阶差分算出的实际加速度
     * 也是满重力 —— 那个字段对掉落物是死字段。
     *
     * <p>仍然写入，是因为它对生物等实体可能有效，且写入极便宜；
     * 但不要指望它能改变掉落物的下落速度 —— 那由
     * {@link VelocityFix#applyItemGravityScale} 负责。
     *
     * @param scale 1.0 = 原版；0.5 = 一半；0 = 不受重力
     */
    public static boolean applyScale(Entity entity, double scale) {
        if (entity == null || !PondusReflect.resolve()) {
            return false;
        }
        Object data = PondusReflect.gravityDataOf(entity);
        if (data == null) {
            return false;
        }
        return PondusReflect.writeBaseStrength(data, scale);
    }
}
