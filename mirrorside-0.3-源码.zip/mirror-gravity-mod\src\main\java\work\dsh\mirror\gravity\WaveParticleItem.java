package work.dsh.mirror.gravity;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.joml.Vector3f;

/**
 * 波粒子：拿在手上<b>右键一个方块</b>，那个方块就获得下坠特性（与沙子同款）。
 *
 * <h2>为什么是"道具"而不是"新方块"</h2>
 * 原版的重力方块是<b>方块类</b>决定的（{@code FallingBlock}），已经放下的方块
 * 换不了类。所以做法是：模组记住"这一格被改造过"（{@link GravityTagData}），
 * 在邻居变化的同一时机按原版规则判定（{@link GravityTagger}）。
 * 道具只是这套机制的"入口"。
 *
 * <h2>只生效一次</h2>
 * 用户选的行为：方块掉下去落地之后就是普通方块，不会再次下坠。
 * 因此 {@link GravityTagger} 在交出去的那一刻就把标记删掉。
 *
 * <h2>客户端/服务端的判定分工</h2>
 * {@link GravityTagger#validate} 是只读的，两端都能算，所以先用它决定
 * "这次交互算不算成功"（关系到手臂摆动与物品动画）；真正的改造只在服务端做，
 * 服务端再校验一次（两次之间世界可能已经变了）。
 */
public class WaveParticleItem extends Item {

    /** 与波粒块同一套粉紫。 */
    private static final Vector3f PINK = new Vector3f(1.00F, 0.55F, 0.86F);
    private static final Vector3f PURPLE = new Vector3f(0.62F, 0.36F, 1.00F);

    public WaveParticleItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        Player player = context.getPlayer();
        if (player == null) {
            return InteractionResult.PASS;
        }

        String reject = GravityTagger.validate(level, pos);
        if (reject != null) {
            if (!level.isClientSide()) {
                hint(player, "message.mirrorgravity.wave_particle.reject." + reject, ChatFormatting.GRAY);
                level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_HIT, SoundSource.PLAYERS, 0.5F, 0.6F);
            }
            return InteractionResult.FAIL;
        }

        if (level.isClientSide()) {
            /* 预判成功：让客户端摆手臂、播使用动画。真正生效在服务端。 */
            return InteractionResult.SUCCESS;
        }

        ServerLevel serverLevel = (ServerLevel) level;
        String failed = GravityTagger.tag(serverLevel, pos);
        if (failed != null) {
            hint(player, "message.mirrorgravity.wave_particle.reject." + failed, ChatFormatting.GRAY);
            return InteractionResult.FAIL;
        }

        if (WaveParticleSettings.consume() && !player.isCreative()) {
            context.getItemInHand().shrink(1);
        }

        feedback(serverLevel, pos, player);
        return InteractionResult.SUCCESS;
    }

    /** 成功反馈：粉紫粒子 + 一声水晶音 + 行动栏说明。 */
    private void feedback(ServerLevel level, BlockPos pos, Player player) {
        double cx = pos.getX() + 0.5D;
        double cy = pos.getY() + 0.5D;
        double cz = pos.getZ() + 0.5D;
        /* 沿方块六个面撒粉紫尘埃：让"这一格被改造了"当场可见。 */
        for (int i = 0; i < 24; i++) {
            Vector3f color = (i % 2 == 0) ? PINK : PURPLE;
            level.sendParticles(new DustParticleOptions(color, 0.9F),
                cx + (level.random.nextDouble() - 0.5D) * 1.2D,
                cy + (level.random.nextDouble() - 0.5D) * 1.2D,
                cz + (level.random.nextDouble() - 0.5D) * 1.2D,
                1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        level.sendParticles(ParticleTypes.END_ROD, cx, cy, cz, 6, 0.3D, 0.3D, 0.3D, 0.01D);
        level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8F, 1.2F);
        hint(player, "message.mirrorgravity.wave_particle.tag", ChatFormatting.LIGHT_PURPLE);
    }

    private static void hint(Player player, String key, ChatFormatting color) {
        if (!WaveParticleSettings.notifyEnabled()) {
            return;
        }
        player.displayClientMessage(Component.translatable(key).withStyle(color), true);
    }
}
