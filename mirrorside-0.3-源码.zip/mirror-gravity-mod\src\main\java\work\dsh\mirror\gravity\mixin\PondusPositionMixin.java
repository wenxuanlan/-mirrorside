package work.dsh.mirror.gravity.mixin;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import work.dsh.mirror.gravity.MirrorGravity;
import work.dsh.mirror.gravity.PondusReflect;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 消掉 Pondus 换重力方向时给实体位置加的那一次平移。
 *
 * <h2>现象与出处</h2>
 * Pondus 的 {@code EntityGravityData.applyGravityDirectionChange} 会重演
 * "玩家转身"的几何。反编译出的算式（{@code rc} = getLocalRotationCenter）：
 * <pre>
 *   newPos = oldPos + vecPlayerToWorld(pos + rc, oldDir) − vecPlayerToWorld(rc, newDir)
 * </pre>
 * {@code RotationUtil.vecPlayerToWorld} 对 UP 是 {@code (x,y,z) → (-x,-y,z)}、
 * 对 DOWN 是恒等（逐条字节码确认），且新方向为旧方向反向时
 * {@code rc = (0, bbHeight/2, 0)}。代入 DOWN→UP：
 * <pre>
 *   newPos.y = oldPos.y + bbHeight
 * </pre>
 * 几何上自洽 —— 实体的位置字段是包围盒**最小角**而非中心，绕中心翻转时
 * 最小角本来就该移动一个包围盒高度。但它让"位置"这个数在换向帧凭空跳了一下。
 *
 * <h2>为什么在 Mixin 这一层修（而不是发包 / 事后补偿）</h2>
 * <ul>
 *   <li>{@code applyGravityDirectionChange} <b>服务端与客户端各自都会调用</b>
 *       —— 服务端由 {@code commonTick()} 触发，客户端收到同一份重力状态后
 *       同样触发。所以在这一处改一次，两端行为天然一致：<b>不需要任何额外的
 *       同步包，也不存在"一端改了另一端没改"的发散。</b></li>
 *   <li>事后补偿（在我们的 tick 处理里把位置掰回去）必须在两端各写一遍，
 *       还要复刻 Pondus 的算法，反而更容易两端算出不同结果。</li>
 *   <li>这里只回退位置一个量；速度处理、旋转动画、包围盒翻转全部原样保留。</li>
 * </ul>
 *
 * <h2>实现方式</h2>
 * 方法入口记下位置，方法出口把净位移回退掉：
 * <ul>
 *   <li><b>不猜常量</b>：偏移由 Pondus 自己算出来，我们只测量并回退，
 *       无需复刻 {@code getLocalRotationCenter} / {@code vecPlayerToWorld}。</li>
 *   <li>在方法<b>出口</b>统一回退，所以 {@code setPos} 之后那六次
 *       {@code xo/yo/zo}、{@code xOld/yOld/zOld} 字段写入会自动跟随一致 ——
 *       {@code x − xOld}（本模组与 KubeJS 都用来判断运动）不会被打乱。</li>
 * </ul>
 * 实测回退量恒为 {@code ±bbHeight}（物品 0.25），两端一致。
 *
 * <h2>⚠️ 这个类只能被 Mixin 加载</h2>
 * <b>绝对不要从普通代码里引用本类</b>（例如 {@code PondusPositionMixin.xxx()}）。
 * Mixin 类由框架特殊处理，被当作普通类解析时会直接让游戏崩溃：
 * <pre>
 *   NoClassDefFoundError: ...PondusPositionMixin is invalid
 *   at ...MixInClassTracker.handlesClass
 * </pre>
 * 这个坑已经踩过一次：诊断计数器原本写在本类里、由 {@code MirrorGravity}
 * 调用，结果一进世界就崩。凡是需要被普通代码使用的状态，一律放普通类。
 *
 * <h2>脆弱性</h2>
 * 依赖 Pondus 的实现细节，因此 {@code require = 0}：Pondus 升级导致织入失败时
 * <b>只退化为原来的瞬移，不会崩游戏</b>。
 */
@Mixin(value = dinner.dev.pondus.util.EntityGravityData.class, remap = false)
public class PondusPositionMixin {

    /**
     * 方法入口的位置。
     *
     * <p>用 {@link ThreadLocal} 而不是 map：入口与出口在同一个调用栈上，
     * 实体 tick 是单线程的，这样没有并发查找开销、也没有分配。
     */
    @Unique
    private static final ThreadLocal<Vec3> MIRRORGRAVITY_BEFORE = new ThreadLocal<>();

    /** 每个实体最多记几条回退日志：往复很快，不设上限会刷屏。 */
    @Unique
    private static final Map<UUID, Integer> MIRRORGRAVITY_LOGGED = new ConcurrentHashMap<>();

    @Unique
    private static final int MIRRORGRAVITY_LOG_MAX = 3;

    /** 取得 Mixin 目标对象里那个 {@code entity} 字段。 */
    @Unique
    private Entity mirrorgravity$self() {
        return ((dinner.dev.pondus.util.EntityGravityData) (Object) this).entity;
    }

    @Inject(method = "applyGravityDirectionChange", at = @At("HEAD"), remap = false, require = 0)
    private void mirrorgravity$captureBefore(CallbackInfo ci) {
        Entity self = mirrorgravity$self();
        /* 生物走 Pondus 原装路径，位置变换是它旋转身体所必需的，不能动。 */
        if (self == null || self instanceof LivingEntity) {
            MIRRORGRAVITY_BEFORE.remove();
            return;
        }
        MIRRORGRAVITY_BEFORE.set(self.position());
    }

    @Inject(method = "applyGravityDirectionChange", at = @At("RETURN"), remap = false, require = 0)
    private void mirrorgravity$rewindPositionShift(CallbackInfo ci) {
        Vec3 before = MIRRORGRAVITY_BEFORE.get();
        MIRRORGRAVITY_BEFORE.remove();
        if (before == null) {
            return;
        }
        Entity self = mirrorgravity$self();
        if (self == null) {
            return;
        }
        try {
            double[] cur = new double[3];
            if (!PondusReflect.readPosition(self, cur)) {
                return;
            }
            double dx = cur[0] - before.x;
            double dy = cur[1] - before.y;
            double dz = cur[2] - before.z;
            if (dx == 0.0D && dy == 0.0D && dz == 0.0D) {
                return;   // 没有平移，无需处理
            }

            /* 回退位置本身与六个历史位置字段。
             *
             * ⚠️ 不能用 Entity.setPos() 单独了事：它只改内部 position 与包围盒，
             * 不碰 xo/yo/zo 与 xOld/yOld/zOld。而 Pondus 刚把这六个字段
             * 都设成了平移后的值，不回退就会留下"上一帧位置被篡改"的状态，
             * 下一帧的位移、渲染插值与位置包都会错。 */
            PondusReflect.shiftPositionBack(self, dx, dy, dz);

            logFirstFew(self, before.y, cur[1], dy);
        } catch (Throwable t) {
            MirrorGravity.LOGGER.debug("[镜维度·位置] 回退失败: {}", t.toString());
        }
    }

    /**
     * 每个实体只记前几条，用来确认回退仍然生效。
     *
     * <p>回退量应当等于包围盒高度（物品 0.25）。若日志里出现明显不同的值，
     * 说明 Pondus 的算法变了、这里需要重新核对。
     */
    @Unique
    private void logFirstFew(Entity self, double beforeY, double afterY, double dy) {
        int n = MIRRORGRAVITY_LOGGED.merge(self.getUUID(), 1, Integer::sum);
        if (n > MIRRORGRAVITY_LOG_MAX) {
            return;
        }
        MirrorGravity.LOGGER.info(
            "[镜维度·位置] [{}] {} 换向位移已抵消: y {} => {} (回退 {}, 盒高 {})",
            self.level().isClientSide() ? "C" : "S", self.getType(),
            r(beforeY), r(afterY), r(dy), r(self.getBbHeight()));
    }

    @Unique
    private static double r(double v) {
        return Math.round(v * 10000) / 10000.0D;
    }
}
