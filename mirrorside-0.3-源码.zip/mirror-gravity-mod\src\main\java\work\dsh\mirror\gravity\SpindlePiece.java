package work.dsh.mirror.gravity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/**
 * 针尖对麦芒 · 结构片段：把自己那一份方块写进当前区块。
 *
 * <h2>为什么一个片段就够</h2>
 * 原版一个结构由若干片段拼成（房间、走廊……），每个片段负责自己那一段。
 * 这里整个装置是一体算出来的（两个圆锥 + 中间一块），所以只要一个片段；
 * 跨区块的问题由原版的机制解决：<b>每个区块生成到 FEATURES 阶段时，
 * 都会拿自己的可写区域（chunkBox）回调一次本片段的 postProcess</b>，
 * 片段只写落在 chunkBox 里的方块。于是"一个结构横跨十几个区块"
 * 就变成了"每个区块各写自己那一格"，不需要任何强行加载。
 *
 * <h2>为什么存的是参数，而不是"用随机数重算一遍"</h2>
 * 生成参数确实可以从种子重算（同一个区块永远是同一套参数）。但
 * {@link SpindleSettings} 是**运行时可改**的：哪天把半径上限从 13 调到 20，
 * 老存档里已生成的结构在重载区块时就会按新规则重算出另一套方块 ——
 * 与存档里已经写下的方块对不上，等于凭空改写了世界。
 * 所以这里把算好的几何量整份存进片段 NBT，读档时原样重建。
 */
public class SpindlePiece extends StructurePiece {

    /**
     * 需要存的双精度量，顺序与 {@link #writeDoubles} / {@link #readDoubles} 一致。
     * 用数组是为了"加一个字段只改一处"，避免两边漏改（0.2 期间就吃过这种亏）。
     */
    private static final String[] DOUBLE_KEYS = {
        "tipUpX", "tipUpY", "tipUpZ",
        "tipDnX", "tipDnY", "tipDnZ",
        "ux", "uy", "uz", "reach",
        "upLen", "upRad", "dnLen", "dnRad",
        "insetUp", "insetDn",
        "yaw", "pitch", "roll",
    };

    private final SpindleGeometry.Plan plan;

    public SpindlePiece(SpindleGeometry.Plan plan) {
        super(MirrorStructures.SPINDLE_PIECE.get(), 0,
            new BoundingBox(plan.minX, plan.minY, plan.minZ, plan.maxX, plan.maxY, plan.maxZ));
        this.plan = plan;
    }

    public SpindlePiece(CompoundTag tag) {
        super(MirrorStructures.SPINDLE_PIECE.get(), tag);
        double[] d = readDoubles(tag);
        this.plan = new SpindleGeometry.Plan(
            tag.getInt("coreX"), tag.getInt("coreY"), tag.getInt("coreZ"),
            d[6], d[7], d[8], d[9],
            d[0], d[1], d[2],
            d[3], d[4], d[5],
            d[10], d[11], tag.getInt("upKind"),
            d[12], d[13], tag.getInt("dnKind"),
            d[14], d[15],
            d[16], d[17], d[18]);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        tag.putInt("coreX", plan.coreX);
        tag.putInt("coreY", plan.coreY);
        tag.putInt("coreZ", plan.coreZ);
        tag.putInt("upKind", plan.upKind);
        tag.putInt("dnKind", plan.dnKind);
        double[] d = {
            plan.tipUpX, plan.tipUpY, plan.tipUpZ,
            plan.tipDnX, plan.tipDnY, plan.tipDnZ,
            plan.ux, plan.uy, plan.uz, plan.reach,
            plan.upLen, plan.upRad, plan.dnLen, plan.dnRad,
            plan.insetUp, plan.insetDn,
            plan.yawDeg, plan.pitchDeg, plan.rollDeg,
        };
        for (int i = 0; i < DOUBLE_KEYS.length; i++) {
            tag.putDouble(DOUBLE_KEYS[i], d[i]);
        }
    }

    private static double[] readDoubles(CompoundTag tag) {
        double[] d = new double[DOUBLE_KEYS.length];
        for (int i = 0; i < DOUBLE_KEYS.length; i++) {
            d[i] = tag.getDouble(DOUBLE_KEYS[i]);
        }
        return d;
    }

    /**
     * 写方块。只处理落在当前区块可写区域里的那些 ——
     * 越界的方块属于别的区块，那一次生成由那个区块自己负责。
     *
     * <h2>为什么直接 setBlock，而不是用 {@code StructurePiece.placeBlock}</h2>
     * 后者会先过一道 {@code canBeReplaced}：原版结构默认不覆盖已有方块。
     * 而这个装置要的正是"锥体穿过白玻璃、把玻璃换掉"（用户确认过），
     * 所以这里直接写。写到哪一层为止仍然受 chunkBox 限制，安全性不减。
     *
     * <p>标志位用 2：同步给客户端、不触发邻居更新 —— 与 {@code FillLayerFeature}
     * 铺玻璃层时用的是同一个标志，大批量生成方块时这是最省的写法。
     */
    @Override
    public void postProcess(
        WorldGenLevel level,
        StructureManager structureManager,
        ChunkGenerator generator,
        RandomSource random,
        BoundingBox chunkBox,
        ChunkPos chunkPos,
        BlockPos pivot) {
        BlockState needle = Blocks.IRON_BLOCK.defaultBlockState();
        BlockState awn = Blocks.HAY_BLOCK.defaultBlockState();
        BlockState core = MirrorBlocks.WAVE_PARTICLE_BLOCK.get().defaultBlockState();
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();

        SpindleGeometry.forEachBlock(
            plan,
            chunkBox.minX(), chunkBox.minY(), chunkBox.minZ(),
            chunkBox.maxX(), chunkBox.maxY(), chunkBox.maxZ(),
            (x, y, z, kind) -> {
                BlockState state;
                if (kind == SpindleGeometry.KIND_NEEDLE) {
                    state = needle;
                } else if (kind == SpindleGeometry.KIND_AWN) {
                    state = awn;
                } else {
                    state = core;
                }
                cursor.set(x, y, z);
                level.setBlock(cursor, state, 2);
            });
    }
}
