#!/usr/bin/env node
/**
 * 镜维度 · 「针尖对麦芒」数据包 ↔ 模组 交叉自检
 *
 * ── 为什么单独一个脚本 ───────────────────────────────────────────────────────
 * 这个装置和 spinning_colors 那种"原版 jigsaw + 结构方块模板"完全不同：
 * 它没有 template_pool、没有 .nbt，形状由**模组里的 Java 结构**自己算。
 * 于是断链点也换了一批，而且每一个都表现为"结构就是刷不出来 / 刷出来是空的"，
 * 且没有任何报错：
 *
 *   数据包 structure JSON 的 type ──→ 模组注册的结构类型 id
 *   数据包 structure JSON 的 biomes ─→ 真的存在那个生物群系
 *   structure_set 的间距 ──────────→ 密度是不是"稀有"
 *   结构的 step ───────────────────→ 与玻璃层（fill_layer）的先后顺序
 *   结构放的方块 ──────────────────→ 模组真的注册了它、且带掉落表与工具标签
 *
 * ── 检查项 ───────────────────────────────────────────────────────────────────
 *   A. 两个数据包文件在、JSON 合法
 *   B. type ↔ 模组结构类型注册；biomes ↔ 群系文件存在
 *   C. 生成密度（spacing/separation/salt）
 *   D. step 与玻璃层的先后关系（决定锥体能不能穿透白玻璃）
 *   E. 结构放置的方块：注册、掉落表、工具标签
 *
 * 用法：node tools-build/check-spindle.mjs      退出码 0 = 全部通过
 */
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const REPO = 'D:\\DSHwork\\MC镜维度';
const V = join(REPO, '.minecraft', 'versions', '镜维度');
const DATA = join(V, 'kubejs', 'data', 'mirror');
const JAVA = join(REPO, 'mirror-gravity-mod', 'src', 'main', 'java', 'work', 'dsh', 'mirror', 'gravity');
const RES = join(REPO, 'mirror-gravity-mod', 'src', 'main', 'resources');

let bad = 0;
const fail = (m) => { bad++; console.log('  ✗ ' + m); };
const ok = (m) => console.log('  ✓ ' + m);
const note = (m) => console.log('  · ' + m);

const read = (p) => readFileSync(p, 'utf8');
const json = (p) => JSON.parse(read(p));

const STRUCT = join(DATA, 'worldgen', 'structure', 'spindle.json');
const SET = join(DATA, 'worldgen', 'structure_set', 'spindle.json');
const BIOME = join(DATA, 'worldgen', 'biome', 'mirror.json');

console.log('=== A. 数据包文件 ===');
for (const p of [STRUCT, SET, BIOME]) {
  if (!existsSync(p)) fail(`缺少 ${p.replace(V + '\\', '')}`);
  else ok(p.replace(V + '\\kubejs\\data\\', ''));
}
if (bad) { console.log('\n✗ 文件不全，后续检查跳过'); process.exit(1); }

const structure = json(STRUCT);
const set = json(SET);
const biome = json(BIOME);

console.log('\n=== B. type ↔ 模组注册 / biomes ↔ 群系 ===');
const mirrorStructures = read(join(JAVA, 'MirrorStructures.java'));
const modId = (/MOD_ID\s*=\s*"([^"]+)"/.exec(read(join(JAVA, 'MirrorGravity.java'))) || [])[1];
const type = String(structure.type || '');
const [typeNs, typeName] = type.split(':');
if (typeNs !== modId) {
  fail(`结构 type 的命名空间是 "${typeNs}"，但模组 id 是 "${modId}"`);
} else if (!new RegExp(`STRUCTURE_TYPES\\.register\\("${typeName}"`).test(mirrorStructures)) {
  fail(`MirrorStructures.java 里没有注册结构类型 "${typeName}" —— JSON 会读不出来（结构静默不生成）`);
} else {
  ok(`type = ${type} ↔ MirrorStructures 注册 "${typeName}"`);
}

const biomes = Array.isArray(structure.biomes) ? structure.biomes : [structure.biomes];
if (!biomes.includes('mirror:mirror')) {
  fail(`biomes 必须包含 mirror:mirror，当前 ${JSON.stringify(structure.biomes)}`);
} else {
  ok(`biomes = ${JSON.stringify(structure.biomes)}（镜维度是固定群系，全维度可用）`);
}
/* 1.21.1 原版机制核对：结构性生成与否只看**结构自己的 biomes**，
 * 群系 JSON 里没有 structures 字段（对照原版 plains.json 的键确认过），
 * 所以这里不需要往 mirror.json 里补东西 —— 补了反而是误解。 */
if ('structures' in biome) {
  note('群系 JSON 里有 structures 字段：1.21.1 原版群系不写它，若无效可删（不影响本结构）');
}

console.log('\n=== C. 生成密度 ===');
const placement = set.placement || {};
const entry = (set.structures || []).find((s) => s.structure === 'mirror:spindle');
if (!entry) fail('structure_set 里没有 mirror:spindle 条目');
else ok(`structure_set 含 mirror:spindle（weight ${entry.weight ?? 1}）`);
if (placement.type !== 'minecraft:random_spread') {
  fail(`placement.type 应为 minecraft:random_spread，当前 ${placement.type}`);
} else {
  ok('placement.type = minecraft:random_spread');
}
const spacing = Number(placement.spacing);
const separation = Number(placement.separation);
if (!Number.isFinite(spacing) || !Number.isFinite(separation)) {
  fail('spacing / separation 必须是数字');
} else if (separation >= spacing) {
  fail(`separation(${separation}) 必须小于 spacing(${spacing})，否则结构会互相挤掉`);
} else {
  const chunks = spacing / 16;
  ok(`spacing ${spacing} / separation ${separation} ⇒ 平均每 ${chunks}×${chunks} 区块一座`
    + `（${(chunks * chunks).toFixed(0)} 个区块一座，属于"稀有"）`);
}
if (placement.salt == null) fail('placement.salt 缺失（同一 spacing 的结构必须用不同 salt 才不会重叠）');
else ok(`salt = ${placement.salt}`);

console.log('\n=== D. step 与玻璃层的先后（锥体能否穿透白玻璃）===');
/* 结论来自对 1.21.1 源码的核对，两条缺一不可：
 *   1) ChunkGenerator.applyBiomeDecoration 按 GenerationStep.Decoration 顺序逐级放置：
 *      每一级先放**该级的结构**，再放该级的地物。玻璃层在 features 数组的最后一格
 *      （top_layer_modification），结构在 surface_structures ⇒ 结构先写。
 *   2) FillLayerFeature.place 的循环体是 `if (isAir()) setBlock(...)`
 *      —— 只填空气。所以后放的玻璃遇到已写好的锥体方块会自己绕开。 */
const step = String(structure.step || '');
if (step !== 'surface_structures') {
  note(`step = ${step || '(缺省 surface_structures)'}；只要在 top_layer_modification 之前都能穿透玻璃`);
} else {
  ok('step = surface_structures（早于玻璃层的 top_layer_modification）');
}
const featArr = Array.isArray(biome.features) ? biome.features : [];
const lastStep = featArr.length ? featArr[featArr.length - 1] : [];
const glassNames = (lastStep || []).filter((x) => String(x).startsWith('mirror:glass_layer_'));
if (!glassNames.length) {
  fail('群系 features 的最后一格（top_layer_modification）里没有找到 mirror:glass_layer_*'
    + ' —— 玻璃层的生成时机变了，锥体穿透玻璃的结论需要重新核对');
} else {
  ok(`玻璃层位于 features 最后一格（${glassNames.length} 个），结构早于它 ⇒ 玻璃只填空气、不会盖掉锥体`);
}
const cfgFeat = join(DATA, 'worldgen', 'configured_feature', 'glass_layer_1_pos63.json');
if (existsSync(cfgFeat)) {
  const t = json(cfgFeat).type;
  if (t !== 'minecraft:fill_layer') {
    fail(`玻璃层配置特征类型是 ${t}，不是 minecraft:fill_layer —— 请重新核对"只填空气"这条结论`);
  } else {
    ok('玻璃层用的仍是 minecraft:fill_layer（1.21.1 源码里只填空气）');
  }
}

console.log('\n=== E. 结构放置的方块 ===');
const mirrorBlocks = read(join(JAVA, 'MirrorBlocks.java'));
const piece = read(join(JAVA, 'SpindlePiece.java'));
const BLOCK = 'wave_particle_block';
if (!new RegExp(`BLOCKS\\.register\\(\\s*"${BLOCK}"`).test(mirrorBlocks)) {
  fail(`MirrorBlocks.java 没有注册方块 ${BLOCK}`);
} else {
  ok(`方块 ${BLOCK} 已在模组里注册`);
}
if (!piece.includes('WAVE_PARTICLE_BLOCK')) {
  fail('SpindlePiece.java 没有引用 WAVE_PARTICLE_BLOCK —— 结构不会放波粒块');
} else {
  ok('结构片段确实会放置波粒块');
}
const loot = join(RES, 'data', 'mirrorgravity', 'loot_table', 'blocks', `${BLOCK}.json`);
if (!existsSync(loot)) {
  fail(`缺少掉落表 data/mirrorgravity/loot_table/blocks/${BLOCK}.json —— 方块会"挖了什么都不掉"`);
} else {
  const l = json(loot);
  const names = JSON.stringify(l);
  if (!names.includes(`mirrorgravity:${BLOCK}`)) fail('掉落表里没有这个方块自己');
  else ok('掉落表存在且掉自己');
}
for (const tag of ['mineable/pickaxe', 'needs_diamond_tool']) {
  const p = join(RES, 'data', 'minecraft', 'tags', 'block', `${tag}.json`);
  if (!existsSync(p)) { fail(`缺少方块标签 ${tag}（钻石镐门槛就不成立）`); continue; }
  const t = json(p);
  if (!(t.values || []).includes(`mirrorgravity:${BLOCK}`)) fail(`${tag} 里没有 mirrorgravity:${BLOCK}`);
  else if (t.replace === true) fail(`${tag} 写了 "replace": true —— 会把原版同标签整个替换掉`);
  else ok(`标签 ${tag} 正确（replace=false，追加）`);
}

console.log('\n' + (bad === 0 ? '✓ 针尖对麦芒数据链全部通过' : `✗ ${bad} 个问题`));
process.exit(bad === 0 ? 0 : 1);
