#!/usr/bin/env node
/**
 * 镜维度 · 音效资源自检
 * =====================================================================
 * 检查「模组 sounds.json 里写的音频文件真的存在」，以及
 *      「KubeJS 配置里引用的音效事件真的有来源」。
 *
 * 为什么需要它（2026-09 实测事故）：
 *   进维度提示音做成了模组自带的烘焙音效，sounds.json 里写成
 *       "name": "mirror/enter_echo"
 *   （想当然地以为"不带命名空间就继承资源包命名空间"）。
 *   结果客户端日志里是：
 *       File minecraft:sounds/mirror/enter_echo.ogg does not exist,
 *       cannot add it to event mirrorgravity:block.mirror_enter
 *       Unable to play empty soundEvent: mirrorgravity:block.mirror_enter
 *   游戏里表现为**完全没有声音**，而服务端侧一切正常（playSound 调用成功、
 *   指令回执也是成功），只有客户端日志里两行 WARN。
 *
 *   原版代码是这样的（net.minecraft.client.sounds.SoundManager#prepare）：
 *     · JSON 的**键**（事件名）会用资源包命名空间补全
 *         ResourceLocation.fromNamespaceAndPath(packNamespace, entry.getKey())
 *     · 但每条音效的 **name 字段**由 Sound 自己的编解码器解析，
 *       走 ResourceLocation 的默认规则 —— **不带冒号就是 minecraft**
 *     然后 Sound.getPath() 拼的是
 *         <name 的命名空间>:sounds/<name 的路径>.ogg
 *   所以模组的 sounds.json 里，name **必须写全命名空间**。
 *
 * 用法:  node tools/check-sound-assets.mjs
 * =====================================================================
 */

import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const INSTANCE = resolve(HERE, '..');
const MOD_SRC = 'D:\\DSHwork\\MC镜维度\\mirror-gravity-mod\\src\\main\\resources';

let bad = 0;
const warn = (m) => { console.log('  ✗ ' + m); bad++; };
const ok = (m) => console.log('  ✓ ' + m);

/* ------------------------------------------------------------------ */
/* 一、模组 sounds.json 里引用的文件是否存在                             */
/* ------------------------------------------------------------------ */

console.log('=== 模组 sounds.json 音频文件自检 ===');
console.log('资源目录: ' + MOD_SRC);

const assetsDir = join(MOD_SRC, 'assets');
if (!existsSync(assetsDir)) {
  console.log('  （没有 assets 目录，跳过）');
} else {
  let checked = 0;
  for (const ns of readdirSync(assetsDir)) {
    const soundsJson = join(assetsDir, ns, 'sounds.json');
    if (!existsSync(soundsJson)) continue;

    let json;
    try {
      json = JSON.parse(readFileSync(soundsJson, 'utf8'));
    } catch (e) {
      warn(`assets/${ns}/sounds.json 不是合法 JSON: ${e.message}`);
      continue;
    }

    for (const [eventName, def] of Object.entries(json)) {
      const list = Array.isArray(def?.sounds) ? def.sounds : [];
      if (list.length === 0) {
        warn(`${ns}:${eventName} 的 sounds 数组是空的（游戏里会报 empty soundEvent）`);
        continue;
      }
      for (const entry of list) {
        const name = typeof entry === 'string' ? entry : entry?.name;
        if (!name) {
          warn(`${ns}:${eventName} 有一条音效没有 name`);
          continue;
        }
        const type = (typeof entry === 'object' && entry.type) || 'file';
        const full = name.includes(':') ? name : 'minecraft:' + name;
        const [entryNs, entryPath] = full.split(':');

        if (type === 'event') {
          checked++;
          if (entryNs === 'minecraft') {
            ok(`${ns}:${eventName} → 引用原版事件 ${full}（type=event，合法）`);
          } else {
            ok(`${ns}:${eventName} → 引用事件 ${full}（type=event）`);
          }
          continue;
        }

        /* ⚠️ 核心检查：FILE 类型的 name 不带命名空间 → 会被当成 minecraft，
         *    对模组来说这几乎总是写错了。 */
        if (!name.includes(':')) {
          warn(`${ns}:${eventName} 的 name "${name}" 没有命名空间 ——`
            + ` 游戏会去找 ${entryNs}:sounds/${entryPath}.ogg 并报`
            + ` "cannot add it to event"。应写成 "${ns}:${name}"`);
        }

        const file = join(assetsDir, entryNs, 'sounds', entryPath + '.ogg');
        checked++;
        if (existsSync(file)) {
          ok(`${ns}:${eventName} → assets/${entryNs}/sounds/${entryPath}.ogg`);
        } else {
          warn(`${ns}:${eventName} 引用的文件不存在: assets/${entryNs}/sounds/${entryPath}.ogg`);
        }
      }
    }
  }
  if (checked === 0) console.log('  （没有可检查的音效条目）');
}

/* ------------------------------------------------------------------ */
/* 二、KubeJS 配置里引用的音效事件是否有来源                             */
/* ------------------------------------------------------------------ */

console.log('\n=== KubeJS 配置引用的音效事件 ===');

const cfgPath = join(INSTANCE, 'kubejs', 'startup_scripts', 'mirror_config.js');
if (!existsSync(cfgPath)) {
  warn('找不到 mirror_config.js');
} else {
  const cfg = readFileSync(cfgPath, 'utf8');
  const refs = [...cfg.matchAll(/event:\s*'([^']+)'/g)].map((m) => m[1]);
  if (refs.length === 0) console.log('  （配置里没有 event: 字段）');

  /* 收集所有模组（含 vanilla）能提供的音效事件名 */
  const provided = new Set();

  /* 1) 本模组自己的 sounds.json */
  for (const ns of existsSync(assetsDir) ? readdirSync(assetsDir) : []) {
    const p = join(assetsDir, ns, 'sounds.json');
    if (!existsSync(p)) continue;
    try {
      for (const k of Object.keys(JSON.parse(readFileSync(p, 'utf8')))) provided.add(ns + ':' + k);
    } catch { /* 上面已经报过 */ }
  }

  /* 2) 原版音效事件表：直接从客户端 jar 的 SoundEvents 常量池里扫字符串太脆，
   *    改成扫实例 assets 里挖出来的 sounds.json（tools 里那份参考副本）。 */
  const vanillaSounds = 'D:\\DSHwork\\MC镜维度\\tools-build\\mirror-audio\\sounds.json';
  if (existsSync(vanillaSounds)) {
    try {
      for (const k of Object.keys(JSON.parse(readFileSync(vanillaSounds, 'utf8')))) {
        provided.add('minecraft:' + k);
      }
    } catch { /* 忽略 */ }
  }

  for (const r of refs) {
    const full = r.includes(':') ? r : 'minecraft:' + r;
    if (provided.has(full)) {
      ok(`${full}`);
    } else if (full.startsWith('minecraft:')) {
      console.log(`  ? ${full} —— 不在参考 sounds.json 里；若确认是原版事件可忽略`);
    } else {
      warn(`${full} 没有任何 sounds.json 提供（游戏里会报 unknown soundEvent）`);
    }
  }
}

console.log('\n' + (bad === 0 ? '✓ 音效资源自检通过' : `✗ 发现 ${bad} 个问题`));
if (bad > 0) process.exitCode = 1;
