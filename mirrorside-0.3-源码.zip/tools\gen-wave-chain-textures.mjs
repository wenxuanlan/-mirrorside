#!/usr/bin/env node
/*
 * 生成「波」与「粒」两个中间材料的贴图（粉紫家族，与波粒子同色）。
 *
 * ── 形状依据（不是凭印象画的）─────────────────────────────────────────────────
 * 用户要求：波 → 仿照**腐肉**；粒 → 仿照**重锤核心**。
 * 两张原版贴图都从版本 jar 里解出来放大 12 倍看过：
 *
 *   腐肉 rotten_flesh.png：一块**沿对角线拉长的撕裂状肉块**，边缘是锯齿/缺口
 *     （不是光滑椭圆），内部有深浅不一的斑块。
 *     ⇒ 本脚本用「45° 拉长的椭圆 + 三个谐波使轮廓起伏 + 逐像素咬边」复刻那种撕裂感。
 *
 *   重锤核心 heavy_core：它其实是**方块**（item 模型直接 parent 到 block/heavy_core），
 *     16×16 的方块面贴图是「亮外框 + 中间一块深色内凹」，在物品栏里渲染成一个小立方体。
 *     ⇒ 二维化成物品图标就是「方形亮框 + 内凹面 + 斜角明暗」，本脚本按这个画。
 *
 * ── 调参入口 ─────────────────────────────────────────────────────────────────
 *   WAVE_HARMONICS  波：轮廓起伏（改成 0 就是光滑椭圆）
 *   WAVE_BITE       波：逐像素咬边的幅度（撕裂感强弱）
 *   CUBE_FRAME      粒：外框宽度分界（越大框越窄）
 *   BEVEL           粒：斜角明暗强度（0 = 平板）
 *
 * 用法（在实例目录下）：
 *   node tools/gen-wave-chain-textures.mjs            # 写入模组资源目录
 *   node tools/gen-wave-chain-textures.mjs --preview  # 额外在 %TEMP% 出放大预览
 */

import { deflateSync } from 'node:zlib';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';

const HERE = dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = join(HERE, '..', '..', '..', '..');
const TEX_DIR = join(PROJECT_ROOT,
  'mirror-gravity-mod/src/main/resources/assets/mirrorgravity/textures/item');

const SIZE = 16;

/* ---- 波（腐肉式撕裂块）调参 ---- */
const WAVE_HARMONICS = [0.09, 0.06, 0.04];   // 三个谐波的幅度
const WAVE_BITE = 0.13;                      // 逐像素咬边幅度

/* ---- 粒（重锤核心式方块）调参 ---- */
const CUBE_FRAME = 0.70;                     // 大于它 = 外框
const CUBE_RECESS = 0.42;                    // 小于它 = 内凹
const BEVEL = 0.35;                          // 斜角明暗强度

/* ---- 粉紫家族（与波粒子保持一致）---- */
const PINK = [246, 143, 216];
const PURPLE = [150, 70, 240];
const DEEP = [122, 52, 156];      // 波：深斑块
const DARK = [92, 40, 118];       // 波：描边
const FRAME = [238, 166, 240];    // 粒：外框
const FACE = [198, 118, 232];     // 粒：面
const RECESS = [104, 48, 150];    // 粒：内凹
const HILIGHT = [255, 226, 252];  // 粒：左上高光
const SHADOW = [74, 34, 104];     // 粒：右下阴影

/* ------------------------------------------------------------------ PNG 编码 */

const CRC_TABLE = (() => {
  const table = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c;
  }
  return table;
})();

function crc32(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, 'latin1'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

function encodePng(rgba, w, h) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;
    Buffer.from(rgba.buffer, rgba.byteOffset + y * w * 4, w * 4).copy(raw, y * (w * 4 + 1) + 1);
  }
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/* ------------------------------------------------------------------ 工具 */

const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
const clamp01 = (v) => Math.min(1, Math.max(0, v));
const smoothstep = (e0, e1, x) => {
  const t = clamp01((x - e0) / (e1 - e0));
  return t * t * (3 - 2 * t);
};

/** 确定性哈希 → [0,1)：像素级"随机"必须可复现，不能用 Math.random。 */
function hash2(x, y) {
  let h = (x * 374761393 + y * 668265263) | 0;
  h = (h ^ (h >>> 13)) * 1274126177;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

/** 低频斑块噪声（双线性插值的格点哈希）。 */
function patchNoise(x, y) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const v00 = hash2(xi, yi), v10 = hash2(xi + 1, yi);
  const v01 = hash2(xi, yi + 1), v11 = hash2(xi + 1, yi + 1);
  const sx = xf * xf * (3 - 2 * xf), sy = yf * yf * (3 - 2 * yf);
  return (v00 * (1 - sx) + v10 * sx) * (1 - sy) + (v01 * (1 - sx) + v11 * sx) * sy;
}

/* ------------------------------------------------------------------ 波 */

function waveTexel(x, y, size) {
  const half = size / 2;
  const dx = (x + 0.5 - half) / (half - 0.5);
  const dy = (y + 0.5 - half) / (half - 0.5);
  /* 45° 拉长：沿主对角线长、垂直方向短（腐肉就是斜着的一条）。
   * 1.20/0.76 试过，太圆、像一团云；1.40/0.60 才接近腐肉那种"斜着的一块"。 */
  const u = (dx + dy) / Math.SQRT2 / 1.40;
  const v = (dx - dy) / Math.SQRT2 / 0.60;
  const r = Math.hypot(u, v);
  const th = Math.atan2(v, u);
  const wav = 1
    + WAVE_HARMONICS[0] * Math.sin(3 * th + 1.1)
    + WAVE_HARMONICS[1] * Math.sin(5 * th + 2.4)
    + WAVE_HARMONICS[2] * Math.sin(7 * th + 0.3);
  /* 逐像素咬边：让轮廓是撕裂状而不是光滑弧线 */
  const bite = 1 + WAVE_BITE * (hash2(x, y) - 0.5) * 2;
  const edge = wav * bite;
  const coverage = 1 - smoothstep(edge - 0.05, edge + 0.05, r);
  if (coverage <= 0) {
    return [0, 0, 0, 0];
  }
  /* 底色：沿对角线 紫→粉 */
  const t = clamp01(0.5 + 0.5 * (dx - dy * 0.55));
  let color = mix(PURPLE, PINK, t);
  /* 深斑块：腐肉内部深浅不一，这里用低频噪声压出几块暗斑。
   * 阈值 0.35/系数 0.75 时几乎看不出来，改成 0.30/1.0 才有"肉块里深浅不一"的感觉。 */
  const patch = patchNoise(x * 0.42, y * 0.42);
  color = mix(color, DEEP, clamp01((patch - 0.30) * 1.0) * 0.95);
  /* 边缘压深一圈当描边 */
  const rim = 1 - smoothstep(edge * 0.72, edge, r);
  color = mix(color, DARK, rim * 0.55);
  return [Math.round(color[0]), Math.round(color[1]), Math.round(color[2]),
    Math.round(coverage * 255)];
}

/* ------------------------------------------------------------------ 粒 */

function particleTexel(x, y, size) {
  const half = size / 2;
  const dx = (x + 0.5 - half) / (half - 0.5);
  const dy = (y + 0.5 - half) / (half - 0.5);
  /* 方形距离：外框 / 面 / 内凹 三层，复刻重锤核心那块方块面 */
  const jitter = (hash2(x * 3 + 1, y * 3 + 7) - 0.5) * 0.07;
  const m = Math.max(Math.abs(dx), Math.abs(dy)) + jitter;
  if (m > 0.94) {
    return [0, 0, 0, 0];
  }
  let color;
  if (m > CUBE_FRAME) {
    color = FRAME;
  } else if (m > CUBE_RECESS) {
    color = FACE;
  } else {
    color = RECESS;
  }
  /* 斜角明暗：左上亮、右下暗，做出"立方体"的体积感 */
  const bevel = (-dx - dy) / 2;
  if (bevel > 0) {
    color = mix(color, HILIGHT, bevel * BEVEL);
  } else {
    color = mix(color, SHADOW, -bevel * BEVEL);
  }
  /* 外缘一圈略收暗，避免像一枚贴纸 */
  const edge = 1 - smoothstep(0.86, 0.94, m);
  color = mix(color, SHADOW, (1 - edge) * 0.5);
  return [Math.round(color[0]), Math.round(color[1]), Math.round(color[2]), 255];
}

/* ------------------------------------------------------------------ 输出 */

function build(size, fn) {
  const rgba = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const px = fn(x, y, size);
      const i = (y * size + x) * 4;
      rgba[i] = px[0];
      rgba[i + 1] = px[1];
      rgba[i + 2] = px[2];
      rgba[i + 3] = px[3];
    }
  }
  return rgba;
}

/** 两张并排放大成一张预览（中灰底，方便看透明与描边） */
function buildPreview(size, scale) {
  const w = size * 2 * scale;
  const h = size * scale;
  const rgba = new Uint8Array(w * h * 4);
  const a = build(size, waveTexel);
  const b = build(size, particleTexel);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const second = x >= size * scale;
      const src = second ? b : a;
      const sx = Math.floor((second ? x - size * scale : x) / scale);
      const sy = Math.floor(y / scale);
      const s = (sy * size + sx) * 4;
      const d = (y * w + x) * 4;
      const alpha = src[s + 3] / 255;
      rgba[d] = Math.round(src[s] * alpha + 64 * (1 - alpha));
      rgba[d + 1] = Math.round(src[s + 1] * alpha + 64 * (1 - alpha));
      rgba[d + 2] = Math.round(src[s + 2] * alpha + 64 * (1 - alpha));
      rgba[d + 3] = 255;
    }
  }
  return { rgba, w, h };
}

mkdirSync(TEX_DIR, { recursive: true });
for (const [name, fn] of [['wave', waveTexel], ['particle', particleTexel]]) {
  const out = join(TEX_DIR, `${name}.png`);
  writeFileSync(out, encodePng(build(SIZE, fn), SIZE, SIZE));
  console.log(`已写入 ${out}`);
}

if (process.argv.includes('--preview')) {
  const { rgba, w, h } = buildPreview(SIZE, 12);
  const previewPath = join(tmpdir(), 'wave-chain-preview.png');
  writeFileSync(previewPath, encodePng(rgba, w, h));
  console.log(`预览（左=波 右=粒）${previewPath}`);
}
