import dev.latvian.mods.rhino.Context;
import dev.latvian.mods.rhino.ContextFactory;
import dev.latvian.mods.rhino.Scriptable;

/**
 * KubeJS 的 Rhino 分支作用域探针（第 1 组）。
 *
 * 用途：验证「哪些 const/let 会抛 TypeError: redeclaration of var xxx」。
 * 起因：mirror_n4_gravity.js 的 PlayerEvents.tick 里
 *       if (!inMirror) { const N5o = moduleRef('n5'); ... }
 *       每次调用都抛异常（日志里刷了 36 条），那一行之后的 leaveOuter()
 *       从未执行 —— 而 KubeJS 加载脚本时依旧显示 0 errors。
 *
 * 怎么跑（不需要启动游戏）：
 *   $rhino = "<实例>\mods\[犀牛] rhino-2101.2.7-build.85.jar"
 *   & javac -encoding UTF-8 -cp $rhino RhinoScopeProbe.java
 *   & java "-Dfile.encoding=UTF-8" -cp "$rhino;." RhinoScopeProbe
 *
 * 结论（配合 RhinoScopeProbe2 一起看）：
 *   · 函数顶层、if/for 块内的 const/let（值被使用）→ 正常
 *   · **try 块内的 const** → 抛 InternalError: TypeError: redeclaration of var xxx
 *     注意：本探针用例 C 把它记成了"正常"，那是**误判** —— 用例 C 写成
 *     `try { const c = 3; } catch (e) {}`，异常被自己的 catch 吞掉、c 又没被
 *     使用，所以外面看不出任何异常。专项复现已拆到 RhinoTryProbe.java，
 *     那里让 catch 把异常当返回值抛出来，才看得到真相。
 *   · 脚本顶层块里的 const/let（if/for 里）→ 抛 redeclaration
 *   · 事件处理器里的嵌套块 → 实测也抛（见 lint 规则与经验总结十五）
 *   本探针只能覆盖"直接调用"的路径，事件处理器走的是 Java 接口代理，
 *   那条路径复现成本高（需要 KubeJS 自己的 ContextFactory），
 *   所以最终以**实机日志**为准，并把规则写进 tools/lint-scripts.mjs。
 */
public class RhinoScopeProbe {

    static int failures = 0;

    static void run(String label, String src) {
        ContextFactory factory = new ContextFactory();
        Context cx = factory.enter();
        try {
            Scriptable scope = cx.initStandardObjects();
            Object result = cx.evaluateString(scope, src, label, 1, null);
            System.out.println("  OK   " + label + "  => " + cx.toString(result));
        } catch (Throwable t) {
            failures++;
            System.out.println("  FAIL " + label + "  => " + t.getClass().getSimpleName()
                + ": " + t.getMessage());
        } finally {
            // 这个分支没有 factory.exit()，Context 用完即弃
        }
    }

    public static void main(String[] args) {
        System.out.println("=== A 函数顶层 const，重复调用 ===");
        run("A", "var f = function () { const a = 1; return a; };"
            + "var s = 0; for (var i = 0; i < 3; i++) { s += f(); } s;");

        System.out.println("=== B if 块内 const，重复调用 ===");
        run("B", "var f = function () { if (true) { const b = 2; } return 1; };"
            + "var s = 0; for (var i = 0; i < 3; i++) { s += f(); } s;");

        System.out.println("=== C try 块内 const，重复调用 ===");
        run("C", "var f = function () { try { const c = 3; } catch (e) {} return 1; };"
            + "var s = 0; for (var i = 0; i < 3; i++) { s += f(); } s;");

        System.out.println("=== D for 头 let，重复调用 ===");
        run("D", "var f = function () { var t = 0; for (let i = 0; i < 3; i++) { t += i; } return t; };"
            + "var s = 0; for (var i = 0; i < 3; i++) { s += f(); } s;");

        System.out.println("=== E 嵌套块内 const 且返回新对象 ===");
        run("E", "var handler = function (ev) {"
            + "  if (ev === 1) { const n = { x: 1 }; return n; }"
            + "  return null; };"
            + "var s = 0; for (var i = 0; i < 3; i++) { s += (handler(1) != null ? 1 : 0); } s;");

        System.out.println("=== F 嵌套块内 var（对照组）===");
        run("F", "var f = function () { if (true) { var v = 2; } return 1; };"
            + "var s = 0; for (var i = 0; i < 3; i++) { s += f(); } s;");

        System.out.println("=== G 块内 const 取自外部同一对象引用 ===");
        run("G", "var dep = { v: 7 };"
            + "var f = function () { if (true) { const d = dep; return d.v; } return 0; };"
            + "var s = 0; for (var i = 0; i < 3; i++) { s += f(); } s;");

        System.out.println("=== H 块内 const，每次都是新对象 ===");
        run("H", "var f = function () { if (true) { const d = { v: 7 }; return d.v; } return 0; };"
            + "var s = 0; for (var i = 0; i < 3; i++) { s += f(); } s;");

        System.out.println("=== I 箭头函数 + 嵌套块内 const（贴近真实写法）===");
        run("I", "var reg = function (fn) { var n = 0; for (var i = 0; i < 3; i++) { n += fn({ p: i }); } return n; };"
            + "reg(ev => { if (ev.p > 0) { const dep = { q: 1 }; return dep.q; } return 0; });");

        System.out.println("=== J 块内 const 在函数外（顶层块）===");
        run("J", "if (true) { const top = 5; } 1;");

        System.out.println();
        System.out.println(failures == 0 ? "全部通过" : (failures + " 项失败"));
    }
}
