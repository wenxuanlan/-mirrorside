#!/usr/bin/env node
/**
 * 贴图分析器：解码 PNG 并输出 ASCII 预览 + 配色统计。
 *
 * 用途：生成"镜维度"自己的贴图前，先看清参照模组（铁砧工艺/AnvilCraft）
 * 的实际画法 —— 明暗怎么排布、用多少种颜色、有没有描边。
 * 只看小图猜很容易画歪。
 *
 * 纯手工解码 PNG（zlib + 反滤波 + 调色板），不依赖任何第三方库。
 *
 * ⚠️ 必须支持 colorType=3（索引调色板）：Minecraft 的方块贴图基本都是
 * 这个格式（体积小）。只支持 RGBA 的解码器会把它们全部读成黑色 —— 实测踩过。
 *
 * 用法：
 *   node tools/inspect-texture.mjs <png 路径>
 */

import { readFileSync } from 'node:fs';
import { inflateSync } from 'node:zlib';

const file = process.argv[2];
if (!file) {
  console.error('用法: node tools/inspect-texture.mjs <png>');
  process.exit(1);
}

const buf = readFileSync(file);
if (buf.readUInt32BE(0) !== 0x89504e47) throw new Error('不是 PNG 文件');

let pos = 8;
let width = 0, height = 0, bitDepth = 0, colorType = 0;
let palette = null, transparency = null;
const idat = [];

while (pos < buf.length) {
  const len = buf.readUInt32BE(pos);
  const type = buf.toString('ascii', pos + 4, pos + 8);
  const data = buf.subarray(pos + 8, pos + 8 + len);

  if (type === 'IHDR') {
    width = data.readUInt32BE(0);
    height = data.readUInt32BE(4);
    bitDepth = data[8];
    colorType = data[9];
  } else if (type === 'PLTE') {
    palette = [];
    for (let i = 0; i < len; i += 3) palette.push([data[i], data[i + 1], data[i + 2]]);
  } else if (type === 'tRNS') {
    transparency = data;
  } else if (type === 'IDAT') {
    idat.push(data);
  } else if (type === 'IEND') break;

  pos += 12 + len;
}

const raw = inflateSync(Buffer.concat(idat));

// 每像素占多少**字节**（不是位）
const channels = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[colorType];
if (bitDepth !== 8 || !channels) {
  throw new Error(`暂不支持 bitDepth=${bitDepth} colorType=${colorType}`);
}

const stride = width * channels;
const px = Buffer.alloc(height * stride);

/* ---------- 反滤波 ---------- */
let rp = 0;
for (let y = 0; y < height; y++) {
  const filter = raw[rp++];
  const row = raw.subarray(rp, rp + stride);
  rp += stride;
  const out = px.subarray(y * stride, (y + 1) * stride);
  const prev = y > 0 ? px.subarray((y - 1) * stride, y * stride) : null;

  for (let i = 0; i < stride; i++) {
    const a = i >= channels ? out[i - channels] : 0;
    const b = prev ? prev[i] : 0;
    const c = (prev && i >= channels) ? prev[i - channels] : 0;
    let v = row[i];
    switch (filter) {
      case 0: break;
      case 1: v = (v + a) & 0xff; break;
      case 2: v = (v + b) & 0xff; break;
      case 3: v = (v + ((a + b) >> 1)) & 0xff; break;
      case 4: {
        const p = a + b - c;
        const pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
        v = (v + (pa <= pb && pa <= pc ? a : (pb <= pc ? b : c))) & 0xff;
        break;
      }
      default: throw new Error(`未知滤波类型 ${filter}`);
    }
    out[i] = v;
  }
}

/** 取像素，统一返回 RGBA。索引格式会查调色板。 */
function pixel(x, y) {
  const o = y * stride + x * channels;
  if (colorType === 3) {
    const idx = px[o];
    const rgb = palette?.[idx] ?? [255, 0, 255];
    const a = transparency && idx < transparency.length ? transparency[idx] : 255;
    return [rgb[0], rgb[1], rgb[2], a];
  }
  if (colorType === 6) return [px[o], px[o + 1], px[o + 2], px[o + 3]];
  if (colorType === 2) return [px[o], px[o + 1], px[o + 2], 255];
  return [px[o], px[o], px[o], 255];
}

/* ---------- ASCII 预览 ---------- */
const ramp = ' .:-=+*#%@';
console.log(`${file}`);
console.log(`尺寸 ${width}x${height}  bitDepth=${bitDepth} colorType=${colorType}` +
  `${palette ? '  调色板 ' + palette.length + ' 色' : ''}\n`);

for (let y = 0; y < height; y++) {
  let line = '';
  for (let x = 0; x < width; x++) {
    const [r, g, b, a] = pixel(x, y);
    if (a < 16) { line += '.'; continue; }
    const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    line += ramp[Math.min(ramp.length - 1, Math.round(lum * (ramp.length - 1)))];
  }
  console.log(line);
}

/* ---------- 配色统计 ---------- */
const hist = new Map();
for (let y = 0; y < height; y++) {
  for (let x = 0; x < width; x++) {
    const [r, g, b, a] = pixel(x, y);
    if (a < 16) continue;
    const key = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
    hist.set(key, (hist.get(key) ?? 0) + 1);
  }
}

const sorted = [...hist.entries()].sort((a, b) => b[1] - a[1]);
console.log(`\n颜色数 ${sorted.length}，前 12 常用色：`);
for (const [c, n] of sorted.slice(0, 12)) console.log(`  ${c}  x${n}`);
