package work.dsh.mirror.gravity;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 世界生成相关的注册表。
 *
 * <h2>为什么要注册两样东西</h2>
 * <ul>
 *   <li>{@code STRUCTURE_TYPE} —— 数据包 JSON 里 {@code "type": "mirrorgravity:spindle"}
 *       指向的就是它，没有它 JSON 读不出来。</li>
 *   <li>{@code STRUCTURE_PIECE} —— 结构片段要能存进区块存档再读回来。
 *       原版 {@code StructurePiece.createTag} 会写一个 {@code id} 字段，
 *       读档时按这个 id 找反序列化器；<b>没注册就会在存盘时直接抛异常</b>
 *       （源码里那句 "unregistered, serializing impossible"）。</li>
 * </ul>
 *
 * <p>两者都用 NeoForge 的 {@link DeferredRegister}：注册必须发生在模组加载期的
 * 注册事件里，早于任何世界生成与存档读取。
 */
public final class MirrorStructures {

    private MirrorStructures() {
    }

    public static final DeferredRegister<StructureType<?>> STRUCTURE_TYPES =
        DeferredRegister.create(Registries.STRUCTURE_TYPE, MirrorGravity.MOD_ID);

    public static final DeferredRegister<StructurePieceType> PIECE_TYPES =
        DeferredRegister.create(Registries.STRUCTURE_PIECE, MirrorGravity.MOD_ID);

    /** 结构类型 {@code mirrorgravity:spindle}。 */
    public static final DeferredHolder<StructureType<?>, StructureType<SpindleStructure>> SPINDLE =
        STRUCTURE_TYPES.register("spindle", () -> (StructureType<SpindleStructure>) () -> SpindleStructure.CODEC);

    /** 结构片段类型 {@code mirrorgravity:spindle}（存档用）。 */
    public static final DeferredHolder<StructurePieceType, StructurePieceType> SPINDLE_PIECE =
        PIECE_TYPES.register("spindle", () -> (StructurePieceType.ContextlessType) SpindlePiece::new);

    public static void register(IEventBus modBus) {
        STRUCTURE_TYPES.register(modBus);
        PIECE_TYPES.register(modBus);
    }
}
