/** 校验模组资源 JSON 与 PNG（用 Node 显式按 UTF-8 读，避免 shell 编码干扰）。 */
import { readFileSync, existsSync } from 'node:fs';

const BASE = 'D:/DSHwork/MC镜维度/mirror-gravity-mod/src/main/resources/assets/mirrorgravity/';
const files = [
  'blockstates/mirror_portal.json',
  'models/block/mirror_portal.json',
  'lang/zh_cn.json',
  'lang/en_us.json',
  'textures/block/mirror_portal.png.mcmeta',
  'sounds.json',
  /* 波粒块（0.3 新增）：方块状态 / 方块模型 / 物品模型 / 纹理。
   * 少任何一个，游戏里的表现都是"紫黑方块"或"missing model"，且日志不一定报错。 */
  'blockstates/wave_particle_block.json',
  'models/block/wave_particle_block.json',
  'models/item/wave_particle_block.json',
  'textures/block/wave_particle_block.png',
  /* 波粒子（道具）：物品模型 + 物品贴图。
   * 少任何一个，游戏里显示的都是紫黑格（missing model）。 */
  'models/item/wave_particle.json',
  'textures/item/wave_particle.png',
  /* 波粒链的两级中间材料（波 = 腐肉式撕裂块，粒 = 重锤核心式方块） */
  'models/item/wave.json',
  'models/item/particle.json',
  'textures/item/wave.png',
  'textures/item/particle.png',
];

let bad = 0;
for (const f of files) {
  const p = BASE + f;
  if (!existsSync(p)) {
    console.log('  ✗ 缺失 ' + f);
    bad++;
    continue;
  }
  if (f.endsWith('.png')) {
    /* PNG 只做头部校验：签名 + IHDR 宽高。纹理是脚本生成的，
     * 尺寸写错不会崩游戏，但会静默变成"被拉伸/被裁剪"的贴图。 */
    const buf = readFileSync(p);
    const sigOk = buf.length > 24 && buf.readUInt32BE(0) === 0x89504e47 && buf.readUInt32BE(4) === 0x0d0a1a0a;
    const w = buf.readUInt32BE(16);
    const h = buf.readUInt32BE(20);
    if (!sigOk) {
      console.log('  ✗ ' + f + ' 不是合法 PNG');
      bad++;
    } else {
      console.log('  ✓ ' + f + `  ${w}x${h}  ${buf.length}B`);
      if (w !== h) {
        console.log('  · 提示：' + f + ' 不是正方形（方块贴图通常用 16/32/64 的正方形）');
      }
    }
    continue;
  }
  try {
    const o = JSON.parse(readFileSync(p, 'utf8'));
    const keys = Object.keys(o).join(', ');
    console.log('  ✓ ' + f + '   keys=' + (keys.length > 60 ? keys.slice(0, 60) + '…' : keys));
  } catch (e) {
    console.log('  ✗ ' + f + ' : ' + e.message);
    bad++;
  }
}

/* 方块状态文件里那个空字符串键是原版规范（"没有属性"的方块就这么写），
 * PowerShell 5.1 的 ConvertFrom-Json 会误报，这里单独确认一次。 */
const bs = JSON.parse(readFileSync(BASE + 'blockstates/mirror_portal.json', 'utf8'));
const variantKeys = Object.keys(bs.variants);
console.log('  · blockstate 变体键 = [' + variantKeys.map((k) => JSON.stringify(k)).join(', ')
  + ']，模型 = ' + bs.variants[variantKeys[0]].model);

/* 波粒块的方块模型必须是"六面同纹理"的全方块：它的贴图是脚本生成的粉紫渐变，
 * 一旦被误写成 cube（缺 down/up 会引用不存在的贴图），游戏里会看到紫黑格。 */
const wpModel = JSON.parse(readFileSync(BASE + 'models/block/wave_particle_block.json', 'utf8'));
if (wpModel.parent !== 'minecraft:block/cube_all' || wpModel.textures?.all !== 'mirrorgravity:block/wave_particle_block') {
  console.log('  ✗ wave_particle_block 的方块模型应为 cube_all + textures.all=mirrorgravity:block/wave_particle_block');
  bad++;
}

/* 中文语言文件：确认没有解码失败留下的替换字符 */
const zh = readFileSync(BASE + 'lang/zh_cn.json', 'utf8');
const replacement = (zh.match(/\uFFFD/g) || []).length;
console.log('  · zh_cn.json 替换字符数 = ' + replacement + '（应为 0）');
if (replacement > 0) bad++;

/* 语言文件必须给方块与物品各一条 —— 缺任何一条，游戏里显示的都是原始 id。 */
for (const key of ['block.mirrorgravity.wave_particle_block', 'item.mirrorgravity.wave_particle_block',
  'item.mirrorgravity.wave_particle', 'item.mirrorgravity.wave', 'item.mirrorgravity.particle']) {
  if (!zh.includes(key)) {
    console.log('  ✗ zh_cn.json 缺少 ' + key);
    bad++;
  }
}

/* 波粒子/波/粒都是物品（不是方块）：物品模型必须是 item/generated + layer0，
 * 写成方块模型（cube_all）在物品栏里会渲染成一张方片。 */
for (const [name] of [['wave_particle'], ['wave'], ['particle']]) {
  const p = BASE + 'models/item/' + name + '.json';
  const m = JSON.parse(readFileSync(p, 'utf8'));
  if (m.parent !== 'minecraft:item/generated'
    || m.textures?.layer0 !== 'mirrorgravity:item/' + name) {
    console.log('  ✗ ' + name + ' 的物品模型应为 item/generated + layer0=mirrorgravity:item/' + name);
    bad++;
  }
}

/* 传送门是**动画贴图**：PNG 高度 = 16 × 帧数，mcmeta 的 frames 必须与之一致。
 * 这三者（PNG 高度 / frames 列表 / frametime）任何一处对不上，游戏里的表现是
 * 贴图被纵向压成一堆条纹、或者只显示第一帧 —— 而且不报任何错。
 * 2026-09-26 把帧数从 32 改成 48，就是靠这条确认三处同步改到了。 */
{
  const portalPng = readFileSync(BASE + 'textures/block/mirror_portal.png');
  const ph = portalPng.readUInt32BE(20);
  const anim = JSON.parse(readFileSync(BASE + 'textures/block/mirror_portal.png.mcmeta', 'utf8')).animation || {};
  const frames = anim.frames || [];
  const n = ph / 16;
  console.log(`  · 传送门动画：PNG 高 ${ph} → ${n} 帧，mcmeta frames ${frames.length} 条，`
    + `frametime=${anim.frametime}，interpolate=${anim.interpolate}`);
  if (!Number.isInteger(n) || n < 2) {
    console.log('  ✗ 传送门 PNG 高度不是 16 的整数倍，算不出帧数（贴图会显示错乱）');
    bad++;
  } else if (frames.length !== n) {
    console.log(`  ✗ mcmeta 的 frames=${frames.length} 与 PNG 的 ${n} 帧不一致 —— 动画会错帧`);
    bad++;
  } else if (!(anim.frametime >= 1)) {
    console.log('  ✗ mcmeta 缺 frametime（或小于 1）');
    bad++;
  } else if (anim.interpolate !== true) {
    console.log('  · 提示：动画没开 interpolate，帧与帧之间会有台阶感');
  } else {
    console.log('  ✓ 传送门动画三处一致（PNG 帧数 / frames / frametime + interpolate）');
  }

  /* 镜面方块的三张贴图（侧面/顶面/底面）都要在，而且模型必须引用到。
   * 少一张的表现是紫黑格或裸模型 —— 同样是"不报错但看得出不对"。 */
  const surfModel = JSON.parse(readFileSync(BASE + 'models/block/mirror_surface.json', 'utf8'));
  const used = Object.values(surfModel.textures || {});
  for (const s of ['side', 'top', 'bottom']) {
    const rel = `textures/block/mirror_surface_${s}.png`;
    if (!existsSync(BASE + rel)) {
      console.log('  ✗ 缺 ' + rel);
      bad++;
      continue;
    }
    const b = readFileSync(BASE + rel);
    const w = b.readUInt32BE(16);
    const h = b.readUInt32BE(20);
    if (w !== 16 || h !== 16) {
      console.log(`  ✗ ${rel} 应为 16x16（方块贴图），实际 ${w}x${h}`);
      bad++;
    }
    if (!used.includes('mirrorgravity:block/mirror_surface_' + s)) {
      console.log(`  ✗ models/block/mirror_surface.json 没有引用 mirror_surface_${s}`);
      bad++;
    }
  }
}

console.log(bad === 0 ? '\n✓ 资源全部合法' : `\n✗ ${bad} 个问题`);
if (bad > 0) process.exitCode = 1;
