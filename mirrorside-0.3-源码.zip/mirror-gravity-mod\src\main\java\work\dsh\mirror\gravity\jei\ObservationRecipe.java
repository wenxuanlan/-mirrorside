package work.dsh.mirror.gravity.jei;

import java.util.List;

/**
 * 一条"波粒观测"配方，只用于 JEI 展示。
 *
 * <h2>它和 {@link GravityRecipe} 的关系</h2>
 * 波粒观测（四个波粒块围住靶心，望远镜右键）**复用**全部引力配方的产物语义，
 * 外加几条专用配方。所以 JEI 的这份数据是从同一批配置导出来的：
 * <pre>
 *   引力配方：穿越类 → 只要靶心放对就行；接触类 → 还要靶心正下方放对
 *   专用配方：冰→蓝冰、羊毛(+下方锁链)→蜘蛛网、灵魂沙→地狱疣、蛋糕→悦灵
 *   兜底规则：染色方块 → 同族的随机另一种颜色
 * </pre>
 *
 * <h2>字段为什么是"一组"而不是一个</h2>
 * {@code input} / {@code below} 都允许写方块标签（{@code #minecraft:wool}），
 * 而标签没法直接画成物品 —— 由 {@link GravityRecipeItems} 在排版时展开成
 * 标签内所有方块，全塞进同一个槽位循环显示。染色方块那条更极端：
 * 它的输入与产物都是 200 多个方块，也只有这么表达才既真实又搜得到。
 *
 * @param inputs   靶心可以放的方块（ID 或 {@code #标签}）
 * @param outputs  可能得到的产物（方块、物品、刷怪蛋形式展示的实体）
 * @param below    要求靶心正下方放的东西（ID 或 {@code #标签}）
 * @param belowRequired 是否**必须**有下方条件（false 时 {@code below} 只是示意）
 * @param label    配方来源（配置里的 id），排查时用来对回配置
 * @param note     版面底部一行蓝色小字
 */
public record ObservationRecipe(
    List<String> inputs,
    List<String> outputs,
    List<String> below,
    boolean belowRequired,
    String label,
    String note
) {

    /** 版面上要不要画"下方"那一行。 */
    public boolean hasBelow() {
        return belowRequired && below != null && !below.isEmpty();
    }

    /** 一行短说明；太长会被画出边框（版面宽度是固定的）。 */
    public String safeNote() {
        return (note == null) ? "" : note;
    }
}
