// =====================================================================
// 镜维度 · 基础层（配置、几何常量、实体判定、通用工具）
// =====================================================================
// 本文件是整个 server 侧的**最底层模块**，不含任何玩法逻辑，只提供：
//   · 从 global.MirrorDimension 取出配置并算好派生常量
//   · 区域 / 半区 的几何判定（纯函数）
//   · 实体类型判定（一律按类型名字符串，原因见下）
//   · 自研模组（MirrorGravityApi）的句柄与参数下发
//   · 几个通用小工具（tryLoadClass / blockIdOf 等）
//
// ---------------------------------------------------------------------
// 【模块之间的组织方式】
// ---------------------------------------------------------------------
// KubeJS 的 server 脚本之间**没有模块系统**。而且有一条硬约束：
//
//   ⚠️ server 脚本里不能给 global 赋值 —— 会导致**整个文件**失效
//      （startup 脚本才可以，见 mirror_core.js 里 global.MirrorDimension 的写法）
//
// 但**读** global 上已存在的对象、并往它身上挂属性是允许的。
// 所以所有 server 侧模块统一挂到 global.MirrorModules 这个命名空间下：
//
//   global.MirrorDimension   ← startup 层建立的（配置 + 运行时容器）
//   global.MirrorModules     ← 本层建立的（server 侧各模块）
//     .n0  基础层（本文件）
//     .n1  实体状态表
//     .n2  区域与方向判定
//     .n3  配方加工
//     .n4  重力下发
//     .n5  镜维度关卡 / 玻璃层
//
// 加载顺序由**文件名**决定（KubeJS 按字母序加载 server_scripts）。
// 文件名用 n0~n5 前缀就是为了固定这个顺序。
//
// ⚠️ 虽然模块在加载时即可通过 global.MirrorModules.nX 拿到前序模块，
//    但**跨模块调用一律写在函数体内部**（不在加载期取引用）。
//    这样即使将来文件改名导致顺序变化，也只是"那一次调用取到 undefined"，
//    而不是整个模块加载失败。
//
// ⚠️ 另一个必须遵守的约定：**所有 try 块内只用 var**。
//    Rhino 对 try 里的 const/let 会抛
//      InternalError: TypeError: redeclaration of var xxx
//    本项目的 tools/lint-scripts.mjs 会检查这一点，改完请跑一次。
// =====================================================================

const MirrorFoundation = (() => {

  const MD = global.MirrorDimension;
  if (MD === undefined || !MD.isLoaded) {
    console.error('[镜维度] 核心未就绪，基础层未启用。');
    return { ready: false };
  }

  /* server 侧模块命名空间。由 startup 层的 mirror_core.js 预先建立 ——
   * server 脚本**不能**给 global 挂新属性（会被判为"给 global 赋值"并
   * 导致整个文件失效，本项目的 lint 会直接报出来），
   * 所以这里只做校验，不负责创建。 */
  const MODULES = MD.modules;
  if (MODULES === undefined || MODULES === null) {
    console.error('[镜维度] MirrorDimension.modules 不存在（startup 层未建立），'
      + '基础层未启用。');
    return { ready: false };
  }

  const cfg = MD.raw;
  const L = cfg.layout;
  /** 本模组维度的 ResourceLocation 字符串，形如 'mirror:mirror' */
  const DIM = String(MD.ids.dimension);

  /* ------------------------------------------------------------------ */
  /* 通用助手                                                            */
  /* ------------------------------------------------------------------ */

  /**
   * 安全地加载一个 Java 类，失败返回 null。
   *
   * ⚠️ 必须用这个助手，不要直接 Java.loadClass：
   * Rhino 在 try 块里遇到 const/let 会抛 redeclaration 错误，
   * 所以"可能失败的类加载"要放在函数里，用 var 承接。
   */
  function tryLoadClass(name) {
    try {
      return Java.loadClass(name);
    } catch (err) {
      return null;
    }
  }

  /**
   * 按名字取另一个模块（'n0' / 'n1' …）。
   *
   * ⚠️ **跨模块引用一律用这个助手，且只在函数体内部调用**，
   *    不要在模块加载时就 `const N5 = MODULES.n5`。
   *
   * 原因：KubeJS 按**文件名字母序**加载 server 脚本，加载期的模块可能
   * 还没建好。延迟到运行时解析，就不必依赖文件名顺序 ——
   * 将来重命名或拆分文件时不会因为顺序变化而整块失效。
   *
   * 拿不到时返回 null，调用方判空即可（一个模块缺失不该拖垮别人）。
   */
  function moduleRef(key) {
    const m = MD.modules;
    if (m == null) return null;
    const got = m[key];
    return (got === undefined) ? null : got;
  }

  /**
   * 读方块 / 方块状态的注册 ID，返回 'minecraft:gravel' 这种形式。
   *
   * ⚠️ 不能用 String(block)：那调的是 Java 的 toString()，
   *    得到的是 `Block{minecraft:gravel}`，与配置里写的 'minecraft:gravel'
   *    永远匹配不上。实测踩过：穿越计数明明在涨，配方却一条都不匹配。
   *
   * ⚠️ 也不用 block.builtInRegistryHolder().key().location()：
   *    那串调用在 Rhino 里很容易断在中间某一步，失败后整体返回 null
   *    （表现为"配方静默失效"）。走 BuiltInRegistries.BLOCK.getKey() 最短。
   */
  function blockIdOf(obj) {
    try {
      if (obj == null) return null;
      var BuiltInRegistries = tryLoadClass('net.minecraft.core.registries.BuiltInRegistries');
      if (BuiltInRegistries == null) return null;
      var block = obj;
      try {
        var b = obj.getBlock();      // 传进来是 BlockState 时取 Block
        if (b != null) block = b;
      } catch (ignored) { fail('foundation', ignored); /* 本来就是 Block */ }
      var rl = BuiltInRegistries.BLOCK.getKey(block);
      if (rl == null) return null;
      return String(rl);
    } catch (err) {
      return null;
    }
  }

  /* ⛔ 这里曾经有 shortId()（UUID 前 8 位，只给日志用）——
   *    全项目没有任何调用点，2026-09-22 随 0.3 的契约收紧一起删除。 */

  /* ------------------------------------------------------------------ */
  /* 几何：区域与半区                                                    */
  /* ------------------------------------------------------------------ */
  /* 设定（见 镜维度设定.txt）：
   *   可建造高度 -192 ~ 191
   *   -1 / 0 为上下界面（两层黑色玻璃）
   *   -64 ~ +63 为镜内，之外为镜外
   * 重力只看 split_y：> split_y 的一侧朝下，<= split_y 的一侧朝上。 */

  const SPLIT_Y = L.split_y != null ? L.split_y : 0;
  const INNER_MIN = L.inner_min_y;
  const INNER_MAX = L.inner_max_y;

  /** 玻璃层摊平成 y -> blockId。同时决定了镜内/镜外边界与交界处的高度。 */
  const GLASS = {};
  for (const layer of (L.glass_layers || [])) {
    for (const y of layer.ys) GLASS[y] = layer.block;
  }
  const GLASS_Y = Object.keys(GLASS).map(Number);

  /* 重力分界的**实际生效高度**。
   *
   * ⚠️ 这里踩过一个严重的坑，别再犯：
   *   曾经想"把分界下移到黑色玻璃之下"，于是遍历 GLASS_Y 取最小值再减 1。
   *   但 GLASS_Y 里**包含了 -64/-65 的白色玻璃**（镜内/镜外的边界），
   *   结果算出 -66 —— 玩家永远在 -66 以上，于是**所有实体都被判成"朝下"，
   *   全局重力反转彻底失效**（实测四个类别全中）。
   *
   * 现在老老实实用 layout.split_y，不做任何推断。
   * 需要微调时显式写 gravity.split_y_override。 */
  const GLASS_SPLIT = cfg.gravity.split_y_override != null
    ? cfg.gravity.split_y_override
    : SPLIT_Y;

  /* 下落方块参照线相对分界的偏移（格）—— **这个值的唯一真相就在这里**。
   *
   * 为什么需要它：黑色玻璃占 y=-1/-2。沙砾落在这层玻璃下沿、包围盒顶到
   * y=-2 时就该反转，所以参照线要相对分界下移一格。
   *
   * ⚠️ 这个值同时被两处使用：
   *     1) 模组的方块物理（决定什么时候反向）
   *     2) 本脚本的配方切换计数（决定什么时候算"切换了一次"）
   *   两边必须完全一致。曾经是"模组里一个常量 + 配置里一个字段"，
   *   靠人工保持一致 —— 结果实测踩坑：KubeJS 的计数用了 y=0，
   *   而沙砾实际在 y≈-2.31 ~ -0.63 之间往复（受 -1.0 那条线控制），
   *   **永远碰不到 y=0** → 计数停在 1 → 需要多次切换的配方一次都不触发。
   *
   * 现在由本层在启动时通过 MG_API.setFallingRefOffset 推给模组，
   * 模组不再自己定义这个值。改这里就够了。 */
  const FALLING_REF_OFFSET = cfg.gravity.falling_ref_offset != null
    ? cfg.gravity.falling_ref_offset
    : -1.0;

  /** 下落方块**实际的反转线**（绝对值，不是偏移）。 */
  const FALLING_SPLIT = GLASS_SPLIT + FALLING_REF_OFFSET;

  /** 区域 -> 重力方向名（来自配置，非法则退回 down / up） */
  const DIR_NAME = (() => {
    const raw = cfg.gravity.region_directions || {};
    return {
      inner: raw.inner != null ? raw.inner : 'down',
      outer_upper: raw.outer_upper != null ? raw.outer_upper : 'down',
      outer_lower: raw.outer_lower != null ? raw.outer_lower : 'up',
    };
  })();

  /**
   * 判断坐标属于哪个区域。
   * @returns 'inner'（镜内 -64..63）/ 'upper'（上半镜外 >=64）
   *          / 'lower'（下半镜外 <=-65）
   */
  function regionOf(y) {
    if (y > INNER_MAX) return 'upper';
    if (y < INNER_MIN) return 'lower';
    return 'inner';
  }

  /** 是否在镜内（-64 ~ +63）。 */
  function isInner(y) {
    return y >= INNER_MIN && y <= INNER_MAX;
  }

  /** 重力意义上的半区：'upper' 或 'lower'。 */
  function halfOf(y) {
    return y > GLASS_SPLIT ? 'upper' : 'lower';
  }

  /** 某个高度应当受的重力方向名。 */
  function dirNameAt(y) {
    return halfOf(y) === 'upper' ? DIR_NAME.outer_upper : DIR_NAME.outer_lower;
  }

  /* ------------------------------------------------------------------ */
  /* 实体类型判定                                                        */
  /* ------------------------------------------------------------------ */
  /* ⚠️ 一律用**类型名字符串**判断，不要用 Java.loadClass(...).isInstance() ——
   * 那条路在 Rhino 里恒为 false，曾经因此让玩家每 tick 被处理两次、
   * 并让重力方块完全拿不到处理。详见 README §11.6。 */

  function typeName(entity) {
    try {
      return String(entity.getType());
    } catch (err) {
      return '?';
    }
  }

  function isPlayer(entity) {
    return typeName(entity) === 'minecraft:player';
  }

  /* 非生物里受重力影响的类型（Pondus 的 allowed_special 白名单成员）。
   * 这些走自研模组那条路。 */
  const NON_LIVING_TYPES = [
    'minecraft:falling_block',
    'minecraft:item',
    'minecraft:tnt',
    'minecraft:eye_of_ender',
    'minecraft:experience_orb',
  ];

  function isNonLivingGravityEntity(entity) {
    return NON_LIVING_TYPES.indexOf(typeName(entity)) >= 0;
  }

  /** 掉落物（掉在地上的物品实体）。
   *
   *  ⚠️ 与 isNonLivingGravityEntity 的区别：后者还包含 TNT / 末影之眼 /
   *     经验球。掉落物是唯一允许"低频检测方向"的那一类 —— 它不做加工、
   *     不参与配方计数，方向判定的实时性只影响自己的振荡幅度。
   *     详见 mirror_config.js 里 item_scan_interval 的注释。 */
  function isDroppedItem(entity) {
    return typeName(entity) === 'minecraft:item';
  }

  function isFallingBlock(entity) {
    return typeName(entity) === 'minecraft:falling_block';
  }

  /** 实体稳定标识（整数实体 id 的字符串形式）。 */
  function entityKey(entity) {
    try {
      return String(entity.getId());
    } catch (err) {
      return 'unknown';
    }
  }

  /* 注意：这里曾经有 isSolidAhead() —— 用于"前方无方块就不翻转"。
   * 那个规则会让所有自由空间中的实体永不反转（玩家/羊/沙砾全失效），
   * 已随该规则一起删除。反转规则是**纯看坐标**。 */

  /* ------------------------------------------------------------------ */
  /* 自研模组句柄与本层参数下发                                            */
  /* ------------------------------------------------------------------ */
  /* 自研模组负责**非生物**实体：直接写 Pondus 的数据字段（绕过白名单），
   * 并自己补回 Pondus 换向时会清零的水平速度。
   * 源码：D:\DSHwork\MC镜维度\mirror-gravity-mod */

  const MANAGE_ATTR = cfg.gravity.manage_attribute === true;
  if (MANAGE_ATTR) {
    /* 把"这半边没实现"变成**看得见**的一句话，而不是让人以为打开了就有效。
     * 详见 mirror_config.js → gravity.manage_attribute 那段注释。 */
    console.warn('[镜维度] gravity.manage_attribute = true —— 注意：属性降级方案'
      + '目前**只实现了"恢复原版重力"**，没有实现"用属性反向重力"。'
      + '真正让重力反转的是 Pondus + 自研模组；这个开关今天不会让玩家往上掉。');
  }
  const SCAN_INTERVAL = Math.max(1, cfg.gravity.entity_scan_interval != null
    ? cfg.gravity.entity_scan_interval : 1);

  /* 掉落物的**方向检测间隔**，与上面的 SCAN_INTERVAL 分开（详见
   * mirror_config.js → gravity.item_scan_interval 的完整说明）。
   *
   * 一句话：下落的方块必须每 tick 判（配方计数 + 往复物理依赖它），
   * 而掉落物不做加工、不参与配方，方向判定的实时性只影响它自己的振荡幅度，
   * 所以可以低频处理，省掉每个掉落物每 tick 一次的模组调用。 */
  const ITEM_SCAN_INTERVAL = Math.max(1, cfg.gravity.item_scan_interval != null
    ? cfg.gravity.item_scan_interval : 4);

  /* 掉落物的重力缩放 —— **唯一默认值就在这一处**。
   *
   * 为什么单独提出来：以前 n4 里有三个地方各自兜底，其中两个写 0.35、
   * 另一个写 0.2（而配置里是 0.2），于是那两个 0.35 永远不生效 ——
   * 属于"配置项哪天被删掉就会立刻咬人"的陷阱。现在统一从这里取。 */
  const FALLING_GRAVITY_SCALE = (cfg.gravity.falling_gravity_scale != null)
    ? cfg.gravity.falling_gravity_scale : 0.2;

  const MG_API = (() => {
    if (cfg.gravity.use_self_mod === false) return null;
    return tryLoadClass('work.dsh.mirror.gravity.MirrorGravityApi');
  })();

  if (MG_API != null) {
    console.info('[镜维度] 自研重力模组已接入 —— 下落的方块/掉落物可反转。');
    try {
      MG_API.setSplitY(GLASS_SPLIT);

      /* 下落方块参照线的偏移也推给模组。
       * 这个值同时被模组的方块物理与本脚本的配方计数使用，
       * 原先两边各写一遍、靠人工保持一致；现在唯一真相在本层，模组只接收。 */
      MG_API.setFallingRefOffset(FALLING_REF_OFFSET);

      /* 迟滞带决定下落方块的摆幅 —— 它是"控制摆幅"的唯一旋钮：
       * 实体要越过 splitY ± band 才反向，带越宽摆得越远。
       * 实测：band=0.75 时沙砾只在 y≈-2.31 ~ -0.63 摆动，够不到 y=0；
       *       band=1.0 时上折点落到 y=0 附近。 */
      if (cfg.gravity.falling_hysteresis != null) {
        MG_API.setHysteresis(cfg.gravity.falling_hysteresis);
      }

      /* 掉落物的重力缩放也推给模组（0.3 新增）。
       *
       * 为什么现在才推：它以前在模组侧是一个 final 常量、与这里的配置各写一份
       * （都是 0.2），靠注释保持一致 —— 改配置不会带动模组，是典型的
       * "改了这边忘了那边"。现在唯一真相是 FALLING_GRAVITY_SCALE（本层常量），
       * 模组只接收；一致性由 tools-build/check-param-parity.mjs 守着。 */
      if (MG_API.setItemGravityScale != null) {
        MG_API.setItemGravityScale(FALLING_GRAVITY_SCALE);
      }

      /* 掉落物的**位置同步间隔**（视觉处理）也推给模组。
       *
       * 语义：运动中的掉落物多久补发一次位置包。
       *   1 = 每 tick（默认，修复"偶发闪现"的那一档）
       *   N = 每 N tick（省包，代价是残留 N tick 的漂移）
       *   0 = 关闭（退回原版 20 tick 的节奏，闪现会回来）
       * 详见 mirror_config.js → gravity.item_sync_interval。
       * 模组收到后会回一行「掉落物位置同步间隔已设为 N tick」。 */
      if (cfg.gravity.item_sync_interval != null) {
        MG_API.setItemSyncInterval(cfg.gravity.item_sync_interval);
      }

      /* 镜面传送门：目标维度、Y 映射区间、结构材料、建门避让层。
       * 同样遵守"唯一真相在脚本配置、模组只接收"。
       * ⚠️ 这里在 try 块内，所以只用 var（Rhino 对 try 里的 const/let 会抛
       *    InternalError: TypeError: redeclaration of var xxx）。 */
      var MP = cfg.mirrorPortal;
      if (MP != null && MP.enabled !== false) {
        /* Y 映射区间：主世界 ↔ 镜维度境内。默认值兜底用 layout 里的境内范围。 */
        var owMin = -64, owMax = 319;
        if (MP.overworld_y_range != null) {
          owMin = MP.overworld_y_range[0];
          owMax = MP.overworld_y_range[1];
        }
        var mirMin = L.inner_min_y != null ? L.inner_min_y : -64;
        var mirMax = L.inner_max_y != null ? L.inner_max_y : 63;
        if (MP.mirror_y_range != null) {
          mirMin = MP.mirror_y_range[0];
          mirMax = MP.mirror_y_range[1];
        }
        MG_API.setMirrorPortalTarget(String(MD.ids.dimension), owMin, owMax, mirMin, mirMax);

        MG_API.setMirrorPortalStructure(String(MP.bottom_block),
          String(MP.top_block), String(MP.center_tag));

        MG_API.setMirrorPortalBuildArrival(MP.build_arrival !== false);

        /* 建门要避开的 Y：把 layout.glass_layers 里所有层高摊平成一串数字。
         * 结构占 cy-1 / cy / cy+1 三层，压到玻璃层上会在分界面上开洞。 */
        var avoidYs = [];
        var layers = L.glass_layers != null ? L.glass_layers : [];
        for (var li = 0; li < layers.length; li++) {
          var layerYs = layers[li].ys != null ? layers[li].ys : [];
          for (var yi = 0; yi < layerYs.length; yi++) {
            avoidYs.push(layerYs[yi]);
          }
        }
        MG_API.setMirrorPortalAvoidY(avoidYs.join(','));
      }

      /* 针尖对麦芒：把 spindle 段的全部数值推给模组（世界生成要用它们）。
       * 避让层仍是 layout.glass_layers —— 波粒块不允许落在黑玻璃夹层里，
       * 否则它会顶掉镜面交界处的玻璃、把重力分界面捅出一个洞。 */
      var SP = cfg.spindle;
      if (SP != null && SP.enabled !== false) {
        var spAvoid = [];
        var spLayers = L.glass_layers != null ? L.glass_layers : [];
        for (var sli = 0; sli < spLayers.length; sli++) {
          var spYs = spLayers[sli].ys != null ? spLayers[sli].ys : [];
          for (var syi = 0; syi < spYs.length; syi++) {
            spAvoid.push(spYs[syi]);
          }
        }
        MG_API.setSpindleAvoidY(spAvoid.join(','));

        /* 世界可建造高度：layout 里给的是 min_y 与 height，
         * 模组要的是闭区间上限，所以这里自己算 maxY = min_y + height - 1。
         * 境内上下界也在这里自己取一遍 —— 不要借用上面传送门分支里的
         * mirMin/mirMax：那两个变量只在 mirrorPortal.enabled 为真时才被赋值，
         * 关掉传送门就会变成 undefined 推进模组。 */
        var bMin = L.min_y != null ? L.min_y : -192;
        var bMax = bMin + (L.height != null ? L.height : 384) - 1;
        var spMirMin = L.inner_min_y != null ? L.inner_min_y : -64;
        var spMirMax = L.inner_max_y != null ? L.inner_max_y : 63;
        MG_API.setSpindleParams([
          SP.radius[0], SP.radius[1],
          SP.length[0], SP.length[1],
          SP.inset[0], SP.inset[1],
          SP.center_y[0], SP.center_y[1],
          SP.pitch_deg[0], SP.pitch_deg[1],
          spMirMin, spMirMax, bMin, bMax,
        ].join(','));
      }

      /* 波粒子：七个开关/数值推给模组（唯一真相在本文件的 waveParticle 段）。
       * 布尔用 1/0 —— 模组侧按整数解析，对拍工具也能直接比大小。 */
      var WP = cfg.waveParticle;
      if (WP != null) {
        MG_API.setWaveParticleParams([
          WP.enabled === false ? 0 : 1,
          WP.consume === false ? 0 : 1,
          WP.fall_delay_ticks != null ? WP.fall_delay_ticks : 2,
          WP.allow_block_entities ? 1 : 0,
          WP.allow_unbreakable === false ? 0 : 1,
          WP.max_tags_per_level != null ? WP.max_tags_per_level : 8192,
          WP.notify === false ? 0 : 1,
        ].join(','));
      }

      /* 天气：镜维度强制晴天（唯一真相在本文件的 weather 段）。 */
      var WEATHER = cfg.weather;
      if (WEATHER != null && MG_API.setForceClearWeather != null) {
        MG_API.setForceClearWeather(WEATHER.force_clear !== false);
      }
    } catch (err) {
      console.info('[镜维度][警告] 无法把重力参数推给模组: ' + err);
    }
  } else if (cfg.gravity.enabled) {
    /* ⚠️ 不要在这里写死版本号：这条提示曾经写着 mirrorside-0.1.jar，
     *    到了 0.2 就变成误导（照它去找文件会找不到）。只说文件名前缀。 */
    console.info('[镜维度][警告] 自研重力模组未加载；下落的方块与掉落物将无法反转。'
      + ' 请确认 mods 里有 mirrorside-*.jar；若只用 Pondus，则非生物实体的反转不可用。');
  }

  /* Java 类句柄（提前加载，避免放进 try 里用 const） */
  const Attributes = Java.loadClass('net.minecraft.world.entity.ai.attributes.Attributes');
  const GameType = Java.loadClass('net.minecraft.world.level.GameType');

  /* ------------------------------------------------------------------ */
  /* 静默失败收集器（0.3 新增）                                            */
  /* ------------------------------------------------------------------ */
  /* 为什么需要它：本项目两次多轮排查的根因都是"某个 catch 把致命错误吞掉了"
   *   · Rhino 的 try 内 const（异常被自己的 catch 吞掉 → 计数身份被悄悄换掉）
   *   · 按竖列计数（同列多个实体互相污染 → 计数暴涨而日志一片正常）
   * 两次都表现为"配置写了却没反应、且没有任何报错"。
   *
   * 但也不能让每个 catch 都打日志 —— 有些在每 tick / 每实体的热路径上，会刷屏。
   * 折中：**只累加计数 + 每类留前几条现场**，再由 `/mirror diag` 一次读出来。
   *
   * 用法：catch (err) { fail('physics', err); ...原有的兜底动作不变... }
   *   —— 加这一行**不改变任何控制流**，只是让失败不再无声无息。
   */
  const FAIL_KINDS = ['foundation', 'state', 'physics', 'recipe',
    'outer', 'portal', 'sound', 'command'];
  const FAIL_KEEP = 3;                 // 每类最多留 3 条现场（防止内存与刷屏）
  const FAIL_COUNTS = {};
  const FAIL_SAMPLES = {};

  function fail(kind, err) {
    try {
      var k = FAIL_KINDS.indexOf(String(kind)) >= 0 ? String(kind) : 'other';
      FAIL_COUNTS[k] = (FAIL_COUNTS[k] || 0) + 1;
      if (FAIL_COUNTS[k] <= FAIL_KEEP) {
        var msg;
        try {
          msg = (err == null) ? '(null)' : String(err.message != null ? err.message : err);
        } catch (e2) {
          msg = '(读不出错误信息)';
        }
        var arr = FAIL_SAMPLES[k] || (FAIL_SAMPLES[k] = []);
        arr.push(String(msg).slice(0, 160));
      }
    } catch (e3) {
      // 收集器自己绝不能把主流程弄挂
    }
  }

  /** 当前会话的静默失败汇总（给 /mirror diag 用）。 */
  function failures() {
    var total = 0;
    var byKind = {};
    for (var i = 0; i < FAIL_KINDS.length; i++) {
      var k = FAIL_KINDS[i];
      var n = FAIL_COUNTS[k] || 0;
      total += n;
      byKind[k] = { count: n, samples: (FAIL_SAMPLES[k] || []).slice() };
    }
    return { total: total, byKind: byKind };
  }

  /* ------------------------------------------------------------------ */
  /* 对外导出                                                            */
  /* ------------------------------------------------------------------ */

  const api = {
    ready: true,

    /* 静默失败收集器：各模块的 catch 调 fail(...)，指令层用 failures() 读。 */
    fail: fail,
    failures: failures,

    // 配置与常量
    cfg: cfg,
    layout: L,
    dim: DIM,
    splitY: GLASS_SPLIT,
    rawSplitY: SPLIT_Y,
    fallingSplit: FALLING_SPLIT,
    innerMin: INNER_MIN,
    innerMax: INNER_MAX,
    glassLayers: GLASS,
    glassYs: GLASS_Y,
    dirName: DIR_NAME,
    scanInterval: SCAN_INTERVAL,
    itemScanInterval: ITEM_SCAN_INTERVAL,
    fallingGravityScale: FALLING_GRAVITY_SCALE,
    manageAttr: MANAGE_ATTR,
    selfModApi: MG_API,
    Attributes: Attributes,
    GameType: GameType,

    // 工具
    tryLoadClass: tryLoadClass,
    moduleRef: moduleRef,
    blockIdOf: blockIdOf,

    // 几何
    regionOf: regionOf,
    isInner: isInner,
    halfOf: halfOf,
    dirNameAt: dirNameAt,

    // 实体判定
    typeName: typeName,
    isPlayer: isPlayer,
    isNonLivingGravityEntity: isNonLivingGravityEntity,
    isDroppedItem: isDroppedItem,
    isFallingBlock: isFallingBlock,
    entityKey: entityKey,
  };

  /* MODULES 就是 MirrorDimension.modules 的引用，
   * 往它身上挂属性等价于挂到 global 上的那个对象里。 */
  MODULES.n0 = api;

  console.info('[镜维度] 基础层就绪 — 维度 ' + DIM
    + '，分界 y=' + GLASS_SPLIT
    + '，下落方块反转线 y=' + FALLING_SPLIT
    + '，自研模组 ' + (MG_API != null ? '已接入' : '未接入'));

  return api;
})();
