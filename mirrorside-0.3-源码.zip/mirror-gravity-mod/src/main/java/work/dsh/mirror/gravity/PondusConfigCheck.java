package work.dsh.mirror.gravity;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import work.dsh.mirror.gravity.internal.Failures;

import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 启动自检：Pondus 的配置会不会把下落方块的轨迹整体挪一格。
 *
 * <h2>为什么要有这个类（用户实测报告）</h2>
 * 同一份 jar、同一份 {@code kubejs}（逐文件哈希一致），在两个整合包里玩法表现不同：
 * 开发包里"可疑沙砾落在陶罐上"这条落点配方放在 <b>y=−3</b> 稳定生效，
 * 而新建的整合包里同样的摆法<b>永远不生效</b>（方块一路穿越 8 次变成绿宝石块，
 * 说明穿越类配方正常、只有落点类配方错过目标行）。
 *
 * <p>查到最后是 Pondus 自己的配置 {@code config/pondus.json} 不同：
 * <pre>
 *   "adjustPositionAfterChangingGravity": false   ← 开发包（落点配方有效）
 *   "adjustPositionAfterChangingGravity": true    ← 新建整合包的默认值
 * </pre>
 * 这一项为 true 时，Pondus 每次改变重力方向都会平移一次实体位置
 * （量级是一个包围盒高度，普通方块 = 1 格）。本模组的位置补偿
 * （{@code PondusPositionMixin}）是在 {@code false} 的条件下标定的，
 * 在 {@code true} 下无法把那一格完全抵消 ⇒ 下落方块整体错开一格 ⇒
 * 落点那一行永远扫不到。
 *
 * <h2>为什么是"警告"而不是"自动改配置"</h2>
 * 那是别的模组的配置文件：自己动手改，会在下次对方启动时被覆盖或造成误解；
 * 而且 {@code worldVelocity} 这类项还牵涉玩家手感，属于房主的决定。
 * 所以本模组只做一件事 —— <b>把结论写进日志</b>，让"配方为什么不生效"
 * 从"靠人肉比对两个整合包"变成"启动就能看懂"。
 *
 * <p>挂 {@link ServerStartedEvent}（一次性），不做任何轮询。
 */
@EventBusSubscriber(modid = MirrorGravity.MOD_ID)
public final class PondusConfigCheck {

    private static final String FILE_NAME = "pondus.json";

    private PondusConfigCheck() {
    }

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        try {
            Path cfg = FMLPaths.CONFIGDIR.get().resolve(FILE_NAME);
            boolean adjust = true;          // 文件缺失 = Pondus 用默认值，而默认正是 true
            boolean worldVelocity = true;
            if (Files.isReadable(cfg)) {
                try (Reader r = Files.newBufferedReader(cfg, StandardCharsets.UTF_8)) {
                    JsonElement root = JsonParser.parseReader(r);
                    if (root != null && root.isJsonObject()) {
                        JsonObject o = root.getAsJsonObject();
                        adjust = readBool(o, "adjustPositionAfterChangingGravity", adjust);
                        worldVelocity = readBool(o, "worldVelocity", worldVelocity);
                    }
                }
            } else {
                MirrorGravity.LOGGER.info(
                    "[镜维度·自检] 还没看到 {}（Pondus 尚未写出配置），按默认值 {} 处理",
                    FILE_NAME, adjust);
            }

            if (adjust) {
                MirrorGravity.LOGGER.warn(
                    "[镜维度·自检] ⚠ Pondus 配置 adjustPositionAfterChangingGravity = true。"
                        + "它会让每次重力反转额外平移实体一格，而本模组的位置补偿是在 false 下"
                        + "标定的 ⇒ 下落方块轨迹整体错开一格 ⇒ **落点类配方会错过目标行**"
                        + "（表现：方块一路穿越、落点配方永不触发）。"
                        + "建议把 {} 改成 false（开发与测试一直用 false）。",
                    FILE_NAME);
            } else {
                MirrorGravity.LOGGER.info(
                    "[镜维度·自检] Pondus 配置 adjustPositionAfterChangingGravity = false，"
                        + "落点判定按标定值工作");
            }
            if (!worldVelocity) {
                MirrorGravity.LOGGER.warn(
                    "[镜维度·自检] ⚠ Pondus 配置 worldVelocity = false（开发测试用的是 true）："
                        + "重力方向变化时速度的处理方式不同，摆幅与折返点会和标定值有偏差。");
            }
        } catch (Throwable t) {
            /* 自检失败绝不能影响启动 —— 它只是给排查用的。 */
            Failures.note("pondus_config_check", t);
        }
    }

    private static boolean readBool(JsonObject o, String key, boolean fallback) {
        JsonElement el = o.get(key);
        if (el == null || !el.isJsonPrimitive() || !el.getAsJsonPrimitive().isBoolean()) {
            return fallback;
        }
        return el.getAsBoolean();
    }
}
