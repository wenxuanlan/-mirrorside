package work.dsh.mirror.gravity.mixin;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.LockCode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.entity.item.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import work.dsh.mirror.gravity.MirrorGravity;
import work.dsh.mirror.gravity.internal.Failures;

import java.util.ArrayList;
import java.util.List;

/**
 * 下落的方块**变成掉落物**时，把方块实体的 NBT 一起带上。
 *
 * <h2>解决什么问题</h2>
 * 波粒子可以把箱子、刷怪笼、试炼刷怪笼这类带方块实体的方块推下去。
 * 原版对"落地"这条路是完整的：
 * <pre>
 *   // FallingBlockEntity#tick，落地分支
 *   if (this.blockData != null && this.blockState.hasBlockEntity()) {
 *       BlockEntity be = this.level().getBlockEntity(blockpos);
 *       ... 把 blockData 里的每个键盖进新方块实体 ...
 *   }
 * </pre>
 * 所以落地时内容物能原样回来。但**另外两条路会丢**：
 * <pre>
 *   // 落点放不下 / 中途被破坏 / 超时 —— 都是同一句
 *   this.spawnAtLocation(block);
 * </pre>
 * 它弹的是一个**干净的方块物品**（{@code new ItemStack(block)}），
 * 没有任何 NBT ⇒ 箱子里的东西、刷怪笼里的怪全丢。
 * 实测用户的原话是："要是容器变成了掉落物，则用保留 nbt 的方式，
 * 使得容器再摆出来还有内容物" —— 就是这一条。
 *
 * <h2>做法</h2>
 * 挂在 {@link Entity#spawnAtLocation(ItemStack, float)} 的 HEAD ——
 * <b>必须是带 float 的那个重载</b>，因为原版下落实体走的是
 * {@code this.spawnAtLocation(block)} 这个 {@code ItemLike} 版本，
 * 而它内部的调用链是：
 * <pre>
 *   spawnAtLocation(ItemLike)      → spawnAtLocation(ItemLike, int)
 *                                  → spawnAtLocation(ItemStack, float)   ← 真正的落点
 *   spawnAtLocation(ItemStack)     → spawnAtLocation(ItemStack, float)
 * </pre>
 * ⚠️ 0.3 第一版挂在 {@code spawnAtLocation(ItemStack)}（单参）上，
 *    <b>而原版恰恰跳过了它</b> —— 结果就是"用户把箱子挖成掉落物再摆出来，
 *    内容物还是没了"。这种错法最阴的地方是：注入点在、require=1 也过了、
 *    日志干干净净，只是永远不会被调用。所以校验脚本里专门有一条
 *    "掉落物必须保留 block_entity_data"的行为断言（见 check-observation.mjs）。
 *
 * <p>给物品补上 {@code minecraft:block_entity_data} 组件 —— 这正是原版
 * 潜影盒/箱子被打掉时保留内容物的那套机制，摆回去会自动还原。
 *
 * <p>{@code require = 1} 与 {@code remap = false} 的理由同
 * {@link ServerLevelWeatherMixin}：静默失效要变成启动期的大声报错，
 * 而运行时用的就是官方名字（见 mirrorgravity.mixins.json 的注释）。
 */
@Mixin(Entity.class)
public abstract class FallingBlockDropMixin {

    /**
     * 真正的落点：所有 spawnAtLocation 重载最后都走到这里。
     *
     * <p>注意签名带 {@code float offsetY}，描述符里是 {@code F}。
     */
    @Inject(
        method = "spawnAtLocation(Lnet/minecraft/world/item/ItemStack;F)"
            + "Lnet/minecraft/world/entity/item/ItemEntity;",
        at = @At("HEAD"),
        require = 1,
        remap = false)
    private void mirrorgravity$keepBlockEntityData(ItemStack stack, float offsetY,
                                                   CallbackInfoReturnable<ItemEntity> cir) {
        if (!((Object) this instanceof FallingBlockEntity falling)) {
            return;
        }
        CompoundTag data = falling.blockData;
        if (data == null || stack.isEmpty()) {
            return;
        }
        /* 已经有组件就别覆盖（例如别的模组也做了同样的事）。 */
        if (stack.has(DataComponents.BLOCK_ENTITY_DATA)) {
            return;
        }
        /* ★ 上线前先按组件的校验条件自检一遍。
         *
         * minecraft:block_entity_data 的编码器是 CustomData.CODEC_WITH_ID，
         * 它要求标签里必须有 String 类型的 "id"（8 = TAG_String）。缺了它，
         * 这个物品**一旦被存档/发包就会抛异常** —— 用户实测：捡起来后
         * 玩家存档时崩溃，"Saving entity NBT / Missing id for entity in: {...}"。
         *
         * 所以这里宁可**不给组件**（退回"掉落物没有内容物"的老行为），
         * 也绝不写出一个非法组件把存档搞崩。真出现了会打一条 WARN，
         * 说明 GravityTagger 那边的 saveWithId 出了问题。 */
        if (!data.contains("id", 8)) {
            MirrorGravity.LOGGER.warn(
                "[镜维度·波粒子] 方块实体数据里没有 id，拒绝写进掉落物（否则存档时会崩）: keys={}",
                data.getAllKeys());
            return;
        }
        stack.set(DataComponents.BLOCK_ENTITY_DATA, CustomData.of(data.copy()));

        /* ★★ 只给 block_entity_data **不够**，必须同时给 container 组件。
         *
         * 原因（对着 1.21.1 源码查的，用户实测"摆出来是空的"）：
         * BlockItem.place 里连着做两件事 ——
         *     updateCustomBlockEntityTag(...)    // 把 block_entity_data 里的 Items 灌进方块实体
         *     updateBlockEntityComponents(...)   // → BlockEntity.applyComponentsFromItemStack
         * 第二件会调到 BaseContainerBlockEntity.applyImplicitComponents：
         *     input.getOrDefault(DataComponents.CONTAINER, ItemContainerContents.EMPTY)
         *          .copyInto(this.getItems());   // ← 拿**物品的 container 组件**整份覆盖
         * 我们的物品没有这个组件 ⇒ 覆盖成空 ⇒ 前一步刚恢复的内容物当场被清掉。
         * 原版潜影盒携带内容物用的就是 container 组件，这里照它办。
         *
         * 顺带把 CUSTOM_NAME / LOCK 也带上：applyImplicitComponents 同样会用
         * 组件里的这两项覆盖方块实体（缺了就把名字与锁清掉），
         * 只搬 Items 会让"改了名的箱子"变回默认名字。 */
        List<ItemStack> items = readItems(data);
        if (!items.isEmpty()) {
            stack.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(items));
        }
        if (data.contains("CustomName", 8)) {
            try {
                Component name = Component.Serializer.fromJson(data.getString("CustomName"),
                    falling.level().registryAccess());
                if (name != null) {
                    stack.set(DataComponents.CUSTOM_NAME, name);
                }
            } catch (Throwable ignored) {
                Failures.note("FallingBlockDropMixin.customName", ignored);
            }
        }
        if (data.contains("Lock", 8)) {
            try {
                stack.set(DataComponents.LOCK, new LockCode(data.getString("Lock")));
            } catch (Throwable ignored) {
                Failures.note("FallingBlockDropMixin.lock", ignored);
            }
        }

        MirrorGravity.LOGGER.info(
            "[镜维度·波粒子] 掉落物保留了方块实体数据（{}，内容物 {} 格）—— 摆回去内容物仍在",
            stack.getItem(), items.size());
    }

    /**
     * 从方块实体 NBT 里读出内容物列表。
     *
     * <p>1.21 的 {@code Items} 列表**没有 Slot 键**（槽位就是列表顺序），
     * 但老存档经数据修复后可能仍带着 {@code Slot}/{@code slot}，所以两种都认：
     * 有就按它放，没有就按顺序放。
     *
     * <p>上限照 {@link ItemContainerContents}（256）截断，避免异常数据把列表撑爆。
     */
    private List<ItemStack> readItems(CompoundTag data) {
        List<ItemStack> out = new ArrayList<>();
        /* ⚠️ 这里不能直接写 this.level()：Mixin 类在源码里并不是 Entity 的子类，
         *    编译器看不到 Entity 的方法（Mixin 只在字节码阶段把本类织进目标类）。
         *    所以要么强转，要么像下面这样从已经拿到的 falling 实例上取。 */
        var registries = ((Entity) (Object) this).level().registryAccess();
        Tag raw = data.get("Items");
        if (!(raw instanceof ListTag list)) {
            return out;
        }
        int next = 0;
        for (int i = 0; i < list.size() && out.size() < 256; i++) {
            Tag entry = list.get(i);
            if (!(entry instanceof CompoundTag one)) {
                continue;
            }
            ItemStack parsed;
            try {
                parsed = ItemStack.parse(registries, one).orElse(ItemStack.EMPTY);
            } catch (Throwable t) {
                Failures.note("FallingBlockDropMixin.readItems", t);
                continue;
            }
            if (parsed.isEmpty()) {
                continue;
            }
            int slot = next;
            if (one.contains("Slot", 99) || one.contains("slot", 99)) {
                slot = one.getInt(one.contains("Slot", 99) ? "Slot" : "slot");
            }
            while (out.size() <= slot && out.size() < 256) {
                out.add(ItemStack.EMPTY);
            }
            if (slot >= 0 && slot < out.size()) {
                out.set(slot, parsed);
            } else {
                out.add(parsed);
            }
            next = slot + 1;
        }
        return out;
    }
}
