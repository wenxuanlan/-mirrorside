// =====================================================================
// 镜维度 · 玩法开关（全局闸门、枚举、区域切换通知钩子）
// =====================================================================
// 这个模块很小，但存在的理由很明确：**消除模块之间的循环依赖**。
//
// 问题：重力下发（n4）在判断"玩家是否进入镜外"时，需要调用镜外模块（n5）
//       的处理函数；而镜外模块的初始化又需要读到重力模块的状态。
//       直接互相引用会形成环。
//
// 做法：把"两边都要用、且不依赖任何一方"的东西抽到这里 ——
//   1) 各项全局开关（重力总开关、配方总开关、镜外模式开关…）
//   2) GameType 枚举句柄
//   3) 一个**可注册的通知钩子**：n5 注册进来，n4 只管调用，
//      于是 n4 不需要知道 n5 的存在
//
// ⚠️ 所有 try 块内只用 var（Rhino 对 try 里的 const/let 会抛
//    InternalError: TypeError: redeclaration of var xxx）
// =====================================================================

const MirrorFlags = (() => {

  const N0 = global.MirrorDimension.modules.n0;
  if (N0 === undefined || !N0.ready) {
    console.error('[镜维度] 基础层未就绪，开关模块未启用。');
    return { ready: false };
  }

  const cfg = N0.cfg;

  /* ------------------------------------------------------------------ */
  /* 全局开关                                                            */
  /* ------------------------------------------------------------------ */

  /** 重力反转总开关（关掉后整套重力逻辑不工作，实体回原版行为）。 */
  const GRAVITY_ON = cfg.gravity.enabled === true;

  /** 坠落物是否会触发"每 tick 全实体扫描"。 */
  const SCAN_INTERVAL = N0.scanInterval;

  /** 镜外（越过镜面边界）的特殊处理是否启用。 */
  const OUTER_ON = cfg.outerRegion != null && cfg.outerRegion.enabled === true;

  /** 玻璃层兜底铺设是否启用（世界生成已负责，默认关）。 */
  const MAINTAIN_GLASS = N0.layout.maintain_glass === true;

  /* ------------------------------------------------------------------ */
  /* GameType 枚举                                                       */
  /* ------------------------------------------------------------------ */
  /* ⚠️ KubeJS 对 ServerPlayer 做了包装，原版方法名不一定可用。实测：
   *    ✗ player.getGameModeForPlayer()        -> Cannot find function
   *    ✗ player.setGameModeForPlayer(gt)      -> Cannot find function
   *    ✓ player.setGameMode(GameType)
   *    ✓ player.gameMode.getGameModeForPlayer()
   * 写错会让 PlayerEvents.tick 处理器中断，后续逻辑全部失效。 */

  const GameType = N0.GameType;

  /* ------------------------------------------------------------------ */
  /* 区域切换通知钩子                                                    */
  /* ------------------------------------------------------------------ */
  /* 重力模块发现"玩家跨越了镜内外边界"时调用 notifyRegionChange；
   * 具体怎么处理（改游戏模式、发提示）由注册方决定。
   *
   * 这样 n4 不需要引用 n5，n5 也不需要被 n4 引用 —— 环被断开。 */

  let regionListener = null;

  /** 由镜外模块注册。fn(player, newRegion, prevRegion) */
  function onRegionChange(fn) {
    regionListener = fn;
    console.info('[镜维度·区域] 镜外处理已注册: ' + (fn != null ? '成功' : '失败（fn 为 null）'));
  }

  /** 由重力模块调用。未注册时什么都不做（n5 若未就绪则静默跳过）。 */
  function notifyRegionChange(player, newRegion, prevRegion) {
    if (regionListener == null) {
      /* 诊断：监听器缺失说明 n5 没注册成功（例如它初始化时 n2 还不可用）。
       * 这种情况功能会静默失效，必须留下痕迹。 */
      console.error('[镜维度·区域] 收到区域变化但**没有注册处理函数**'
        + '（player=' + player.username + ' ' + prevRegion + '->' + newRegion + '）');
      return false;
    }
    try {
      regionListener(player, newRegion, prevRegion);
      console.info('[镜维度·区域] 已处理: ' + player.username
        + ' ' + prevRegion + '->' + newRegion);
      return true;
    } catch (err) {
      console.error('[镜维度] 区域切换处理失败: ' + err);
      return false;
    }
  }

  /* ------------------------------------------------------------------ */
  /* 对外导出                                                            */
  /* ------------------------------------------------------------------ */

  const api = {
    ready: true,
    gravityOn: GRAVITY_ON,
    scanInterval: SCAN_INTERVAL,
    outerOn: OUTER_ON,
    maintainGlass: MAINTAIN_GLASS,
    GameType: GameType,
    onRegionChange: onRegionChange,
    notifyRegionChange: notifyRegionChange,
  };

  global.MirrorDimension.modules.n2 = api;
  return api;
})();
