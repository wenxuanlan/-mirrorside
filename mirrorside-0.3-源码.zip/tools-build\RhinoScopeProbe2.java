import dev.latvian.mods.rhino.Context;
import dev.latvian.mods.rhino.ContextFactory;
import dev.latvian.mods.rhino.Scriptable;

/** 进一步定位：什么样的结构会触发 redeclaration of var。 */
public class RhinoScopeProbe2 {

    static int failures = 0;

    static void run(String label, String src) {
        ContextFactory factory = new ContextFactory();
        Context cx = factory.enter();
        try {
            Scriptable scope = cx.initStandardObjects();
            Object result = cx.evaluateString(scope, src, label, 1, null);
            System.out.println("  OK   " + label + "  => " + cx.toString(result));
        } catch (Throwable t) {
            failures++;
            System.out.println("  FAIL " + label + "  => " + t.getClass().getSimpleName()
                + ": " + t.getMessage());
        }
    }

    public static void main(String[] args) {
        System.out.println("=== K 外层 const=IIFE + 注册回调 + 嵌套 const ===");
        run("K", "const M = (() => {"
            + "  var reg = function (fn) { var n = 0; for (var i = 0; i < 3; i++) n += fn({ v: i }); return n; };"
            + "  return reg(ev => { if (ev.v === 1) { const dep = { q: 2 }; return dep.q; } return 0; });"
            + "})(); M;");

        System.out.println("=== L 回调里同时有顶层 const 与嵌套 const ===");
        run("L", "var reg = function (fn) { var n = 0; for (var i = 0; i < 3; i++) n += fn({ v: i }); return n; };"
            + "reg(ev => { const a = 1; if (ev.v === 1) { const dep = { q: 2 }; return dep.q + a; } return a; });");

        System.out.println("=== M 回调里顶层有 let + 嵌套 const ===");
        run("M", "var reg = function (fn) { var n = 0; for (var i = 0; i < 3; i++) n += fn({ v: i }); return n; };"
            + "reg(ev => { let a = 1; if (ev.v === 1) { const dep = { q: 2 }; return dep.q + a; } return a; });");

        System.out.println("=== N 同名 const 出现在两个不同函数的块里 ===");
        run("N", "var f = function () { if (true) { const dup = 1; return dup; } return 0; };"
            + "var g = function () { if (true) { const dup = 2; return dup; } return 0; };"
            + "var s = 0; for (var i = 0; i < 2; i++) { s += f() + g(); } s;");

        System.out.println("=== O 同名 const 在同一函数的不同块里 ===");
        run("O", "var f = function (k) {"
            + "  if (k === 1) { const dup = 1; return dup; }"
            + "  if (k === 2) { const dup = 2; return dup; }"
            + "  return 0; };"
            + "var s = 0; for (var i = 0; i < 2; i++) { s += f(1) + f(2); } s;");

        System.out.println("=== P 嵌套 const 在 if 里，且 if 之后还有代码 ===");
        run("P", "var f = function (flag) {"
            + "  if (flag) { const dep = { q: 2 }; return dep.q; }"
            + "  var t = 9; return t; };"
            + "var s = 0; for (var i = 0; i < 3; i++) { s += f(true); } s;");

        System.out.println("=== Q 函数被调用时同一个块每次走不同分支 ===");
        run("Q", "var f = function (flag) {"
            + "  if (flag) { const dep = { q: 2 }; return dep.q; }"
            + "  return 0; };"
            + "var s = 0; s += f(true); s += f(false); s += f(true); s;");

        System.out.println("=== R 顶层 while/for 块里的 const（脚本顶层）===");
        run("R", "var s = 0; for (var i = 0; i < 3; i++) { const dep = { q: 1 }; s += dep.q; } s;");

        System.out.println("=== S 顶层块里 let ===");
        run("S", "{ let x = 3; } 1;");

        System.out.println("=== T 真实结构：IIFE 里注册两个处理器，一个含嵌套 const ===");
        run("T", "const Mod = (() => {"
            + "  let counter = 0;"
            + "  var handlers = [];"
            + "  var reg = function (fn) { handlers.push(fn); };"
            + "  reg(ev => {"
            + "    counter++;"
            + "    const top = 1;"
            + "    if (!ev.inMirror) {"
            + "      const dep = { q: 2 };"
            + "      if (dep != null) counter += dep.q;"
            + "      return counter + top;"
            + "    }"
            + "    return top;"
            + "  });"
            + "  var out = 0;"
            + "  for (var i = 0; i < 3; i++) out += handlers[0]({ inMirror: i % 2 === 0 });"
            + "  return out;"
            + "})(); Mod;");

        System.out.println();
        System.out.println(failures == 0 ? "全部通过" : (failures + " 项失败"));
    }
}
