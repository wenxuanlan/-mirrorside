#!/usr/bin/env node
/*
 * 生成「波粒子」的物品贴图。
 *
 * 放在实例 tools/ 下，与 gen-wave-texture.mjs / gen-mirror-textures.mjs 一致 ——
 * 都是"用代码确定性地造二进制资源"。
 *
 * ── 形状 ─────────────────────────────────────────────────────────────────────
 * 用户要求"形状参考下界之星"。下界之星是一颗**四角星**：四个尖角 + 凹进去的边。
 * 这类形状的解析式是超椭圆族 |x|^n + |y|^n = 1：
 *     n = 2   → 圆
 *     n = 1   → 菱形
 *     n = 2/3 → 星形线（astroid，角最尖）
 * 下界之星的观感介于菱形与星形线之间，所以取 n ≈ 0.62。
 * **调 n 就能调"角的胖瘦"**，不用重画。
 *
 * ── 颜色 ─────────────────────────────────────────────────────────────────────
 * 与波粒块同一套粉紫（粉 #F68FD8 / 紫 #9646F0），按"离中心的深度"做三段渐变：
 *   最中心 近白粉 → 中段 粉 → 角尖 紫，最外一圈再压深一点当描边，
 * 这样在浅色和深色背景上都立得住。
 *
 * 用法（在实例目录下）：
 *   node tools/gen-wave-particle-texture.mjs            # 写入模组资源目录
 *   node tools/gen-wave-particle-texture.mjs --preview  # 额外在 %TEMP% 出放大预览
 */

import { deflateSync } from 'node:zlib';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';

const HERE = dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = join(HERE, '..', '..', '..', '..');
const OUT = join(
  PROJECT_ROOT,
  'mirror-gravity-mod/src/main/resources/assets/mirrorgravity/textures/item/wave_particle.png',
);

const SIZE = 16;
/** 四角星的胖瘦（见文件头）。0.48 ≈ 接近星形线，角细长、贴近下界之星的观感
 *  （0.62 试过，16 像素下角太短、整颗星偏"圆胖菱形"）。 */
const STAR_N = 0.48;

/* 渐变端点色（试过三版，这版观感最好）：
 * 亮核心 → 粉 → 紫，四角再压一圈**不太深**的紫当描边。
 * ⚠️ 两个试错的教训记在这里，免得以后重复：
 *   · 尖端用深紫 (74,35,128) → 四个角糊成脏点；
 *   · 尖端用亮紫 (201,156,255) + 半透明 → 整颗星发白、没有立体感。 */
const CORE = [255, 242, 251];   // 近白粉（核心，只占很小一块）
const PINK = [246, 143, 216];   // 粉（与波粒块同色）
const PURPLE = [150, 70, 240];  // 紫（角尖）
const RIM = [96, 48, 160];      // 描边（比角尖略深一点就够）

/* ------------------------------------------------------------------ PNG 编码 */

const CRC_TABLE = (() => {
  const table = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c;
  }
  return table;
})();

function crc32(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, 'latin1'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

function encodePng(rgba, w, h) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;
  ihdr[9] = 6; // RGBA
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;
    Buffer.from(rgba.buffer, rgba.byteOffset + y * w * 4, w * 4).copy(raw, y * (w * 4 + 1) + 1);
  }
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/* ------------------------------------------------------------------ 画星星 */

const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
const smoothstep = (edge0, edge1, x) => {
  const t = Math.min(1, Math.max(0, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
};

function texel(x, y, size) {
  const half = size / 2;
  const dx = (x + 0.5 - half) / (half - 0.5);
  const dy = (y + 0.5 - half) / (half - 0.5);
  const d = Math.pow(Math.abs(dx), STAR_N) + Math.pow(Math.abs(dy), STAR_N);
  /* 边缘抗锯齿：d 在 0.92~1.08 之间做 1 像素的羽化 */
  const coverage = 1 - smoothstep(0.92, 1.08, d);
  if (coverage <= 0) {
    return [0, 0, 0, 0];
  }
  /* depth：1 = 正中，0 = 边界 */
  const depth = Math.min(1, Math.max(0, 1 - d));
  let color;
  if (depth > 0.72) {
    /* 核心只占很小一块（下界之星就是一个小亮核），否则整颗星会显得发白 */
    color = mix(PINK, CORE, (depth - 0.72) / 0.28);
  } else {
    color = mix(PURPLE, PINK, depth / 0.72);
  }
  /* 最外一圈略压深当描边 */
  if (depth < 0.12) {
    color = mix(RIM, color, depth / 0.12);
  }
  /* 尖端渐隐（下界之星的角是半透明的），但只隐一点点 —— 隐太多整颗星会发灰。 */
  const tipFade = 0.72 + 0.28 * Math.min(1, depth / 0.30);
  return [Math.round(color[0]), Math.round(color[1]), Math.round(color[2]),
    Math.round(coverage * tipFade * 255)];
}

function buildRgba(size) {
  const rgba = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const px = texel(x, y, size);
      const i = (y * size + x) * 4;
      rgba[i] = px[0];
      rgba[i + 1] = px[1];
      rgba[i + 2] = px[2];
      rgba[i + 3] = px[3];
    }
  }
  return rgba;
}

function buildPreview(size, scale) {
  const w = size * scale;
  const rgba = new Uint8Array(w * w * 4);
  const tile = buildRgba(size);
  for (let y = 0; y < w; y++) {
    for (let x = 0; x < w; x++) {
      const s = (Math.floor(y / scale) * size + Math.floor(x / scale)) * 4;
      const d = (y * w + x) * 4;
      /* 预览铺在一个中灰背景上，方便看描边与透明度 */
      const a = tile[s + 3] / 255;
      rgba[d] = Math.round(tile[s] * a + 64 * (1 - a));
      rgba[d + 1] = Math.round(tile[s + 1] * a + 64 * (1 - a));
      rgba[d + 2] = Math.round(tile[s + 2] * a + 64 * (1 - a));
      rgba[d + 3] = 255;
    }
  }
  return { rgba, w };
}

/* ------------------------------------------------------------------ 主流程 */

mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, encodePng(buildRgba(SIZE), SIZE, SIZE));
console.log(`已写入 ${OUT}`);

if (process.argv.includes('--preview')) {
  const { rgba, w } = buildPreview(SIZE, 14);
  const previewPath = join(tmpdir(), 'wave-particle-item-preview.png');
  writeFileSync(previewPath, encodePng(rgba, w, w));
  console.log(`预览 ${previewPath}`);
}
