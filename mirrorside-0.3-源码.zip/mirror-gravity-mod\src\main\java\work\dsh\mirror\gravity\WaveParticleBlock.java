package work.dsh.mirror.gravity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.joml.Vector3f;

/**
 * 波粒块。
 *
 * <h2>它是什么</h2>
 * 「针尖对麦芒」装置正中间那一块：两锥尖连线的中点，落在境内。
 * 外表粉紫平滑融合、微微自发光，周围飘粉紫尘埃 —— 名字取自波粒二象性，
 * 是整条设定里唯一的"奖品"，钻石镐及以上才挖得下来（工具门槛在
 * {@code requiresCorrectToolForDrops()} + 两个方块标签里，
 * 掉落表在 {@code data/mirrorgravity/loot_table/blocks/wave_particle_block.json}）。
 *
 * <h2>为什么粒子写在方块里，而不是模组每 tick 扫世界</h2>
 * {@code Block.animateTick} 由客户端每 tick 对<b>玩家附近</b>的方块抽样调用，
 * 天然带距离限制、天然只在客户端跑，不需要自己维护任何表。
 * 换成事件扫描就得自己算距离、自己防止在服务端生成粒子。
 *
 * <p>注意 {@code animateTick} 里<b>不能</b>改世界状态（它可能在任何线程上下文被调），
 * 只允许加粒子 —— 这里也只做这件事。
 */
public class WaveParticleBlock extends Block {

    /** 粉。 */
    private static final Vector3f PINK = new Vector3f(1.00F, 0.55F, 0.86F);
    /** 紫。 */
    private static final Vector3f PURPLE = new Vector3f(0.62F, 0.36F, 1.00F);

    public WaveParticleBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        double cx = pos.getX() + 0.5D;
        double cy = pos.getY() + 0.5D;
        double cz = pos.getZ() + 0.5D;

        /* 粉紫尘埃：方块周围 0.6~1.1 格的环上飘，少量向上。
         * 两种颜色交替，视觉上就是"粉紫融合"的动态版。 */
        if (random.nextInt(3) == 0) {
            Vector3f color = random.nextBoolean() ? PINK : PURPLE;
            double angle = random.nextDouble() * Math.PI * 2.0D;
            double radius = 0.6D + random.nextDouble() * 0.5D;
            level.addParticle(
                new DustParticleOptions(color, 0.8F + random.nextFloat() * 0.6F),
                cx + Math.cos(angle) * radius,
                cy + (random.nextDouble() - 0.5D) * 1.2D,
                cz + Math.sin(angle) * radius,
                0.0D, 0.008D, 0.0D);
        }

        /* 偶尔一颗末地烛光点：给静态的粉紫加一点"闪烁"，也让远处更容易注意到。 */
        if (random.nextInt(10) == 0) {
            level.addParticle(
                ParticleTypes.END_ROD,
                cx + (random.nextDouble() - 0.5D) * 1.4D,
                cy + 0.6D,
                cz + (random.nextDouble() - 0.5D) * 1.4D,
                0.0D, 0.004D, 0.0D);
        }
    }
}
