#!/usr/bin/env node
/*
 * 生成「波粒块」的方块纹理。
 *
 * 放在实例的 tools/ 下，与 gen-mirror-textures.mjs / gen-portal-texture.mjs 一致 ——
 * 这三者都是"把某个方块/音效的二进制资源用代码确定性地造出来"。
 *
 * ── 为什么要有生成器，而不是塞一张手画的 PNG ─────────────────────────────────
 *   1. 设定要求的是"粉紫色**平滑融合**"——这是可参数化的（粉/紫两个端点色 +
 *      一条无缝的正弦混合曲线）。写成代码以后调色只改两个常量，不用重画图片。
 *   2. 纹理是二进制资源，Review 时看不见。生成器本身就是"这张图长什么样"的
 *      唯一说明，评审时看这个文件就够了。
 *
 * ── 尺寸与无缝性 ─────────────────────────────────────────────────────────────
 *   32×32：原版是 16×16，但"平滑渐变"在 16 格上会出现明显色带，32 格刚好够，
 *   而且仍是方块纹理的常用尺寸。
 *   混合相位取自 sin(2π(x+y)/N)，x 或 y 加 N 时相位正好走一整圈 ⇒ 平铺无接缝。
 *
 * 用法（在实例目录下）：
 *   node tools/gen-wave-texture.mjs            # 写入模组资源目录
 *   node tools/gen-wave-texture.mjs --preview  # 额外在 %TEMP% 出 3×3 平铺放大图
 */

import { deflateSync } from 'node:zlib';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';

const HERE = dirname(fileURLToPath(import.meta.url));
/* tools/ 往上四级 = 工程根（与 gen-mirror-textures.mjs 的算法一致：
 *   tools → 镜维度 → versions → .minecraft → MC镜维度） */
const PROJECT_ROOT = join(HERE, '..', '..', '..', '..');
const OUT = join(
  PROJECT_ROOT,
  'mirror-gravity-mod/src/main/resources/assets/mirrorgravity/textures/block/wave_particle_block.png',
);

const SIZE = 32;

/** 两个端点色（粉 → 紫）。改这两个常量就换了整张纹理的色调。 */
const PINK = [246, 143, 216];
const PURPLE = [150, 90, 240];

/** 中心那点柔光的强度（0 = 完全平铺，1 = 明显一颗颗）。 */
const CORE_GLOW = 0.10;

/* ------------------------------------------------------------------ PNG 编码 */

const CRC_TABLE = (() => {
  const table = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c;
  }
  return table;
})();

function crc32(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, 'latin1'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

/** @param {Uint8Array} rgba 长度 = w*h*4 */
function encodePng(rgba, w, h) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type: RGBA
  // 10..12 = compression / filter / interlace = 0
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0; // filter type 0
    Buffer.from(rgba.buffer, rgba.byteOffset + y * w * 4, w * 4).copy(raw, y * (w * 4 + 1) + 1);
  }
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/* ------------------------------------------------------------------ 画纹理 */

function waveTexel(x, y, size) {
  const u = (x + 0.5) / size;
  const v = (y + 0.5) / size;
  // 主混合：斜向正弦，周期正好铺满整张图 ⇒ 平铺无缝
  const main = Math.sin(2 * Math.PI * (u + v));
  // 次混合：反斜向，弱一点，避免纹理看起来太"条带"
  const cross = Math.sin(2 * Math.PI * (u - v));
  let mix = 0.5 + 0.5 * (0.85 * main + 0.15 * cross);
  // 中心柔光：单块悬浮时像一颗微微发亮的珠子
  const dx = (x + 0.5 - size / 2) / (size / 2);
  const dy = (y + 0.5 - size / 2) / (size / 2);
  const glow = Math.max(0, 1 - Math.sqrt(dx * dx + dy * dy));
  mix = Math.min(1, Math.max(0, mix + CORE_GLOW * glow * glow));
  return mix;
}

function buildRgba(size) {
  const rgba = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const t = waveTexel(x, y, size);
      const i = (y * size + x) * 4;
      for (let c = 0; c < 3; c++) {
        rgba[i + c] = Math.round(PINK[c] + (PURPLE[c] - PINK[c]) * t);
      }
      rgba[i + 3] = 255;
    }
  }
  return rgba;
}

/** 3×3 平铺 + 放大，用来肉眼确认接缝与整体观感。 */
function buildPreview(size, scale) {
  const w = size * 3 * scale;
  const rgba = new Uint8Array(w * w * 4);
  const tile = buildRgba(size);
  for (let y = 0; y < w; y++) {
    for (let x = 0; x < w; x++) {
      const sx = (x / scale) % size;
      const sy = (y / scale) % size;
      const s = (Math.floor(sy) * size + Math.floor(sx)) * 4;
      const d = (y * w + x) * 4;
      rgba[d] = tile[s];
      rgba[d + 1] = tile[s + 1];
      rgba[d + 2] = tile[s + 2];
      rgba[d + 3] = 255;
    }
  }
  return { rgba, w };
}

/* ------------------------------------------------------------------ 主流程 */

mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, encodePng(buildRgba(SIZE), SIZE, SIZE));
console.log(`已写入 ${OUT}`);

if (process.argv.includes('--preview')) {
  const { rgba, w } = buildPreview(SIZE, 6);
  const previewPath = join(tmpdir(), 'wave-particle-preview.png');
  writeFileSync(previewPath, encodePng(rgba, w, w));
  console.log(`预览（3×3 平铺）${previewPath}`);
}
