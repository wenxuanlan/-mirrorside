package work.dsh.mirror.gravity.mixin;

import net.minecraft.core.BlockPos;
import net.minecraft.world.Containers;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import work.dsh.mirror.gravity.MirrorGravity;
import work.dsh.mirror.gravity.internal.ContainerDropGuard;

/**
 * 把"改造成下落实体"那一刻的内容物掉落压掉。
 *
 * <h2>现象（用户实测报告）</h2>
 * 用波粒子改造箱子/木桶后，里面的东西会**爆出来一份**，同时方块照常下落、
 * 落地后重新变成箱子且内容物还在 —— 等于凭空刷了一份物品。
 *
 * <h2>原因</h2>
 * 原版 {@code ChestBlock.onRemove} 与 {@code BarrelBlock.onRemove} 都调了
 * {@code Containers.dropContentsOnDestroy(...)}（见 1.21.1 源码），
 * 而 {@code FallingBlockEntity.fall(...)} 内部正是用
 * {@code level.setBlock(pos, 空气, 3)} 清空原位 —— 于是 onRemove 被触发，
 * 内容物当场掉了一地；我们这边又把同一段 NBT 存进了下落实体，
 * 落地时原样写回新的方块实体 ⇒ 两份。
 *
 * <h2>修法</h2>
 * 只在**我们自己那一次改造**期间取消这个方法（见
 * {@link ContainerDropGuard}）。玩家正常挖掉箱子时开关是关的，
 * 原版掉落一点不受影响。
 *
 * ⚠️ 开关只在"确实抓到了方块实体 NBT"时才打开：抓不到还压掉，
 *    东西就凭空没了 —— 那比刷物品更糟。
 */
@Mixin(Containers.class)
public class ContainersDropMixin {

    @Inject(
        method = "dropContentsOnDestroy(Lnet/minecraft/world/level/block/state/BlockState;"
            + "Lnet/minecraft/world/level/block/state/BlockState;"
            + "Lnet/minecraft/world/level/Level;"
            + "Lnet/minecraft/core/BlockPos;)V",
        at = @At("HEAD"),
        cancellable = true,
        require = 1,
        remap = false)
    private static void mirrorgravity$keepContentsWhenFalling(BlockState oldState, BlockState newState,
                                                              Level level, BlockPos pos, CallbackInfo ci) {
        if (ContainerDropGuard.active()) {
            ci.cancel();
            /* 打一条 debug：内容物"不见了"这种事一定要能查到原因，
             * 而这一行就是"是我们压掉的、不是丢了"的唯一凭证。 */
            MirrorGravity.LOGGER.debug(
                "[镜维度·波粒子] 已在改造期间压掉一次容器内容物掉落 @ {}（{} → {}）",
                pos, oldState.getBlock(), newState.getBlock());
        }
    }
}
