package work.dsh.mirror.gravity;

import work.dsh.mirror.gravity.internal.Failures;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 访问 Pondus 内部数据的**唯一**反射入口。
 *
 * <h2>为什么必须用反射</h2>
 * Pondus 没有发布到任何公共 Maven 仓库，拿不到编译期坐标。
 * 反射让本模组能编译而完全不依赖它的 jar —— 它在运行时由 mods/ 提供即可。
 *
 * <h2>为什么解析结果全部静态缓存</h2>
 * {@code Class.forName} 与 {@code getDeclaredField} 是昂贵操作，但只需做一次。
 * 真正每 tick 发生的是 {@code Method.invoke} / {@code Field.get}，
 * 它们只占调用开销的一小部分。
 *
 * <h2>为什么不用 MethodHandle</h2>
 * {@code MethodHandle} 确实比 {@code Method.invoke} 快，但：
 * <ul>
 *   <li>本模组每 tick 的反射调用在**个位到几十次**之间，不构成瓶颈</li>
 *   <li>换成 MethodHandle 要处理 {@code unreflect} 的异常、类型描述符、
 *       {@code invokeExact} 的签名匹配，可读性显著下降</li>
 * </ul>
 * 结论：属于过早优化，不做。若将来反射进入热路径（每 tick 上千次）再改不迟。
 *
 * <h2>失败行为</h2>
 * 可用性由 {@link #isAvailable()} 单点回答。解析失败**不抛异常**，
 * 但会记一条明确的 WARN —— 此时重力反转整体不可用，
 * 属于"必须让人看见"的故障，而不是可以静默降级的可选功能。
 *
 * <h2>⚠️ 为什么不按职责拆成多个类（评估过，结论是不拆）</h2>
 * 本类现在装着四块职责：方向读写、强度写入、位置回退、旋转参数刷新。
 * 看起来该拆，但两条实测依据说明**不该拆**：
 * <ol>
 *   <li><b>解析是"一次成功或整体失败"的。</b>所有字段与方法都在
 *       {@link #resolve()} 里一次性解析并缓存，配合 {@link #available}
 *       给出明确的"Pondus 接上没有"。拆开后每个类都要各搞一套解析与
 *       可用性判定，就会出现"方向可用、位置不可用"这种中间状态 ——
 *       而调用方（mixin / BlockPhysics / VelocityFix）是**跨职责**使用的，
 *       没法据此做合理降级。</li>
 *   <li><b>位置回退依赖方向字段。</b>回退要同时改 {@code posX/Y/Z}、
 *       {@code xo/yo/zo}、{@code xOld/yOld/zOld} 三组，而"这些字段是否存在"
 *       与方向字段共享同一次反射探测。拆开后要么重复探测、要么跨类暴露
 *       内部字段。</li>
 * </ol>
 * 所以保持单类，改用**段落分隔 + 每块职责写明**来维持可读性。
 *
 * <h2>⚠️ 每个对外方法都必须自己调用 resolve()</h2>
 * {@link work.dsh.mirror.gravity.mixin.PondusPositionMixin} 可能在
 * **类加载期**就被触发，不能依赖"别的类先调用过 resolve"这种隐式顺序。
 * 曾经 {@link #readPosition} 没调 resolve，位置字段未初始化 → 返回 false →
 * 回退静默失效（症状是"已经修好的瞬移又回来了"，且日志里毫无异常）。
 *
 * <p>可见性说明：本包与 {@code internal} 包分处两层，所以跨包要用的成员
 * 必须是 public。对外部而言它们仍是实现细节，只是 Java 包级封装
 * 无法跨包生效。
 */
public final class PondusReflect {

    private PondusReflect() {
    }

    /** Pondus 暴露出来的 API 门面类（所有操作都从它拿 EntityGravityData）。 */
    private static final String API_CLASS = "dinner.dev.pondus.api.PondusAPI";

    /** 承载重力方向的附件对象。 */
    private static final String DATA_CLASS = "dinner.dev.pondus.util.EntityGravityData";

    // ---- PondusAPI ----
    private static Method getGravityDataMethod;    // getGravityData(Entity) → EntityGravityData

    // ---- EntityGravityData ----
    private static Method setBaseDirectionMethod;  // setBaseGravityDirection(Direction)
    private static Field baseDirectionField;       // baseGravityDirection
    private static Field currDirectionField;       // currGravityDirection
    private static Field baseStrengthField;        // baseGravityStrength
    private static Field currStrengthField;        // currGravityStrength（真正参与计算的）
    private static Field needsSyncField;           // needsSync（置 true 才向客户端发同步包）

    // ---- Entity 的上一帧 / 上上帧位置字段（供位置回退用）----
    /* ⚠️ 1.21.1 的 Entity **没有** posX/posY/posZ 三个字段 ——
     * 位置存的是一个 private Vec3 position（见 Entity.position() 的字节码：
     * getfield position:Lnet/minecraft/world/phys/Vec3;）。
     * 曾经按 posX/posY/posZ 去反射查找，三个都拿到 null，
     * 于是 shiftPositionBack 静默什么都不做、注入形同虚设。
     *
     * 位置本身改成走 entity.getX()/getY()/getZ() 公开 API；
     * 这里只保留确实存在的六个"历史位置"字段。 */
    private static Field oldXField;    // xo
    private static Field oldYField;    // yo
    private static Field oldZField;    // zo
    private static Field prevXField;   // xOld
    private static Field prevYField;   // yOld
    private static Field prevZField;   // zOld

    // ---- RotationParameters ----
    private static Method updateDefaultMethod;     // updateDefault()

    private static boolean resolved;
    private static boolean available;

    /**
     * 解析一次并缓存。线程安全（synchronized + resolved 提前置位）。
     *
     * @return Pondus 是否可用
     */
    public static synchronized boolean resolve() {
        if (resolved) {
            return available;
        }
        resolved = true;
        try {
            Class<?> api = Class.forName(API_CLASS);
            Class<?> dataCls = Class.forName(DATA_CLASS);
            Class<?> entityCls = Class.forName("net.minecraft.world.entity.Entity");
            Class<?> dirCls = Class.forName("net.minecraft.core.Direction");

            getGravityDataMethod = api.getMethod("getGravityData", entityCls);

            /* 用 Pondus 自己的 setter，而不是直接写 baseGravityDirection 字段。
             * 差别在 needsSync：setter 会置位它，从而触发向客户端的同步包。
             * 直接写字段不会同步，客户端会一直用旧方向。
             * 这是"客户端不同步"问题的修复关键。 */
            setBaseDirectionMethod = optionalMethod(dataCls, "setBaseGravityDirection", dirCls);

            baseDirectionField = requiredField(dataCls, "baseGravityDirection");
            currDirectionField = optionalField(dataCls, "currGravityDirection");
            baseStrengthField = optionalField(dataCls, "baseGravityStrength");
            currStrengthField = optionalField(dataCls, "currGravityStrength");
            needsSyncField = optionalField(dataCls, "needsSync");

            Class<?> rotationCls = Class.forName("dinner.dev.pondus.api.RotationParameters");
            updateDefaultMethod = optionalMethod(rotationCls, "updateDefault");

            /* 位置字段。全部 optional：拿不到只是让"换向位置回退"失效，
             * 方向本身照常写入，不会把整个 Pondus 接驳判为失败。
             *
             * ⚠️ 这里**没有** posX/posY/posZ —— 1.21.1 的 Entity 不存在这三个
             * 字段（位置是一个 private Vec3 position）。位置读写改走公开 API。 */
            oldXField = optionalField(entityCls, "xo");
            oldYField = optionalField(entityCls, "yo");
            oldZField = optionalField(entityCls, "zo");
            prevXField = optionalField(entityCls, "xOld");
            prevYField = optionalField(entityCls, "yOld");
            prevZField = optionalField(entityCls, "zOld");


            available = true;
        } catch (Throwable t) {
            available = false;
            MirrorGravity.LOGGER.warn(
                "[镜维度·重力] 未能接上 Pondus（{}）；非生物实体的重力反转将不可用。", t.toString());
        }
        return available;
    }

    public static boolean isAvailable() {
        return resolve();
    }

    /** 必有字段，缺失即视为 Pondus 版本不兼容。 */
    private static Field requiredField(Class<?> cls, String name) throws NoSuchFieldException {
        Field f = cls.getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }

    /** 可选字段，缺失时返回 null（调用处需判空）。 */
    private static Field optionalField(Class<?> cls, String name) {
        try {
            return requiredField(cls, name);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 可选方法，缺失时返回 null。 */
    private static Method optionalMethod(Class<?> cls, String name, Class<?>... params) {
        try {
            return cls.getMethod(name, params);
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * 取出实体的重力数据附件对象。
     *
     * @return 附件对象；实体无效或 Pondus 不可用时返回 null
     */
    public static Object gravityDataOf(Entity entity) {
        if (!resolve() || entity == null || getGravityDataMethod == null) {
            return null;
        }
        try {
            return getGravityDataMethod.invoke(null, entity);
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * 读实体**当前实际生效**的重力方向。
     *
     * <p>直接读 Pondus 的方向字段，**不管是谁设的**
     * （模组 BlockPhysics、KubeJS、Pondus 自己都算），
     * 所以对下落的方块同样有效。
     *
     * <p>KubeJS 侧靠它做配方计数 —— 以实际方向为唯一真相，
     * 视觉与程序才能真正统一（否则会与模组的迟滞状态机形成两套度量，
     * 实测症状是"视觉上来回好几次、计数只涨 1"）。
     */
    public static Direction direction(Entity entity) {
        Object data = gravityDataOf(entity);
        if (data == null || baseDirectionField == null) {
            return null;
        }
        try {
            Object v = baseDirectionField.get(data);
            return v instanceof Direction d ? d : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 调 Pondus 的 setter 写入基础方向。返回是否成功调用。 */
    public static boolean invokeSetBaseDirection(Object data, Direction dir) {
        if (setBaseDirectionMethod == null || data == null || dir == null) {
            return false;
        }
        try {
            setBaseDirectionMethod.invoke(data, dir);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 兜底：直接写 base 字段（setter 不可用时）。 */
    public static boolean writeBaseDirection(Object data, Direction dir) {
        if (baseDirectionField == null || data == null || dir == null) {
            return false;
        }
        try {
            baseDirectionField.set(data, dir);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * 直接写 curr 字段。
     *
     * <p>只对**不调用 super.tick()** 的实体使用（下落的方块）：
     * Pondus 把 curr 的同步逻辑挂在 Entity.tick() 的 RETURN 上，
     * 这类实体永远不触发，curr 不会从 base 跟上，必须手动写。
     */
    public static void writeCurrDirection(Object data, Direction dir) {
        if (currDirectionField == null || data == null || dir == null) {
            return;
        }
        try {
            currDirectionField.set(data, dir);
        } catch (Throwable ignored) {
            Failures.note("PondusReflect.writeCurrDirection", ignored);
            // 写失败不影响主流程：方向仍会通过 base 生效
        }
    }

    /** 置 needsSync，触发向客户端的重力同步包。 */
    public static void markNeedsSync(Object data) {
        if (needsSyncField == null || data == null) {
            return;
        }
        try {
            needsSyncField.setBoolean(data, true);
        } catch (Throwable ignored) {
            Failures.note("PondusReflect.markNeedsSync", ignored);
            // 同上，非关键路径
        }
    }

    /**
     * 写重力强度倍数（base 与 curr 都写）。返回是否成功。
     *
     * <h2>为什么两个字段都要写</h2>
     * Pondus 在 {@code EntityMixin.injected} 里做的是：
     * <pre>
     *   getGravity() 的返回值 × PondusAPI.getGravityStrength(entity)
     * </pre>
     * 而 {@code getGravityStrength()} 读的是 {@code currGravityStrength}。
     *
     * <p>只写 base 是不够的：base 还要经过 {@code updateGravityStatus()}
     * 才会同步到 curr，而那个同步在某些路径上不一定发生。
     * 实测证据：把 base 写成 0.2 之后，用位置二阶差分算出的实际加速度
     * 仍是 0.038（≈原版满重力），说明**参与计算的 curr 没被改成 0.2**。
     *
     * <p>所以这里把两个字段一起写死，不依赖 Pondus 的同步时机。
     */
    public static boolean writeBaseStrength(Object data, double scale) {
        if (data == null) {
            return false;
        }
        boolean ok = false;
        if (baseStrengthField != null) {
            try {
                baseStrengthField.set(data, scale);
                ok = true;
            } catch (Throwable ignored) {
                Failures.note("PondusReflect.writeBaseStrength", ignored);
                // 下面再看 curr 是否写成功
            }
        }
        if (currStrengthField != null) {
            try {
                currStrengthField.set(data, scale);
                ok = true;
            } catch (Throwable ignored) {
                Failures.note("PondusReflect.writeCurrStrength", ignored);
                // curr 写失败时至少 base 已写
            }
        }
        return ok;
    }

    /**
     * 实体是否会走到 Pondus 的 commonTick()。
     *
     * <p>Pondus 把 commonTick 注入在 {@code Entity.tick()} 的 RETURN 上。
     * 只要某个类重写了 tick() 又**不调用 super.tick()**，那条注入就永不触发，
     * 它的 currGravityDirection 也不会更新。已知下落的方块就是这种情况。
     *
     * <p>这里用"类名里是否含 FallingBlock"判断，而不是反射调方法 ——
     * 简单、无副作用，而且这类实体本来就很少。
     */
    public static boolean callsSuperTick(Entity entity) {
        return !entity.getClass().getName().contains("FallingBlockEntity");
    }

    /* ------------------------------------------------------------------ */
    /* 位置回退：撤销 Pondus 换向时对位置做的平移                              */
    /* ------------------------------------------------------------------ */
    /* 为什么不用 entity.setPos()：它只改 posX/posY/posZ 与包围盒，**不碰**
     * xo/yo/zo 与 xOld/yOld/zOld。而 Pondus 在换向时把这六个字段都设成了
     * 平移后的值，只回退位置会留下"上一帧位置被篡改"的状态 ——
     * 下一帧的位移（x − xOld，本模组与 KubeJS 都靠它判断运动）、渲染插值
     * 与位置包全都会错。所以这里按字段精确回退。
     *
     * 唯一调用方是 mixin.PondusPositionMixin。 */

    /**
     * 读取实体当前位置，写进 out[0..2]。走公开 API，不依赖字段名。
     *
     * <p>⚠️ 必须自己先 {@link #resolve()}：位置回退的调用方是
     * {@code PondusPositionMixin}，它在<b>类加载期就可能被触发</b>，
     * 不一定晚于 {@code DirectionWriter} 的首次调用。而位置字段只在
     * {@code resolve()} 里赋值 —— 不在这里兜一下，回退会静默失效
     * （表现为"上次修好的瞬移又回来了"，且没有任何报错）。
     */
    public static boolean readPosition(Entity entity, double[] out) {
        resolve();
        if (entity == null || out == null || out.length < 3) {
            return false;
        }
        try {
            out[0] = entity.getX();
            out[1] = entity.getY();
            out[2] = entity.getZ();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * 把实体位置整体平移 {@code -delta}。
     *
     * <p>分两步：
     * <ol>
     *   <li>位置本身走 {@link Entity#setPos(double, double, double)} ——
     *       它同时更新内部 position 与包围盒。</li>
     *   <li>{@code xo/yo/zo} 与 {@code xOld/yOld/zOld} 这六个字段必须**手工**
     *       回退：{@code setPos} 不碰它们，而 Pondus 在换向时把它们都设成了
     *       平移后的值。不回退就会留下"上一帧位置被篡改"的状态 ——
     *       下一帧的位移（{@code x − xOld}，本模组与 KubeJS 都靠它判断运动）、
     *       渲染插值与位置包全都会错。</li>
     * </ol>
     */
    public static void shiftPositionBack(Entity entity, double dx, double dy, double dz) {
        resolve();
        if (entity == null || (dx == 0.0D && dy == 0.0D && dz == 0.0D)) {
            return;
        }
        try {
            entity.setPos(entity.getX() - dx, entity.getY() - dy, entity.getZ() - dz);
            shift(oldXField, entity, dx);
            shift(oldYField, entity, dy);
            shift(oldZField, entity, dz);
            shift(prevXField, entity, dx);
            shift(prevYField, entity, dy);
            shift(prevZField, entity, dz);
        } catch (Throwable ignored) {
            Failures.note("PondusReflect.revertPosition", ignored);
            // 回退失败只影响视觉连续性，方向仍然已生效
        }
    }

    private static void shift(Field f, Entity e, double delta) throws IllegalAccessException {
        if (f == null) {
            return;
        }
        f.setDouble(e, f.getDouble(e) - delta);
    }

    /**
     * 让 Pondus 的 {@code RotationParameters} 默认值从配置文件刷新一次。
     *
     * <h2>这是上游 bug，不是我们的用法问题</h2>
     * Pondus 的初始化链是：
     * <pre>
     *   PondusNeoForge.&lt;init&gt;() → Pondus.init()          // 注册配置、读文件
     *   configHolder.registerSaveListener(cfg -&gt; updateDefault())  // 只在"保存配置"时刷新
     * </pre>
     * 而 {@code RotationParameters} 的默认值是**编译期写死**的：
     * <pre>
     *   public static RotationParameters defaultParam =
     *       new RotationParameters(true, true, 500);
     *                            ^^^^ rotateVelocity = true
     * </pre>
     * <b>updateDefault() 在启动时从不被调用</b> —— 既不在 init() 里，
     * 也不在 FMLCommonSetupEvent 里。后果：
     * <ul>
     *   <li>config/pondus.json 里的 worldVelocity 改了也没人读</li>
     *   <li>换重力时速度永远被强行旋转（Pondus 自己的注释也承认这
     *       "会让物体看起来急转弯"）</li>
     * </ul>
     * 所以由本模组主动调一次。
     */
    public static boolean refreshRotationDefaults() {
        if (!resolve() || updateDefaultMethod == null) {
            return false;
        }
        try {
            updateDefaultMethod.invoke(null);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
