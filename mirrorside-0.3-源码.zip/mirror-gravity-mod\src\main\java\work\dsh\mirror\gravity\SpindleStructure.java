package work.dsh.mirror.gravity;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

import java.util.Optional;

/**
 * 针尖对麦芒 · 世界生成结构。
 *
 * <h2>为什么走世界生成，而不是脚本在玩家进维度时搭</h2>
 * 用户选的是"世界生成时就存在、不要求一个世界只有一座、密度较小比较稀有"。
 * 这也确实是这个装置的合理形态：它横跨整个世界高度（−190 ~ +189）、
 * 横向几十格，脚本运行时搭建需要把几十个区块强行加载进来、
 * 还要在世界存档里记账"建过没有"。交给世界生成则完全不需要这些：
 * 区块生成时顺手把方块写进自己那一格，玩家没去过它就已经在那儿。
 *
 * <h2>为什么必须写自定义 Structure，而不是原版 jigsaw + 结构方块文件</h2>
 * 原版结构与模板池只能放<b>固定的 .nbt 模板</b>，而这个装置的每个参数
 * （半径 5~13、长度 64~128、俯仰角、谁在上、伸进境内几格）都是随机的，
 * 组合空间是连续统，不可能预生成模板。所以这里在第一性原理上就得自己算方块。
 *
 * <h2>与玻璃层的关系（重要，且已核对原版源码）</h2>
 * 白玻璃层是 {@code minecraft:fill_layer} 放在
 * {@code GenerationStep.Decoration} 的<b>最后一步</b>（{@code top_layer_modification}），
 * 而结构在本步骤（{@code surface_structures}）之前就已写入。
 * 看起来玻璃会把穿透处的锥体盖掉，但原版 {@code FillLayerFeature.place} 的循环体是
 * <pre>
 *   if (worldgenlevel.getBlockState(pos).isAir()) { worldgenlevel.setBlock(pos, state, 2); }
 * </pre>
 * —— 它<b>只填空气</b>（1.21.1 源码第 26 行）。所以锥体穿过玻璃的位置会留下锥体方块，
 * 玻璃自动绕开，"被穿过的白玻璃被替换掉"这条设定不需要额外代码。
 *
 * <h2>生成位置由谁决定</h2>
 * 由 {@code kubejs/data/mirror/worldgen/structure_set/spindle.json} 的
 * {@code random_spread}（spacing/separation/salt）决定；本类只负责
 * "在被选中的区块里长成什么样"。区块内的水平位置由几何层随机。
 */
public class SpindleStructure extends Structure {

    /** 结构 JSON 只带原版必需字段，可调数字一律走 KubeJS 推送（见 {@link SpindleSettings}）。 */
    public static final MapCodec<SpindleStructure> CODEC = simpleCodec(SpindleStructure::new);

    public SpindleStructure(Structure.StructureSettings settings) {
        super(settings);
    }

    @Override
    public StructureType<?> type() {
        return MirrorStructures.SPINDLE.get();
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext context) {
        SpindleGeometry.Rules rules = SpindleSettings.rules();
        String problem = rules.problem();
        if (problem != null) {
            /* 规则自相矛盾（比如伸入格数区间放不下高度带）：宁可不生成，
             * 也不要生成一堆错位方块再让人去查。失败进静默失败收集器，/mirror diag 能看到。 */
            SpindleSettings.noteFailure("规则非法，跳过生成", problem);
            return Optional.empty();
        }

        SpindleGeometry.Plan plan = SpindleGeometry.sample(
            wrap(context.random()),
            rules,
            context.chunkPos().getMinBlockX(),
            context.chunkPos().getMinBlockZ());

        /* 每次生成打一行 INFO：这是"装置到底长成什么样"的唯一现场证据，
         * /locate structure mirror:spindle 只能给位置，给不了尺寸和朝向。
         * 结构很稀有，所以不会刷屏。 */
        MirrorGravity.LOGGER.info("[镜维度·针尖对麦芒] 生成于区块 {}：{}",
            context.chunkPos(), plan.describe());

        return Optional.of(new Structure.GenerationStub(
            new BlockPos(plan.coreX, plan.coreY, plan.coreZ),
            pieces -> pieces.addPiece(new SpindlePiece(plan))));
    }

    /**
     * 把 MC 的随机源适配成几何层的最小接口。
     *
     * <p>几何层不能 import Minecraft（否则离线测试跑不起来），
     * 所以这里做一层薄包装，随机流本身仍然是原版那一条 ——
     * 也就是说同一个种子 + 同一个区块永远生成同一套参数。
     */
    private static SpindleGeometry.Rng wrap(RandomSource random) {
        return new SpindleGeometry.Rng() {
            @Override
            public double nextDouble() {
                return random.nextDouble();
            }

            @Override
            public int nextInt(int bound) {
                return random.nextInt(bound);
            }
        };
    }
}
