package work.dsh.mirror.gravity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 「被波粒子赋予重力特性」的方块位置表（每个维度一份，存进存档）。
 *
 * <h2>为什么需要一张表</h2>
 * 原版的下坠行为是<b>绑在方块类上</b>的：{@code FallingBlock}（1.21 里沙子/沙砾的统一实现）
 * 靠 {@code onPlace} / {@code updateShape} 调度一个 2 tick 后的**方块 tick**，
 * tick 里判断下方能不能穿透，再交给 {@code FallingBlockEntity.fall(...)}。
 * 任意方块没法获得这个 tick（{@code ServerLevel#scheduleTick} 要求坐标上的方块类型与
 * 登记时一致，否则那一次 tick 直接被丢掉），所以只能在模组侧自己记"哪些位置被改造过"，
 * 并在同样的时机（邻居更新 / 区块加载）重新判定。
 *
 * <h2>为什么存 BlockState 而不是只存坐标</h2>
 * 存了状态就能回答"这一格还是当初被标记的那个方块吗"：
 *   · 方块被挖掉 → 变成空气 → 状态对不上 → 标记自动失效
 *   · 玩家在原地放了别的方块 → 同样对不上 → 失效
 * 于是不需要监听"方块被破坏"这类事件也不会留下脏数据（{@link GravityTagger}
 * 仍会在破坏事件里顺手清一次，属于加速收敛）。
 *
 * <h2>为什么用 SavedData</h2>
 * 它是原版给"每个维度一份、随存档读写"的容器（{@code level.getDataStorage()
 * .computeIfAbsent(...)}）。玩家标记完一个方块就退出游戏、下次进来再抽掉支撑，
 * 这个标记必须还在 —— 否则"重力特性"就变成了一次性会话内的玩具。
 */
public class GravityTagData extends SavedData {

    /** 存档里的文件名（{@code data/mirrorgravity_gravity_tags.dat}）。 */
    public static final String FILE_ID = "mirrorgravity_gravity_tags";

    private static final String KEY_ENTRIES = "Tags";
    private static final String KEY_POS = "Pos";
    private static final String KEY_STATE = "State";

    public static final SavedData.Factory<GravityTagData> FACTORY =
        new SavedData.Factory<>(GravityTagData::new, GravityTagData::load);

    /** 坐标（{@link BlockPos#asLong()}）→ 被标记时的方块状态。 */
    private final Map<Long, BlockState> tagged = new LinkedHashMap<>();

    public static GravityTagData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(FACTORY, FILE_ID);
    }

    public int size() {
        return tagged.size();
    }

    public boolean contains(long posKey) {
        return tagged.containsKey(posKey);
    }

    /** @return 该位置被标记时的状态；没标记过返回 {@code null} */
    public BlockState stateAt(long posKey) {
        return tagged.get(posKey);
    }

    public void put(BlockPos pos, BlockState state) {
        tagged.put(pos.asLong(), state);
        setDirty();
    }

    /** @return 原本是否被标记过（调用方常需要据此决定要不要发提示） */
    public boolean remove(long posKey) {
        if (tagged.remove(posKey) != null) {
            setDirty();
            return true;
        }
        return false;
    }

    /** 遍历快照（{@link GravityTagger} 在区块加载时按区块筛选用）。 */
    public Map<Long, BlockState> snapshot() {
        return new LinkedHashMap<>(tagged);
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        ListTag list = new ListTag();
        for (Map.Entry<Long, BlockState> entry : tagged.entrySet()) {
            CompoundTag one = new CompoundTag();
            one.putLong(KEY_POS, entry.getKey());
            one.put(KEY_STATE, NbtUtils.writeBlockState(entry.getValue()));
            list.add(one);
        }
        tag.put(KEY_ENTRIES, list);
        return tag;
    }

    private static GravityTagData load(CompoundTag tag, HolderLookup.Provider provider) {
        GravityTagData data = new GravityTagData();
        ListTag list = tag.getList(KEY_ENTRIES, CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag one = list.getCompound(i);
            /* 方块注册表在数据修复/换版本后可能认不出旧状态 —— 读不出来就跳过这一条，
             * 不要让整份存档读失败（那会让维度直接加载不了）。 */
            try {
                data.tagged.put(one.getLong(KEY_POS),
                    NbtUtils.readBlockState(provider.lookupOrThrow(net.minecraft.core.registries.Registries.BLOCK),
                        one.getCompound(KEY_STATE)));
            } catch (Throwable ignored) {
                // 单条坏数据不影响其它标记
            }
        }
        return data;
    }
}
