/**
 * 把 mirror_config.js 的配方表在沙箱里跑一遍，打印摘要 —— 用来确认
 * 循环生成的 32 条混凝土配方、标签目标、动态产物、容器插入都写对了。
 *
 * 用法: node tools-build/check-recipes.mjs
 */
import { readFileSync } from 'node:fs';

const CONFIG = 'D:/DSHwork/MC镜维度/.minecraft/versions/镜维度/kubejs/startup_scripts/mirror_config.js';
const src = readFileSync(CONFIG, 'utf8').replace('global.MIRROR_CONFIG = MIRROR_CONFIG;', '');
const cfg = new Function(src + '; return MIRROR_CONFIG;')();

const list = cfg.gravityBlockRecipes.list;
console.log('配方总数: ' + list.length);
console.log('启用: ' + cfg.gravityBlockRecipes.enabled);

const kinds = new Set(list.map((r) => r.input));
console.log('涉及方块种类: ' + kinds.size);

/* 重复 id 检查 */
const ids = new Map();
for (const r of list) {
  ids.set(r.id, (ids.get(r.id) ?? 0) + 1);
}
const dup = [...ids.entries()].filter(([, n]) => n > 1);
console.log('重复 id: ' + (dup.length ? JSON.stringify(dup) : '无 ✓'));

/* 混凝土 32 条自检 */
const concrete = list.filter((r) => r.input.includes('_concrete_powder'));
console.log('\n混凝土粉末配方: ' + concrete.length + ' 条（应为 32）');
const COLORS = ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink',
  'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black'];
let concreteOk = true;
for (const c of COLORS) {
  const terracotta = concrete.find((r) => r.id === c + '_concrete_powder_to_terracotta');
  const glazed = concrete.find((r) => r.id === c + '_concrete_powder_to_glazed_terracotta');
  const ok = terracotta && terracotta.output === 'minecraft:' + c + '_terracotta'
    && terracotta.trigger === 'crossing' && terracotta.crossings === 8
    && glazed && glazed.output === 'minecraft:' + c + '_glazed_terracotta'
    && glazed.trigger === 'landing' && glazed.on === 'minecraft:furnace'
    && glazed.crossings === 4;
  if (!ok) {
    concreteOk = false;
    console.log('  ✗ ' + c + ' 没配对: ' + JSON.stringify([terracotta, glazed]));
  }
}
console.log(concreteOk ? '  ✓ 16 色 × 2 条全部对齐（陶瓦 8 次 / 熔炉上带釉陶瓦 4 次）' : '  ✗ 有颜色没配对');

/* 特殊机制抽样 */
console.log('\n特殊机制:');
for (const id of ['minecraft:suspicious_gravel', 'minecraft:suspicious_sand',
  'minecraft:anvil', 'minecraft:red_sand', 'minecraft:scaffolding',
  'minecraft:pointed_dripstone']) {
  for (const r of list.filter((x) => x.input === id)) {
    const bits = [r.input + ' -> ' + r.output, '×' + r.crossings, r.trigger];
    const wants = Array.isArray(r.on) ? r.on : (r.on ? [r.on] : []);
    if (wants.length) bits.push('on ' + wants.join(' + '));
    if (r.output === '@landed') bits.push('[产物=落点]');
    if (r.output === '@mapped') bits.push('[产物按落点查表]');
    if (r.drop) bits.push('[掉落物形式]');
    if (r.insert) {
      bits.push('insert(' + r.insert.items.length + ' 项随机'
        + (r.insert.force ? '，满也触发' : '') + ')');
    }
    console.log('  ' + bits.join('  '));
  }
}

/* 标签与动态产物 */
const onListOf = (r) => (Array.isArray(r.on) ? r.on : (r.on ? [r.on] : []));
const tagRecipes = list.filter((r) => onListOf(r).some((t) => t.startsWith('#')));
const dynRecipes = list.filter((r) => r.output === '@landed');
const mappedRecipes = list.filter((r) => r.output === '@mapped');
const dropRecipes = list.filter((r) => r.drop === true);
const insRecipes = list.filter((r) => r.insert);
console.log('\n用标签判定落点: ' + tagRecipes.length + ' 条');
for (const r of tagRecipes) {
  console.log('  · ' + r.input + ' → ' + r.output + '  ' + onListOf(r).join(' + '));
}
console.log('动态产物 @landed: ' + dynRecipes.length + ' 条');
console.log('查表产物 @mapped: ' + mappedRecipes.length + ' 条');
console.log('掉落物形式: ' + dropRecipes.length + ' 条 → '
  + JSON.stringify(dropRecipes.map((r) => r.input + '→' + r.output)));
console.log('落上容器塞物品: ' + insRecipes.length + ' 条 → '
  + JSON.stringify(insRecipes.map((r) => r.input)));

/* --- 逐条自检：这几条是本次新增的机制，写错了不会有任何报错，只能靠这里 --- */
console.log('\n本次新增机制自检:');
let bad = 0;
const fail = (msg) => { bad++; console.log('  ✗ ' + msg); };

/* 1) 陶罐两条必须 force:true（用户要求"罐子满了也照样加工"） */
for (const id of ['minecraft:suspicious_gravel', 'minecraft:suspicious_sand']) {
  const r = list.find((x) => x.id === id.replace('minecraft:', '') + '_to_coal_block');
  if (!r) fail(id + ' 的陶罐配方不见了');
  else if (!r.insert || r.insert.force !== true) fail(r.id + ' 没有 force:true');
  else if (r.on !== 'minecraft:decorated_pot') fail(r.id + ' 的落点不是陶罐');
}
console.log('  ✓ 陶罐两条都 force:true（满罐也触发）');

/* 2) 铁砧必须覆盖 AnvilCraft 的 6 种粗矿块子标签
 *    （父标签 c:storage_blocks 里只有 raw_zinc_block，实测确认） */
const anvil = list.find((r) => r.id === 'anvil_to_landed_block');
const ANVIL_RAW = ['raw_lead', 'raw_silver', 'raw_tin', 'raw_titanium', 'raw_tungsten', 'raw_uranium'];
if (!anvil) fail('铁砧配方不见了');
else {
  const wants = onListOf(anvil);
  if (!wants.includes('#c:storage_blocks')) fail('铁砧没写 c:storage_blocks');
  for (const raw of ANVIL_RAW) {
    if (!wants.includes('#c:storage_blocks/' + raw)) fail('铁砧少了粗矿块子标签 ' + raw);
  }
  console.log('  ✓ 铁砧覆盖 c:storage_blocks + ' + ANVIL_RAW.length + ' 个粗矿块子标签');
}

/* 3) 脚手架（**只有两条**）
 *    8 次 crossing     → 蜘蛛网
 *    树叶落点 + 4 次   → @mapped + map 表（对应树苗）
 *
 * ⛔ 第三条「4 次 + 落在灵魂沙上 → 地狱疣」2026-09-22 **放弃并整条删除**。
 *    它是脚手架唯一需要"专用机制"的配方：为了它写过 sticky（碰到过就算数）
 *    与"跨重生继承计数"；后者一旦按位置（竖列）共用状态，同一列的多个脚手架
 *    就会互相污染 —— 实测 0→8 只用 1 秒，全变蜘蛛网。
 *    前后十几轮、三套机制仍然时灵时不灵 ⇒ 判定性价比不成立。
 *    完整复盘见 README 14.17 / 14.21 / 14.22。
 *    下面两条反向断言防止它（或它的专用机制）被重新加回来。 */
const scaffold = list.filter((r) => r.input === 'minecraft:scaffolding');
const cob = scaffold.find((r) => r.output === 'minecraft:cobweb');
const sap = scaffold.find((r) => r.id === 'scaffolding_to_sapling');
if (!cob || cob.trigger !== 'crossing' || cob.crossings !== 8) fail('脚手架 → 蜘蛛网 不是 8 次 crossing');
if (!sap || sap.trigger !== 'landing' || sap.crossings !== 4 || !sap.drop
  || sap.output !== '@mapped') {
  fail('脚手架 → 树苗（@mapped）不见了或写错了 —— 对照实验结束后应已恢复');
}
if (sap && onListOf(sap)[0] !== '#minecraft:leaves') fail('脚手架 → 树苗 的落点不是 #minecraft:leaves');
if (scaffold.length !== 2) {
  fail('脚手架应有且仅有 2 条配方（蜘蛛网 / 树苗），实际 ' + scaffold.length + ' 条：'
    + scaffold.map((r) => r.id).join('、'));
}
/* ⛔ 反向断言一：地狱疣那条配方不该再出现（已放弃）。 */
if (scaffold.some((r) => r.output === 'minecraft:nether_wart')) {
  fail('脚手架 → 地狱疣 已于 2026-09-22 放弃并删除，不该再出现（见 README 14.22）');
}
/* ⛔ 反向断言二：不许再出现"按竖列计数"那套配置。
 *   实测：同一竖列的多个脚手架共用计数 + 共用"上一次方向"
 *   → 每 tick 记假翻转 → 0 到 8 只用 1 秒 → 全变蜘蛛网。 */
if (cfg.gravity != null && cfg.gravity.position_count_blocks != null) {
  fail('gravity.position_count_blocks 已删除（会让同列多个脚手架互相污染计数），不该再出现');
}
/* ⛔ 反向断言二之二：count_mode 也不该再出现（0.3 删掉的旧计数方式）。
 *   它的 'crossing' 分支靠"y 是否跨过一条线"推断方向，与模组的迟滞状态机
 *   是两套不同度量，会出现"视觉上来回好几次、计数只涨 1"。
 *   现在只有一种计数方式：读模组给出的实际方向。 */
if (cfg.gravity != null && cfg.gravity.count_mode != null) {
  fail('gravity.count_mode 已删除（旧 crossing 计数会与模组迟滞打架），不该再出现');
}
/* ⛔ 反向断言二之三：inverted 是死配置（全项目无人读取），0.3 已删。 */
if (cfg.gravity != null && cfg.gravity.inverted != null) {
  fail('gravity.inverted 是死配置（属性降级方案没实现反向那半边），不该再出现');
}
/* ⛔ 反向断言三：不许再出现 sticky —— 它只为上面那条配方存在，已随它删除。
 *   （留着它会让 landing 的语义变成"蹭过一次就算"，且没有配方需要这种语义。） */
if (scaffold.some((r) => r.sticky === true)) {
  fail('sticky 机制已随「脚手架 → 地狱疣」一起删除，不该有配方再用它');
}
/* 泥巴那条按用户要求已删除 —— 留着断言防止它哪天又被加回来 */
if (scaffold.some((r) => r.output === 'minecraft:mangrove_propagule')) {
  fail('脚手架 → 红树幼苗（泥巴）已经按要求删除，不该再出现');
}
/* 脚手架/滴水石锥有"原版才有的前置条件"，必须带 hint 提示玩家 */
for (const r of [...scaffold, ...list.filter((x) => x.input === 'minecraft:pointed_dripstone')]) {
  if (r.hint == null || String(r.hint).length < 6) fail(r.id + ' 缺少 hint（脚手架/滴水石锥的掉落前提必须能查到）');
}
const LEAVES = ['oak', 'spruce', 'birch', 'jungle', 'acacia', 'dark_oak',
  'mangrove', 'cherry', 'azalea', 'flowering_azalea'];
if (sap && sap.output === '@mapped') {
  const map = sap.map ?? {};
  for (const leaf of LEAVES) {
    if (!map['minecraft:' + leaf + '_leaves']) fail('树叶对照表缺 ' + leaf);
  }
  const extra = Object.keys(map).filter((k) => !LEAVES.some((l) => k === 'minecraft:' + l + '_leaves'));
  if (extra.length) console.log('  · 对照表另有 ' + extra.length + ' 项（模组树叶）：' + extra.join(', '));
  console.log('  ✓ 树叶对照表覆盖全部 ' + LEAVES.length + ' 种原版树叶');
}
console.log('  ✓ 脚手架 ' + scaffold.length + ' 条（地狱疣那条已放弃，见 README 14.22）：'
  + '8 次→蜘蛛网 / 4 次+树叶→对应树苗（@mapped，掉落物）');

/* 3b) 接触判定参数（本该在 gravity 段里） */
const look = cfg.gravity?.landing_lookahead;
if (look !== 0 && look !== 1 && look !== 2) fail('gravity.landing_lookahead 应为 0/1/2，实际 ' + JSON.stringify(look));
else console.log('  ✓ gravity.landing_lookahead = ' + look + '（高速下落时按运动方向预判 1 格）');

/* 4) 滴水石锥 16 次 */
const drip = list.find((r) => r.input === 'minecraft:pointed_dripstone');
if (!drip || drip.output !== 'minecraft:dripstone_block' || drip.crossings !== 16
  || drip.trigger !== 'crossing') fail('滴水石锥配方写错了');

/* 5) 同一输入 + 同一次数的多条 landing 配方是允许的（引擎会全试一遍），
 *    但同一次数的多条 crossing 只有第一条生效 —— 那才是配置冲突。 */
const clash = new Map();
for (const r of list.filter((x) => x.trigger === 'crossing')) {
  const k = r.input + '@' + r.crossings;
  clash.set(k, (clash.get(k) ?? 0) + 1);
}
const conflicts = [...clash.entries()].filter(([, n]) => n > 1);
if (conflicts.length) fail('crossing 冲突（同输入同次数多条）: ' + JSON.stringify(conflicts));
else console.log('  ✓ 没有 crossing 冲突');

if (bad === 0) console.log('  ✓ 全部通过');
else console.log('  ✗ ' + bad + ' 项不通过');

const lootG = list.find((r) => r.insert && r.insert.items.includes('minecraft:music_disc_relic'));
const lootS = list.find((r) => r.insert && r.insert.items.includes('minecraft:sniffer_egg'));
console.log('  可疑沙砾战利品池: ' + (lootG ? lootG.insert.items.length + ' 项 ✓' : '✗ 缺失'));
console.log('  可疑沙子战利品池: ' + (lootS ? lootS.insert.items.length + ' 项 ✓' : '✗ 缺失'));

/* ------------------------------------------------------------------ */
/* 工作台配方（无序合成）—— 与重力配方同一份配置，一起自检               */
/* ------------------------------------------------------------------ */
/* 这些配方由 mirror_n9_crafting.js 用 ServerEvents.recipes 注册进
 * 服务端 RecipeManager（原版配方），JEI 的工作台分类自动可见。
 * 这里只做**配置层**的自检：产物/原料写没写对、ID 有没有重复、
 * 原料数量是否超上限。注册是否真的成功，由游戏内 /mirror crafting 回读。 */

const craft = cfg.craftingRecipes ?? {};
const craftList = Array.isArray(craft) ? craft : (craft.list ?? []);
console.log('\n工作台配方（无序合成）: ' + craftList.length + ' 条，启用: ' + craft.enabled);

const EXPECTED_CRAFT = [
  { output: 'minecraft:suspicious_sand', ingredients: ['minecraft:sand', 'minecraft:glow_lichen'] },
  { output: 'minecraft:suspicious_gravel', ingredients: ['minecraft:gravel', 'minecraft:glow_lichen'] },
];
let craftBad = 0;
const craftFail = (m) => { craftBad++; console.log('  ✗ ' + m); };

for (const want of EXPECTED_CRAFT) {
  const r = craftList.find((x) => x.output === want.output);
  if (!r) { craftFail('缺少配方 ' + want.output); continue; }
  const got = [...(r.ingredients ?? [])].sort().join(',');
  const exp = [...want.ingredients].sort().join(',');
  if (got !== exp) craftFail(want.output + ' 的原料是 [' + got + ']，期望 [' + exp + ']');
  if (r.count != null && r.count !== 1) craftFail(want.output + ' 的 count 应为 1');
  if (r.id == null || !String(r.id).includes(':')) craftFail(want.output + ' 的 id 没写全（应形如 mirror:xxx）');
}
/* id 重复 = 后者覆盖前者，表现是"某条配方凭空消失" */
const craftIds = new Map();
for (const r of craftList) craftIds.set(r.id, (craftIds.get(r.id) ?? 0) + 1);
const craftDup = [...craftIds.entries()].filter(([, n]) => n > 1);
if (craftDup.length) craftFail('id 重复: ' + JSON.stringify(craftDup));
/* 原料允许两种写法，两种都要查上限：
 *   'minecraft:stick'                        —— 1 个
 *   { item: 'mirrorgravity:wave', count: 4 } —— 4 个
 * ⚠️ 真正占格子的是**展开后的条目数**（原版 shapeless 一格一个物品），
 *    所以不能只看"原料种数"。 */
for (const r of craftList) {
  const raw = r.ingredients ?? [];
  if (raw.length < 1 || raw.length > 9) {
    craftFail(r.output + ' 的原料种数是 ' + raw.length + '，应在 1~9');
  }
  let expanded = 0;
  for (const one of raw) {
    if (one != null && typeof one === 'object' && !Array.isArray(one)) {
      if (typeof one.item !== 'string' || !one.item.includes(':')) {
        craftFail(r.output + ' 的原料对象缺少合法 item: ' + JSON.stringify(one));
        continue;
      }
      const c = one.count ?? 1;
      if (!Number.isInteger(c) || c < 1 || c > 9) {
        craftFail(r.output + ' 的原料 ' + one.item + ' 数量是 ' + c + '，应在 1~9');
        continue;
      }
      expanded += c;
    } else if (typeof one === 'string' && one.includes(':')) {
      expanded += 1;
    } else {
      craftFail(r.output + ' 的原料写法不认识: ' + JSON.stringify(one));
    }
  }
  if (expanded > 9) craftFail(r.output + ' 展开后需要 ' + expanded + ' 个物品，超过工作台 9 格');
}

/* 波粒链：波粒块 → 波 → 粒 → 波粒子，三正三逆（用户指定的合成链）。
 * 这条链的形状是**契约**：数量写错照样能合、看不出问题，所以在这里钉死。
 * 表项：[配方 id, 产物, 产物数量, 原料, 原料数量] */
const CHAIN = [
  ['mirror:wave_from_wave_particle_block', 'mirrorgravity:wave', 4, 'mirrorgravity:wave_particle_block', 1],
  ['mirror:wave_particle_block_from_wave', 'mirrorgravity:wave_particle_block', 1, 'mirrorgravity:wave', 4],
  ['mirror:particle_from_wave', 'mirrorgravity:particle', 4, 'mirrorgravity:wave', 1],
  ['mirror:wave_from_particle', 'mirrorgravity:wave', 1, 'mirrorgravity:particle', 4],
  ['mirror:wave_particle_from_particle', 'mirrorgravity:wave_particle', 4, 'mirrorgravity:particle', 1],
  ['mirror:particle_from_wave_particle', 'mirrorgravity:particle', 1, 'mirrorgravity:wave_particle', 4],
];
let chainOk = 0;
for (const [id, out, outCount, inItem, inCount] of CHAIN) {
  const r = craftList.find((x) => x.id === id);
  if (!r) { craftFail('缺少波粒链配方 ' + id); continue; }
  if (r.output !== out) { craftFail(id + ' 的产物应为 ' + out + '，实际 ' + r.output); continue; }
  if ((r.count ?? 1) !== outCount) {
    craftFail(id + ' 的产物数量应为 ' + outCount + '，实际 ' + (r.count ?? 1)); continue;
  }
  const raw = r.ingredients ?? [];
  if (raw.length !== 1) { craftFail(id + ' 应只有 1 种原料，实际 ' + raw.length + ' 种'); continue; }
  const one = raw[0];
  const item = (one != null && typeof one === 'object') ? one.item : one;
  const cnt = (one != null && typeof one === 'object') ? (one.count ?? 1) : 1;
  if (item !== inItem || cnt !== inCount) {
    craftFail(id + ' 的原料应为 ' + inCount + '× ' + inItem + '，实际 ' + cnt + '× ' + item);
    continue;
  }
  chainOk++;
}
/* 可逆性（用户要求"可以逆向合成"）：每一对正逆配方的换算比例必须一致，
 * 否则来回合一次就凭空多/少了东西。判据 out₁×out₂ == in₁×in₂。 */
for (const [a, b] of [[0, 1], [2, 3], [4, 5]]) {
  const f = craftList.find((x) => x.id === CHAIN[a][0]);
  const bwd = craftList.find((x) => x.id === CHAIN[b][0]);
  if (!f || !bwd) continue;
  const lhs = (f.count ?? 1) * (bwd.count ?? 1);
  const rhs = CHAIN[a][4] * CHAIN[b][4];
  if (lhs !== rhs) {
    craftFail(`波粒链 ${CHAIN[a][0]} 与 ${CHAIN[b][0]} 不成可逆比例：产物 ${lhs} ≠ 原料 ${rhs}`);
  }
}

if (craftBad === 0) {
  console.log('  ✓ 沙子 + 发光地衣 → 可疑的沙子');
  console.log('  ✓ 沙砾 + 发光地衣 → 可疑的沙砾');
  console.log('  ✓ 无重复 id、原料数量（含展开后）都在 1~9');
  console.log('  ✓ 波粒链 ' + chainOk + '/6 条正确：波粒块 →4 波 →4 粒 →4 波粒子，且三对正逆比例一致');
} else {
  console.log('  ✗ ' + craftBad + ' 项不通过');
}

/* ------------------------------------------------------------------ */
/* 定点配方（用户点名要的，2026-09-25）                                   */
/* ------------------------------------------------------------------ */
/* 6 条 8 次穿越 + 3 条落点触发 + 1 条 @random（骨块→山羊角）。
 * 这些是逐条点名要的，所以在这里逐条核对 —— 次数/落点写错在游戏里
 * 只表现为"那个方块不变"，没有任何报错，靠肉眼极难发现。 */
const SPECIAL = [
  ['shroomlight_to_ochre_froglight', 'minecraft:shroomlight', 'minecraft:ochre_froglight', 8, 'crossing', null],
  ['sea_lantern_to_verdant_froglight', 'minecraft:sea_lantern', 'minecraft:verdant_froglight', 8, 'crossing', null],
  ['amethyst_block_to_pearlescent_froglight', 'minecraft:amethyst_block', 'minecraft:pearlescent_froglight', 8, 'crossing', null],
  ['sculk_to_sculk_catalyst', 'minecraft:sculk', 'minecraft:sculk_catalyst', 8, 'crossing', null],
  ['obsidian_to_crying_obsidian', 'minecraft:obsidian', 'minecraft:crying_obsidian', 8, 'crossing', null],
  ['gold_block_to_bell', 'minecraft:gold_block', 'minecraft:bell', 8, 'crossing', null],
  ['dried_kelp_block_to_prismarine', 'minecraft:dried_kelp_block', 'minecraft:prismarine', 8, 'crossing', null],
  ['prismarine_to_sea_lantern', 'minecraft:prismarine', 'minecraft:sea_lantern', 8, 'crossing', null],
  ['sculk_to_sculk_sensor', 'minecraft:sculk', 'minecraft:sculk_sensor', 4, 'landing', 'minecraft:sculk_catalyst'],
  ['sculk_to_sculk_shrieker', 'minecraft:sculk', 'minecraft:sculk_shrieker', 4, 'landing', 'minecraft:crying_obsidian'],
  ['deepslate_to_reinforced_deepslate', 'minecraft:deepslate', 'minecraft:reinforced_deepslate', 4, 'landing', 'minecraft:obsidian'],
];
let specialBad = 0;
const specialFail = (m) => { specialBad++; console.log('  ✗ ' + m); };
console.log('\n定点配方（用户指定）: ' + SPECIAL.length + ' 条 + 骨块→山羊角');
for (const [id, input, output, crossings, trigger, on] of SPECIAL) {
  const r = list.find((x) => x.id === id);
  if (!r) { specialFail('缺少配方 ' + id); continue; }
  if (r.input !== input) specialFail(id + ' 的输入应为 ' + input);
  if (r.output !== output) specialFail(id + ' 的产物应为 ' + output);
  if (r.crossings !== crossings) specialFail(id + ' 的次数应为 ' + crossings);
  if ((r.trigger ?? 'crossing') !== trigger) specialFail(id + ' 的触发应为 ' + trigger);
  if (on != null && r.on !== on) specialFail(id + ' 的落点应为 ' + on);
}
/* 骨块 → 山羊角：@random + pool 8 项 + 必须 drop；触发是**8 次穿越**（不需要落点方块） */
const horn = list.find((x) => x.id === 'bone_block_to_goat_horn');
if (!horn) {
  specialFail('缺少 bone_block_to_goat_horn');
} else {
  if (horn.input !== 'minecraft:bone_block') specialFail('骨块配方输入不对');
  if (horn.output !== '@random') specialFail('骨块配方产物应为 @random');
  if (horn.crossings !== 8) specialFail('骨块配方次数应为 8');
  if ((horn.trigger ?? 'crossing') !== 'crossing') {
    specialFail('骨块配方应为 8 次穿越触发（用户已改为不需要切石机）');
  }
  if (horn.on != null) specialFail('骨块配方不该再写落点方块（用户已去掉切石机）');
  if (horn.drop !== true) specialFail('骨块配方必须 drop:true（山羊角是物品，放不成方块）');
  /* pool 里的 count 必须是整数：Rhino 会把整数序列化成 1.0，
   * 而原版 ItemStack.CODEC 的 count 是 int ⇒ 整条掉落静默失败。
   * （n3 现在手工拼整数 JSON，模组侧也会归一化；这里再从配置层拦一道。） */
  if (Array.isArray(horn.pool)) {
    horn.pool.forEach((one, i) => {
      if (one && typeof one === 'object' && one.count != null && !Number.isInteger(one.count)) {
        specialFail(`骨块配方 pool 第 ${i + 1} 项的 count 不是整数：${one.count}`);
      }
    });
  }
  if (!Array.isArray(horn.pool) || horn.pool.length !== 8) {
    specialFail('骨块配方 pool 应为 8 项，实际 ' + (Array.isArray(horn.pool) ? horn.pool.length : '无'));
  } else {
    const insts = horn.pool.map((o) => String((o && o.components) ? o.components['minecraft:instrument'] : ''));
    const need = ['ponder', 'sing', 'seek', 'feel', 'admire', 'call', 'yearn', 'dream']
      .map((n) => 'minecraft:' + n + '_goat_horn');
    const missing = need.filter((n) => !insts.includes(n));
    if (missing.length) specialFail('骨块配方缺少乐器: ' + missing.join(', '));
  }
}
if (specialBad === 0) {
  console.log('  ✓ ' + SPECIAL.length + ' 条与用户指定一致；骨块→山羊角 pool 8 种乐器齐全');
}

/* ⚠️ 必须让"发现问题"变成非零退出码。
 *    之前这里没有 exit：打出 ✗ 也返回 0，调用方只看退出码就会把问题放过去。 */
const totalBad = bad + craftBad + specialBad;
if (totalBad > 0) {
  console.log(`\n共 ${totalBad} 项不通过（重力配方 ${bad} + 工作台配方 ${craftBad} + 定点配方 ${specialBad}）`);
  process.exit(1);
}