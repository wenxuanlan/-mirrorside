package work.dsh.mirror.gravity;

import work.dsh.mirror.gravity.internal.Failures;

import java.util.Locale;

/**
 * 波粒子 · 运行时参数（唯一真相在 {@code mirror_config.js} 的 {@code waveParticle} 段）。
 *
 * <p>与 {@link SpindleSettings} 同一套路：默认值只用于"脚本还没推过来"的极端情况，
 * 启动时由 n0 通过 {@link MirrorGravityApi#setWaveParticleParams} 整体推送，
 * 两边的一致性由 {@code tools-build/check-param-parity.mjs} 强制对拍。
 */
public final class WaveParticleSettings {

    private WaveParticleSettings() {
    }

    private static volatile boolean enabled = true;
    /** 每次成功使用是否消耗 1 个（创造模式一律不消耗，与原版道具一致）。 */
    private static volatile boolean consume = true;
    /** 排队多久之后再判定是否下坠。原版 {@code FallingBlock#getDelayAfterPlace} 是 2。 */
    private static volatile int fallDelayTicks = 2;
    /**
     * 是否允许把带方块实体的方块（箱子/熔炉/刷怪笼/试炼刷怪笼……）也变成重力方块。
     *
     * <p>默认**开**（用户要求）。内容物靠下落实体的 {@code blockData} 保住：
     * 落地时原版会把它写回新方块实体；若中途变成掉落物，则由
     * {@code FallingBlockDropMixin} 给掉落物补 {@code minecraft:block_entity_data}
     * 组件，摆回去内容物仍在。
     */
    private static volatile boolean allowBlockEntities = true;
    /**
     * 是否允许改造"挖不动的方块"（基岩、传送门、命令方块……）。
     *
     * <p>判据是 {@code getDestroySpeed < 0}（原版 {@code getDestroyProgress} 对 -1 直接返回 0）。
     * 默认放开 —— 用户明确要求"让它也能对挖不动的方块生效"。
     * 关掉时这类方块会被拒绝，理由代码 {@code unbreakable}。
     */
    private static volatile boolean allowUnbreakable = true;
    /** 每个维度最多同时存在多少个标记（防止误用/刷屏把存档撑大）。 */
    private static volatile int maxTagsPerLevel = 8192;
    /** 失败与成功是否给玩家行动栏提示。 */
    private static volatile boolean notify = true;

    private static volatile boolean pushed = false;

    public static boolean enabled() {
        return enabled;
    }

    public static boolean consume() {
        return consume;
    }

    public static int fallDelayTicks() {
        return fallDelayTicks;
    }

    public static boolean allowBlockEntities() {
        return allowBlockEntities;
    }

    public static boolean allowUnbreakable() {
        return allowUnbreakable;
    }

    public static int maxTagsPerLevel() {
        return maxTagsPerLevel;
    }

    /**
     * 是否给行动栏提示。
     *
     * <p>⚠️ 方法名不能叫 {@code notify()} —— 那会与 {@link Object#notify()} 冲突
     * （编译期直接报"无法覆盖 Object 中的 notify()"，因为它是 final）。
     */
    public static boolean notifyEnabled() {
        return notify;
    }

    public static boolean pushed() {
        return pushed;
    }

    /** CSV 顺序即 {@link MirrorGravityApi#setWaveParticleParams} 的契约。 */
    public static String describe() {
        return String.format(Locale.ROOT, "%d,%d,%d,%d,%d,%d,%d",
            enabled ? 1 : 0, consume ? 1 : 0, fallDelayTicks,
            allowBlockEntities ? 1 : 0, allowUnbreakable ? 1 : 0, maxTagsPerLevel, notify ? 1 : 0);
    }

    /**
     * 接收脚本推送。任何一项不合法就整体拒绝并保留上一份 —— 半套参数会让
     * "消耗了但不生效"这类问题变得极难查。
     *
     * @return 失败原因，成功返回 {@code null}
     */
    static String push(String csv) {
        if (csv == null || csv.isBlank()) {
            return "参数为空";
        }
        String[] parts = csv.split(",");
        if (parts.length != 7) {
            return "需要 7 个数（启用/消耗/延迟/允许方块实体/允许挖不动的/上限/提示），实际 " + parts.length;
        }
        int[] v = new int[7];
        for (int i = 0; i < 7; i++) {
            try {
                v[i] = Integer.parseInt(parts[i].trim());
            } catch (NumberFormatException e) {
                return "第 " + (i + 1) + " 项不是整数: " + parts[i];
            }
        }
        if (v[2] < 0 || v[2] > 200) {
            return "下坠延迟必须在 0~200 刻，收到 " + v[2];
        }
        if (v[5] < 1 || v[5] > 1_000_000) {
            return "标记上限必须在 1~1000000，收到 " + v[5];
        }
        enabled = v[0] != 0;
        consume = v[1] != 0;
        fallDelayTicks = v[2];
        allowBlockEntities = v[3] != 0;
        allowUnbreakable = v[4] != 0;
        maxTagsPerLevel = v[5];
        notify = v[6] != 0;
        pushed = true;
        return null;
    }

    static void noteFailure(String what, String detail) {
        Failures.note("wave_particle", new IllegalArgumentException(what + ": " + detail));
    }
}
