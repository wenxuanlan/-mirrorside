#!/usr/bin/env node
/**
 * 镜维度 · 脚本 API 静态自检
 * =====================================================================
 * 为什么需要它：
 *   KubeJS 脚本的报错发生在运行时，而且相当一部分是「静默失效」——
 *   写错一个符号名，事件回调根本不会被调用，游戏里毫无提示。
 *   最典型的一类错误是把原版 Java 类当成 KubeJS 全局：
 *     SoundEvents、Level、ResourceLocation、Blocks、Items ……
 *   这些**都不是**全局绑定，必须 Java.loadClass()，直接写会抛
 *   ReferenceError 让整个脚本文件失效。
 *
 * 做法：
 *   1. 用一张从 KubeJS jar 里提取出来的权威全局表（GLOBALS）做白名单
 *   2. 扫 kubejs/{startup,server,client}_scripts/**.js 的根符号
 *   3. 事件组（ServerEvents / PlayerEvents / PortalEvents …）单独识别
 *   4. 报告任何「既不是全局、也不是事件组、也不是本文件局部」的根符号
 *
 * 这张表是核对 `BuiltinKubeJSPlugin.class` 的常量池得出的，对应
 * KubeJS 2101.7.2-build.377。换 KubeJS 版本后请重跑 --dump-globals 更新。
 *
 * 用法:
 *   node tools/check-script-api.mjs
 * =====================================================================
 */

import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { inflateRawSync } from 'node:zlib';

const HERE = dirname(fileURLToPath(import.meta.url));
let INSTANCE = resolve(HERE, '..');
const iFlag = process.argv.indexOf('--instance');
if (iFlag !== -1 && process.argv[iFlag + 1]) INSTANCE = resolve(process.argv[iFlag + 1]);

const MODS = join(INSTANCE, 'mods');
const KUBEJS_JAR = readdirSync(MODS).find((f) => /^kubejs.*\.jar$/i.test(f));
if (!KUBEJS_JAR) { console.error('✗ mods/ 里找不到 kubejs 的 jar'); process.exit(1); }

/* ------------------------------------------------------------------ */
/* 权威全局表（来自 BuiltinKubeJSPlugin.class 的常量池）                 */
/* ------------------------------------------------------------------ */

const GLOBALS = new Set([
  'AABB', 'AnimalArmor', 'Axe', 'Block', 'BlockPos', 'BlockProperties',
  'BlockStatePredicate', 'Blocks', 'Boots', 'Chestplate', 'Color', 'Component',
  'DamageSource', 'DataMap', 'Direction', 'Duration', 'EntitySelector',
  'Fluid', 'FluidAmounts', 'Helmet', 'Hoe', 'Ingredient', 'Item', 'ItemModifications',
  'Items', 'Java', 'JavaMath', 'JsonIO', 'JsonUtils', 'KMath', 'Keys',
  'Matrix3f', 'Matrix4f', 'MobEffectUtil', 'NBT', 'NBTIO', 'NativeEvents',
  'NoiseParameters', 'Notification', 'ParticleOptions', 'Pickaxe', 'Platform',
  'Quaternionf', 'Registry', 'RotationAxis', 'SY', 'Shovel', 'SizedIngredient',
  'SoundType', 'Stats', 'StringUtils', 'Text', 'TextIcons', 'Type', 'UUID',
  'Utils', 'Vec3d', 'Vec3f', 'Vec3i', 'Vec4f',
]);

/** 本仓脚本自己定义的顶层名字，不算 KubeJS 全局 */
const OWN_LOCALS = new Set(['MirrorDimension', 'MirrorPortal', 'MirrorServer']);

/** 由 KubeJS 之外的原版/模组类名：必须以 Java.loadClass 出现 */
const MUST_LOADCLASS = [
  'SoundEvents', 'ResourceLocation', 'Level', 'ServerLevel', 'ItemStack',
  'BlockState', 'EntityType', 'MobCategory', 'BuiltInRegistries',
  'Paths', 'Files', 'Files2',
];

/** 语言内建，不算问题 */
const LANGUAGE_BUILTINS = new Set([
  'String', 'Number', 'Boolean', 'Object', 'Array', 'Math', 'JSON', 'Date',
  'RegExp', 'Error', 'TypeError', 'Promise', 'Map', 'Set', 'Symbol', 'BigInt',
  'Infinity', 'NaN', 'Undefined', 'Function', 'Infinity',
]);

/* ------------------------------------------------------------------ */
/* zip 读取                                                           */
/* ------------------------------------------------------------------ */

function readZip(p) {
  const buf = readFileSync(p);
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0; i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd === -1) throw new Error('不是 zip');
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const map = new Map();
  for (let n = 0; n < count; n++) {
    const method = buf.readUInt16LE(off + 10), compSize = buf.readUInt32LE(off + 20);
    const nameLen = buf.readUInt16LE(off + 28), extraLen = buf.readUInt16LE(off + 30), cmtLen = buf.readUInt16LE(off + 32);
    const localOff = buf.readUInt32LE(off + 42);
    map.set(buf.toString('utf8', off + 46, off + 46 + nameLen), { method, compSize, localOff });
    off += 46 + nameLen + extraLen + cmtLen;
  }
  return {
    names: [...map.keys()],
    read(n) {
      const e = map.get(n); if (!e) return null;
      const a = buf.readUInt16LE(e.localOff + 26), b = buf.readUInt16LE(e.localOff + 28);
      const s = e.localOff + 30 + a + b;
      const raw = buf.subarray(s, s + e.compSize);
      return e.method === 0 ? raw : inflateRawSync(raw);
    },
  };
}

const zip = readZip(join(MODS, KUBEJS_JAR));
console.log('KubeJS jar : ' + KUBEJS_JAR);

/* ------------------------------------------------------------------ */
/* 事件组：从 KubeJS 与 addon jar 里的 *Events 类名反推                  */
/* ------------------------------------------------------------------ */

const eventGroups = new Set();
for (const n of zip.names) {
  const m = n.match(/\/([A-Za-z]+Events)\.class$/);
  if (m) eventGroups.add(m[1]);
}
for (const jarName of readdirSync(MODS).filter((f) => /\.jar$/i.test(f))) {
  if (jarName === KUBEJS_JAR) continue;
  try {
    const z2 = readZip(join(MODS, jarName));
    for (const n of z2.names) {
      const m = n.match(/\/([A-Za-z]+Events)\.class$/);
      if (m) eventGroups.add(m[1]);
    }
  } catch { /* 某些 jar 读不了，跳过 */ }
}

/* ------------------------------------------------------------------ */
/* 扫描脚本                                                           */
/* ------------------------------------------------------------------ */

const files = [];
for (const d of ['startup_scripts', 'server_scripts', 'client_scripts']) {
  const dir = join(INSTANCE, 'kubejs', d);
  if (!existsSync(dir)) continue;
  for (const f of readdirSync(dir)) if (f.endsWith('.js')) files.push(join(dir, f));
}
if (!files.length) { console.log('（没有找到脚本文件）'); process.exit(0); }

const used = new Map();       // 名字 -> Set(文件)
const declared = new Set();   // 脚本自己 const/let/var/function 声明的名字
const loadClassed = new Set(); // 通过 Java.loadClass('...') 拿到的简单类名

for (const f of files) {
  const src = readFileSync(f, 'utf8')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    // 行尾注释也要去掉：曾经因为一句
    //     var b = obj.getBlock();   // 传进来是 BlockState 时取 Block
    // 里的 BlockState 被当成"用了未加载的类"而误报。
    // 前面排除 : ' " \ 三种字符，是为了不误伤 https:// 与字符串里的 //。
    .replace(/(^|[^:'"\\])\/\/[^\n]*/g, '$1')
    // 去掉字符串字面量：否则 console.info("... Loaded ... World ...") 里的
    // 普通单词会被当成根符号，产生大量误报。
    .replace(/'(?:[^'\\]|\\.)*'/g, "''")
    .replace(/"(?:[^"\\]|\\.)*"/g, '""')
    .replace(/`(?:[^`\\]|\\.)*`/g, '``');
  const short = f.replace(INSTANCE, '').replace(/\\/g, '/');

  // 跳过 KubeJS 首次运行自动生成的示例脚本。它不是我们的代码。
  if (/client_scripts\/main\.js$/.test(short)) {
    console.log(`  （跳过 KubeJS 示例脚本 ${short}）`);
    continue;
  }

  // 1) 收集声明
  for (const m of src.matchAll(/\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)/g)) declared.add(m[1]);
  for (const m of src.matchAll(/\bfunction\s+([A-Za-z_$][\w$]*)/g)) declared.add(m[1]);

  // 2) 收集 Java.loadClass('a.b.C') 的简单类名
  for (const m of src.matchAll(/Java\.loadClass\(\s*['"]([\w.$]+)['"]\s*\)/g)) {
    const simple = m[1].split('.').pop();
    loadClassed.add(simple);
  }

  // 3) 收集用到的根符号。
  //    只收「不作为成员访问」的那些 —— 否则 X.Y 里的 Y 也会被当成根符号，
  //    产生大量误报（例如 Registries.DIMENSION、Attributes.GRAVITY、
  //    GameType.SPECTATOR 里的 DIMENSION / GRAVITY / SPECTATOR）。
  for (const m of src.matchAll(/(\.?)\b([A-Z][A-Za-z0-9]{2,})\b/g)) {
    const isMember = m[1] === '.';
    const name = m[2];
    if (isMember) continue;
    if (OWN_LOCALS.has(name)) continue;
    if (!used.has(name)) used.set(name, new Set());
    used.get(name).add(short);
  }
}

/* ------------------------------------------------------------------ */
/* 判定                                                               */
/* ------------------------------------------------------------------ */

console.log('\n脚本根符号判定');
console.log('='.repeat(78));

const bad = [];
for (const [name, where] of [...used].sort((a, b) => a[0].localeCompare(b[0]))) {
  const w = [...where].join(', ');

  if (GLOBALS.has(name)) {
    console.log(`  ✓ ${name.padEnd(18)} KubeJS 全局绑定          ${w}`);
  } else if (eventGroups.has(name)) {
    console.log(`  ✓ ${name.padEnd(18)} 事件组                  ${w}`);
  } else if (declared.has(name)) {
    // 脚本自己声明的局部/顶层名字，合法
  } else if (loadClassed.has(name)) {
    console.log(`  ✓ ${name.padEnd(18)} Java.loadClass 取得      ${w}`);
  } else if (LANGUAGE_BUILTINS.has(name)) {
    // JS 语言内建
  } else if (MUST_LOADCLASS.includes(name)) {
    bad.push(`${name} 不是 KubeJS 全局绑定，必须写成 Java.loadClass('...')   [${w}]`);
    console.log(`  ✗ ${name.padEnd(18)} 不是全局！需 loadClass      ${w}`);
  } else {
    bad.push(`${name} 既不是全局/事件组，也没有声明或 loadClass（疑似拼写错误）   [${w}]`);
    console.log(`  ? ${name.padEnd(18)} 未定义                  ${w}`);
  }
}

/* ------------------------------------------------------------------ */
/* 结论                                                               */
/* ------------------------------------------------------------------ */

console.log('\n' + '='.repeat(78));
if (bad.length) {
  console.log('发现 ' + bad.length + ' 个问题：\n');
  for (const b of bad) console.log('  ✗ ' + b);
  console.log('');
  process.exit(1);
}
console.log('✓ 所有根符号都在 KubeJS 全局表或事件组里，没有裸用原版类名。\n');
