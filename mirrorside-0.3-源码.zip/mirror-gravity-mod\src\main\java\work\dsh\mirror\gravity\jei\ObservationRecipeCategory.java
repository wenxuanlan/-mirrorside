package work.dsh.mirror.gravity.jei;

import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import work.dsh.mirror.gravity.MirrorBlocks;
import work.dsh.mirror.gravity.MirrorGravity;
import work.dsh.mirror.gravity.internal.Failures;

import java.util.List;

/**
 * JEI 分类：波粒观测。
 *
 * <h2>版面</h2>
 * <pre>
 *   ┌──────────────────────────────────────────┐
 *   │ [波粒块] [靶心方块] → [产物]                │
 *   │ 下方 [方块]                                │
 *   │ 说明（掉落物 / 生成实体 / 随机换色 …）      │
 *   └──────────────────────────────────────────┘
 * </pre>
 *
 * <h2>为什么左侧的工作方块是波粒块</h2>
 * JEI 版面的第一格惯例是**工作方块**（合成台、熔炉…）。波粒观测的工作方块
 * 就是四个波粒块围出来的那座结构，所以这一格画波粒块 —— 用户明确要求
 * "左侧的工作方块就写成波粒块"。这也是它与「重力方块加工」（左侧画镜面）
 * 分成两个分类的原因：两者的工作方块不同，混在一个分类里左侧只能画一个。
 *
 * <h2>下方那一格</h2>
 * 接触类配方（红沙 + 正下方荧石 → 荧石）必须把"下方要放什么"画出来，
 * 否则玩家会以为随便放都行。写标签时（例如"任意矿物块"）槽里会循环显示
 * 标签内所有方块，于是每一个成员都能被 JEI 搜到 —— 与重力分类里的做法一致。
 */
public class ObservationRecipeCategory implements IRecipeCategory<ObservationRecipe> {

    public static final RecipeType<ObservationRecipe> TYPE =
        RecipeType.create(MirrorGravity.MOD_ID, "wave_particle_observation", ObservationRecipe.class);

    private static final int WIDTH = 160;
    private static final int HEIGHT = 64;

    private static final int ROW1_Y = 3;
    /** 工作方块（波粒块）。 */
    private static final int WORKBENCH_X = 3;
    private static final int INPUT_X = 30;
    private static final int OUTPUT_X = 110;

    /** 下方条件那一行。 */
    private static final int BELOW_LABEL_Y = 25;
    private static final int BELOW_SLOT_X = 30;
    private static final int BELOW_SLOT_Y = 22;

    private static final int NOTE_Y = 48;

    private final IDrawable background;
    private final IDrawable icon;

    public ObservationRecipeCategory(IGuiHelper guiHelper) {
        this.background = guiHelper.createBlankDrawable(WIDTH, HEIGHT);
        this.icon = guiHelper.createDrawableItemLike(iconItem());
    }

    /** 分类图标 = 波粒块；注册表还没就绪时退回玻璃，绝不让 JEI 崩。 */
    private static ItemLike iconItem() {
        try {
            ItemLike item = MirrorBlocks.WAVE_PARTICLE_BLOCK_ITEM.get();
            if (item != null) {
                return item;
            }
        } catch (Throwable t) {
            Failures.note("ObservationRecipeCategory.iconItem", t);
        }
        return Items.GLASS;
    }

    @Override
    public RecipeType<ObservationRecipe> getRecipeType() {
        return TYPE;
    }

    @Override
    public Component getTitle() {
        return Component.literal("波粒观测");
    }

    @Override
    public IDrawable getBackground() {
        return background;
    }

    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, ObservationRecipe recipe, IFocusGroup focuses) {
        // 工作方块
        builder.addInputSlot(WORKBENCH_X, ROW1_Y)
            .setStandardSlotBackground()
            .addItemStack(new ItemStack(iconItem()));

        addSlotIfAny(builder, INPUT_X, ROW1_Y,
            GravityRecipeItems.resolveAll(recipe.inputs(), 1), false);
        addSlotIfAny(builder, OUTPUT_X, ROW1_Y,
            GravityRecipeItems.resolveAll(recipe.outputs(), 1), true);

        if (recipe.hasBelow()) {
            addSlotIfAny(builder, BELOW_SLOT_X, BELOW_SLOT_Y,
                GravityRecipeItems.resolveAll(recipe.below(), 1), false);
        }
    }

    private static void addSlotIfAny(IRecipeLayoutBuilder builder, int x, int y,
                                     List<ItemStack> stacks, boolean output) {
        if (stacks == null || stacks.isEmpty()) {
            return;
        }
        var slot = output ? builder.addOutputSlot(x, y) : builder.addInputSlot(x, y);
        slot.setStandardSlotBackground();
        if (output) {
            slot.setOutputSlotBackground();
        }
        slot.addItemStacks(stacks);
    }

    @Override
    public void draw(ObservationRecipe recipe, IRecipeSlotsView slotsView, GuiGraphics g,
                     double mouseX, double mouseY) {
        g.fill(0, 0, WIDTH, 1, 0xFFC0C0C0);
        g.fill(0, HEIGHT - 1, WIDTH, HEIGHT, 0xFFC0C0C0);
        g.fill(0, 0, 1, HEIGHT, 0xFFC0C0C0);
        g.fill(WIDTH - 1, 0, WIDTH, HEIGHT, 0xFFC0C0C0);

        var font = Minecraft.getInstance().font;
        // 工作方块 → 输入
        g.drawString(font, "\u2192", 22, ROW1_Y + 5, 0xFF606060, false);
        if (recipe.hasBelow()) {
            g.drawString(font, "下方", 3, BELOW_LABEL_Y, 0xFF404040, false);
            // 下方方块 → 靶心（暗示"它影响加工结果"）
            g.drawString(font, "\u2191", 50, BELOW_LABEL_Y - 2, 0xFF606060, false);
        }
        String note = recipe.safeNote();
        if (!note.isEmpty()) {
            g.drawString(font, note, 4, NOTE_Y, 0xFF3060A0, false);
        }
    }
}
