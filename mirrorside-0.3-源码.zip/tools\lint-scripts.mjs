import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const V = 'D:\\DSHwork\\MC镜维度\\.minecraft\\versions\\镜维度';
const dirs = ['kubejs\\startup_scripts', 'kubejs\\server_scripts', 'kubejs\\client_scripts'];

let bad = 0;
console.log('=== JS 语法检查 ===');
for (const d of dirs) {
  const dir = join(V, d);
  let files = [];
  try { files = readdirSync(dir).filter((f) => f.endsWith('.js')); } catch { continue; }
  for (const f of files) {
    const p = join(dir, f);
    const src = readFileSync(p, 'utf8');
    try {
      new Function(src);
      console.log('  OK    ' + d + '\\' + f);
    } catch (e) {
      console.log('  FAIL  ' + d + '\\' + f + '  -> ' + e.message);
      bad++;
    }
  }
}

console.log('\n=== try 块内 const/let 审计 ===');
// 说明：Rhino 的 bug 只对「字面写在 try {} 内部」的 const/let 触发。
// 早期版本用 inTry++/-- 按行计数，try 块里出现对象字面量（{ ... } 多行）
// 时括号会失步，导致 try 之后的 const 被误报。这里改成按花括号深度判定：
// 记录 try 起始深度，深度回到该值即视为 try 结束。
// （不处理字符串/注释里的花括号——本项目的脚本里没有这种写法。）
//
// ★ 这条规则抓的是**真实事故**（不是理论洁癖），务必保留：
//   配方引擎的计数键函数里写过
//       try { const col = <按键取身份>(...); if (col != null) return col; }
//       catch (err2) { /* 取不到坐标就退回按实体计 */ }
//   每调用一次就抛 InternalError: TypeError: redeclaration of var col，
//   被自己的 catch 吞掉后**静默走了 fallback** ——
//   于是计数身份悄悄变了，配方行为与预期完全不符；
//   而 KubeJS 显示 0 errors、日志一个字都没有。
//   复现：tools-build/RhinoTryProbe.java（不需要启动游戏）。
//   ⚠️ tools-build/sim-recipes.mjs **抓不到**这一类问题：模拟器跑在 Node 上，
//      而 Node 对 try 块内的 const 完全正常。所以这条静态审计是唯一的防线。
//
// --fix：把这些 const/let 就地改成 var（语义等价，且能绕开 Rhino 的 bug）。
//   手工改 36 处容易漏，所以提供这个机械修复。
const FIX = process.argv.includes('--fix');
for (const d of dirs) {
  const dir = join(V, d);
  let files = [];
  try { files = readdirSync(dir).filter((f) => f.endsWith('.js')); } catch { continue; }
  for (const f of files) {
    const lines = readFileSync(join(dir, f), 'utf8').split(/\r?\n/);
    let depth = 0;
    const tryDepths = [];
    let fixedInFile = 0;
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      const startsTry = /try\s*\{/.test(l);
      if (startsTry) tryDepths.push(depth + 1);
      const inTry = tryDepths.length > 0 && depth >= tryDepths[tryDepths.length - 1];
      if (inTry && /^\s*(const|let)\s/.test(l)) {
        if (FIX) {
          // 只替换行首的声明关键字，保留缩进与其余内容
          lines[i] = l.replace(/^(\s*)(const|let)(\s)/, '$1var$3');
          fixedInFile++;
        } else {
          console.log('  BAD  ' + f + ':' + (i + 1) + '  ' + l.trim());
          bad++;
        }
      }
      for (const ch of l) {
        if (ch === '{') depth++;
        else if (ch === '}') depth--;
      }
      while (tryDepths.length > 0 && depth < tryDepths[tryDepths.length - 1]) tryDepths.pop();
    }
    if (FIX && fixedInFile > 0) {
      writeFileSync(join(dir, f), lines.join('\n'), 'utf8');
      console.log('  FIXED ' + f + '  ' + fixedInFile + ' 处 const/let → var');
    }
  }
}

console.log('\n=== 事件处理器内「嵌套块 const/let」审计 ===');
// 血泪教训（实测，2026-09）：
//   KubeJS 的事件处理器（PlayerEvents.tick / ServerEvents.tick / …）是通过
//   Java 接口代理回调进来的。在这种调用路径下：
//     · 处理器**函数体顶层**的 const/let ……… 正常（每 tick 跑几千次都没事）
//     · 处理器里**嵌套块（if/for/try）内**的 const/let ……… 每次调用都抛
//           InternalError/EvaluatorException: TypeError: redeclaration of var xxx
//   实测现场：mirror_n4_gravity.js 的 PlayerEvents.tick 里
//       if (!inMirror) { const N5o = moduleRef('n5'); … }
//   结果日志里刷了 36 条 `redeclaration of var N5o`，那行之后的
//   leaveOuter() 一次都没执行 —— 表现是「从镜外传送去别的世界不会恢复原模式」
//   而这种异常**不会**让脚本加载失败，KubeJS 只说 "0 errors"。
//
//   普通函数（不是事件处理器）里嵌套块的 const/let 是**正常**的
//   （applyGravityTo 里那些 const N3 跑了成千上万次都没事），
//   所以这条规则只在「事件处理器范围内」生效，不做全局扩大化。
//
// --fix：就地改成 var（处理器里这些声明都只在本次调用内使用，语义等价）。
const EVENT_REG = /\b[A-Z]\w*Events\.\w+\s*\(/;
for (const d of dirs) {
  const dir = join(V, d);
  let files = [];
  try { files = readdirSync(dir).filter((f) => f.endsWith('.js')); } catch { continue; }
  for (const f of files) {
    const lines = readFileSync(join(dir, f), 'utf8').split(/\r?\n/);
    let depth = 0;
    let handlerDepth = -1;      // 事件处理器函数体的括号深度（-1 = 不在处理器里）
    let awaitingBody = false;   // 注册语句跨行时，等下一行出现的 {
    let fixedInFile = 0;
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      const depthBefore = depth;
      const isReg = EVENT_REG.test(l) && !/^\s*\/\//.test(l);

      for (const ch of l) {
        if (ch === '{') depth++;
        else if (ch === '}') depth--;
      }

      if (isReg) {
        if (depth > depthBefore) handlerDepth = depth;   // 同行开了处理器体
        else awaitingBody = true;                        // 跨行：等下一行的 {
      } else if (awaitingBody && depth > depthBefore) {
        handlerDepth = depth;
        awaitingBody = false;
      }

      // 处理器体已闭合 → 退出该范围
      if (handlerDepth >= 0 && depth < handlerDepth) {
        handlerDepth = -1;
        awaitingBody = false;
      }

      if (handlerDepth < 0) continue;

      const decl = /^(\s*)(const|let)(\s)/.exec(l);
      const forHead = /^(\s*)(for\s*\(\s*)(const|let)(\s)/.exec(l);
      // 只报"比处理器体更深"的那些：函数体顶层是安全的
      if (depth > handlerDepth && (decl || forHead)) {
        if (FIX) {
          lines[i] = decl
            ? l.replace(/^(\s*)(const|let)(\s)/, '$1var$3')
            : l.replace(/^(\s*for\s*\(\s*)(const|let)(\s)/, '$1var$3');
          fixedInFile++;
        } else {
          console.log('  BAD  ' + f + ':' + (i + 1) + '  ' + l.trim());
          bad++;
        }
      }
    }
    if (FIX && fixedInFile > 0) {
      writeFileSync(join(dir, f), lines.join('\n'), 'utf8');
      console.log('  FIXED ' + f + '  ' + fixedInFile + ' 处 const/let → var');
    }
  }
}

console.log('\n=== global 赋值审计（只允许 startup_scripts）===');
for (const d of dirs) {
  const dir = join(V, d);
  let files = [];
  try { files = readdirSync(dir).filter((f) => f.endsWith('.js')); } catch { continue; }
  for (const f of files) {
    const lines = readFileSync(join(dir, f), 'utf8').split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      if (/^\s*global\.[A-Za-z_$][\w$]*\s*=/.test(lines[i])) {
        const isStartup = d.includes('startup_scripts');
        console.log(`  ${isStartup ? 'OK  ' : 'BAD '} ${d}\\${f}:${i + 1}`);
        if (!isStartup) bad++;
      }
    }
  }
}

console.log('\n' + (bad === 0 ? '✓ 全部通过' : `✗ 发现 ${bad} 个问题`));
/* ⚠️ 必须让"发现问题"变成非零退出码。
 *    之前这里没有 exit：`node tools/lint-scripts.mjs` 打出 ✗ 也返回 0，
 *    调用方（人或脚本）只看退出码就会把问题放过去 —— 而这条审计抓的是
 *    Rhino 的致命语义 bug（try 块内 const/let → 静默抛错），不能再漏。 */
process.exit(bad === 0 ? 0 : 1);
