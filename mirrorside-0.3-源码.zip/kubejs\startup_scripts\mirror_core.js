// =====================================================================
// 镜维度 · 核心（全局作用域）
// ---------------------------------------------------------------------
// 读取 mirror_config.js 暴露的配置，整理出统一的 ID 与工具函数，
// 通过 global.MirrorDimension 提供给其它脚本使用。
//
// 加载顺序靠文件名保证：KubeJS 按字母序加载 startup_scripts，
//   mirror_config.js  ->  mirror_core.js  ->  mirror_portal.js
//
// ⚠️ 文件加载顺序很重要：如果 mirror_core.js 抛错，配置就不会进 global，
//    紧接着 mirror_portal.js 会打印「配置未加载，跳过传送门注册」，
//    传送门静默失效、游戏里毫无提示。排查时先看 startup.log 第一处报错。
// =====================================================================

const MirrorDimension = (() => {

  const cfg = global.MIRROR_CONFIG;

  if (cfg === undefined || cfg === null) {
    console.error('[镜维度] 读不到 global.MIRROR_CONFIG —— mirror_config.js 可能加载失败。');
    return {
      raw: null,
      isLoaded: false,
      ids: { namespace: 'mirror', dimension: 'mirror:mirror', dimensionType: 'mirror:mirror', biome: 'mirror:mirror_plain' },
      id: () => null,
      blockOf: () => null,
      itemOf: () => null,
    };
  }

  const ns = cfg.namespace;

  /* ------------------------------------------------------------------ */
  /* 工具                                                                */
  /* ------------------------------------------------------------------ */

  // ⚠️⚠️ 本文件所有 try 块内**必须用 var，不能用 const / let** ⚠️⚠️
  // Rhino（KubeJS 的 JS 引擎）在这个版本有 bug：try 块内的 const/let 声明
  // 会抛  InternalError: TypeError: redeclaration of var xxx
  // 实测对照：
  //     try { const t = 1; } catch(e){}   -> 抛 redeclaration of var t
  //     try { var   t = 1; } catch(e){}   -> 正常
  // 非 try 块内的 const/let 都正常，所以只有这几个函数需要迁就。

  /** 把 'minecraft:overworld' 解析成 ResourceLocation。
   *  net.minecraft 在类过滤器里是放行的。 */
  function id(value) {
    try {
      var loc = Java.loadClass('net.minecraft.resources.ResourceLocation').parse(String(value));
      return loc;
    } catch (err) {
      console.error('[镜维度] 非法的资源 ID: ' + value + ' —— ' + err);
      return null;
    }
  }

  /** PortalJS / CPA 的 builder 只接受 Block 对象 */
  function blockOf(value) {
    try {
      var blk = Block.getBlock(String(value));
      if (blk == null) {
        console.error('[镜维度] 找不到方块: ' + value);
        return null;
      }
      return blk;
    } catch (err) {
      console.error('[镜维度] 方块 ID 非法: ' + value + ' —— ' + err);
      return null;
    }
  }

  /** 同上，返回 Item 对象 */
  function itemOf(value) {
    try {
      var st = Item.of(String(value));
      if (st == null || st.isEmpty()) {
        console.error('[镜维度] 找不到物品: ' + value);
        return null;
      }
      return st.item;
    } catch (err) {
      console.error('[镜维度] 物品 ID 非法: ' + value + ' —— ' + err);
      return null;
    }
  }

  /** 解析音效事件 ID，失败返回 null（调用方需容忍 null） */
  function soundOf(value) {
    try {
      var loc2 = id(value);
      if (loc2 == null) return null;
      return Java.loadClass('net.minecraft.sounds.SoundEvent').createVariableRangeEvent(loc2);
    } catch (err) {
      console.error('[镜维度] 音效 ID 无法解析: ' + value + ' —— ' + err);
      return null;
    }
  }

  /* ------------------------------------------------------------------ */
  /* Pondus：真实重力方向反转（含视角翻转）                                */
  /* ------------------------------------------------------------------ */
  /* 为什么不能用原版属性：
   *   minecraft:generic.gravity 设成 -0.08 只是让「下落」变成「上浮」，
   *   相机朝向、玩家模型、碰撞朝向全都没变，看起来还是上下颠倒的世界。
   *   Pondus 用 mixin 改了 Entity#getUpVector / LivingEntity#travel /
   *   碰撞盒朝向，并在客户端挂了 CameraMixin + GameRendererMixin +
   *   PlayerEntityRendererMixin，所以方向、相机、模型会一起转。
   *
   * 类过滤器：KubeJS 内置的 kubejs.classfilter.txt 是一份黑名单
   *   （- java.lang / java.io / java.nio / java.net / sun / asm / netty ...），
   *   dinner.dev.pondus 不在任何一条 deny 里，所以默认就能 loadClass。
   *   如果哪天报 "Class is not allowed by class filter"，
   *   在 kubejs/classfilter.txt 里加一行  + dinner.dev.pondus  即可。
   * ------------------------------------------------------------------ */

  const pondus = (() => {
    if (!cfg.gravity || !cfg.gravity.use_pondus) {
      return { available: false, reason: '配置里关闭了 use_pondus' };
    }
    try {
      var API = Java.loadClass('dinner.dev.pondus.api.PondusAPI');
      var Dir = Java.loadClass('net.minecraft.core.Direction');
      if (API == null || Dir == null) {
        return { available: false, reason: 'PondusAPI / Direction 解析为 null' };
      }
      return {
        available: true,
        reason: 'ok',
        API: API,
        Direction: Dir,
        /** 名字 -> Direction 枚举；非法名字返回 null */
        dirOf: function (name) {
          try {
            var v = String(name == null ? 'down' : name).trim().toUpperCase();
            var d = Dir[v];
            return d == null ? null : d;
          } catch (err) {
            return null;
          }
        },
      };
    } catch (err) {
      return { available: false, reason: String(err) };
    }
  })();

  if (pondus.available) {
    console.info('[镜维度] Pondus 已接入 —— 重力方向与视角会一起反转。');
  } else if (cfg.gravity && cfg.gravity.enabled) {
    console.info('[镜维度][警告] Pondus 不可用（' + pondus.reason + '）；'
      + '重力将退回原版属性方案：能上浮，但视角不会转。'
      + ' 请确认 mods 目录里有 pondus-1.0.1.jar。');
  }

  return {
    raw: cfg,
    isLoaded: true,
    /** 与 tools/generate-mirror-pack.mjs 和 mirror_dimension.json 保持一致 */
    ids: {
      namespace: ns,
      dimension: ns + ':' + cfg.dimension_path,
      dimensionType: ns + ':' + cfg.dimension_type_path,
      biome: ns + ':' + cfg.biome_path,
    },
    id: id,
    blockOf: blockOf,
    itemOf: itemOf,
    soundOf: soundOf,
    /** Pondus 句柄。available=false 时其余字段不可用。 */
    pondus: pondus,
    /* 共享容器：server 脚本不能给 global 赋值（会整份失效），
     * 但**可以读** global 上已存在的对象并挂自己的东西上去。
     * 这样 mirror_server.js（字母序在前，加载更早）在运行时也能
     * 拿到 mirror_setting.js 建立的重力状态。
     * 注意：不要给 MirrorDimension 本身加东西时写错成整体替换。 */
    runtime: {},
    /* server 侧模块的命名空间。
     *
     * ⚠️ 必须在 startup 层建立，不能在 server 脚本里现建：
     *    server 脚本给 global 挂**新属性**同样会被判为"给 global 赋值"，
     *    本项目的 tools/lint-scripts.mjs 会直接报错。
     *    （"改已存在对象的属性"才是允许的，所以这里先占位。）
     *
     * 各 server 模块按文件名顺序 n0→n5 依次挂进这个对象，
     * 详见 mirror_n0_foundation.js 顶部的模块组织说明。 */
    modules: {},
  };
})();

global.MirrorDimension = MirrorDimension;

if (MirrorDimension.isLoaded) {
  console.info('[镜维度] 核心已就绪 — 维度 ' + MirrorDimension.ids.dimension
    + '，生物群系 ' + MirrorDimension.ids.biome);
}

// ⚠️ 这里**不要**注册 ServerEvents.* —— 那些是 SERVER 类型事件，
// 在 startup 脚本里注册会直接报：
//     Tried to register event handler 'ServerEvents.xxx' for invalid script type STARTUP!
//      Valid script types: [SERVER]
// 而且会让**整个 startup 脚本**失败。指令自检放在 server_scripts 里做。

