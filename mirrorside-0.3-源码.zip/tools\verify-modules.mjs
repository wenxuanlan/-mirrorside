#!/usr/bin/env node
/**
 * 镜维度 · 模块接线静态核对
 *
 * ── 为什么需要它 ──────────────────────────────────────────────────
 * server 侧的玩法逻辑拆成了 n0~n6 七个模块，模块之间靠
 * global.MirrorDimension.modules 传递引用。这种"隐式接线"有两个
 * 容易出错的地方：
 *
 *   1) 加载顺序依赖：某个模块在**加载期**引用了编号比自己大的模块，
 *      那个模块那时还没建好 → 整块逻辑失效（而且是静默的）
 *   2) 编号冲突：两个文件注册同一个编号，后者覆盖前者
 *
 * 这两种错误在游戏里表现为"某个功能没反应"，日志里未必有明显线索。
 * 本脚本在**不启动游戏**的前提下把它们查出来。
 *
 * ── 检查项 ───────────────────────────────────────────────────────
 *   A. 每个 mirror_nX_*.js 注册的编号是否与文件名一致
 *   B. 编号是否有重复
 *   C. 加载期直接引用（`modules.nY` 出现在顶层 const 里）是否只指向
 *      编号更小的模块
 *   D. moduleRef('nY') 引用的模块是否存在
 *   E. 是否还有人引用已删除的 mirror_setting.js
 *
 * 用法：node tools/verify-modules.mjs
 */

import { readFileSync, readdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const SERVER_DIR = join(here, '..', 'kubejs', 'server_scripts');

const problems = [];
const notes = [];

/* ---------- 收集所有模块文件 ---------- */

const files = readdirSync(SERVER_DIR).filter(f => /^mirror_n\d+_.+\.js$/.test(f)).sort();

if (files.length === 0) {
  console.error(`在 ${SERVER_DIR} 里没找到 mirror_nX_*.js —— 路径对吗？`);
  process.exit(1);
}

const modules = new Map();   // 编号 -> { file, name }

for (const f of files) {
  const src = readFileSync(join(SERVER_DIR, f), 'utf8');

  // 文件名里的编号
  const fileNum = f.match(/^mirror_(n\d+)_/)[1];

  // 注册语句：modules.nX = api  或  MODULES.nX = ...
  const regs = [...src.matchAll(/(?:modules|MODULES)\.(n\d+)\s*=/g)].map(m => m[1]);

  // 模块对象名（const MirrorXxx = (() => { ... })()）
  const nameMatch = src.match(/const\s+(Mirror\w+)\s*=\s*\(\(\)\s*=>/);

  if (regs.length === 0) {
    problems.push(`${f}：没有找到 modules.nX = 的注册语句`);
    continue;
  }
  for (const r of regs) {
    if (r !== fileNum) {
      problems.push(`${f}：文件名编号是 ${fileNum}，却注册成 ${r}`);
    }
    if (modules.has(r)) {
      problems.push(`编号 ${r} 被重复注册：${modules.get(r).file} 与 ${f}`);
    }
    modules.set(r, { file: f, name: nameMatch ? nameMatch[1] : '?' });
  }
  void nameMatch;
}

notes.push(`发现 ${modules.size} 个模块：`);
for (const [num, info] of [...modules.entries()].sort()) {
  notes.push(`  ${num}  ${info.name.padEnd(18)} ${info.file}`);
}

/* ---------- C. 加载期引用顺序 ---------- */

const numOf = (s) => parseInt(String(s).replace('n', ''), 10);

for (const f of files) {
  const src = readFileSync(join(SERVER_DIR, f), 'utf8');
  const fileNum = numOf(f.match(/^mirror_(n\d+)_/)[1]);

  const lines = src.split('\n');
  lines.forEach((line, i) => {
    // 顶层（非缩进的函数体内）的 const NX = ...modules.nY...
    const m = line.match(/^\s{0,4}(?:const|let|var)\s+\w+\s*=\s*(?:\w+\.)?[Mm]odules\.(n\d+)/);
    if (m) {
      const refNum = numOf(m[1]);
      if (refNum >= fileNum) {
        problems.push(
          `${f}:${i + 1} 加载期引用了 ${m[1]}（自身是 n${fileNum}）`
          + ' —— 编号更大的模块此时还没建立，该逻辑会失效。'
          + ' 请改用 n0.moduleRef(\'' + m[1] + '\') 在函数体里延迟解析。');
      }
    }
  });
}

/* ---------- D. moduleRef 目标是否存在 ---------- */

const referencedByRef = new Set();
for (const f of files) {
  const src = readFileSync(join(SERVER_DIR, f), 'utf8');
  for (const m of src.matchAll(/moduleRef\(\s*['"](n\d+)['"]\s*\)/g)) {
    referencedByRef.add(m[1]);
    if (!modules.has(m[1])) {
      problems.push(`${f}：moduleRef('${m[1]}') 指向的模块不存在`);
    }
  }
}

/* ---------- E. 对已删除文件的引用 ---------- */

const allServer = readdirSync(SERVER_DIR).filter(f => f.endsWith('.js'));
for (const f of allServer) {
  const src = readFileSync(join(SERVER_DIR, f), 'utf8');
  if (/mirror_setting/.test(src)) {
    const bad = src.split('\n')
      .map((l, i) => [i + 1, l])
      .filter(([, l]) => /mirror_setting/.test(l));
    for (const [ln, l] of bad) {
      problems.push(`${f}:${ln} 仍提到已删除的 mirror_setting.js: ${l.trim()}`);
    }
  }
}

/* ---------- 输出 ---------- */

console.log('=== 模块接线核对 ===\n');
for (const n of notes) console.log(n);
console.log(`\n加载期已解析的跨模块引用：${[...referencedByRef].sort().join(', ') || '（无）'}`);

if (problems.length === 0) {
  console.log('\n✓ 接线检查通过');
  process.exit(0);
}

console.log(`\n✗ 发现 ${problems.length} 个问题：`);
for (const p of problems) console.log('  - ' + p);
process.exit(1);
