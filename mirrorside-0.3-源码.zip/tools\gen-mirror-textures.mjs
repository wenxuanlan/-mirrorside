#!/usr/bin/env node
/**
 * 生成"镜面"方块贴图。
 *
 * ── 为什么要用脚本生成，而不是手画的图片 ──────────────────────────
 * 贴图要是**确定性的**：颜色、明暗、网格位置全都由代码写死，
 * 任何时候重跑都能得到完全一样的文件。手画的 PNG 一旦丢了或想微调，
 * 就只能重画一遍；脚本改一个数字就能重新生成。
 *
 * ── 这一版怎么让它"真的像镜子"（第二版，替代旧的瓷砖式画法）──────
 * 旧版把贴图做成 10 档色板 + 8×8 斜角明暗 + 板缝，理由是对齐铁砧工艺
 * 那种"抛光金属块"。结果在游戏里看着像**磨砂瓷砖/金属地板**而不是镜子，
 * 原因是镜面的两个视觉特征它都没有：
 *   1) 连续渐变 —— 分档色板会把渐变切成一圈圈色块；
 *   2) 锐利高光 —— 只有一条明确的镜面反光才叫"镜面"。
 * 现在改为：
 *   · 连续色阶函数 silver(t)，不再量化（银蓝冷调保留，仍是低饱和）；
 *   · 一道沿对角线的高斯型高光（1~2 像素宽），强度拉到接近纯白；
 *   · 一层低频斜向"反射光带"，让镜面里有可见的反射内容，而不是死白；
 *   · 外圈 1 像素收暗边，远处也能看出这是一块"板材"，不会糊成一片白。
 *
 * ── 产出 ────────────────────────────────────────────────────────
 *   mirror_surface_side.png   侧面：竖着的镜面板，上缘受光、往下压暗，
 *                                   上三分之一有一道横向反光
 *   mirror_surface_top.png    顶面：完整镜面 + 对角高光带
 *   mirror_surface_bottom.png 底面：暗色磨砂背板
 *
 * 纯手工编码 PNG（zlib + CRC32），不依赖任何第三方库。
 *
 * 用法:  node tools/gen-mirror-textures.mjs
 */

import { writeFileSync, mkdirSync } from 'node:fs';
import { deflateSync } from 'node:zlib';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* ------------------------------------------------------------------ */
/* PNG 编码                                                            */
/* ------------------------------------------------------------------ */

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c;
  }
  return t;
})();

/* ⚠️ 名字不能叫 crc32 —— 上面那个数组如果也叫 crc32，会把它遮蔽掉，
 * 调用时直接 TypeError。 */
function crcOf(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crcOf(Buffer.concat([typeBuf, data])));
  return Buffer.concat([len, typeBuf, data, crc]);
}

/**
 * 把 RGBA 像素数组编码成 PNG。
 *
 * 用 colorType=6（真彩 + alpha）、bitDepth=8。
 * 也许成索引调色板更省体积，但那要额外做量化，
 * 而这几张贴图只有 16x16，体积差异可以忽略。
 *
 * @param {number} w 宽
 * @param {number} h 高
 * @param {(x:number,y:number)=>number[]} get 返回 [r,g,b,a]
 */
function encodePng(w, h, get) {
  const stride = w * 4;
  const raw = Buffer.alloc(h * (stride + 1));
  let p = 0;
  for (let y = 0; y < h; y++) {
    raw[p++] = 0;                                  // 滤波类型 0（None）
    for (let x = 0; x < w; x++) {
      const [r, g, b, a] = get(x, y);
      raw[p++] = r & 0xff;
      raw[p++] = g & 0xff;
      raw[p++] = b & 0xff;
      /* ⚠️ alpha 必须原样写入。这几张贴图完全不透明（a=255），
       * 但这里绝不能写 `a & 0xff` 之类的裁剪 —— 那会把 255 变成 0，
       * 结果是贴图在游戏里全透明（实测踩过：解码出来全是 "."）。 */
      raw[p++] = a;
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;    // bitDepth
  ihdr[9] = 6;    // colorType: RGBA
  ihdr[10] = 0;   // compression
  ihdr[11] = 0;   // filter
  ihdr[12] = 0;   // interlace

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/* ------------------------------------------------------------------ */
/* 配色：连续银蓝（0 = 背板暗银，1 = 镜面高光）                         */
/* ------------------------------------------------------------------ */

const SIZE = 16;
const TAU = Math.PI * 2;

/**
 * 连续色阶：t∈[0,1] → 冷调银蓝。
 *
 * ⚠️ 必须返回**四元组**，alpha 不能省。
 * 早先的写法是查一个 [r,g,b] 三元组色板，直接当像素返回时编码器解构出的
 * a 是 undefined，写进 Buffer 被强转成 0 —— 整张贴图全透明，游戏里看不到
 * 方块，解码出来却是清一色透明点。这里显式补 255。
 *
 * 暗端 B 略高于 R（冷调），亮端几乎纯白 —— 饱和度全程很低，
 * 不会比原版方块更"艳"。
 */
function silver(t) {
  const k = Math.min(1, Math.max(0, t));
  const r = 0x2c + (0xff - 0x2c) * k;
  const g = 0x33 + (0xff - 0x33) * k;
  const b = 0x3d + (0xff - 0x3d) * k;
  return [Math.round(r), Math.round(g), Math.round(b), 255];
}

/* ------------------------------------------------------------------ */
/* 三张图案                                                            */
/* ------------------------------------------------------------------ */

/** 顶面：完整镜面 —— 连续斜向渐变 + 一道对角高光。 */
function topTexture() {
  return (x, y) => {
    // 受光渐变：左上最亮，向右下连续压暗（不分档，所以不会出现色环）
    let t = 0.90 - 0.36 * ((x + y) / (2 * (SIZE - 1)));
    // 反射内容：低频斜向光带，频率取 16 的整周期 → 上下左右都无缝
    t += 0.08 * Math.sin(TAU * ((x - y) / 16 + 0.2));
    // 锐利高光：沿主对角线的一条高斯反光，宽度约 1.35 像素
    const dd = (x - y - 1) / 1.35;
    t += 0.50 * Math.exp(-dd * dd);
    // 上缘再抬一点（像反射到天空），让"镜面朝上"这件事一眼能看出来
    t += 0.05 * (1 - y / (SIZE - 1));
    // 外圈 1 像素收边：远处看是一块板材，不会和旁边方块糊成一片白
    if (x === 0 || y === 0 || x === SIZE - 1 || y === SIZE - 1) t -= 0.45;
    return silver(t);
  };
}

/** 侧面：竖立的镜面板 —— 上缘受光、往下压暗，上三分之一一道横向反光。 */
function sideTexture() {
  return (x, y) => {
    let t = 0.86 - 0.60 * (y / (SIZE - 1));
    // 竖向拉丝（抛光面细节）。频率取 16 的整倍数 → 左右接缝处不会断开
    t += 0.035 * Math.sin(TAU * 3 * x / SIZE);
    /* 上三分之一的柔和横向反光带。
     * ⚠️ 强度别超过 0.20：0.28 时 y=2..4 三行会一起顶到 255，
     * 侧面变成"一条纯白带 + 一片灰"，看着像贴纸而不是镜面。 */
    const g = (y - 3.5) / 1.9;
    t += 0.18 * Math.exp(-g * g);
    // 上下各一条暗线：方块叠起来时能看出分层
    if (y === 0) t -= 0.30;
    if (y === SIZE - 1) t -= 0.42;
    return silver(t);
  };
}

/** 底面：暗色磨砂背板（镜子背面），确定性噪点，没有反光。 */
function bottomTexture() {
  return (x, y) => {
    let t = 0.30 - 0.12 * (y / (SIZE - 1));
    // 确定性散列噪点：同一像素任何时候都是同一个值，重跑结果一致
    const h = ((x * 73856093) ^ (y * 19349663)) >>> 0;
    t += ((h % 1000) / 1000 - 0.5) * 0.10;
    if (x === 0 || y === 0 || x === SIZE - 1 || y === SIZE - 1) t -= 0.10;
    return silver(t);
  };
}

/* ------------------------------------------------------------------ */
/* 输出                                                                */
/* ------------------------------------------------------------------ */

const here = dirname(fileURLToPath(import.meta.url));

/*
 * 定位模组资源目录。
 *
 * 目录层级（相对本脚本）：
 *   tools/                                  ← 本脚本所在
 *   <实例>/                                  ← 上溯 1 层
 *   versions/                                ← 上溯 2 层
 *   .minecraft/                              ← 上溯 3 层
 *   <工程根>/                                 ← 上溯 4 层
 *   <工程根>/mirror-gravity-mod/src/main/resources/...
 *
 * ⚠️ 是 **4 层**不是 3 层。曾经写成 3 层，结果文件被写进了
 *    <工程根>/.minecraft/mirror-gravity-mod/ —— 一个并不存在的工程副本目录。
 *    当时没报错（目录被自动创建了），但贴图永远不会被打进 jar，
 *    表现是"贴图没生效"。手算层数很容易错，改这里时请对着上面的层级数一遍。
 */
const PROJECT_ROOT = join(here, '..', '..', '..', '..');
const OUT_DIR = join(PROJECT_ROOT,
  'mirror-gravity-mod', 'src', 'main', 'resources',
  'assets', 'mirrorgravity', 'textures', 'block');

mkdirSync(OUT_DIR, { recursive: true });

const targets = [
  ['mirror_surface_side.png', sideTexture()],
  ['mirror_surface_top.png', topTexture()],
  ['mirror_surface_bottom.png', bottomTexture()],
];

const written = [];
for (const [name, fn] of targets) {
  const png = encodePng(SIZE, SIZE, fn);
  const out = join(OUT_DIR, name);
  writeFileSync(out, png);
  written.push([name, fn, png.length]);
  console.log(`${name}  ${png.length}B  → ${out}`);
}

/* ------------------------------------------------------------------ */
/* 自检：把生成结果再量一遍                                            */
/* ------------------------------------------------------------------ */

const RAMP = ' .:-=+*#%@';

/** 字符画预览：不用开图片也能看出渐变走向与高光位置。 */
function preview(name, fn) {
  console.log(`  ── ${name}（字符越靠右越亮）──`);
  for (let y = 0; y < SIZE; y++) {
    let line = '   |';
    for (let x = 0; x < SIZE; x++) {
      const [r] = fn(x, y);
      line += RAMP[Math.min(RAMP.length - 1, Math.floor((r / 256) * RAMP.length))];
    }
    console.log(line + '|');
  }
}

console.log('\n=== 自检 ===');

let ok = true;
for (const [name, fn] of written) {
  let min = 255;
  let max = 0;
  let alphaBad = 0;
  let brightX = -1;
  let brightY = -1;
  for (let y = 0; y < SIZE; y++) {
    for (let x = 0; x < SIZE; x++) {
      const [r, , , a] = fn(x, y);
      min = Math.min(min, r);
      max = Math.max(max, r);
      if (a !== 255) alphaBad++;
      if (r > max - 1 && brightX < 0) {
        brightX = x;
        brightY = y;
      }
    }
  }
  console.log(`  ${name}: 亮度 ${min} ~ ${max}，跨度 ${max - min}，最亮像素在 (${brightX},${brightY})`);
  if (alphaBad > 0) {
    console.log(`  ✗ ${name} 有 ${alphaBad} 个像素不是不透明（方块贴图必须 a=255）`);
    ok = false;
  }
  if (max - min < 60) {
    console.log(`  ✗ ${name} 明暗跨度过小（${max - min}），会是一张平板贴图`);
    ok = false;
  }
}

/* 顶面必须有高光，而且高光要落在对角线上 —— 这是"镜面"的设计要点，
 * 一旦有人把高光项删掉或改错方向，这条会立刻红。 */
const topFn = topTexture();
let topMax = 0;
let topMaxAt = [0, 0];
for (let y = 0; y < SIZE; y++) {
  for (let x = 0; x < SIZE; x++) {
    const [r] = topFn(x, y);
    if (r > topMax) {
      topMax = r;
      topMaxAt = [x, y];
    }
  }
}
const diagOk = Math.abs(topMaxAt[0] - topMaxAt[1] - 1) <= 2;
console.log(`  顶面最亮点 (${topMaxAt[0]},${topMaxAt[1]})，|x-y-1| = ${Math.abs(topMaxAt[0] - topMaxAt[1] - 1)}（高光应对角分布，≤2）`);
if (topMax < 245) {
  console.log(`  ✗ 顶面最亮只有 ${topMax}，镜面高光不够亮`);
  ok = false;
}
if (!diagOk) {
  console.log('  ✗ 顶面高光不在对角线上，镜面反光方向不对');
  ok = false;
}

preview('顶面 mirror_surface_top', topFn);
preview('侧面 mirror_surface_side', sideTexture());

console.log(ok ? '  ✓ 镜面（连续渐变 + 对角高光 + 不透明）符合预期'
  : '  ✗ 贴图不符合预期，检查上面的公式');
if (!ok) process.exitCode = 1;

console.log('\n已生成 3 张贴图（16x16，RGBA）。');
console.log('记得：方块模型要引用 mirrorgravity:block/mirror_surface_* 这几张，');
console.log('改完贴图要重新构建模组 jar（贴图在 jar 里，不是数据包）。');
