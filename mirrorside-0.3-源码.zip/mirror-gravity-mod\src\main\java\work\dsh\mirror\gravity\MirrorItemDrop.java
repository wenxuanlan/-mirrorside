package work.dsh.mirror.gravity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;

/**
 * 镜维度 · 「加工产物以**掉落物**形式弹出」的机制。
 *
 * <h2>为什么需要它</h2>
 * 大多数配方的产物是**方块**，直接 {@code level.setBlockAndUpdate} 放下就行。
 * 但设定里有两条例外：
 * <pre>
 *   脚手架 —— 4 次切换 + 落在**树叶**上   → 对应的树苗（掉出来，不是种下去）
 *   脚手架 —— 4 次切换 + 落在**灵魂沙**上 → 地狱疣（同样是掉出来）
 * </pre>
 * 树苗与地狱疣都是"能当方块放、也能当物品拿"的东西。这里刻意生成
 * **物品实体**而不是原地放方块 —— 玩家要的是"加工出来的东西可以捡走"，
 * 直接种在原地反而会把落点（树叶/灵魂沙）盖掉。
 *
 * <h2>为什么放在模组而不是 KubeJS 里做</h2>
 * 脚本侧 new 一个 {@code ItemEntity} 需要跨 Rhino 传构造参数与
 * {@code DeltaMovement}，这条链在本环境里没有先例（同类问题已经踩过：
 * {@code BlockPos.above(int)} 静默失败）。模组这边是一次普通的 Java 调用，
 * 脚本只给"坐标 + 物品 ID + 数量"。这与整套架构一致：
 * <b>配置是唯一真相，模组只提供原语</b>。
 *
 * <h2>初速度为什么这么小</h2>
 * 弹出发生在**分界面附近**，那里的重力可能是反的。给一个原版
 * "方块被破坏"那种 0.2 的抛射速度，掉落物会立刻被反向重力加速甩飞，
 * 观感像"炸出来"。这里只给一点点随机横向漂移 + 极小的向上分量，
 * 让它先待在原处，再由所在半区的重力接手 ——
 * 这样上下两个界面的表现都自然。
 */
public final class MirrorItemDrop {

    private MirrorItemDrop() {
    }

    /** 初速度幅度（格/tick）。原版方块掉落是 0.2，这里刻意小一个量级。 */
    private static final double SPREAD = 0.06D;

    /** 向上分量（格/tick），只为让物品离地一点点，不至于卡在方块里。 */
    private static final double LIFT = 0.04D;

    /**
     * 在世界里生成一个掉落物。
     *
     * @param level 服务端世界
     * @param x     生成点（方块中心，调用方负责 +0.5）
     * @param y     生成点
     * @param z     生成点
     * @param stack 物品堆（会被复制，调用方之后改动它不影响已生成的实体）
     * @return 是否成功生成
     */
    public static boolean drop(ServerLevel level, double x, double y, double z, ItemStack stack) {
        if (level == null || stack == null || stack.isEmpty()) {
            return false;
        }
        try {
            ItemEntity entity = new ItemEntity(level, x, y, z, stack.copy());
            /* 拾取延时用原版默认值（10 tick）—— 生成瞬间就被旁边的人吸走
             * 会让人来不及看清掉的是什么。 */
            entity.setDefaultPickUpDelay();
            entity.setDeltaMovement(
                (level.random.nextDouble() - 0.5D) * SPREAD,
                LIFT,
                (level.random.nextDouble() - 0.5D) * SPREAD);
            return level.addFreshEntity(entity);
        } catch (Throwable t) {
            MirrorGravity.LOGGER.warn("[镜维度·掉落物] 生成掉落物失败: {}", t.toString());
            return false;
        }
    }
}
