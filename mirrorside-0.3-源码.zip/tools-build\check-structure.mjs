#!/usr/bin/env node
/**
 * 镜维度 · 结构数据包自检
 *
 * ── 为什么需要它 ─────────────────────────────────────────────────────────────
 * 结构是**纯数据包**内容（KubeJS 7 没有结构 API），四个文件互相引用：
 *
 *   structure_set/<id>.json   → structures[].structure
 *   worldgen/structure/<id>.json → start_pool
 *   worldgen/template_pool/<id>.json → elements[].element.location
 *   structure/<id>.nbt        ← 真正的模板（结构方块保存的那个）
 *
 * 任何一环写错，游戏里的表现都是**同一个**："结构就是刷不出来"，而且
 * **没有任何报错**（数据包 JSON 无效时只是这条结构不注册）。这与本项目
 * 反复踩过的"静默失效"是同一类问题，所以这里把能静态查的都查一遍。
 *
 * ── 检查项 ───────────────────────────────────────────────────────────────────
 *   A. 四个文件都在、JSON 能解析
 *   B. 交叉引用闭合（结构集 → 结构 → 模板池 → NBT）
 *   C. NBT 关键字段：size / 无 air（应为 structure_void）/ DataVersion
 *   D. 关键数值在合理范围（高度区间、间距/分离、size 深度上限）
 *   E. 引用的原版 ID 是否真的存在（标签与处理器列表，从原版 jar 里查）
 *
 * 用法：node tools-build/check-structure.mjs [结构名，默认 spinning_colors]
 */
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { gunzipSync } from 'node:zlib';

const V = 'D:\\DSHwork\\MC镜维度\\.minecraft\\versions\\镜维度';
const DATA = join(V, 'kubejs', 'data', 'mirror');
const NS = 'mirror';
const name = process.argv[2] || 'spinning_colors';
const id = `${NS}:${name}`;
const VANILLA_JAR = join(V, '镜维度.jar');

let bad = 0;
const fail = (m) => { bad++; console.log('  ✗ ' + m); };
const ok = (m) => console.log('  ✓ ' + m);
const warn = (m) => console.log('  · ' + m);

const P = {
  set: join(DATA, 'worldgen', 'structure_set', `${name}.json`),
  structure: join(DATA, 'worldgen', 'structure', `${name}.json`),
  pool: join(DATA, 'worldgen', 'template_pool', `${name}.json`),
  nbt: join(DATA, 'structure', `${name}.nbt`),
};

console.log(`=== A. 四个文件（${id}）===`);
const json = {};
for (const [k, p] of Object.entries(P)) {
  if (!existsSync(p)) { fail(`缺少 ${p.replace(V + '\\', '')}`); continue; }
  if (k === 'nbt') { ok(`structure/${name}.nbt  (${readFileSync(p).length} B)`); continue; }
  try {
    json[k] = JSON.parse(readFileSync(p, 'utf8'));
    ok(`${k.padEnd(9)} ${p.replace(V + '\\kubejs\\data\\', '')}`);
  } catch (e) { fail(`${p} 不是合法 JSON: ${e.message}`); }
}

/* ---------- B. 交叉引用 ---------- */
console.log('\n=== B. 交叉引用闭合 ===');
if (json.set) {
  const list = json.set.structures || [];
  const hit = list.find((s) => s.structure === id);
  if (!hit) fail(`结构集里没有引用 ${id}（只有 ${list.map((s) => s.structure).join(', ')}）`);
  else ok(`结构集 → ${id}（weight ${hit.weight ?? 1}）`);
}
if (json.structure) {
  if (json.structure.start_pool !== id) fail(`结构的 start_pool 应为 ${id}，实际 ${json.structure.start_pool}`);
  else ok(`结构 → 模板池 ${id}`);
}
if (json.pool) {
  const locs = (json.pool.elements || []).map((e) => e.element && e.element.location).filter(Boolean);
  if (!locs.includes(id)) fail(`模板池里没有 location=${id}（只有 ${locs.join(', ') || '空'}）`);
  else ok(`模板池 → 模板 NBT ${id}`);
  if (locs.length > 1) warn(`模板池里有 ${locs.length} 个候选模板（本结构只应有 1 个）`);
}
if (existsSync(P.nbt)) {
  const nm = `${name}.nbt`;
  const locs = json.pool ? (json.pool.elements || []).map((e) => e.element.location) : [];
  if (locs.includes(id)) ok(`模板 NBT 存在：structure/${nm}`);
}

/* ---------- C. NBT 内容 ---------- */
console.log('\n=== C. 模板 NBT ===');
if (existsSync(P.nbt)) {
  const buf = gunzipSync(readFileSync(P.nbt));
  /* 极简 NBT 读取（只取顶层几个字段） */
  class R {
    constructor(b) { this.b = b; this.i = 0; }
    u1() { return this.b[this.i++]; }
    i1() { return this.b.readInt8(this.i++); }
    i2() { const v = this.b.readInt16BE(this.i); this.i += 2; return v; }
    i4() { const v = this.b.readInt32BE(this.i); this.i += 4; return v; }
    i8() { const v = this.b.readBigInt64BE(this.i); this.i += 8; return v; }
    f4() { const v = this.b.readFloatBE(this.i); this.i += 4; return v; }
    f8() { const v = this.b.readDoubleBE(this.i); this.i += 8; return v; }
    str() { const n = this.b.readUInt16BE(this.i); this.i += 2; const s = this.b.toString('utf8', this.i, this.i + n); this.i += n; return s; }
  }
  const pay = (r, t) => {
    switch (t) {
      case 1: return r.i1(); case 2: return r.i2(); case 3: return r.i4(); case 4: return r.i8();
      case 5: return r.f4(); case 6: return r.f8();
      case 7: { const n = r.i4(); r.i += n; return null; }
      case 8: return r.str();
      case 9: { const it = r.u1(); const n = r.i4(); const o = []; for (let k = 0; k < n; k++) o.push(pay(r, it)); return o; }
      case 10: { const o = {}; for (;;) { const tt = r.u1(); if (tt === 0) break; const nm = r.str(); o[nm] = pay(r, tt); } return o; }
      case 11: { const n = r.i4(); const o = []; for (let k = 0; k < n; k++) o.push(r.i4()); return o; }
      case 12: { const n = r.i4(); const o = []; for (let k = 0; k < n; k++) o.push(r.i8()); return o; }
      default: throw new Error('未知 NBT 类型 ' + t);
    }
  };
  const r = new R(buf); const t = r.u1(); r.str();
  const nbt = pay(r, t);
  const size = nbt.size || [];
  ok(`尺寸 ${size.join(' × ')}，方块条目 ${nbt.blocks.length}，实体 ${(nbt.entities || []).length}`);
  const pal = (nbt.palette || []).map((p) => p.Name);
  const airN = (nbt.blocks || []).filter((b) => pal[Number(b.state)] === 'minecraft:air').length;
  const voidN = (nbt.blocks || []).filter((b) => pal[Number(b.state)] === 'minecraft:structure_void').length;
  const solidN = (nbt.blocks || []).length - airN - voidN;
  ok(`实体方块 ${solidN} ／ 空气 ${airN} ／ 结构空位 ${voidN}`);
  if (airN > 0) {
    /* 这不是错误，但它有一个**必须知道的副作用**，所以明确写出来而不是静默通过：
     *   air            → 放置时会把范围内的方块**替换成空气**
     *   structure_void → 放置时跳过，不动已有方块
     * 本项目当前**刻意选择 air**（用户决定）：空中放置两者看起来一样；
     * 但若结构落在山体里、或 /place 在玩家脚下，会挖空一整个
     * size 体积的空间。高度区间（见 D 段）越贴近地形，这个副作用越明显。 */
    warn(`调色板含 minecraft:air（${airN} 格，占 ${Math.round((airN / nbt.blocks.length) * 100)}%）`
      + ' —— 放置时会把范围内的方块替换成空气（空中无影响；落在地形上会挖出一个 '
      + `${size.join('×')} 的空腔）。这是当前**有意选择**，如需改为不破坏地形，`
      + '把调色板里的 air 换成 minecraft:structure_void 即可。');
  } else {
    ok('无 air（不会覆盖世界里的任何方块）');
  }
  if (nbt.DataVersion !== 3955) warn(`DataVersion=${nbt.DataVersion}（1.21.1 为 3955；不同版本进游戏时会被数据修复器转换）`);
  else ok('DataVersion 3955 = 1.21.1 ✓');

  /* ---------- D. 数值范围 ---------- */
  console.log('\n=== D. 关键数值 ===');
  if (json.structure) {
    const s = json.structure;
    const sh = s.start_height || {};
    const lo = sh.min_inclusive && sh.min_inclusive.absolute;
    const hi = sh.max_inclusive && sh.max_inclusive.absolute;
    if (sh.type === 'minecraft:uniform' && lo != null && hi != null) {
      if (hi - lo < size[1]) { fail(`高度区间 ${lo}~${hi} 比结构高度 ${size[1]} 还窄，很多次会放不下`); }
      else ok(`高度区间 ${lo} ~ ${hi}（结构高 ${size[1]}，放得下）`);
      if (lo < 64) warn(`下限 ${lo} 低于海平面 63，可能穿进地形`);
      if (hi + size[1] > 320) fail(`上限 ${hi} + 结构高 ${size[1]} 超过世界高度上限`);
    } else if (typeof sh.absolute === 'number') {
      ok(`固定高度 y=${sh.absolute}`);
      if (sh.absolute + size[1] > 320) fail(`y=${sh.absolute} + 结构高 ${size[1]} 超过世界高度上限`);
    } else {
      fail(`start_height 形式无法识别：${JSON.stringify(sh)}`);
    }
    if (s.project_start_to_heightmap) {
      warn(`写了 project_start_to_heightmap=${s.project_start_to_heightmap} —— 这会把结构**贴到地形表面**，`
        + '与"刷在天空中"矛盾（要贴天就删掉这一项）');
    } else ok('未贴地形（没有 project_start_to_heightmap）→ 用 start_height 的绝对高度');
    if ((s.size ?? 1) > 20) fail(`size=${s.size} 超过原版上限 20`);
    if ((s.max_distance_from_center ?? 80) > 128) fail('max_distance_from_center 超过原版上限 128');
    if (s.terrain_adaptation && s.terrain_adaptation !== 'none') {
      warn(`terrain_adaptation=${s.terrain_adaptation} —— 空中结构一般用 none（否则会在下方堆地形）`);
    } else ok('terrain_adaptation = none');
  }
  if (json.set && json.set.placement) {
    const p = json.set.placement;
    if (p.type !== 'minecraft:random_spread') warn(`placement.type=${p.type}`);
    if (p.separation >= p.spacing) fail(`separation(${p.separation}) 必须小于 spacing(${p.spacing})`);
    else ok(`间距 spacing=${p.spacing} / separation=${p.separation} → 平均每 ${p.spacing * 16} 格见一次`);
  }
}

/* ---------- E. 引用的原版 ID ---------- */
console.log('\n=== E. 引用的原版 ID（从原版 jar 查）===');
if (!existsSync(VANILLA_JAR)) {
  warn('找不到原版 jar，跳过这一节');
} else {
  /* 直接读 ZIP 的中央目录，不依赖外部 jar/7z 命令（本机 PATH 上没有 jar） */
  const listZip = (path) => {
    const b = readFileSync(path);
    /* 找 EOCD（签名 0x06054b50），从尾部往前扫 */
    let eocd = -1;
    for (let i = b.length - 22; i >= Math.max(0, b.length - 22 - 65536); i--) {
      if (b.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('不是 ZIP（找不到 EOCD）');
    const count = b.readUInt16LE(eocd + 10);
    let off = b.readUInt32LE(eocd + 16);
    const names = new Set();
    for (let k = 0; k < count; k++) {
      if (b.readUInt32LE(off) !== 0x02014b50) break;
      const nLen = b.readUInt16LE(off + 28);
      const eLen = b.readUInt16LE(off + 30);
      const cLen = b.readUInt16LE(off + 32);
      names.add(b.toString('utf8', off + 46, off + 46 + nLen));
      off += 46 + nLen + eLen + cLen;
    }
    return names;
  };
  let entries = null;
  try {
    entries = listZip(VANILLA_JAR);
    ok(`已读取原版 jar 目录（${entries.size} 项）`);
  } catch (e) {
    warn('读取原版 jar 失败：' + e.message + '（跳过这一节）');
  }
  const inJar = (p) => entries != null && entries.has(p);
  const bio = json.structure && json.structure.biomes;
  if (entries != null) {
    if (typeof bio === 'string' && bio.startsWith('#')) {
      const tag = bio.slice(1).replace('minecraft:', '');
      const p = `data/minecraft/tags/worldgen/biome/${tag}.json`;
      if (inJar(p)) ok(`生物群系标签 ${bio} 存在`);
      else fail(`生物群系标签 ${bio} 在原版 jar 里找不到（${p}）`);
    } else if (bio) {
      warn(`biomes 直接写了列表（${JSON.stringify(bio).slice(0, 60)}）—— 无法在此静态核对每个群系 ID`);
    }
    const proc = json.pool && json.pool.elements && json.pool.elements[0]
      && json.pool.elements[0].element.processors;
    if (typeof proc === 'string') {
      const p = `data/minecraft/worldgen/processor_list/${proc.replace('minecraft:', '')}.json`;
      if (inJar(p)) ok(`处理器列表 ${proc} 存在`);
      else fail(`处理器列表 ${proc} 不存在（${p}）`);
    } else if (proc) ok('处理器列表写成了内联对象');
  }
}

console.log('\n' + (bad === 0 ? '✓ 结构数据包自检通过' : `✗ ${bad} 项不通过`));
if (bad > 0) process.exit(1);
