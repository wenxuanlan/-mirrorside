# 镜维度 · 开发说明

Minecraft **1.21.1** + **NeoForge 21.1.250**，基于 **KubeJS 7.2** 的数据包 + 脚本方案。

---

## 0. 设定实现对照（镜维度设定.txt）

| 设定 | 实现方式 | 状态 |
|---|---|---|
| 可建造高度 -192 ~ 191 | `dimension_type.min_y = -192`、`height = 384` | ✅ 已生成 |
| -1/0 为上下界面 | 黑玻璃层 `y ∈ {-2,-1,0,1}`；重力分界 `split_y = 0` | ✅ |
| -64 ~ +63 为镜内，此外为镜外 | `mirror_setting.js` 的 `regionOf(y)` | ✅ |
| 镜面上方正常重力、下方反转 | **Pondus** 的 `setBaseGravityDirection`（方向 + 视角一起转） | ⚠️ 待游戏内验证 |
| 无日夜、自然亮度 | `has_skylight: true` + `ambient_light: 1.0` + `fixed_time: 6000` | ✅ |
| 无任何物块 | 自定义 `mirror:mirror_void` 空地形 | ✅ |
| +63/-64 淡白玻璃、-1/0 黑色玻璃 | 群系内 `minecraft:fill_layer` 地物，**世界生成期**铺设 | ✅ 已生成 |
| 镜外随机旁观者/冒险，回镜内或离开维度恢复 | `setGameMode` + `persistentData` | ⏸ 暂时搁置（见 §10） |

### 实现细节

**空地形**：拿原版 `end` 的 noise_settings 当骨架（末地本身就是"虚空+岛"），把 `noise_router` 全部密度函数设成**裸数字** `0`（数字 = 常数密度函数），`final_density = 0` 即全空气。同时关掉含水层与矿脉，`features` 与 `carvers` 全空。骨架以 gzip+base64 **内嵌在生成器里**，所以 `generate-mirror-pack.mjs` 自包含、不依赖外部文件。

**玻璃层（世界生成，不用脚本）**：用了一个几乎没人用、但正好合用的地物类型：

```
minecraft:fill_layer     配置 { height: int, state: BlockState }
```

它的实现会遍历该区块**全部 256 个 X/Z**，在指定高度 `setBlock`，且**只在目标是空气时写入**：

- **无遗漏** —— 不像 `count` + `in_square` 那样随机撒点、必然留洞
- **不覆盖** —— 你手动放的方块不会被冲掉
- **生成期完成** —— 不需要脚本逐区块补、也不需要玩家靠近
- **零额外开销** —— 替代了原先「每秒 20 个区块 × 4 层 × 256 次」的脚本铺设

`height` 是相对 `min_y` 的偏移（`FillLayerHeight` 用 `getMinBuildHeight() + height`）。生成器按 `mirror_config.js` 的 `layout.glass_layers` 自动为每个 y 产出一份 configured_feature + placed_feature，并挂进群系的第 11 步（`TOP_LAYER_MODIFICATION`）。

**群系**：文件是 `worldgen/biome/mirror.json`，ID 为 `mirror:mirror`。除了玻璃地物之外不生成任何东西。

---

## 1. 现在能做什么

- 一个**独立的自定义维度** `mirror:mirror`，与主世界、下界、末地都没有关联。
- 进去的方式有三种：
  - 搭一座 **3×3×3 传送门**（底层抛光黑石 / 中层 8 格空气 + 中心玻璃 /
    顶层平滑石英），拿**望远镜**右键中心玻璃点燃 —— 传送门与传送逻辑都是
    本模组自己的（§13），不依赖 PortalJS
  - `/mirror tp` / `/mirror back`
  - `/mirror portal` 直接在你面前把门搭好并点燃
- 一个独立的生物群系 `mirror:mirror`，冷色调天空 / 雾 / 水色，不下雨。
- **分界面上下重力相反**：掉落物、下落的方块、生物、玩家都会在交界处反转
  （基于 Pondus + 本模组的补丁，§11）。
- **重力方块加工**：沙子 / 沙砾 / 混凝土粉末 / 铁砧 / 脚手架 / 滴水石锥
  等 26 种方块的 48 条配方 —— 在交界处反复坠落够次数后变成别的东西（§14）。
- **工作台配方**：沙子 / 沙砾 + 发光地衣 → 可疑的沙子 / 可疑的沙砾（无序合成，§15）。
- 所有可调参数集中在**一份配置**里，改完跑一次生成器就能同步到全部文件。

---

## 2. 目录结构

```
.minecraft/versions/镜维度/
├─ mods/                                ← 模组
│  ├─ mirrorgravity-0.1.jar                   ★ 本项目自写的模组（发布名 mirrorside-0.1.jar）
│  ├─ kubejs-neoforge-2101.7.2-build.377.jar
│  ├─ [犀牛] rhino-2101.2.7-build.85.jar      （KubeJS 的 JS 引擎，必需）
│  ├─ pondus-1.0.1.jar                        ← 重力方向反转（见 §11），**必需**
│  ├─ [JEI物品管理器] jei-1.21.1-neoforge-19.51.0.418.jar   （可选，配方查看 §14.8）
│  ├─ [铁砧工艺] anvilcraft-…-1.6.0+snapshot.2327.jar       （可选，粗矿块参与铁砧配方 §14.3）
│  ├─ worldjs-1.21.1-1.1.0.jar
│  ├─ ProbeJS-8.0.3.jar                       （可选，只用来生成补全）
│  ├─ [钠] sodium-… / [钠·扩展] / [铁氧体磁芯] ferritecore    （性能优化）
│  ├─ [鼠标手势] MouseTweaks / better-advanced-tooltips
│  └─ portaljs-1.21.1-1.2.0.jar + cpapireforged      ⚠️ 已不再使用（旧传送门方案已删，可移除）
│
├─ kubejs/
│  ├─ startup_scripts/      ← 只在启动时加载，唯一能给 global 赋值的脚本类型
│  │  ├─ mirror_config.js      运行时配置本体（也是文档）
│  │  ├─ mirror_core.js        读配置、暴露 global.MirrorDimension
│  │  └─ mirror_portal.js      PortalJS 传送门注册
│  ├─ server_scripts/       ← 进世界 / /reload 时加载
│  │  ├─ mirror_n0..n9_*.js    服务端模块（n0 基础 … n5 镜外 / n6 门面 /
│  │  │                        n7 音效 / n8 传送门点燃 / n9 工作台配方）
│  │  └─ mirror_server.js      /mirror 系列指令（Brigadier）
│  ├─ client_scripts/main.js
│  ├─ config/mirror_dimension.json   世界侧配置（只被生成器读）
│  └─ data/mirror/                   ← 生成出来的数据包，勿手改
│     ├─ dimension_type/mirror.json
│     ├─ dimension/mirror.json
│     └─ worldgen/
│        ├─ biome/mirror.json
│        ├─ noise_settings/mirror_void.json
│        ├─ configured_feature/glass_layer_*.json   （8 个）
│        └─ placed_feature/glass_layer_*.json       （8 个）
│
├─ tools/
│  ├─ generate-mirror-pack.mjs   数据包生成器（自包含）
│  ├─ preflight.mjs              启动前静态预检
│  ├─ lint-scripts.mjs           JS 语法 + Rhino 陷阱审计
│  ├─ check-script-api.mjs       脚本 API 白名单检查
│  ├─ check-sound-assets.mjs     音效资源自检（sounds.json → ogg 是否对得上）
│  ├─ sync-jei-recipes.mjs       把配方导出成 jar 内 JEI 数据（改完配方必跑，见 §14.8）
│  ├─ gen-enter-sound.mjs        用 ffmpeg 烘焙进入提示音（响度对齐地狱门）
│  └─ 生成镜维度数据包.bat        双击即可跑生成器
│
└─ README-镜维度.md
```

> 模组工程与它的自检脚本在上一层：`D:\DSHwork\MC镜维度\mirror-gravity-mod`（Java 源码）
> 与 `D:\DSHwork\MC镜维度\tools-build\check-recipes.mjs`、`check-mod-assets.mjs`。

---

## 3. 配置分成两份，各管一半

### 3.1 世界侧（维度本体）

`kubejs/config/mirror_dimension.json` —— **只有数据包生成器读它**。改完必须重跑生成器。

### 3.2 运行时侧（重力、传送门、落点）

`kubejs/startup_scripts/mirror_config.js` —— 脚本运行时读它。**权限更高**：命名空间、路径、玻璃层、重力方向、传送门参数都以这里为准；生成器也会解析它并覆盖世界侧 JSON 里的对应字段。

### 3.3 生效方式速查

| 改了什么 | 怎么生效 |
|---|---|
| `mirror_dimension.json` / 生成器 | 跑生成器 → **退出并重进世界**（改世界生成后 `/reload` 无效，见 MC-187938） |
| `mirror_config.js`（startup） | `/kubejs reload_startup_scripts` 或重启游戏 |
| `mirror_server.js` / `mirror_setting.js`（server） | `/reload` 即可 |

> 世界类型必须保持 **Default**，否则 `dimension/` 目录会被忽略，维度不存在。

---

## 4. 配置项速查

### 4.1 `kubejs/config/mirror_dimension.json`（世界侧）

| 键 | 含义 |
|---|---|
| `namespace` | 命名空间，默认 `mirror` |
| `dimension_path` / `dimension_type_path` / `biome_path` | 三个注册名 |
| `noise_settings_path` | 空地形设置文件名，默认 `mirror_void` |
| `min_y` / `height` | 世界高度范围，默认 `-192` / `384` |

### 4.2 `kubejs/startup_scripts/mirror_config.js`（运行时侧）

| 键 | 含义 |
|---|---|
| `layout.min_y` / `height` | 同上；`height` 必须等于 `dimension_type.height` |
| `layout.inner_min_y` / `inner_max_y` | 镜内范围，默认 `-64` / `63` |
| `layout.split_y` | **重力分界**：`y > split_y` 向下，`y <= split_y` 向上，默认 `0` |
| `layout.glass_layers[]` | 每项 `{ name, ys: [...], block }`，生成器按此产出 fill_layer |
| `layout.maintain_glass` | 脚本兜底铺设，默认 `false`（世界生成已负责） |
| `gravity.enabled` | 重力总开关 |
| `gravity.use_pondus` | 用 Pondus 做真实方向+视角反转，默认 `true` |
| `gravity.region_directions` | `inner` / `outer_upper` / `outer_lower` 各自的方向名 |
| `gravity.entity_scan_interval` | 非玩家实体扫描间隔（tick），默认 `1`（每 tick）。**不要调大** —— 下落的方块依赖它做配方计数 |
| `gravity.item_scan_interval` | **掉落物的方向检测间隔**（tick），默认 `4`（0.2 秒）。只影响 `minecraft:item`；1 = 几乎贴着分界线小幅振荡，调大则越界后多飞一段、摆幅变大 |
| `gravity.item_sync_interval` | **运动中掉落物的位置同步间隔**（tick），默认 `10`（2 包/秒，原版是 20 tick / 1 包）。修"偶发闪现"用的那一档；`1` = 每 tick（漂移归零但包量 20 倍），`20` = 退回原版，`0` = 关闭（闪现回来） |
| `gravity.landing_lookahead` | **接触判定的预判格数**，默认 `1`。landing 类配方每 tick 只看一次，而原生重力下下落实体最快约 2 格/tick，可能一帧跨过"贴着"的瞬间 → 配方静默失效。`1` = 再认"下一 tick 一定会贴上"的那一格；`0` = 关掉（只认当帧真的贴着，见 §14.11） |
| `gravityBlockRecipes.list[]` | 重力方块加工配方（46 条）。字段见 §14.1；`/mirror recipes [关键词]` 可查，JEI 里在「重力方块加工」分类（§14.8） |
| `craftingRecipes.list[]` | **工作台配方**（无序合成 2 条：沙子/沙砾 + 发光地衣 → 可疑方块）。字段见 §15；`/mirror crafting [关键词]` 可查并回读服务端配方表 |
| `gravity.force_direction` / `force_until_tick` | 手动覆盖（游戏里用 `/mirror gravity` 改） |
| `gravity.manage_attribute` | 只有降级方案才置 `true`（见 §11 的红线） |
| `outerRegion.*` | 镜外游戏模式（当前搁置） |
| `mirrorPortal.*` | **镜面传送门**：点燃物品、3×3×3 三层材料、中心玻璃标签、坐标映射区间、到达侧自动建门（见 §13） |
| `entry` | `/mirror tp` 的落点 |

> 旧的 PortalJS 传送门（石英门框 + 打火石）**已删除** —— 它从未真正生效过。
> `mirror_portal.js`、配置里的 `portal.*` 段、`/mirror platform` 指令都已移除。
> §7.3 保留 PortalJS 的三个坑作为历史记录（将来若再用那个模组要注意）。

---

## 5. 为什么用生成器而不是直接手写 JSON

因为一份维度配置要拆成 **4 个注册文件 + 16 个地物文件**才能工作，而且里面有几处「写错就崩」的类型陷阱（见 §7.2）。手写几乎必然出错，所以：

- 全部由 `tools/generate-mirror-pack.mjs` 产出，命名规则、交叉引用、坐标换算都在代码里保证一致。
- 生成器**自包含**：空地形骨架以 gzip+base64 内嵌，不读外部文件。
- 它还会解析 `mirror_config.js`，让运行时配置覆盖 JSON —— 这样两份配置不会打架。

---

## 6. VS Code 与代码补全

装 ProbeJS 后，进游戏执行 `/probejs dump`，会在 `.minecraft/versions/镜维度/probe/` 生成类型定义，然后就能在 `kubejs/` 里获得补全。

`.vscode/settings.json` 建议加：

```json
{
  "files.encoding": "utf8",
  "files.autoGuessEncoding": false
}
```

> ⚠️ 这条不是可选项。见 §12：README 曾经因为写文件时用了系统默认代码页而整份变成乱码。

---

## 7. 排错

### 7.0 ⚠️ 已经踩过并修好的坑：启动器把 NeoForge 装了一半

**症状**：启动时报

```
Missing or unsupported mandatory dependencies ...
Mod ID: 'neoforge'   Actual version: '[MISSING]'
Mod ID: 'minecraft'  Actual version: '[MISSING]'
```

**原因**：PCL 没有把 `net.neoforged:neoforge` 拉下来，`libraries` 里是空的。

**修复**：手动把 `neoforge-21.1.250-universal.jar`（3,551,255 字节）放进 `libraries`。

**然后遇到第二个坑**：

```
ClassNotFoundException: net.minecraft.world.level.block.entity.BlockEntityType
```

**原因**：`versions/镜维度/` 里的那个 version jar 是**未打补丁的原版混淆客户端**（里面只有 26 个 `net/minecraft/*` 类）。正确的应该是 `neoforge-21.1.250-client.jar`（含 1562 个 mc 类）。

**再遇到第三个坑**：

```
java.lang.module.ResolutionException: Module xxx reads more than one module named neoforge
```

**修复**：把 `neoforge-21.1.250-client.jar` 加进 `-DignoreList`，并且**不要**把 `universal` 显式放进 classpath。`tools/launch-dev.mjs` 已经把这套编码好了。

版本 JSON 必须是**继承式**的（`inheritsFrom: 1.21.1`）。

### 7.1 ⚠️ KubeJS 脚本的三个隐形陷阱

**(1) 类过滤器挡住了文件读写**

```
Failed to load Java class 'java.nio.file.Paths': Class is not allowed by class filter!
Failed to load Java class 'java.io.File':     Class is not allowed by class filter!
```

KubeJS 内置的 `kubejs.classfilter.txt`（在 jar 根目录）是一份黑名单，明确拒绝 `java.io`、`java.nio`、`java.net`、`java.lang`（只逐个放行少数类）、`sun`、`asm`、`netty` 等。

**后果**：脚本**没有读文件的手段**。所以运行时配置只能写成 `.js`，不能放 JSON 再读。

**反过来这也说明**：黑名单之外的包（比如 `dinner.dev.pondus`）默认是放行的，所以脚本能直接 `Java.loadClass` 调第三方模组 API。真被拦了就在 `kubejs/classfilter.txt` 里加一行 `+ 包名`。

**(2) Rhino 的 `try` 块 bug**

```js
try { const t = 1; } catch (e) {}   // ✗ InternalError: TypeError: redeclaration of var t
try { var   t = 1; } catch (e) {}   // ✓
```

**`try` 块内部一律用 `var`**，不能用 `const` / `let`。非 try 块里随便用。`tools/lint-scripts.mjs` 会按花括号深度审计这一点。

**(3) server / client 脚本不能给 `global` 赋值**

```
'global' cannot be assigned to in client or server scripts
```

非 startup 脚本拿到的是 `GlobalUnmodifiableMap`；一旦赋值，**整个文件**加载失败，里面的指令和事件全部静默失效。

- 需要跨脚本共享 → 在 **startup** 脚本里挂 `global.xxx`
- server 脚本要读 → 读 `global.xxx` 没问题
- server 脚本要**写** → 改 `global.xxx.某属性` 可以（改属性不是重新赋值），本项目就是用 `global.MirrorDimension.runtime` 这个共享容器做的

### 7.2 ⚠️ 崩溃实录：noise_settings 的两个字段类型陷阱

**症状**：创建或进入世界直接崩，日志里是

```
Failed to load registries due to above errors
```

真正的根因在更上面两行：

```
Not a JSON object: []
Not a number
No key argument in MapLike[{"type":"minecraft:constant","value":0}]
```

**含义**：

| 写法 | 结果 |
|---|---|
| `"surface_rule": [...]` | ✗ `Not a JSON object: []` —— 它必须是**对象** |
| `"noise_router": { "final_density": {"type":"minecraft:constant","value":0} }` | ✗ `Not a number` —— 密度函数要写**裸数字** |
| `"surface_rule": {"type":"minecraft:block","result_state":{"Name":"minecraft:air"}}` | ✓ |
| `"noise_router": { "final_density": 0 }` | ✓ |

一个 649 字节的文件能崩掉整个注册表加载，而且报错位置和真正出错的字段隔了很远。`tools/preflight.mjs` 现在会专门检查这两条。

### 7.3 ⚠️ PortalJS 的三个反直觉行为

**(1) 不要调 `register()`**

```
Cannot find function register in object ...PortalMaker
Cannot find function registerPortal in object ...PortalMaker
```

PortalJS 的 `register()` 标了 `@HideFromJS`，`PortalMaker` 会在创建时就自动注册。

**(2) `setDestination` 必须在 `frameBlock` 之前**

```
Destination dimension is unset for portal frame
```

**(3) 残留的探测脚本会污染静态注册表**

```
Error registering portal for an unset frame
```

调试用的临时脚本如果建了没配好的 `PortalMaker`，它会留在 PortalJS 的静态 `createdPortals` 里，后续每次注册都报错。删干净再跑。

正确写法（见 `mirror_portal.js`）：

```js
PortalEvents.create(event => {
  event.create('mirror_gate')
    .setDestination(...)   // 必须在前
    .frameBlock(...)
    .lightWithItem(...)
});
```

### 7.4 ⚠️ `/mirror` 指令"不存在"的原因

一开始用的是 `ServerEvents.command('mirror', ...)`。它是 `TargetedEventHandler<String>`，匹配的是 `event.commandName` —— 而 `commandName` 来自 Brigadier 解析出的第一个节点。**如果 `mirror` 从未注册进指令表，`/mirror tp` 连解析都过不去，`commandName` 就不是 `'mirror'`，处理器永远不触发。**

表现就是"指令不存在"，而且完全没有报错。

**正确做法**：`ServerEvents.commandRegistry`，直接往 Brigadier 注册：

```js
ServerEvents.commandRegistry(event => {
  event.register(LiteralArgumentBuilder.literal('mirror')...);
});
```

`mirror_server.js` 里的 `ServerEvents.loaded` 自检会直接检查 Brigadier 指令表，注册成功会打印：

```
[镜维度] 指令表自检通过，已注册: mirror, mirrortp, mirrorback, mirrorinfo
```

### 7.5 其他现象

| 现象 | 原因 |
|---|---|
| 改了玻璃层但游戏里没变 | 只影响**新生成**的区块；旧区块已经有了就不会改 |
| 改了维度配置没生效 | 改世界生成必须**退出并重进世界**，`/reload` 不够（MC-187938） |
| 维度整个不存在 | 世界类型不是 Default，`dimension/` 被忽略 |
| `/mirror gravity` 说"未就绪" | `mirror_setting.js` 加载失败，看 `logs/kubejs/server.log` 第一处报错 |

### 7.6 每次改动后建议跑的检查

```powershell
cd "D:\DSHwork\MC镜维度\.minecraft\versions\镜维度"
node tools\lint-scripts.mjs        # JS 语法 + try 块 const/let + global 赋值
node tools\check-script-api.mjs    # 脚本根符号是否都在 KubeJS 全局表里
node tools\check-sound-assets.mjs  # sounds.json 引用的 ogg 是否存在
node tools\verify-modules.mjs      # 模块接线（n0..n8 引用是否都能解析）
node tools\generate-mirror-pack.mjs # 重新产出数据包
node tools\preflight.mjs           # 依赖核对 + 数据包字段类型 + 地物链交叉引用
node tools\sync-jei-recipes.mjs    # 配方改了就必须跑（否则 JEI 显示与实际脱节）
node ..\..\..\tools-build\check-recipes.mjs      # 配方表逐条自检
node ..\..\..\tools-build\sim-recipes.mjs        # 在 Node 里真跑一遍配方引擎（不启动游戏）
node ..\..\..\tools-build\check-mod-assets.mjs   # 模组资源自检
```

**改了配方**（`mirror_config.js → gravityBlockRecipes`）还要重新构建模组：

```powershell
cd "D:\DSHwork\MC镜维度\mirror-gravity-mod"
.\gradlew.bat build --no-daemon
copy build\libs\mirrorside-0.1.jar "..\.minecraft\versions\镜维度\mods\mirrorgravity-0.1.jar"
```

`tools/verify-launch.mjs` 和 `tools/verify-world.mjs` 会**启动游戏**，只在需要自动化实测时用。

---

## 8. 版本兼容红线（1.21.1 专用，别照抄高版本文档）

- `carvers` 是**对象**，不是数组
- `features` 是 **11 层嵌套数组**（对应 11 个 GenerationStep）
- `music` 是**单个对象**，不是数组
- **没有** `cloud_height`、`attributes`、`skybox`、`music_volume`、`dry_foliage_color`
- `pack_format` 无所谓 —— KubeJS 会用自己那套

---

## 9. 已知限制

- `kubejs/data/` 里的数据包**总是**会被加载，不用额外声明。
- `kubejs/config/` 是脚本唯一可写的目录。
- 玻璃层只在**新生成**的区块出现。
- KubeJS 对 `ServerPlayer` 做了包装，原版方法名不一定可用：

  | 方法 | 可用 |
  |---|---|
  | `player.getGameModeForPlayer()` | ✗ `Cannot find function` |
  | `player.setGameModeForPlayer(gt)` | ✗ |
  | `player.setGameMode(GameType)` | ✓ |
  | `player.gameMode.getGameModeForPlayer()` | ✓ |

  写错会让整个 `PlayerEvents.tick` 处理器中断，后续逻辑（含 `persistentData` 写入）全部失效 —— 表现就是"什么都不生效"，排查时先看这条。

---

## 10. 搁置项：镜外游戏模式

`mirror_setting.js` 里已实现「进入镜外随机切旁观者/冒险，回到镜内或离开维度时恢复」，由 `cfg.outerRegion.enabled` 控制。当前按用户要求**暂时不管**这一块，先专注重力。

---

## 11. 重力反转：为什么必须用模组

### 11.1 原版属性不够用

原版只有 `minecraft:generic.gravity` 这个属性（默认 `0.08`）。把它设成 `-0.08` 确实能让实体"往上掉"，但：

- **相机朝向不变** —— 你看到的还是正着的世界
- **玩家模型不变**
- **碰撞盒朝向不变** —— 脚还算在下面

结果就是"人倒着飘起来"，完全不是"进入了一个重力反过来的世界"。实测确认过：y 从 20 涨到 29，但视角纹丝不动。

要真正做到"脚下换到另一边"，必须同时改**实体上方向量、移动逻辑、碰撞盒朝向**，以及客户端的**相机和渲染**。这些都在客户端/渲染层，**KubeJS 碰不到**（脚本没有渲染钩子）。所以只能靠模组。

### 11.2 Pondus

- **Pondus 1.0.1**，NeoForge 1.21.1，`mods/pondus-1.0.1.jar`
- 官方描述：*Custom gravity API for Minecraft, fork of "Gravity Changer Unofficial Port"*
- 源码：<https://github.com/dinnermc/Pondus>（CC-BY-NC-SA-4.0）
- **自足**：内嵌 cloth-config 15.0.140（jarJar），**不需要**额外下载前置

它提供了：

| 能力 | 说明 |
|---|---|
| 完整 3D 重力方向 | 六个正交方向 + 相对视角方向 |
| 相机一起转 | 客户端 `CameraMixin` + `CameraMixinNeoForge` |
| 渲染一起转 | `GameRendererMixin`、`EntityRenderMixin`、`PlayerEntityRendererMixin` |
| 物理一起转 | `LivingEntityMixin`、`EntityMixin`、碰撞盒朝向 |
| 按实体设置 | `PondusAPI.setBaseGravityDirection(entity, Direction)` |
| 按维度设强度 | `setDimensionGravityStrength(level, double)` |
| 指令 | `/gravity set_base_direction <方向> [实体]`（权限等级 2） |
| 重力效果 | `up` / `down` / `invert` 等状态效果与药水 |
| 旋转过渡 | 客户端配置 `rotationTime`（相机转场时长）、`keepWorldLook` |

**作用对象**由 Pondus 的 `EntityTags.canChangeGravity` 决定：

- **一律可以**：`LivingEntity`（玩家、怪物、动物）、`Projectile`（箭、雪球、末影珍珠）、`Minecart`
- **白名单**（`data/pondus/tags/entity_types/allowed_special.json`）：`falling_block`（沙子/沙砾/混凝土粉末）、`item`（掉落物）、`tnt`、`eye_of_ender`、`experience_orb`

所以「玩家 + 生物 + 重力方块」是**自动全覆盖**的，不需要我们逐个处理。

### 11.3 本项目的接法

`mirror_setting.js` 里：

1. 玩家**每 tick** 判一次方向（很便宜：一次读取，不一致才下发）
2. 其余实体按 `entity_scan_interval`（默认 **1** tick，即每 tick）扫一次镜维度的实体列表
   - **掉落物例外**：按 `item_scan_interval`（默认 **4** tick，0.2 秒）判一次方向。
     掉落物不做加工、不参与配方计数，方向判定的实时性只影响自己的振荡幅度，
     所以低频处理以省掉大部分重复的模组调用；下落的方块必须每 tick 判，两者不能共用一档。
     **首次判定不受间隔限制**（刚丢出来的会立刻判一次）
3. 方向由 `y` 与 `layout.split_y`（默认 `0`）比较得出：
   - `y > 0` → `outer_upper` → `down`
   - `y <= 0` → `outer_lower` → `up`
4. 只有「应有方向 ≠ 当前方向」时才真的调 `setBaseGravityDirection`
5. 离开镜维度时调 `resetGravity` 还原，避免把反转重力带去主世界

### 11.4 ⚠️ 红线：两个方案不能同时开

**用 Pondus 时，`minecraft:generic.gravity` 必须保持默认 `0.08`。**

否则：属性把重力反成向上 **+** Pondus 把方向反成向上 = **双倍上浮**。

所以配置里 `gravity.manage_attribute` 默认 `false`。只有在 Pondus 缺失、不得不降级时，才把它置 `true`（此时 `use_pondus` 也应为 `false`）。

降级方案仍然"能用"——实体确实会往上掉——但**视角不会转**，不是想要的效果。

### 11.5 游戏内验证步骤

**第一步：先用 Pondus 自己的指令做对照测试**（不经过我写的任何代码）

```
/gravity set_base_direction up @s
```

这条指令是 Pondus 自带的。如果执行后**视角真的翻转了**，说明 Pondus 功能正常，
问题一定在我们的脚本侧；如果**毫无反应**，那才是 Pondus 真的不可用。

```
/gravity view        → 看它自己报告的当前方向
/gravity reset @s    → 还原
```

**第二步：看我们脚本的状态**

```
/mirror gravity      → 一次性输出实现方式、Pondus 读数、判定结果、扫描统计
```

重点看三行：

| 行 | 期望 | 不对时说明什么 |
|---|---|---|
| `实现方式` | `Pondus（方向 + 视角一起转）` | 若显示「自动降级」，说明 Pondus 写入失败 |
| `判定结果` | `是重力候选=是` | 若为「否」，说明实体类没加载成功 |
| `Pondus读取` | `base` 与「应有方向」一致 | 若不一致，说明 `setBaseGravityDirection` 写不进去 |

**第三步：走一遍完整流程**

```
/mirror tp            → 进镜内 y=20
飞到 y < 0            → 穿过分界线时相机应自动转 180°
/mirror back          → 回主世界，重力应恢复正常
/mirror sound         → 就地试听"穿过镜面"的提示音（紫水晶钟声 + 回响）
```

**听音效：进入提示音（已烘焙，响度对齐原版地狱门）**

进入镜维度时会响一次提示音，事件是模组自带的
**`mirrorgravity:block.mirror_enter`**，音频文件在
`mirrorside-0.1.jar → assets/mirrorgravity/sounds/mirror/enter_echo.ogg`。

它是用 `tools/gen-enter-sound.mjs`（配合 `D:\App\ffmpeg`）离线烘焙出来的：

| 内容 | 说明 |
|---|---|
| 4 层合唱 | 原版紫水晶钟声复制 4 份，各调 ±3% 音高、错开 0~34 ms |
| 回响 | 8 抽头多抽头延迟，左右两路抽头时间不同 → 立体声宽度 |
| 长度 | 8.00 秒，最后 2 秒淡出 |

**为什么非烘焙不可**（ffmpeg `ebur128` 实测）：

| 音效 | 积分响度 | 真峰值 |
|---|---|---|
| 原版紫水晶钟声 `shimmer.ogg` | **−44.7 LUFS** | −29.3 dBFS |
| └ 原版还给它写了 `"volume": 0.2`（再压 14 dB） | −58.7 | −43.3 |
| 原版地狱门 `portal/travel.ogg` | **−13.0 LUFS** | −0.7 dBFS |
| └ 播放音量 0.25 → **有效 −25.0 LUFS** | −25.0 | −12.7 |
| **本次生成 `enter_echo.ogg`** | **−21.6 LUFS** | −11.0 dBFS |

两边原本差 30 dB 以上，运行时"叠 4 层"最多补 12 dB —— 怎么叠都不够，必须改文件。
成品由**原版客户端自己的解码器**（`net.minecraft.client.sounds.JOrbisAudioStream`）
验过：44.1 kHz / 立体声 / 8.00 秒，可正常解码。

**响度定标 = 原版地狱门 +3.4 dB**（−21.6 LUFS）。这个数是量出来的：
用 `/mirror sound 2` 试听后选定的"叠两份"大小 —— 而叠两份的实际提升取决于
两份拷贝的音高差（完全相干 +6 dB；带 ±3% 抖动去相关则 +3 dB），
按分布加权约 **+3.5 dB**，取 −21.5 为目标、实测落在 −21.6。

**归哪根滑块管**：`source: 'ambient'` → **设置 → 音乐和声音 → 环境**。
这与原版地狱门**完全同一根滑块** —— 原版是用
`SimpleSoundInstance.forLocalAmbience(PORTAL_TRAVEL, pitch, 0.25F)` 播的，
`forLocalAmbience` 内部就是 `SoundSource.AMBIENT`。

⚠️ **模组 sounds.json 里 `name` 必须写全命名空间**（踩过一次，游戏里表现为完全没声音）：

```json
"sounds": [ { "name": "mirrorgravity:mirror/enter_echo" } ]   ← 正确
"sounds": [ { "name": "mirror/enter_echo" } ]                 ← 错！会被当成 minecraft
```

原版 `SoundManager#prepare` 里，JSON 的**键**（事件名）用资源包命名空间补全，
但每条音效的 **`name` 字段**走 `ResourceLocation` 默认规则 —— 不带冒号就是 `minecraft`，
于是客户端去找 `minecraft:sounds/mirror/enter_echo.ogg`，找不到就把这条丢掉，
事件变成空的，日志里是：

```
File minecraft:sounds/mirror/enter_echo.ogg does not exist, cannot add it to event mirrorgravity:block.mirror_enter
Unable to play empty soundEvent: mirrorgravity:block.mirror_enter
```

服务端这边一切正常（playSound 调用成功、指令回执是成功），只有客户端两行 WARN ——
所以这种问题只能靠日志发现。`tools/check-sound-assets.mjs` 专门查这个
（含"KubeJS 配置引用的音效事件是否有来源"），改动音效后请先跑它。

想改响度：改 `tools/gen-enter-sound.mjs` 顶部的 `TARGET_LUFS`（默认 **−21.5**，
即原版地狱门 +3.5 dB）后重跑，脚本会打印对齐验收表；重新构建模组 jar 即可。
临时试听更响的效果：`/mirror sound 2`（叠 2 份 ≈ +3 ~ +6 dB，取决于音高差）。

⚠️ **`volume` 调到 1 以上不会更响**。原版客户端在 `SoundEngine.play` 里：
`f2 = clamp(volume × 分类音量, 0, 1)` —— 实际增益被夹到 1.0（写 2.4 与写 1.0 一样响）；
`f1 = max(volume, 1.0) × 衰减距离` —— volume > 1 只把可听半径从 16 格拉到 `volume × 16` 格。
而且 `volume > 1` 还会把滑块架空（滑块要拉到 `1/volume` 以下才开始起作用）。

`mirror_config.js → sound.enter` 其余字段（`stack` / `taps` / `pitch` 等）是给
**换回原版音效**这条备用路径用的：把 `event` 改成
`minecraft:block.amethyst_block.chime`、`stack` 改成 4、恢复注释里的那组 `taps`，
就回到"运行时叠加 + 运行时回响"的旧行为（响度会明显更低）。

不穿门就能试听：`/mirror sound`。音效报错统一带 `[镜维度·音效]` 前缀 —— **不会**再被静默吞掉。

### 11.6 ⚠️ 五个 KubeJS 语义陷阱（都踩过，都是"零报错静默失效"）

**(1) 绝对不要自己做"这个实体要不要处理"的类型判断**

这是**最坑的一个**。原先为了省性能，用 `Java.loadClass` 拿到 `LivingEntity`、
`Projectile`、`FallingBlockEntity` 等类的 `Class` 对象，再：

```js
cls.isInstance(entity)   // ← 在 Rhino 里恒为 false，且异常被 try 吞掉
```

后果：`applyGravityTo` 对所有实体直接 `return`，**一次都没调用过 Pondus**。
表现就是「重力完全不生效，日志里一条错都没有」，而 Pondus 自带指令
`/gravity set_base_direction up @s` 却完全正常 —— 因为那条路不经过这个判断。

**结论**：要不要处理某个实体，交给 `PondusAPI.setBaseGravityDirection`
（它内部有 `canChangeGravity` 白名单）。我们只负责**调用 + 回读确认**：

```js
PONDUS.API.setBaseGravityDirection(entity, want);
var after = PONDUS.API.getBaseGravityDirection(entity);   // 回读，确认写进去了
```

凡是「本地判断 + 静默 return」的写法都要警惕：它会把功能整个挡掉却不留痕迹。

**(2) 不要用 `sendSuccess(() => Text.xxx(), false)`**

`CommandSourceStack.sendSuccess` 有多个重载，其中一个是
`sendSuccess(Supplier<Component>, boolean)`，而 KubeJS 的 `Text` 恰好实现了
`Supplier`，Rhino 在重载消歧时又会退到 `Object` 那个重载，结果把 lambda
**直接 toString 发进聊天栏** —— 玩家看到的就是满屏 `ArrowFunction (0) => {...}`。

**(3) 更别用 `Text.gray('a') + Text.white('b')` 拼富文本**

KubeJS 的 `Text` 走 **MiniMessage 解析**。这些工厂方法拼出来的东西送进聊天栏
会变成**未渲染的字面量**：

```
{style=color=white}literal{实现方式：[style=color=gray]literal{...}
```

比纯文本还难读（实测截图确认）。

**正确做法**：整条输出链只用**原版文本组件**。

```js
var Component = Java.loadClass('net.minecraft.network.chat.Component');
player.tell(Component.literal('纯文本'));                       // 无样式
player.tell(Component.literal('黄字')
  .copy().withStyle(Java.loadClass('net.minecraft.ChatFormatting').YELLOW));
```

`mirror_server.js` 里的 `txt()` / `colored()` 就是这两个包装。
要颜色就整行一个颜色，不做富文本拼接。

**(4) 不要用 `server.getLevel(ResourceKey)`，也别用
`getAllLevels()` + `lv.dimension().location()`**

前者报重载歧义：

```
InternalError: The choice of Java method
net.minecraft.server.MinecraftServer.getLevel matching JavaScript argument types
(net.minecraft.resources.ResourceKey) is ambiguous
```

后者更阴 —— `lv.dimension().location()` 这条链式调用在 Rhino 里**会抛异常**，
被外层 `try` 吞掉之后整个扫描器**一次都没跑成**。表现是
**「只有玩家能反转，羊/沙砾/掉落物全都不动」**，日志里只有零星几条报错。

**正确做法**：从已在镜维度里的玩家身上取那一层 ——
`player.level.dimension` 这个写法在玩家逻辑里已经验证可用。

```js
var players = server.getPlayerList().getPlayers();
// 找第一个 player.level.dimension === 'mirror:mirror' 的，取其 .level
```

**(5) 事件处理器里，嵌套块内一律用 `var`，不要用 `const` / `let`**

KubeJS 的事件处理器（`PlayerEvents.tick` / `ServerEvents.tick` / …）是被
**Java 接口代理**回调进来的。这条调用路径下：

| 写法 | 结果 |
|---|---|
| 处理器函数体**顶层**的 `const` / `let` | 正常（同一个处理器里跑上万次都没事） |
| 处理器里**嵌套块（`if` / `for` / `try`）内**的 `const` / `let` | **每次调用都抛** `TypeError: redeclaration of var xxx` |
| **普通函数**里嵌套块的 `const` / `let` | 正常（`applyGravityTo` 里那些 `const N3` 就是活证据） |
| **脚本顶层**块里的 `const` / `let` | 也抛 |

后果特别隐蔽：异常只在回调里抛出，**不会**让脚本加载失败，KubeJS 依旧显示
`0 errors`。实测现场是 `mirror_n4_gravity.js` 的 `PlayerEvents.tick`：

```js
if (!inMirror) {
  const N5o = moduleRef('n5');           // ← 这行抛异常
  if (N5o != null && N2.outerOn) N5o.leaveOuter(player);   // ← 从此再没执行过
  return;
}
```

日志里刷了 36 条 `redeclaration of var N5o`，而设定里
「在镜外传送到其他世界时恢复原模式」这条**从未生效过** ——
用户看到的功能却是"正常"的。

**兜底**：`tools/lint-scripts.mjs` 有「事件处理器内嵌套块 const/let 审计」，
只扫处理器范围、只报比处理器体更深的声明，不会误伤普通函数；
`--fix` 可把这批 `const`/`let` 就地改成 `var`。
（同一个 Rhino bug 的另一个表现是「`try` 块内的 `const`/`let`」，见同文件另一节。）

### 11.7 交界处防抖：迟滞带 + 确认停留

站在分界线附近时，`y` 在 `split_y` 上下微抖，方向会来回翻，
相机跟着 180° 反复旋转，根本没法操作。两个措施配合：

| 措施 | 作用 |
|---|---|
| **迟滞带** | 已朝上时要离开 `split_y + zone` 才切回朝下，反之亦然。带内维持原方向 → 站在线上不会抖 |
| **确认停留** | 想翻到对面，必须在对面**连续停留** `flip_gap` tick；中途回到原来那边就重新计时、不翻 |

#### ⚠️ 为什么不是"两次反向至少隔 N tick"

最初用的是"冷却间隔"，结果**完全无效**（实测 `/mirror gravity` 里
`被防抖挡下 = 0 次`）。因为那种冷却管不住**慢速来回穿越**：
如果你每 1 秒出头穿越一次边界，每次都刚好过了冷却，
结果变成**每秒翻一次**，照样晕。

"确认停留"就解决了这个问题：来回快速穿越时，`pendingFlip` 计时不断被重置，
**根本不会翻**；只有真正走过去并留下来才会翻。

#### 快速实体的特殊处理

下落的方块（沙砾/沙子）和掉落物**横向不可控、下落很快**。
如果对它们也用"3 秒确认"，它们还没确认完就已经穿过分界线飞走了 ——
表现就是「重力方块从不反转」（实测踩过）。

所以单独配一组很短的参数，并且判断方式用**「没有 `minecraft:generic.gravity`
属性」**来识别这类实体（生物/矿车都有该属性，`FallingBlockEntity` 没有）：

```js
falling_dead_zone: 0.3,   // 窄，尽快响应
falling_flip_gap: 4,      // 只需停留 0.2 秒
```

同时 `entity_scan_interval` 默认改成 **1**（每 tick 扫）——
间隔大了沙子会在两次扫描之间就落地，同样会漏掉。
`getEntities()` 只是返回一个已维护的列表，每 tick 遍历开销极小，
而且只有方向不一致时才会真的下发。

#### 玩家和其他实体分开配

```js
player_dead_zone: 0.25,   // 玩家：带窄，手感优先
player_flip_gap: 20,      // 玩家：停留 1 秒
entity_dead_zone: 1.5,    // 其它实体：带宽，省得一群羊集体抽搐
entity_flip_gap: 60,      // 其它实体：停留 3 秒
```

### 11.8 已知限制：水不能向上流

水流是**方块流体**，走 `FlowingFluid` 那套逻辑，**不是实体**。
Pondus 管的是实体（`canChangeGravity` 白名单：生物 / 弹射物 / 矿车 /
下落的方块 / 掉落物 / TNT / 末影之眼 / 经验球），**完全不涉及流体**。

要让水在反转区往天花板流，需要重写流体扩散逻辑，那属于自研模组的工作量，
而且会和原版流体渲染/刻度强耦合。当前**不做**，如需再说。

### 11.9 Pondus 源码审查结论（下落的方块 / 掉落物为什么不反转）

为查清"沙砾和掉落物不反转"，把 Pondus 源码过了一遍。

#### 已确认没问题的部分

| 检查项 | 结论 |
|---|---|
| 重力数据挂载 | `EntityMixin` 用 `@Inject(method="<init>", at=@At("RETURN"))` 给**每个** `Entity` 挂 `EntityGravityData` → 非生物也有 |
| 白名单 | `EntityTags.canChangeGravity` 允许 `LivingEntity`/`Projectile`/`Minecart`，外加 `allowed_special` 标签；该标签里**确实含** `minecraft:falling_block` 与 `minecraft:item` |
| 强度缩放 | `EntityMixin.injected` 对 `Entity.getGravity()` 做 `* getGravityStrength()` |

所以**不是**白名单问题，也不是数据没挂上。

#### 关键发现：重力**方向**的处理几乎全挂在生物专有方法上

`LivingEntityMixin` 处理重力方向的位置：`travel()`（4 处 `@Redirect`）、
`tick()`、`playBlockFallSound`、`hasLineOfSight`、`getLocalBoundsForPose`、
`hurt`、`calculateFallDamage`、`calculateEntityAnimation` …

**`travel()` 是 `LivingEntity` 专有的**，而
**`FallingBlockEntity` 和 `ItemEntity` 都不是 `LivingEntity`**。
对它们只有 `EntityMixin` 那层通用处理：
`move()`（3 处 `@ModifyVariable`）、`collide()`/`collideBoundingBox`、
`makeBoundingBox`、`calculateViewVector`。

并且 `pondus.mixins.json` 里**没有任何针对 `FallingBlockEntity` 的 mixin**，
它完全依赖通用 `EntityMixin`。

#### 尚未确证的一环（已加取证日志）

`FallingBlockEntity.tick()` 与 `ItemEntity.tick()` 是**自己算重力、自己移动**的，
和 `LivingEntity.travel()` 路径完全不同。它们是否经过 `Entity.move()`
（Pondus 唯一能给它们处理方向的地方），需要反编译补丁后的 Minecraft 类才能确认。

本机**没有** Minecraft 的 Gradle 映射缓存，NeoForge 补丁类也只在运行时存在，
无法离线反编译。为此加了**快速实体取证日志**
（`[镜维度·快速实体取证]`，记录 `want / base / cur / vel`），一测即可判定：

- `base` 一直是 down → **API 层就不接受这类实体**
- `base` 变成 up 但 `vel` 一直为负 → **实体自己在往下加速**，
  Pondus 的方向处理没覆盖到它的移动路径

#### 可选方案（待你决定，尚未实现）

1. **自研 NeoForge 小模组**：给 `FallingBlockEntity`/`ItemEntity` 加专门 mixin，
   在自己的 tick 里按重力方向旋转速度。与 Pondus 同层的做法，最干净。
   需与你已有的 KubeJS 代码**独立打包**。
2. **脚本补丁**：在实体 tick 里手动旋转 `deltaMovement`，走 Pondus 已有的
   `RotationUtil`。改动小；但会与 Pondus 自身物理叠加，属打补丁而非根治。
3. **接受限制**。

### 11.10 Pondus 的血统（可放心使用）

`dinner.dev.pondus` 是 **GravityChanger** 的后代：源码里保留了原作者的署名
（`@author qouteall`）和 `gravity_changer.command.*` 的翻译键。GravityChanger
是 Fabric 上久经使用的重力方向模组，Pondus 是它面向 NeoForge 的移植/重写。

实测（2026-09-18 日志）：**49 个 mixin 全部注入成功**，含
`CameraMixin`、`CameraMixinNeoForge`、`GameRendererMixin`、`PlayerEntityRendererMixin`、
`EntityMixin`、`LivingEntityMixin`；零 WARN/ERROR；并生成了自己的 `config/pondus.json`。

它在 Modrinth / MC 百科上检索不到，只是因为作者没有发布到那些平台，
不代表模组不可用。**2026-09-19 已实测确认**：`/gravity set_base_direction up @s`
能正常翻转玩家的重力与视角。

---

## 12. ⚠️ 文件编码：README 曾整份变成乱码

**现象**：README 在编辑器里显示成 `# 闀滅淮搴?路 寮€鍙戣鏄?` 这样的乱码，但文件本身是合法 UTF-8（没有替换字符）。

**原因**：写文件时用了系统默认代码页（GBK/936）。内容先被 UTF-8 编码，又被按 GBK 解读，最后再存成 UTF-8 —— 三重错位。

**后果**：这不是显示问题，**文件内容真的坏了**。逆推（UTF-8 解码 → GBK 编码 → UTF-8 解码）只能救回一部分，因为映射到非法 GBK 序列的字节已经永久丢失（实测 456 个字符无法还原）。只能重写。

**预防**：

- 用文件工具（而不是 shell 重定向）写含中文的文件
- 必须用 shell 时显式指定编码，例如 `Set-Content -Encoding UTF8`
- VS Code 里设 `"files.encoding": "utf8"`、`"files.autoGuessEncoding": false`

**排查命令**（检查任意文件的编码健康度）：

```powershell
$t = [System.IO.File]::ReadAllText($p, [System.Text.Encoding]::UTF8)
([regex]::Matches($t, [char]0xFFFD)).Count   # > 0 说明有不可逆损坏
```

---

## 13. 镜面传送门（3×3×3 结构 + 望远镜点燃）

### 13.1 设定原文

> 传送门整体是 3\*3\*3 大小。最下面一层 3\*3 是磨制黑石，最上面一层 3\*3 是平滑石英块。
> 中间一层的中心一格为玻璃（任意，只需要有玻璃标签），周围八格为空气。
> 传送门结构成形后，用望远镜右键中间的玻璃，玻璃变为一个传送门方块。
> 这时上下两层的磨制黑石和平滑石英块就不是必要的了。
> 它不能被玩家用工具挖掘，但是可以在创造模式下打掉。也可以被爆炸炸掉。
> 样子就做成黑白光彩变换的透明状态。

### 13.2 原版传送门机制（调研结论，1.21.1 源码）

**地狱门不是一个"特殊的方块"，而是"一个实现了 `Portal` 接口的普通方块"。**
整条链路是：

| 环节 | 原版代码 | 说明 |
|---|---|---|
| 方块声明 | `NetherPortalBlock extends Block implements Portal` | 接口在 `net.minecraft.world.level.block.Portal` |
| 进入判定 | `entityInside` → `if (entity.canUsePortal(false)) entity.setAsInsidePortal(this, pos)` | 只要实体包围盒与方块相交就会调 `entityInside`，**与方块是否可碰撞无关** |
| 计时 | `PortalProcessor.processPortalTeleportation` | 站在门里 `portalTime++`，离开时每 tick **衰减 4**；达到 `getPortalTransitionTime()` 才传 |
| 延迟 | `getPortalTransitionTime(level, entity)` | 玩家取 gamerule（生存 80 tick / 创造 1 tick），非玩家 0 |
| 传送 | `getPortalDestination(level, entity, pos)` → `DimensionTransition` | 由 `Entity#handlePortal` 调 `entity.changeDimension(...)` 执行 |
| 冷却 | `Entity#setPortalCooldown` | 传送后自动上冷却：**玩家 10 tick**（`Player#getDimensionChangingDelay`）、其它实体 300 |
| 表现 | `getLocalTransition()` = `CONFUSION` | 就是站在地狱门里那种屏幕扭曲（恶心感） |

`DimensionTransition` 是个 record：

```java
record DimensionTransition(ServerLevel newLevel, Vec3 pos, Vec3 speed,
                            float yRot, float xRot, boolean missingRespawnBlock,
                            PostDimensionTransition postDimensionTransition)
```

`postDimensionTransition` 是"落地之后做什么"，原版提供两个现成的：
`PLAY_PORTAL_SOUND`（给玩家发 1032 号关卡事件 = 传送音效）与
`PLACE_PORTAL_TICKET`（在落点放区块票据，保证目的地是加载的），
可以用 `.then(...)` 组合。

**⚠️ `PortalForcer` 不能用于本项目。** 它是地狱门专用的：
`findClosestPortalPosition` 只找 `NETHER_PORTAL` 兴趣点，
找不到就调 `createPortal` **现场盖一座黑曜石门**。
拿它给镜维度找出口，结果是主世界里凭空出现黑曜石地狱门。

### 13.3 可用 API（本项目环境实测）

| 候选 | 结论 |
|---|---|
| **自研模组（Java）** | ✅ 传送门方块必须是它 —— 自定义方块、`Portal` 接口、`BlockState#is(TagKey)` 都只有 Java 能做 |
| **KubeJS `BlockEvents.rightClicked`** | ✅ 点燃触发用它。KubeJS 这个事件挂的是 NeoForge 的 `PlayerInteractEvent.RightClickBlock`，它由 `ServerPlayerGameMode#useItemOn` **开头**触发，所以**手持望远镜右键方块照样会触发**（望远镜的"开镜"是物品 `use` 行为，发生在方块交互之后） |
| **NeoForge `UseItemOnBlockEvent`** | ⚪ 可用（由 `ItemStack#useOn` / `BlockBehaviour#useItemOn` 触发），但 KubeJS 那条更省事，就没用 |
| **PortalJS** | ⚪ 只能做"门框 + 点火物品"式的门（已有 `portal.*` 那套），不支持自定义门方块与自定义点燃条件 |
| **玻璃标签** | ✅ 用 NeoForge 通用标签 **`c:glass_blocks`**（聚合 `colorless`/`cheap`/`tinted`），原版所有玻璃与其它模组登记的玻璃都在里面，不用自己维护清单 |

### 13.4 实现结构

| 文件 | 职责 |
|---|---|
| `MirrorPortalBlock.java` | 传送门方块：`entityInside` → `setAsInsidePortal`；`getPortalTransitionTime` / `getPortalDestination` / `getLocalTransition`；坐标映射；客户端粒子 |
| `MirrorPortalShape.java` | 3×3×3 结构校验 + 点燃 + **到达侧自动建门**、建门避让玻璃层、错误码文案 |
| `MirrorPortalOverlay.java` | **客户端**：站在门里时的渐现遮罩（用本方块贴图，见 §13.9） |
| `MirrorBlocks.MIRROR_PORTAL` | 注册方块（属性见 §13.5） |
| `MirrorGravityApi` | 给脚本的口子：`tryIgniteMirrorPortal` / `describePortalResult` / `setMirrorPortalTarget` / `setMirrorPortalStructure` / `setMirrorPortalBuildArrival` / `setMirrorPortalAvoidY` |
| `mirror_n8_portal.js` | 触发：判断手持物品 → 调用点燃 → 把状态码翻成中文提示 |
| `tools/gen-portal-texture.mjs` | 生成黑白流光**动态贴图**（32 帧，见 §13.6） |
| `mirror_config.js → mirrorPortal` | 唯一真相：点燃物品、三层材料、中心标签、坐标映射区间、自动建门 |
| `kubejs/config/mirror_dimension.json` | `dimension_type.coordinate_scale = 16`（XZ 缩放，见 §13.8） |

### 13.5 与地狱门的差异及其理由

| 行为 | 本传送门 | 原版地狱门 | 理由 |
|---|---|---|---|
| 框架检查 | **不检查** | 每次 `updateShape` 重新验证黑曜石框，拆一格就碎 | 设定要求"点燃后上下两层不再必要" |
| 挖不挖得动 | 硬度 `-1`：生存挖不动、**创造能打掉** | 相同 | `getDestroyProgress` 对 -1 直接返回 0；创造模式走的是"立即破坏"分支，绕开硬度判定（基岩同理） |
| 爆炸 | 抗性 `0.5`，TNT 一下就炸掉 | 抗性 3600000，炸不动 | 设定要求"可以被爆炸炸掉" |
| 穿过 | `noCollission` | 相同 | 否则走不进去 |
| 发光 | 亮度 11 | 相同 | — |
| 屏幕扭曲 | `NONE`（自己画渐现遮罩，见 §13.9） | `CONFUSION` |
| 落点 | **先 POI 搜索目标维度里已有的门**，找到就用那扇门的位置；没找到才按坐标新建（§13.8） | `PortalForcer` 找/建黑曜石门 | 同原版机制，只是门的形状换成我们的 3×3×3 |
| 计时/冷却/音效 | **完全沿用原版那套**（但**传送音效换成了我们自己的**，见下） | — | 不自己造轮子，行为与原版门一致，也不需要 mixin |
| 传送音效 | **完全由模组播**（见下） | `PLAY_PORTAL_SOUND` → 客户端放 **地狱门 travel 音效** | 原版那个音效是地狱门专用，与我们的提示音完全是两回事 |

> **⚠️ 为什么不用 `DimensionTransition.PLAY_PORTAL_SOUND`**
> 它给玩家发的是 1032 号关卡事件，客户端据此播放 `SoundEvents.PORTAL_TRAVEL`
> —— 也就是**地狱门那条 travel 音效**。用户实测反馈"来回传送响的是地狱门的声音"，
> 就是这一条。
>
> 换成模组自己播 `MirrorBlocks.MIRROR_ENTER`（注册在模组里，
> `/playsound mirrorgravity:block.mirror_enter` 也能直接用），两个方向各管一处：
>
> | 方向 | 触发点 |
> |---|---|
> | 回主世界 | `MirrorPortalBlock` 的落地后处理（`postDimensionTransition`） |
> | **任何方式**进入镜维度 | `MirrorGravity#onPlayerChangedDimension` 监听"玩家进入镜维度" |
>
> 进入那一条特意**不写在传送门里**，而是挂在"维度变化"事件上 ——
> 传送门只是入口之一，`/mirror tp`、`/execute in mirror:mirror run tp`
> 同样是跨维度传送（`ServerPlayer#teleportTo(ServerLevel,…)` 内部就是
> `changeDimension`，所以同样会触发这个事件），挂事件就让**所有入口自动有声音**。
> 两处各管一个方向，不会重复播。
>
> 音量/音高固定 1.0：响度是烘焙进音频文件的（−21.6 LUFS），
> 客户端又会把最终增益夹到 1.0。
> `mirror_config.js → sound.enter` 那一段现在**不再影响游戏里的提示音**，
> 只作用于 `/mirror sound` 试听与"换回原版音效"的备用路径。


### 13.6 黑白流光贴图怎么来的

贴图**不是画出来的，是脚本算出来的**（`tools/gen-portal-texture.mjs`，纯 Node + zlib，
不需要任何图像软件；`D:\App\ffmpeg` 是上一个功能装的声音工具，这里用不上）：

```
a = sin(2π(x/8 + y/8 + t/T))        斜向波
b = sin(2π(x/8 - y/8 - t/T·0.7))    反斜向波 → 两者交叉出菱形光带
c = sin(2π(x/4 + t/T·1.5))          细横纹 → 让光带"闪"起来
n = ((a + b + 0.5c)/2.5 + 1) / 2    → [0,1]
亮度 = 255·min(1, 1.22n)²            波峰纯白、波谷纯黑
alpha = 60 + 195·min(1, 1.3n)       0.24 ~ 1.0，整体半透明
```

- 输出 `mirror_portal.png`（16 × 512 = **32 帧纵向排开**）+ `.mcmeta`（`frametime: 1`，一轮 1.6 秒）
- 所有相位都写成 `2π·k·t/T`，所以第 T 帧与第 0 帧严丝合缝，**循环不跳帧**
- 图案周期是 8 像素，**相邻方块之间也接得上**，不会看出接缝
- 生成器自带自检：断言亮度范围 0~255、alpha 明显小于 1（"透明"）

模型用 `"render_type": "minecraft:translucent"` 让 alpha 真正参与混合
（默认 `solid` 会当作不透明，贴图会变成一块黑白板）。

### 13.7 游戏内验证步骤

```
/mirror portal      → 在脚下自动搭好 3×3×3 并点燃；回执里会写点燃结果与坐标映射
（或手动搭：下 3×3 磨制黑石 / 中 8 格空气 + 中心任意玻璃 / 上 3×3 平滑石英，
  然后手持望远镜右键中心玻璃）

结构不对时的提示会直接说错在哪：
  镜面没有反应：中心那一格必须是玻璃
  镜面没有反应：中间层的其余 8 格必须是空气
  镜面没有反应：最下面一层 3×3 必须是磨制黑石
  镜面没有反应：最上面一层 3×3 必须是平滑石英块

点燃后：
  · 站进门里 → 约 4 秒（gamerule 默认 80 tick）后传送到镜维度
    这 4 秒里画面会**逐渐浮现黑白流光遮罩**（见 §13.9）
  · 到达镜维度时会在对应坐标**自动生成一座同样的门**，人落在门里
    （走一步就出来；站着不动约 4 秒会被送回去 —— 与原版地狱门相同）
  · 从镜维度走回来 → **回到主世界那扇门的位置**（POI 搜索，见 §13.8）
  · 生存模式挖它 → 挖不动；创造模式 → 能打掉
  · TNT 炸 → 会消失
  · 拆掉上下两层 → 门还在（不检查框架）
```

### 13.8 坐标映射：两个维度怎么对应

**X/Z 用原版机制，不自己算。** 原版是这么做的（`NetherPortalBlock#getPortalDestination`）：

```java
double d0 = DimensionType.getTeleportationScale(fromLevel.dimensionType(), toLevel.dimensionType());
BlockPos pos = worldborder.clampToBounds(entity.getX() * d0, entity.getY(), entity.getZ() * d0);
```

`getTeleportationScale` 返回"源维度 `coordinate_scale` ÷ 目标维度 `coordinate_scale`" ——
下界的 1:8 就是靠下界 `dimension_type` 里的 `coordinate_scale: 8`。
所以**镜维度 1 格 = 主世界 16 格**只需在
`kubejs/config/mirror_dimension.json` 里把 `coordinate_scale` 从 1 改成 **16**，
再跑一次数据包生成器（改 dimension_type 后要**退出世界重新进入**才生效）。

**Y 必须重新映射**（这是镜维度的特殊之处）：主世界可建高度 −64~319（384 格），
而镜维度**境内**只有 −64~63（128 格），外面就是镜外 —— 掉到镜外会被切成
冒险/旁观模式，等于把玩家困住。所以按比例压进去：

```
主世界  -64 ─────────── 319         (384 格)
          │  线性映射  │
镜维度  -64 ───────────  63         (128 格)
```

两端对齐、单调，所以来回自洽：主世界 y=70（典型地面）落到镜维度约 y=−20，
稳稳在境内；反向换算回去也是原高度附近（±1.5 格）。

**回程：不靠坐标反算，靠"找门"。**

坐标映射只用来决定**该在哪建门**（把镜维度那一侧压进境内）。真正决定
落点的是原版那套机制 —— **先找目标维度里已有的门**：

```java
// PortalForcer#findClosestPortalPosition —— 地狱门就是这么做出口的
poiManager.ensureLoadedAndValid(level, targetPos, radius);      // 先加载搜索区
poiManager.getInSquare(r -> r.is(PoiTypes.NETHER_PORTAL), targetPos, radius, ANY)
          .min(比较与 targetPos 的距离);                         // 取最近的
// 找到 → 落点 = 那扇门自己的位置；没找到 → createPortal 新建一座
```

我们**第一版漏掉了这一步**，直接拿映射坐标当落点，于是回程必然对不上：

| 环节 | 原版 | 第一版实现 | 后果 |
|---|---|---|---|
| 找已有的门 | POI 搜索最近的传送门（半径 16/128 格） | 完全没有 | 落点与玩家建的门无关 |
| X/Z | `entity × scale` | 又加了半格单元（`+scale×0.5`） | 多偏 8 格。玩家站在方块**中心**（62.5），乘 16 本来正好回到 1000，+8 反而错了 |
| Y | **不缩放**，取找到的那扇门的 Y | 按比例反算 | 映射取整误差 ±1.5 格，加上建门避让玻璃层挪的几格，能偏 5 格以上 |
| 落点 | 相对门的位置精确还原 | "门顶 +2" | 误差直接叠加，人落不到门上 |

修法就是补上原版那一步：**先 POI 搜索，找到就用那扇门的位置**。
`getTeleportationScale` 仍然用于"没找到门时该在哪新建"。

⚠️ **POI 登记是必需的**：门方块必须注册成兴趣点类型
（`MirrorBlocks.MIRROR_PORTAL_POI`，参数照抄地狱门：`maxTickets=0, validRange=1`），
POI 表由区块数据维护（`ServerLevel#onBlockStateChange` 自动增删），
所以查询是按区块索引的，不用遍历几万个方块，也不会因为区块没加载而漏掉门。
搜索半径沿用原版思路：目标是主世界 128 格、目标是镜维度（1:16，密）16 格。

**落点在门里**（门方块中心、脚底与门同高），与原版一致。
门方块不碰撞、中间层周围 8 格是空气，从任意一侧走一步就出去了。
代价与原版相同：落地后有传送冷却（玩家 10 tick），站着不动约 4 秒会被送回去。

**兜底扫描**：POI 记录是"方块被放下那一刻"写进去的
（`ServerLevel#onBlockStateChange` → `PoiManager#add`），而 POI 段的
`Valid` 标记一旦为真，加载区块时也不会重建（`PoiSection#refresh` 只在
`!isValid` 时跑）。所以**加 POI 类型之前就已存在的门在 POI 表里没有记录** ——
只靠 POI 搜索会漏掉它。于是 POI 未命中时再补一次方块扫描
（±16 格 XZ、±12 格 Y），只在兜底路径上跑。


区间都在 `mirror_config.js → mirrorPortal.overworld_y_range / mirror_y_range`，
启动时推给模组（日志会回一行「坐标映射：主世界 Y[…↔…]」）。

### 13.9 站在门里时的渐现遮罩（客户端）

传送门要站 80 tick（4 秒）才生效，这期间必须让玩家知道"我在进门了、还要多久"。
做法是**照抄原版地狱门遮罩那一套，只把贴图换成我们自己的**：

原版（1.21.1）：
```java
// LocalPlayer#tick —— 强度：门里每 tick +0.0125，离开每 tick −0.05（夹 0~1）
handleConfusionTransitionEffect(getActivePortalLocalTransition() == Portal.Transition.CONFUSION);
// Gui#renderPortalOverlay —— 铺满全屏，alpha 走 a⁴×0.8+0.2 的曲线
texture = blockModelShaper.getParticleIcon(Blocks.NETHER_PORTAL.defaultBlockState());
gui.blit(0, 0, -90, guiWidth, guiHeight, texture);
```

我们沿用同样的**强度速率**与**alpha 曲线**（所以遮罩铺满时正好是快传走的时候），
但遮罩用的是 `MIRROR_PORTAL` 的贴图，也没有屏幕扭曲。
进门开始浮现、**出门立刻回落**（20 tick 退干净）。

三个实现细节：

1. **用方块模型的 particleIcon 取贴图**，而不是直接 blit 那个 PNG ——
   只有图集里的 sprite 才会播放 `.mcmeta` 动画，独立纹理走的是
   `SimpleTexture`，blit 出来是一张静止图。
2. **判断"在不在我们门里"必须按包围盒查方块**。
   ⚠️ 踩过的坑：一开始读的是客户端侧的 `PortalProcessor`，结果
   **遮罩再也退不掉** —— 那个对象的清理由 `Entity#handlePortal` 负责，
   而它的第一行是 `if (this.level() instanceof ServerLevel)`：
   **只在服务端清理**。客户端那份一旦被 `entityInside` 建出来就一直在，
   `entryPosition` 还指着门方块、方块也还在，于是"在门里"恒为真。
   现在改成取玩家包围盒覆盖的方块范围（与原版 `Entity#checkInsideBlocks`
   用的范围完全一致），两端判据同源。
3. **挂载点**：`@EventBusSubscriber(value = Dist.CLIENT)` + `ClientTickEvent.Post`
   与 `RenderGuiEvent.Post`。标注了 `Dist.CLIENT`，所以专用服务端不会加载这个类
   （它引用了 `Minecraft`/`GuiGraphics` 这些纯客户端类）。

### 13.10 到达侧自动建门

**先找门，找不到才建**（顺序不能反 —— 见 §13.8 的对比表）。
`MirrorPortalShape.buildPortal(level, center)` 按与玩家手搭完全相同的形状
（下 3×3 底块 / 中间 8 格空气 + 中心传送门 / 上 3×3 顶块）写进世界。

两个细节：

- **避让玻璃层**：结构占 `cy−1 / cy / cy+1` 三层，压在世界生成的玻璃层上
  会在"上下界面 / 镜内外分界"上开洞。避让名单由脚本从
  `layout.glass_layers` 收集后推给模组（`setMirrorPortalAvoidY`），
  生成时向上/向下找最近的安全高度。
- **建门失败也照常传送**：写方块出错时只记一条 warn，
  不会把传送本身毁掉（否则玩家会卡在门里反复触发）。

---

## 14. 重力方块加工配方（46 条）

玩法：重力方块在交界处反复坠落，**切换够次数**之后变成另一种方块。
完整清单在 `mirror_config.js → gravityBlockRecipes.list`，
游戏内用 `/mirror recipes`（分组摘要）或 `/mirror recipes <关键词>`（明细）查看，
JEI 里是「重力方块加工」分类（见 14.8）。

### 14.1 配方字段

| 字段 | 说明 |
|---|---|
| `input` | 下落的方块的原始方块 ID |
| `output` | 达成后的产物。**`'@landed'`** = 变成"落在的那个方块"；**`'@mapped'`** = 按 `map` 表把落点翻成产物 |
| `crossings` | 需要重力切换几次 |
| `trigger` | `'crossing'`（默认）：切换那一刻直接变；`'landing'`：切换够次数后落在指定方块上才变 |
| `on` | 仅 landing 用。方块 ID，**`#` 开头的标签**（如 `#c:storage_blocks`），或**一组**（数组，逐条试） |
| `map` | 仅 `@mapped` 用：`'落点方块 ID' → '产物 ID'` 的对照表；表里没有的落点**不触发** |
| `drop` | 可选，`true` = 产物以**掉落物**形式弹出，而不是原地放成方块 |
| `insert` | 可选：落在容器上时往容器里塞物品 `{ items:[...], count:1, force:false }` |
| `hint` | 可选：一句话提示，只显示在 `/mirror recipes <关键词>` 里。**用于记录"前提在方块的原版规则上、不在配置里"的情况**（如脚手架下方 6 格内不能有结实方块），否则这类前提只能靠翻代码注释 |
| `at` | 可选：`'lower'` / `'upper'`，不写 = 两侧都算 |

**两种触发方式的次数语义不同**（踩过坑）：`crossing` 用**精确等于**
（它就在切换那一瞬间发生，等号天然对齐）；`landing` 用**大于等于**
（曾经误用精确等于，结果"达到 N 次时多半在分界线上方空中"，
等它回到目标方块旁边次数已经 N+1，条件再也不成立）。

**产物形态四种**：写死的 ID / `@landed`（落点决定产物）/ `@mapped`（落点查表决定产物）/
以上任意一种加 `drop: true`（弹成掉落物）。

> ⚠️ **「物品」和「方块」在这套配置里是两件独立的事，别混。**
> `input` / `output` / `on` 写的都是**注册 ID**，而同一个 ID 可能既有物品形态
> 又有方块形态。踩过的同类易混对：
>
> | 容易看串的一对 | 区别 |
> |---|---|
> | `nether_wart` / `nether_wart_block` | 地狱疣**植株**（种在灵魂沙上那一格，也是物品 ID） / 下界疣块（9 个合成的实心方块） |
> | `soul_sand` / `soul_soil` | 灵魂沙（支撑形状不满格） / 灵魂土（满格方块） |
> | `mud` / `muddy_mangrove_roots` | 泥巴 / 沾泥的红树根 |
> | `*_leaves` / `*_sapling` | 树叶（原料） / 树苗（产物） |
>
> 这个坑真的踩过（详见 14.14）；而**「脚手架 + 灵魂沙 → 地狱疣」那条配方
> 已于 2026-09-22 放弃并删除**（14.17 / 14.22）——
> 现在配置里出现的 ID 都能用 `/mirror recipes` 直接核对。
>
> 产物是"弹出来的物品"还是"放下去的方块"，**只由 `drop` 决定**，与 ID 长什么样无关：
> `drop: true` → 调模组 `dropItem` 生成物品实体，**绝不调用 `setBlockAndUpdate`**；
> 不写 `drop` → 原地放成方块。这条有断言守着：
> `tools-build/sim-recipes.mjs` 会检查 drop 配方**没有**往世界里放任何方块，
> 并用一条普通配方（沙子 → 石英块）做对照。

### 14.2 配方全表

| 输入 | 次数 | 触发 | 产物 / 条件 |
|---|---|---|---|
| `gravel` | 2 | crossing | `iron_block` |
| `sand` | 3 | landing | `quartz_block`（落在黑色玻璃上） |
| `*_concrete_powder` ×16 | 8 | crossing | 同色 `terracotta` |
| `*_concrete_powder` ×16 | 4 | landing | 同色 `glazed_terracotta`（落在熔炉上） |
| `red_sand` | 8 | crossing | `gold_block` |
| `red_sand` | 4 | landing | `glowstone`（落在荧石上） |
| `suspicious_gravel` | 8 | crossing | `emerald_block` |
| `suspicious_gravel` | 4 | landing | `coal_block` + 往陶罐塞 1 个古迹废墟考古战利品（**满罐也触发**） |
| `suspicious_sand` | 8 | crossing | `tnt` |
| `suspicious_sand` | 4 | landing | `coal_block` + 往陶罐塞 1 个沙漠/海底废墟考古战利品（**满罐也触发**） |
| `damaged_anvil` | 4 | crossing | `chipped_anvil` |
| `chipped_anvil` | 4 | crossing | `anvil` |
| `anvil` | 8 | landing | **`@landed`**（落在矿物块/金属块上 → 变成那一块，落点见 14.3） |
| `scaffolding` | 8 | crossing | `cobweb` |
| `scaffolding` | 4 | landing | **树苗掉落物**（落在 `#minecraft:leaves` 上，按落点查表，见 14.5） |

| `pointed_dripstone` | 16 | crossing | `dripstone_block` |

16 色混凝土那 32 条**由循环生成**（`mirror_config.js` 末尾的 IIFE）——
手抄 16 色极易写错一个字母，而写错的表现只是"某两种颜色没反应"，很难查。

### 14.3 铁砧的落点：为什么 `on` 要写**一组**标签

```
on: [
  '#c:storage_blocks',              // NeoForge 通用标签：原版矿物块 + 多数模组的金属块
  '#c:storage_blocks/raw_lead',     // ⚠️ 以下 6 条父标签里**没有**
  '#c:storage_blocks/raw_silver',
  '#c:storage_blocks/raw_tin',
  '#c:storage_blocks/raw_titanium',
  '#c:storage_blocks/raw_tungsten',
  '#c:storage_blocks/raw_uranium',
]
```

- 原先只写了 `#c:storage_blocks`，结果**铁砧工艺（AnvilCraft）的粗矿块大部分没反应**。
- 查证（读 `anvilcraft-neoforge-1.21.1-1.6.0` 的
  `data/c/tags/block/storage_blocks.json`）：父标签里 AnvilCraft 只登记了
  `raw_zinc_block`，另外 6 种粗矿块只写在 `storage_blocks/raw_xxx` 子标签里，
  而**子标签没有被挂回父标签**。这是上游标签表的疏漏，我们只能在自己的配方里补齐。
- 读的是 AnvilCraft 自己写的子标签，所以它改方块 ID、或将来补齐父标签，这里都不用动。
- 另有 4 种**非矿物**的储量块也在 `c:storage_blocks` 里（骨粉 / 干海带 / 粘液 / 小麦）。
  想让铁砧对它们也生效就保持现状；要严格只要矿物与金属，得自建标签替换第一条。

### 14.4 原版重力方块全集（查证：谁真的调用 `FallingBlockEntity.fall`）

| 方块 | 是否已配 |
|---|---|
| `sand` / `red_sand` / `gravel` | ✅ |
| `*_concrete_powder` ×16 | ✅ |
| `suspicious_sand` / `suspicious_gravel`（`BrushableBlock implements Fallable`） | ✅ |
| `anvil` / `chipped_anvil` / `damaged_anvil`（`AnvilBlock extends FallingBlock`） | ✅ |
| `scaffolding`（脚手架） | ✅ —— `ScaffoldingBlock` 失去支撑时会 `FallingBlockEntity.fall`（字节码确认） |
| `pointed_dripstone`（滴水石锥） | ✅ —— 钟乳石失去支撑时会 `FallingBlockEntity.fall`（字节码确认） |

另外 `powder_snow` 只是**判断**实体是不是 `FallingBlockEntity`（落进细雪不掉落伤害），
它本身不下落；`dragon_egg`（龙蛋）在 1.21.1 也不走 `FallingBlockEntity`（是随机传送）。

#### ⚠️⚠️ 脚手架的前置条件：它**不是**"悬空就掉"

这是"灵魂土上不出下界疣"的真正原因，读字节码确认：

```
ScaffoldingBlock.tick(state, level, pos, random):
    int i = getDistance(level, pos);              // 向下找结实支撑面
    blockState = state.setValue(DISTANCE, i).setValue(BOTTOM, isBottom(...));
    if (blockState.DISTANCE == 7) {
        if (state.DISTANCE == 7) FallingBlockEntity.fall(level, pos, blockState);   // ← 只有这里
        else level.scheduleTick(pos, this, 1);
    }
```

`getDistance` 从脚手架往下**最多看 6 格**，找到第一个 `isFaceSturdy(..., UP)` 的方块就返回
它的距离；6 格内一个都没有才返回 `7`。**只有 `DISTANCE == 7` 才会生成下落实体。**

**⇒ 结论：脚手架下方 6 格以内只要有结实方块，它就永远不会掉** —— 而
**下界疣块、灵魂土、泥巴、黑色玻璃、石头全都是结实方块**。所以：

- ❌ "在落点方块上方摆一格脚手架，等它掉到落点方块上" —— **它根本不会掉**，什么都不会发生
- ❌ 在镜面玻璃层附近摆脚手架 —— 玻璃是结实方块，同样不掉
- ✅ 正确摆法：**脚手架至少要离下方任何结实方块 7 格**，让它先真的掉下来

一个能直接用的测试台（在分界线上挖一条竖井，把玻璃层挖穿）：

```
y=+3  下界疣块      ← 落点：做成天花板，让脚手架"朝上飘"贴上去
y=+2  空气
y=+1  空气          ← 脚手架摆这里（下方 6 格内全是空气 → DISTANCE=7 → 会掉）
y= 0  空气（挖穿黑色玻璃）
y=-1  空气（挖穿黑色玻璃）
y=-2  空气（挖穿黑色玻璃）
y=-3 以下继续留空   ← 关键：脚手架下方 6 格不能出现任何结实方块
```

脚手架从 y=1 掉下去 → 进入下半区（y<0）重力反转 → 朝上飘回 → 贴上 y=3 的树叶
→ 切换 4 次后弹出对应树苗。

> **判别技巧**：如果连「8 次 → 蜘蛛网」也从来没成功过，那就是脚手架**压根没掉**
> （前置条件问题）；如果蜘蛛网成功、只有落点配方不灵，才是落点判定问题。
> 现在不用靠猜了 —— `/mirror recipes scaffolding` 里的**引擎采样**会直接给出答案
> （见 14.13）。

| 方块 | 怎么让它落下来 |
|---|---|
| 脚手架 | **下方 6 格内不能有任何结实方块**（含下界疣块 / 灵魂土 / 玻璃 / 石头），满足后它会自己掉 |
| 滴水石锥 | 钟乳石（`vertical_direction=down`）**上方那一格被挖掉** → 变成下落实体 |

这两条同时写进了配置的 `hint` 字段，游戏里 `/mirror recipes scaffolding` 能看到。

### 14.5 脚手架 → 树苗：为什么要一张对照表

`map` 表（`mirror_config.js` 开头的 `MIRROR_LEAVES_TO_SAPLING`）把落点树叶
翻成对应树苗。**必须手写**，不能靠"把 `_leaves` 换成 `_sapling`"猜：

| 树叶 | 产物 | 备注 |
|---|---|---|
| `mangrove_leaves` | `mangrove_propagule` | 不叫 `*_sapling` |
| `azalea_leaves` | `azalea` | 同上 |
| `flowering_azalea_leaves` | `flowering_azalea` | 同上 |
| 其余 7 种 | 同名 `*_sapling` | oak / spruce / birch / jungle / acacia / dark_oak / cherry |

猜名字的写法遇到前三种会**静默失效**（配方永不触发、也没有报错）。
表里查不到的落点（例如别的模组新增的树叶）不触发，方块继续往复。

`drop: true` 的意义：树苗与地狱疣都能当方块放，但产物原地放成方块会把落点
（树叶 / 灵魂沙）盖掉，玩家也捡不走。所以让它们以物品形式弹出来
（模组侧 `MirrorItemDrop`，初速度刻意只有原版方块掉落的 1/3，
免得在反向重力里被甩飞）。

### 14.6 「落在容器上塞物品」的机制

实现在模组侧 `MirrorContainerInsert`，规则**照抄原版往陶罐里放物品的那一段**
（`DecoratedPotBlock#useItemOn`）：

```
容器是空的，或者装的是同一种物品（组件也相同）且没到该物品的最大堆叠
→ 放入；随后 wobble(POSITIVE) + 播 DECORATED_POT_INSERT（音高随装入比例）
  + 罐口打 7 个 DUST_PLUME 粒子
装不下 → wobble(NEGATIVE) + DECORATED_POT_INSERT_FAIL
```

模组只依赖原版 `Container` 接口，所以**箱子、木桶、漏斗等任何容器都能用**，
陶罐只是被 `ContainerSingleItem` 特化的那一种。

**给脚本的接口**（`MirrorGravityApi`）：

| 方法 | 用途 |
|---|---|
| `blockStateHasTag(BlockState, String)` | 标签查询（`on` 写 `#c:storage_blocks` 时用） |
| `canInsertIntoContainer(Level, BlockPos, String itemId, int count)` | **先问**装不装得下 |
| `tryInsertIntoContainer(Level, BlockPos, String itemId, int count)` | 真的放进去 |
| `dropItem(Level, x, y, z, String itemId, int count)` | 产物弹成掉落物（`drop: true` 时用） |

配方侧的顺序是**先问后做**：`force:false`（默认）时容器装不下就**不触发**，
方块继续往复等位置；`force:true` 时容器满了也照触发，那一个物品白扔。

> ⚠️ 两条陶罐配方（可疑沙砾 / 可疑沙子）现在是 **`force: true`**。
> 起因是玩家反馈"罐子装满以后，沙砾就再也不加工了、一直往复"——
> 因为默认行为是等容器腾出位置，而单槽陶罐装满后永远不会腾出来。
> 代价是满罐时确实会丢一个战利品（日志里有一条 `insertMissOnce` 提示）。

### 14.7 考古战利品表（刷子能刷出什么）

原版 1.21 的考古战利品表是**代码生成**的（`VanillaArchaeologyLoot`），
不是 `data/` 里的 JSON，所以直接读的源码。按方块对应关系整理：

| 方块 | 对应的战利品表 | 项数 |
|---|---|---|
| 可疑的沙砾 | `TRAIL_RUINS_ARCHAEOLOGY_COMMON` + `_RARE`（古迹废墟） | 43 |
| 可疑的沙子 | `DESERT_WELL` + `DESERT_PYRAMID` + `OCEAN_RUIN_WARM` + `OCEAN_RUIN_COLD` | 34 |

⚠️ 游戏里具体用哪张表由**方块实体里存的战利品表**决定（取决于它在哪个结构里生成）；
一旦变成下落的方块，这份数据就没了。所以配置里取的是"这种方块**可能**刷出的
全部物品"当作池子随机抽。想给某个物品加权，把它的 ID 在列表里重复写几次即可。

### 14.8 JEI 显示（`重力方块加工` 分类）

JEI 的配方注册发生在**客户端启动期**（世界还没加载），KubeJS 脚本那时还没跑，
脚本也**无法写文件**，所以走"派生"这条路：

```
mirror_config.js  →  node tools/sync-jei-recipes.mjs  →
mirror-gravity-mod/src/main/resources/gravity_recipes.json  →  gradlew build  →  JEI
```

⚠️ **改完配方必须跑一次同步 + 重新构建 jar**，否则 JEI 里看到的还是旧的。

**同步脚本早先是拿正则"读"配置文本的**，后果是 JEI 里几乎什么都没有：

- 末尾循环生成的 **32 条混凝土配方一条都没导出**（正则只认字面量）
- 落点标签、容器插入池、动态产物 `@landed` 全部丢失
- 于是 JEI 里只剩最初手写的两条，看起来就是"配方不进 JEI"

现在改成 `new Function(src)` **真的把配置脚本跑一遍**再取 `MIRROR_CONFIG`
（它本来就是纯数据 + 一个循环，不依赖任何游戏 API），
导出内容与运行时**逐字段一致**。`tools-build/check-recipes.mjs` 一直就是这么干的。

版面：

```
┌──────────────────────────────────────────────┐
│ [镜面] → [输入]        ↓↑         [产物]       │
│ 落在 [落点方块] → 塞入 [物品池]                 │
│ 重力切换 N 次后…                                │
│ 掉落物形式；产物＝落点方块；容器满也触发          │
└──────────────────────────────────────────────┘
```

- **落点与产物都是真实物品槽**，不是文字。写标签时（`#c:storage_blocks`、
  `#minecraft:leaves`）会在**同一个槽里循环显示标签的全部成员**
  —— 于是搜"粗锡块""橡树树苗"都能搜到对应配方（文字是搜不到的）。
- **容器要求与塞入物也是真实槽位**：陶罐画成落点槽（它就是容器），
  43 / 34 项考古战利品池画成"塞入"槽，一眼能看出"落在陶罐上会吐出一个战利品"。
- `@landed` / `@mapped` 的产物槽同样循环显示全部候选，
  搜"铁块"就能找到铁砧那条配方。

客户端启动日志里会打一行
`[镜维度·JEI] 已载入 N 条重力方块加工配方用于展示`；
若 JEI 里**整个分类都不见了**，先看这一行有没有出现（没有 = 插件没被 JEI 扫到）。

### 14.9 顺带修的两个细节

- **铁砧朝向**：铁砧有 `facing` 属性，下落实体带着原朝向。第一版一律用
  `defaultBlockState()` 放方块，于是所有铁砧落地后都朝同一个方向。
  现在会从下落实体搬运 `HORIZONTAL_FACING`（两边都有该属性时才搬）。
- **`/mirror recipes` 不刷屏**：48 条配方全打出来会刷满聊天栏，
  所以默认只给分组摘要（混凝土 32 条收成一行），要看明细用
  `/mirror recipes concrete` 这样带关键词。明细里会额外标出
  `[产物=落点]`、`[产物按落点查表]`、`[掉落物形式]`、`[放入容器: N 选 1，装不下也触发]`。

### 14.10 ⚠️ 同一输入、同一次数的多条 landing 配方

脚手架有**两条** 4 次切换的 landing 配方，区别只在落点（树叶 / 灵魂土）。
引擎原先只返回"第一条匹配的配方"，落点判断发生在之后 ——
于是**第二条起永远不会被考虑**，表现是"其中几种落点完全没反应，且没有任何报错"。

现在 `matchRecipeAll` 返回**全部**候选，逐个去做落点判定（`process` 里的循环）。
顺带加了一条自检：同输入 + 同次数的多条 **crossing** 配方属于配置冲突
（一次切换只能变一种方块），会打 error 日志，`check-recipes.mjs` 也会拦。

### 14.11 ⚠️ 接触判定的几何：`getY()` 不是格子中心

排查"灵魂土上不出下界疣"时挖出来的第二个真问题。

判定探针原先写的是 `BlockPos.containing(x, y±1, z)`，也就是
"脚下那一格 / 头上那一格"。但 `entity.getY()` 是**碰撞箱的底面**，不是格子中心，
于是"向上贴天花板"这一侧（**镜维度下半区正是这种情况**）算出来的窗口是：

```
天花板在 y=S，实体贴上时碰撞箱 [S-0.98, S]
   探针 y+1 = S+0.02  →  floor = S   ✅
   实体还在从下方靠近时 y = S-1.5 → y+1 = S-0.5 → floor = S-1   ❌
```

也就是说**只有完全贴住的那 0.02 格内才判得到**，从下方靠近的整段（约 1 格）全部漏掉。
"往下落到地板上"那一侧没这个问题，所以这个 bug 只在下半区暴露 —— 极难察觉。

现在改成按**碰撞箱实际占的格子**取上下相邻格：

```
minB = floor(box.minY)，maxB = floor(box.maxY - ε)     // ε 必须有：
下方相邻格 = minB - 1，上方相邻格 = maxB + 1           // 贴住时 maxY 正好等于 S，
                                                      // 不减一点点就会算成 S+1
```

两侧于是都是完整的 1 格窗口，靠近过程中必然被采到，不再依赖"刚好停住"。

### 14.12 ⚠️ 高速下落会整帧跳过"贴着"的瞬间

判定的另一半：landing 每 tick 只看一次，而**上半区是原版在管**——
原生重力下下落实体最快约 **2 格/tick**，落地当帧原版就把方块放回世界、没有模组的
3 tick 宽限。于是它可能从"还差两格"直接变成"已经落地并变回方块"，
中间那个接触瞬间**一帧都没被看到过**。

修法是加一条**运动方向上的预判**（配置项 `gravity.landing_lookahead`，默认 1 格）：

- 方向直接用模组当前生效的重力方向（与实际运动方向一致，不需要额外速度状态）
- 只往**运动方向**多看，不动另一侧
- 默认 1 格 = "下一 tick 一定会贴上"的那一格，**不是**用户当初否掉的"隔空取物"
  （那一版是两侧各 4 格，隔着三四格空气就会变）

想回到"只认当帧真的贴着"，把 `gravity.landing_lookahead` 设成 `0` 即可。

### 14.13 排查这类"配方不生效"的顺序

**第零步（最重要）：先分清"引擎有没有 bug"和"摆法对不对"。**

这两件事在游戏里长得一模一样（什么都不发生），所以项目里有一个
**配方引擎模拟器**，它在 Node 里**真的执行 `mirror_n3_recipes.js`**
（喂假世界与假实体，不启动游戏）：

```powershell
cd "D:\DSHwork\MC镜维度"
node tools-build\sim-recipes.mjs
```

它会打印"某个位置 / 某个方向 / 某切换次数下，引擎匹配到哪条配方、
`applyRecipe` 有没有真的执行、产物是什么"。**引擎的问题在这里一次性排除掉**，
剩下的就只可能是摆法。

**第一步：`/mirror recipes <关键词>` 里的「引擎采样」段。**

它按方块种类记五件事：被当过多少次下落实体（处理 tick 数）、最高切换次数、
**活动范围（y 的最小/最大值）**、最近一次采样时探针看到的方块、
以及**探针在旁边实际见过哪些方块**。

| 采样里看到什么 | 结论 |
|---|---|
| **这种方块根本不出现** | 它从来没变成过下落实体 —— 前置条件问题（脚手架见 14.4） |
| 出现，但"最高切换"一直上不去 | 摆幅不够 / 被夹住 / 次数没到 |
| **活动范围够不到落点方块** | 摆错位置了 —— 落点方块必须落在活动范围**之内** |
| **"旁边出现过"里没有你摆的方块** | 要么世界里那个方块的 **ID 不对**（看列表里真正的 ID 是什么），要么真的没碰到 |
| 位置、ID 都对却不变 | 那才是引擎的问题（用 `sim-recipes.mjs` 复现后报我） |

输出长这样：

```
── 引擎采样（下落实体被处理的 tick / 最高切换）──
  · minecraft:scaffolding  处理 1520 tick，最高切换 4 次
      活动范围 y=-2.31 ~ 0.28（落点方块必须在这段里，它才碰得到）
      最近采样 y=-0.98 方向=up，相邻方块 下/本/上 = air / air / black_stained_glass
      旁边出现过: minecraft:oak_leaves、minecraft:black_stained_glass
```

> ⚠️ **「活动范围」+「旁边出现过」这两行是这一节的核心。**
> 前者回答"够不够得着"，后者回答"够着的到底是不是你以为的那个方块"。
> 落点配方不生效**只有**这两种可能，这两行一次就能分开。
>
> ⚠️ **下半区是"朝上飘"，落点通常要放在上方。** 分界线以下重力是反的，
> 方块在那里**向上**飞 —— 所以下半区的"落在某方块上"其实是"贴到它下面"。
> 把落点方块摆成**地板**（尤其是离分界线较远的低处），实体可能永远碰不到。
> **最稳的验证方法：把落点方块摆在原来**能生效**的那个方块的位置上**
> （例如树叶能生效，就把下界疣块放在树叶那一格再试一次）。
> 想让它跑得更远：把 `gravity.falling_hysteresis` 调大（例如 2.0），摆幅会跟着变大。

**第二步：看日志里那行去重提示**（每种配方各一行）：
`… 正在等待接触 X（recipe_id）；y=… 方向=… 相邻方块 下/本/上 = …`
—— 与采样同源，但会保留更早的一次现场。

（⚠️ 2026-09 之前这行是**按方块种类**去重的，脚手架永远只提示第一条配方的落点，
测试下界疣块时日志却在说树叶 —— 诊断信息本身把人带偏，现已改为按配方去重。）

**第三步**：输入方块是脚手架 / 滴水石锥时，先确认它**到底掉没掉**（见 14.4）。

### 14.14 ⚠️ "名字很像"的两个 ID 往往是两个方块

这一节记录的是一次**真实误判**，也是最容易复发的坑。

**现象**：脚手架落在"下界疣块"上不变地狱疣，而是继续往复，攒到 8 次切换后
**变成了蜘蛛网**（被 crossing 配方接走）。而同一批的树叶配方一切正常。

**原因**：配置里写的落点是 `minecraft:nether_wart_block`，
但世界里摆的是 `minecraft:nether_wart`（**地狱疣植株**，种在灵魂沙上的那一格）。
**这是两个完全不同的方块**，摆一个不会认另一个 —— 于是落点永远匹配不上，
方块就一直往复；等到第 8 次切换，crossing 配方（→ 蜘蛛网）先命中了。

**修法**：落点写**世界里真实存在的那一格**。地狱疣植株是种在灵魂沙上的，
所以设定上的"落点"就是**灵魂沙**：

```js
on: 'minecraft:soul_sand',   // 世界里的落点方块
output: 'minecraft:nether_wart',   // 长出来的东西（drop:true → 弹成掉落物）
```

> 中途试过把 `on` 写成 `['minecraft:nether_wart', 'minecraft:nether_wart_block']`
> 一组，**这是错的**：`nether_wart_block` 是满格方块，当落点会让脚手架一接触就
> 结束加工（14.16），而"穿过植株"根本不是设定要的效果。已删除。

> 玩家侧的判别：**摆的是灵魂沙**（不是灵魂土 —— `soul_soil` 是满格方块，
> 见 14.14 的易混对，也是 14.16 的禁用落点）。

**复现与验证**（`tools-build/sim-recipes.mjs` 场景 H/I，跑的是真引擎代码）：

```
场景 I（同位置、只换落点方块）:
  落点=橡树树叶（→树苗）:              切换=4 → scaffolding_to_sapling
  落点=杜鹃叶（→杜鹃树苗）:            切换=4 → scaffolding_to_sapling
  落点=灵魂沙（配方已删除，不该命中）:   切换=4 → 没有匹配
  落点=下界疣块（从来没有过这条）:      切换=4 → 没有匹配
场景 H-3（周围全空气、攒到 8 次）:
  周围全是空气、攒到 8 次切换：scaffolding_to_cobweb ← 就是"一直往复、最后变蜘蛛网"的原因
```

**顺带修的另一半**：目标方块**不一定有碰撞箱**。地狱疣植株、火把、草、告示牌
都没有碰撞，下落的方块会**直接从它中间穿过去**，因此接触探针必须把
**碰撞箱自己占的格子**也算进去（原先只探"上下相邻"，穿过去的那一瞬正好漏掉）。
现在探针顺序是：① 碰撞箱占的格子 → ② 上下相邻 → ③ 运动方向预判。

**通用教训**：配置里写 ID 时，别凭名字推。先用 `/give` 或 `/setblock` 确认
**世界里那个方块的真实 ID**（F3 调试信息 / `F3+H` 高级提示），再往配置里写。
同类易混对：`nether_wart` / `nether_wart_block`、`soul_sand` / `soul_soil`、
`mud` / `muddy_mangrove_roots`、`*_leaves` / `*_sapling`。

### 14.15 ⚠️ 每个下落实体的"摆幅"都不一样 —— 落点要按摆幅摆

**这条是读游戏日志（`logs/latest.log`）量出来的，非常重要。**

```
[镜维度·摆幅] minecraft:red_sand    最高 y=-0.65  最低 y=-1.77   摆幅=1.12 格
[镜维度·摆幅] minecraft:scaffolding 最高 y=16.96  最低 y=-2.31   摆幅=19.27 格
```

同一个分界线、同一套物理，两种方块的**活动范围差了 17 倍**。原因是它们
进入镜维度的方式不同：

- **红沙**是直接落在分界线附近的，能量很小 → 稳态就是**贴着分界线小幅抖动**
  （1 格多）。落点方块只要摆在那一层附近，几乎每一帧都碰得到。
- **脚手架**是玩家**从高处放下来**的（还得满足"下方 6 格无结实方块"，
  所以起手位置本来就在高处）→ 它一口气砸下 19 格，然后靠模组的阻尼
  慢慢把能量耗掉，**最后才收缩到分界线附近**。

⚠️ 而"摆幅"那一行打的是**历史极值**（只增不减）：它会把
"一开始从高处砸下来"和"后来在分界线附近抖动"两段混在一起，
看起来像"它一直在 19 格范围内跑"，其实**稳态只有 1~2 格**。

**⇒ 落点方块要摆在"它现在实际待着的那一段"里。** 游戏内用
`/mirror recipes <关键词>` 看这两行：

```
活动范围 y=-2.31 ~ 16.96（历史极值，含一开始从高处砸下来的那一段）
最近 3 秒在 y=-1.42 ~ -0.36（★ 落点摆进这一段最稳）
```

> **判别口诀**：`最近 3 秒` 那一段才是落点该在的位置。
> 摆到竖井底部（历史最低点）往往**碰不到** —— 因为实体早就不去那儿了。

**其它与 landing 判定有关的原版机制**（一并记在这里）：

| 机制 | 影响 |
|---|---|
| 落点若是**实心**方块，实体撞上去会停住 | 模组的着陆补丁连续确认 3 tick 就把方块放回世界；脚本在实体 tick 之前跑，这几帧就是判定窗口 |
| 落点若是**无碰撞**方块（地狱疣植株、火把、草） | 实体会**穿过去**，所以探针必须把"碰撞箱自己占的格子"也算进去（已实现） |
| `FallingBlockEntity` 落地当帧就会被原版放回方块（**上半区**没有 3 tick 宽限） | 上半区靠 `gravity.landing_lookahead` 的 1 格预判兜住 |

### 14.16 ★★ 脚手架配方的真正门槛：落点必须是**支撑形状不满格**的方块

**这是"脚手架落在 X 上不生效"折腾了十几轮的最终答案**，来源是用户自己
观察到的现象 + 原版源码（javap 逐条读）确认。

`ScaffoldingBlock` 有两条独特规矩：

```java
protected boolean canSurvive(state, level, pos) { return getDistance(level, pos) < 7; }
// tick() 里：int i = getDistance(level, pos);
//            if (重算 == 7 && 已存 == 7) FallingBlockEntity.fall(…);   ← 只有这里
//            else if (已存 != 7) scheduleTick(pos, this, 1);
//            else /* 重算 != 7 */ level.setBlock(pos, state, 3);
```

`getDistance` 往下找的是 `isFaceSturdy(…, Direction.UP)`（**支撑形状满格**）的方块。
结论：**脚手架方块只有下方 6 格内有结实支撑时才活得下来。**

⇒ 于是"落在某个方块上"这件事，按落点的**支撑形状**分成两种结局：

| 落点方块 | `getDistance` | 会发生什么 | 用户看到的现象 |
|---|---|---|---|
| **结实**（泥土 / 灵魂土 / 下界岩 / 下界疣块 / 荧石 / 石头） | 变 0 | `fall` 不再调用 → 变成稳定方块，**这次下落实体结束** | "脚手架直接变成方块" |
| **不结实**（灵魂沙 / 泥巴 / 树叶） | 仍是 7 | 方块**立刻又变成下落实体** → 继续往复，还能再碰到它 | "一直在往复" ✅ 要的就是这个 |

**⇒ 关键认识：对脚手架来说，"不结实"不是缺点，而是唯一能反复接触的条件。**
落在结实方块上是**一次接触就终结**，永远攒不到 4 次切换；
落在不结实方块上则是"碰一下 → 马上又掉 → 再碰一下"，
次数按竖列累计（14.17），攒够了就触发。

| 方块 | 覆盖 `getBlockSupportShape` | 支撑形状满格？ | 当落点 |
|---|---|---|---|
| **灵魂沙** `soul_sand` | ✅ 覆盖（14/16） | ❌ 不结实 | **✅ 本配方用的就是它** |
| **泥巴** `mud` | ✅ 覆盖（14/16） | ❌ 不结实 | ✅ 可用 |
| **树叶** `*_leaves` | ✅ 覆盖 | ❌ 不结实 | ✅ 可用（树苗配方） |
| 泥土 `dirt` | ❌ | ✅ 满格 | ❌ 一接触就变成稳定方块 |
| 灵魂土 `soul_soil` | ❌ | ✅ 满格 | ❌ 同上 |
| 下界岩 `netherrack` | ❌ | ✅ 满格 | ❌ 同上 |
| 下界疣块 `nether_wart_block` | ❌ | ✅ 满格 | ❌ 同上 |
| 荧石 `glowstone` / 石头 `stone` | ❌ | ✅ 满格 | ❌ 同上 |

> **这条也解释了整段排查史**：最初写的**灵魂沙**本来是对的；
> 中途换成**灵魂土**（满格方块）之后才开始"怎么都不生效"，
> 后面又试下界疣块 / 下界岩 / 泥土 —— **全都是满格方块，全都不行**。
> 而树叶那条一直是好的，正因为树叶不结实。
>
> **为什么红沙 + 荧石（满格）却没问题**：红沙没有这条"需要无支撑"的规矩 ——
> 它下方没有方块就掉，落地后就是普通方块，与支撑形状无关。
> **这条规矩是脚手架独有的**，所以同样形状的配方在红沙身上成立、在脚手架身上不成立。

**✗ 一个被否决的思路（记下来避免重走）**：既然满格方块不行，那就用**没有碰撞箱**的
方块（地狱疣植株 `minecraft:nether_wart`、火把、草）让脚手架**穿过去**。
这条路和设定不符 —— 设定是"落在**灵魂沙**上长出地狱疣"，
而不是"脚手架穿过一株地狱疣"。而且它并不必要：灵魂沙本身就不结实，
已经满足"能反复接触"这个唯一的物理要求。**配置里已删除，只剩灵魂沙这一条。**

**给将来加脚手架配方的建议**：落点优先选 `soul_sand` / `mud` / 树叶这类
**支撑形状不是满格**的方块；`check-recipes.mjs` 里已经加了断言，
把 `dirt / soul_soil / netherrack / nether_wart_block / glowstone / stone`
列为禁用落点，写进去会直接报错。

### 14.17 ⛔ 「脚手架 → 地狱疣」：三条路都试过，2026-09-22 **放弃并删除**

这条配方（脚手架 4 次切换 + 落在灵魂沙上 → 地狱疣掉落物）前后折腾了十几轮，
把三条可能的路都走完了。**结论：投入产出不成立，整条删除。**
这一节把三条路与它们各自的死因记全，免得将来有人再走一遍。

#### 它的特殊之处

脚手架是**唯一"碰一下方块就会重生"的下落方块**：方块被原版放回世界，
下一 tick 再掉，是**新实体、新 UUID**。而它的往复区间每轮都不一样
（`[镜维度·摆幅]` 量过：一轮 y=−2.31~16.96，另一轮 y=−1.23~−18.04）。
于是"攒够 4 次切换、同时正好碰到灵魂沙"这两件事很难对齐。

#### 三条路与它们的结果

| # | 思路 | 死因 |
|---|---|---|
| 1 | **严格语义**：计数 ≥4 且此刻探针正看到灵魂沙 | 往复区间不稳定 ⇒ 同帧接触是抽奖；而 crossing（8 次 → 蜘蛛网）一到 8 就立刻把实体收走，抽奖机会更少 |
| 2 | **`sticky`**：这一趟碰到过落点就记住，计数达标即触发 | 语义被放宽成"蹭过一次就算"；而且它需要"跨重生继承记忆"，又牵出第 3 条 |
| 3 | **按竖列计数**：让次数跨重生延续（+ `BlockEvents.placed` 清零） | **更糟**：同一竖列的多个脚手架共用计数，**连"上一次方向"也共用** → 每 tick 记一次假翻转 → 0→8 只用 1 秒、全变蜘蛛网（详见 14.21） |

实测记录：

```
（路 2，2026-09-22 13:53）曾连续触发 3 次 —— 这是唯一跑通过的一次
（路 3，2026-09-22 15:22）15:22:43 一秒内出了 6 个蜘蛛网，地狱疣一次都没有
（最终定论，2026-09-22 15:4x）用户复测：仍然不行 ⇒ 放弃
```

#### 现在的状态（代码里已删干净）

- 配方 `scaffolding_to_nether_wart` **删除**；
- `sticky` 机制（引擎的提前踩点 / 达标即触发 / `stickyTouch` 记忆）**整段删除**；
- `gravity.position_count_blocks` 配置项、`columnKeyOf` / `clearColumnCount`、
  `BlockEvents.placed` 清零处理器**全部删除**（它们只为这条配方存在）；
- mod 侧 JEI 的 `sticky` 字段与提示一并删除（`gravity_recipes.json` 里 0 条带它）。

**脚手架现在只有两条配方**，都只依赖"次数"与"落点"，没有任何专用机制：

| 输入 | 次数 | 触发 | 产物 |
|---|---|---|---|
| `scaffolding` | 8 | crossing | `cobweb` |
| `scaffolding` | 4 | landing（`#minecraft:leaves`） | 对应树苗（`@mapped`，掉落物） |

反向断言守在 `tools-build/check-recipes.mjs`：脚手架**必须正好 2 条**、
不许再出现地狱疣那条、不许再出现 `position_count_blocks` 或任何 `sticky`。
详细复盘与"下次遇到这类方块该怎么判断"写在 **14.22**。

### 14.20 ★★ 落点必须摆在**下落实体所在的那一竖列**（1 格宽），别摆到隔壁

**这是"灵魂沙摆好了却不生效"最常见、也最难自己看出来的原因。**

下落的方块实体**只在竖直方向动** —— 它的 X/Z 永远是那一格（日志里 `pos=(-34.5, …, 4.5)`
反复出现、小数位都不变）。而玩家的竖井通常是好几格宽。于是：

| 你把落点放在 | 结果 |
|---|---|
| 实体那一列（同一个 X/Z） | ✅ 它上下往复时一定会扫到 |
| 隔壁一列（X 或 Z 差 1 格） | ❌ **永远碰不到**，而且现象与"配方坏了"完全一样 |

**怎么知道该摆哪一列** —— 引擎现在直接把坐标念出来。

游戏内：

```
/mirror recipes scaffolding
```

```
· minecraft:scaffolding  处理 249 tick，最高切换 8 次
      落点该摆在哪: x=-35, z=4，y=-4 ~ 18（就是这一竖列；铺满整个水平面一层最省事）
      旁边出现过: minecraft:flowering_azalea_leaves
```

日志里（`landing` 配方没命中时，每种配方打 3 条后给一次总结）：

```
[镜维度·配方]   ↑ minecraft:scaffolding 全程探针**一个方块都没见过** —— 它待的这一列（x=-35 z=4）整列都是空气：落点方块不在这一列里。
[镜维度·配方]   ★ 要把「minecraft:soul_sand」摆在 x=-35 z=4 这一列，y=-4 ~ 18 之间（上下各留 1 格）才会被扫到；**最省事的做法是把目标方块铺满整个水平面的一层** —— 谁掉下来都碰得到。
```

> **省事原则**：与其精确摆一格，不如**把目标方块铺满整个水平面的一层**
> （井有多宽就铺多宽）。谁掉在哪一列都碰得到，也就不必再对坐标。

#### ★ 真实案例（2026-09-22，读存档量出来的）

用户报"下界疣配方一次都不触发，同一层的树叶配方每次都触发"。读存档得到：

```
下落实体    pos=(-34.5, …, 4.5)   → 它那一列 = x=-35, z=4
那一列 y=-4 摆的是   minecraft:flowering_azalea_leaves   ← 在列里 ✓（所以树叶配方一直好）
用户摆的 5 格灵魂沙：
    (-35,-4,2) (-34,-4,2) (-35,-4,3) (-34,-4,3) (-34,-4,4)
    ① 一格都没落在 x=-35, z=4 里 ✗
    ② 只有 3 格在实体的 3×3 邻域内（另 2 格连邻域都在外面）
```

**差一格 = 永远碰不到。** 而当时日志里只有一句"探针一个方块都没见过"，
既看不出"是隔壁"，也看不出"只有 2 格在邻域外"——这一轮之后补了下面的输出。

`tools-build/sim-recipes.mjs` 的**场景 L** 就是照这个真实局面复现的
（连 5 个坐标都照抄），32 条断言守着它。

#### 现在日志会直接把答案说出来

`landing` 配方连续没命中时，除了原来的"探针逐格"，还会打：

```
[镜维度·配方]   ↑ 它这一列 x=-35 z=4（y=-6 ~ 18）实际有: y=-4=minecraft:flowering_azalea_leaves
[镜维度·配方]   ↑ …；★ 你要的「minecraft:soul_sand」**就在隔壁**：
                (-35,-4,3)=minecraft:soul_sand（差 z 1 格）、(-34,-4,4)=minecraft:soul_sand（差 x 1 格）
                —— 挪进 x=-35 z=4 这一列即可
```

- **这一列实际有什么** → 一眼看出"落点根本不在这一列"（甚至是"整列空气"）。
- **你要的就在隔壁** → 直接给出差几格、往哪挪。这一句能省掉一整轮排查。
- 两者都只在**打总结日志时**扫一次，不进每 tick 主循环。

引擎侧实现是 `probeColumnOf()` / `columnReportText()`，并通过
`R.probeColumn(...)` 对外暴露（命令层与模拟器共用，避免在别处复刻扫描逻辑）。

#### 附带工具：不启动游戏也能看世界里到底有什么

`tools/inspect-column.mjs` 直接读存档（region 文件 → NBT → 方块调色板），
用来回答"**世界里那个方块到底在不在、在哪一格**"：

```powershell
node tools/inspect-column.mjs --dim mirror --x -35 --z 4            # 打印这一竖列
node tools/inspect-column.mjs --dim mirror --x -35 --z 4 --scan minecraft:soul_sand --radius 48
node tools/inspect-column.mjs --dim mirror --x -35 --z 4 --scan MAP --radius 9 --y0 -1 --y1 -1
```

`--dim` 支持 `mirror` / `overworld` / `nether` / `end`，也可以直接给相对路径；
不写 `--world` 就取 `saves` 下最近修改的那个世界。

**它已经实战过一次**：用户报"下界疣配方不生效"，日志显示探针"一个方块都没见过"，
而这个工具证明**整个镜维度存档里一个灵魂沙都没有**（扫描范围覆盖全部 4 个 region 文件、
y=-64~320）—— 于是问题立刻从"配方引擎"变成"落点方块根本不在世界里"。
日志说"我当时看见了什么"，这个工具说"世界里到底有什么"，两者一对，摆位问题当场结案。

> ⚠️ 两个已知的读档注意点（都已处理，别再踩）：
> ① 路径里有中文（`镜维度`），必须用 `fileURLToPath` 而不是 `url.pathname`，
>    否则拿到的是百分号编码、`fs` 找不到目录；
> ② 扫方块时不要"对每个 (x,z) 再扫一遍整个盒子"，那会把同一批方块重复计数 N 倍
>    （第一版把玻璃数成了 155 万个）。要**按区块遍历一次**。

---

## 15. 工作台配方（无序合成）

**玩法**：把「发光地衣」当**镜面的碎屑**，和沙子 / 沙砾揉在一起，就得到对应的
**可疑方块** —— 玩家不必满世界找考古点，也能自己造出加工原料。

| 原料（无序） | 产物 | 配方 ID |
|---|---|---|
| 沙子 + 发光地衣 | 可疑的沙子 | `mirror:suspicious_sand_from_glow_lichen` |
| 沙砾 + 发光地衣 | 可疑的沙砾 | `mirror:suspicious_gravel_from_glow_lichen` |

配置在 `mirror_config.js → craftingRecipes`，注册脚本是新模块
`kubejs/server_scripts/mirror_n9_crafting.js`，游戏内用 `/mirror crafting [关键词]` 查看。

### 15.1 原版合成机制（调研结论，1.21.1 源码）

| 事项 | 结论 |
|---|---|
| 配方类型 | `ShapelessRecipe implements CraftingRecipe`，字段 `group` / `category` / `result:ItemStack` / `ingredients:NonNullList<Ingredient>` |
| 序列化 | `ShapelessRecipe.Serializer` 注册在 `BuiltInRegistries.RECIPE_SERIALIZER` 的 `minecraft:crafting_shapeless` 下 |
| 数据形状 | `{ type, category, ingredients:[{item}/{tag}], result:{ id, count } }`（1.21 起 result 用 `id` 而不是 `item`） |
| 原料数量 | 最多 9（3×3 工作台）；无序 = 摆放位置随便 |
| **同步到客户端** | 服务端 `RecipeManager` 通过 `ClientboundUpdateRecipesPacket` 把**全部**配方发给客户端 |

### 15.2 为什么这些配方**不需要**为 JEI 做任何事

JEI 的工作台分类读的是**客户端的 `RecipeManager`**。KubeJS 的
`ServerEvents.recipes` 注册的是**真正的原版配方对象**（进服务端 RecipeManager），
所以会随上面那条原版同步机制自动到达客户端，JEI 里**自动**就能看到 ——
搜「可疑的沙子」、或在沙子上按用途键，都能找到。

⚠️ 这与 §14 的重力方块加工配方**完全不同**：那种不是原版配方类型，没有 JSON、
不参与原版合成，客户端无从得知，所以必须自己导出数据 + 写一个 JEI 分类（§14.8）。
**"JEI 里看不到"要先分清是这两类里的哪一类**，排查方向完全相反。

### 15.3 KubeJS 7.2 的接口（调研结论）

```js
// 只能注册在 kubejs/server_scripts 下；/reload 即可生效，不必重启
ServerEvents.recipes(event => {
  event.shapeless('minecraft:suspicious_sand', [   // 位置参数 1：产物（可写 '3x 物品ID'）
    'minecraft:sand',                              // 位置参数 2：原料数组
    'minecraft:glow_lichen'                        //   也可以写 '3x minecraft:x' 或 '#标签'
  ]).id('mirror:suspicious_sand_from_glow_lichen') // 建议显式给 ID
})
```

- `event.shapeless` 是 `RecipesKubeEvent` 的 `RecipeTypeFunction` 字段，
  继承 Rhino 的 `BaseFunction`，所以在脚本里**直接当函数调**。
- 参数是**位置参数**：产物在前、原料数组在后。写成一组对象字段的形式也行，
  但位置写法是官方文档给的形状。
- **顺序写反不会报错** —— 只会得到一条永远合不出来的配方。
  所以 `mirror_n9_crafting.js` 里建完配方会立刻 `serializeChanges()` 回读
  `json.result.id`，与配置对不上就打 error（见 15.5）。

### 15.4 三条硬规矩（都踩过）

1. `ServerEvents.recipes` **只能注册在 server_scripts**。写在 startup 脚本会报
   `invalid script type STARTUP`，而且会让**整个 startup 脚本**失败（配置都进不了 global）。
2. 所有 `try` 块内只用 `var`（Rhino 对 try 里的 `const/let` 会抛
   `redeclaration of var xxx`）。
3. 事件处理器**嵌套块**里也只用 `var`。这条最隐蔽：加载时显示 0 errors，
   但每次回调都抛异常，那行之后的代码一次都不执行。

### 15.5 排查：`/mirror crafting`

工作台配方出问题时游戏里**毫无表现**（合不出来就是合不出来），只有日志里一行字。
所以这条指令做两件事：

1. 列出配置里写了什么（原料 → 产物 → 配方 ID），以及本次注册成功 / 失败的条数；
2. **回读服务端配方表**：`server.getRecipeManager().byKey(ResourceLocation)`
   逐个确认配方 ID 真的在表里 —— 这一条才是"能不能合出来"的决定性证据。

输出示例：

```
工作台配方：已启用
配方数量  2 条（无序合成，最多 9 种原料）
  · minecraft:sand + minecraft:glow_lichen  →  minecraft:suspicious_sand
      ID mirror:suspicious_sand_from_glow_lichen
  · minecraft:gravel + minecraft:glow_lichen  →  minecraft:suspicious_gravel
      ID mirror:suspicious_gravel_from_glow_lichen
── 本次注册：提交 2 条 ──
  ✓ minecraft:sand + minecraft:glow_lichen → minecraft:suspicious_sand
  ✓ minecraft:gravel + minecraft:glow_lichen → minecraft:suspicious_gravel
── 服务端配方表回读：找到 2 / 2 条（当前世界共有 1234 条配方）──
JEI 的工作台分类会自动显示它们（原版配方，无需额外导出）
```

回读不可用时（API 变化等）会降级成"只看上面的注册结果"，不会抛错。


### 14.18 脚手架现在只有两条配方（以及地狱疣那条为什么被放弃）

| 输入 | 次数 | 触发 | 产物 | 备注 |
|---|---|---|---|---|
| `scaffolding` | 8 | crossing | `cobweb` | 只依赖次数 |
| `scaffolding` | 4 | landing（`#minecraft:leaves`） | 对应树苗（`@mapped`） | `drop:true` 弹成掉落物；落点用原版标签，10 种树叶全覆盖 |

两条都**只依赖"次数"与"落点"**，没有 sticky、没有跨重生计数、没有按位置共享状态 ——
这正是它们一直稳定的原因。

⛔ **被放弃的第三条**：`scaffolding` + 4 次 + 落在 `minecraft:soul_sand` 上 → `minecraft:nether_wart`。
它为"脚手架一碰方块就重生（新实体、新 UUID）"这件事，先后需要过三套机制
（严格同帧接触 → `sticky` → 按竖列计数），**每一套都带来新的失败模式**，
最终在 2026-09-22 判定性价比不成立、整条删除。完整复盘见 **14.17 / 14.21 / 14.22**。

回归覆盖：`tools-build/sim-recipes.mjs`
场景 F（脚手架 + 树叶 → 树苗掉落物：命中、`@mapped` 查表、不放方块）、
场景 I（换落点方块：树叶命中 / 灵魂沙与下界疣块都不命中）、
场景 **J**（同一竖列两个脚手架：键不同、计数互不影响、方向不变时**不记假翻转**）、
场景 L（落点摆到隔壁列 → 日志说得出"就在隔壁、差几格"）。


### 14.19 ★★ 第三个门槛：`try` 块里不能写 `const`（Rhino 会抛错，而 catch 会把它吞掉）

**这一条是读代码 + 跑 Rhino 探针查出来的**（不需要启动游戏）：
当时的现场是"计数身份键"那个函数：`try` 里写了一个 `const`，于是每次调用都静默走 fallback、身份键被悄悄换掉（见 14.21 的四层"看不见"）。
**教训与"按竖列计数"那次是同一个形状：静默 fallback 会把致命错误伪装成正常运行。**

#### 现场

配方引擎里判断"这个实体该按竖列计数还是按实体计数"的函数原本是这样写的：

```js
function stateKeyOf(entity) {
  var blockId = null;
  try { blockId = fallingBlockIdOf(entity); } catch (err) { blockId = null; }
  try {
    const col = columnKeyOf(blockId, entity.getX(), entity.getZ());   // ← 就是这里
    if (col != null) return col;
  } catch (err2) {
    // 取不到坐标就退回按实体计
  }
  return entityKey(entity);
}
```

看起来完全合理，**但它把"按竖列计数"这条机制悄悄关掉了。**

#### 为什么

KubeJS 用的是 Rhino 的一个分支（`dev.latvian.mods.rhino`）。它的解释器对
**字面写在 `try {}` 内部的 `const`** 会抛：

```
InternalError: TypeError: redeclaration of var col.
```

而这段代码**自己带着 `catch`** —— 异常被它吞掉，函数继续往下走，
返回实体键。于是：

| 没有异常时（期望） | 实际 |
|---|---|
| `col:minecraft:scaffolding@96,0` | `ent:<实体 id>` |

**后果**（若这条 fallback 真的生效）：`position_count_blocks` 形同不存在，
脚手架每次重生（新实体、新 UUID）进度都归零 → 切换次数攒不到 4 →
**脚手架那两条配方（蜘蛛网 / 树苗）一起失灵**；
而其它 44 条配方完全不碰这条路径，全都正常。

> ⚠️ **注意**：`stateKeyOf` 每次调用都会走这个 try，所以它一旦抛异常，
> fallback 是**无条件**的 —— 不存在"有时按列、有时按实体"。
> 但**能不能看出来**取决于场景：
> 脚手架一次没碰到方块时（一直在空中往复），按列与按实体**完全同解**，
> 日志里看不出任何区别；只有"碰到落点 → 原版让它重生 → 接着再攒"
> 这条路径才依赖按列计数。

#### 为什么这么久都没被发现

四个"看不见"叠在一起：

1. **异常被自己的 catch 吞掉** —— 日志里一个字都没有，KubeJS 加载显示 `0 errors`。
2. **表现与"落点方块摆错位置"一模一样** —— 都是"什么都不发生"。
3. **模拟器抓不到**：`tools-build/sim-recipes.mjs` 跑在 **Node** 上，
   而 Node 对 `try` 块内的 `const` 完全正常 —— 20 条断言全绿，游戏里全灭。
4. **之前的 Rhino 探针也误判过**：`RhinoScopeProbe` 的用例 C 写成了
   `try { const c = 3; } catch (e) {}` —— 异常同样被吞掉、`c` 又没被使用，
   于是记下了"函数内（含嵌套块）的 const/let 正常"这个**错误结论**。
   排查时照着这个结论走，就会把 `try` 块内的 `const` 当成安全写法。

#### 复现（不用启动游戏）

`tools-build/RhinoTryProbe.java`（第 3 组探针，让 catch 把异常**当返回值抛出来**）：

```
=== 1) 异常不再被吞：try 里 const 到底抛不抛 ===
  OK    try 内 const，异常原样暴露
          得到: CAUGHT(InternalError: TypeError: redeclaration of var c. (probe#1))
=== 2) 第 1 组探针为什么会误判「正常」===
  OK    try 内 const + 空 catch（异常被吞，看不出问题）
          得到: ok
=== 3) 事故原型的三种写法（值都要用上）===
  OK    const 写在 try 里（事故原型 → 静默退回 fallback）   得到: entity:7
  OK    var   写在 try 里（修复后 → 拿到正确的键）          得到: col:7
  OK    let   写在 try 里（同样是好的）                     得到: col:7
```

怎么跑：

```powershell
$rhino = "<实例>\mods\[犀牛] rhino-2101.2.7-build.85.jar"
& javac -encoding UTF-8 -cp $rhino RhinoTryProbe.java
& java "-Dfile.encoding=UTF-8" -cp "$rhino;." RhinoTryProbe
```

**结论：`try` 块内只能用 `var`。**（`let` 也可以，但为了统一，规则取 `var`。）

#### 修法（已落地）

1. `stateKeyOf` 里那个 `const col` → **`var col`**（当时并写了注释说明原因）。
   ⚠️ 后来"按竖列计数"整套被实测否决（14.21），那个函数的 `try` 也随之删掉；
   但**这条 Rhino 规则仍然要守**——项目里任何 `try` 块内都不许出现 `const`/`let`。
2. `tools/lint-scripts.mjs` 的"try 块内 const/let 审计"本来就能抓到它 ——
   但**它以前不会让命令失败**：打出 `✗ 发现 1 个问题` 却仍然 `exit 0`，
   于是这个检查形同虚设。现在已改成**非零退出码**，问题会直接卡住验证流程。
   （这条静态审计是**唯一**能拦住它的防线：模拟器跑在 Node 上，复现不了 Rhino 的行为。）
3. 当时还加过一个"计数键"读数（`stateKeyOfQuiet` + `/mirror recipes` 里那行
   `计数键 col:…`）来当场判定 fallback 有没有发生。随着按竖列计数一起删除了。
   **它留下的经验仍然有效**：凡是"配置说了 A、实际按 B 跑"的地方，
   都该有一行**能读出实际值**的仪表 —— 而不是只能靠推断。

> **通用教训**：**"自己 catch 自己"的兜底代码会把致命错误伪装成正常运行。**
> 写兜底时要么把异常报出来（日志/命令），要么就让它在测试里可见 ——
> 一段静默的 `catch {}` 比崩溃难查一百倍。
>
> 以及：**跨解释器的检查不能只靠 Node。** 模拟器的价值在于"逻辑对不对"，
> 而"这个写法在 Rhino 里能不能跑"必须由 Rhino 自己回答（`RhinoTryProbe`）
> 或由静态规则守住（`lint-scripts.mjs`）。


### 14.21 ★★★ 第四个门槛：**"上一次方向"不能共用** —— 按竖列计数为什么会把配方全灭

**这一节是 2026-09-22 15:22 那次"第二个脚手架又变蜘蛛网、没有脚手架能变下界疣"
的最终结论。** 起因是我把计数键从"实体 id"改成了"竖列"（为了让重生不丢进度），
把两个配方一起打死了。

#### 现场（日志原样）

```
15:22:28.274  已切换 4 次，正在等待接触 minecraft:soul_sand；y=14.1   方向=down
15:22:28.323  已切换 5 次，正在等待接触 minecraft:soul_sand；y=-1.99  方向=up
15:22:28.338  已切换 6 次，正在等待接触 minecraft:soul_sand；y=13.64  方向=down
15:22:28.373  已切换 8 次，触发交界处加工（y=13.1）→ 蜘蛛网
```

**三行之间只隔 49 毫秒**，而 y 从 14.1 跳到 −1.99 又跳回 13.64 ——
一秒之内它不可能跑 30 格。所以这三行**不是同一个实体**：
用户在同一竖列放了两个脚手架，而它们**共用一个计数器**。

随后用户又连放 10 个（15:22:30–33），于是：

```
15:22:43.268 → 蜘蛛网   15:22:43.369 → 蜘蛛网   15:22:43.468 → 蜘蛛网
15:22:43.569 → 蜘蛛网   15:22:43.668 → 蜘蛛网   15:22:43.820 → 蜘蛛网
```

**每 100ms 出一个蜘蛛网**，每个后面还跟着一句"已切换 0 次，配方要求 8 次"。

#### 为什么按竖列会这么夸张（两层原因，第二层才是致命的）

| # | 原因 | 后果 |
|---|---|---|
| 1 | 同一竖列的实体**共用一个 `crossings`** | 谁翻一下都算进同一个数，计数涨得比单个实体快 N 倍 |
| 2 | **"上一次方向"（`lastFlipDir`）也共用** | 两个实体方向相反 → 脚本处理 A 时看到 `down`，上次记的是 B 的 `up` → **记一次翻转**；下一 tick 处理 B 又反过来 → 又记一次。**方向没变也在涨** |

第 2 层是关键：它让"切换次数"彻底脱离物理事实 ——
实体一直朝上飞，计数照样每 tick +1。所以 0 → 8 只要一秒。

**而"4 次切换 + 落在灵魂沙上 → 下界疣"必须赢下这场竞速**：它要求计数落在
[4, 8) 之间、且那一刻探针正看到灵魂沙。计数被推到 8 只要一秒，它永远没机会。

#### 结论（已落地）

```js
// mirror_n3_recipes.js —— 计数键一律是实体 id，一个实体一份状态
function stateKeyOf(entity) {
  return entityKey(entity);
}
```

- **同一竖列的两个脚手架必须是两个不同的键**（各算各的计数与方向）。
  这是 `tools-build/sim-recipes.mjs` **场景 J** 守的东西：断言两个键不同、
  第二个不继承第一个的进度，而且"方向不变地跑 6 tick 不产生任何假翻转"。
- **玩家另放一个**不再需要任何特殊处理（新实体天然就是新键），
  于是 `BlockEvents.placed` 清零、`position_count_blocks` 配置项一并**删除**。
- **"重生丢进度"**改用配方上的 `sticky: true`（14.17）——
  这是 13:53 实测跑通过的那条路。

#### 这一节真正的通用教训

> **共享状态只能共享"确实属于整体"的东西。**
> `crossings` 或许还能争论"算不算同一趟"，但**"上一次方向"天然只能属于一个实体** ——
> 一旦把它按竖列共享，逻辑就再也不成立了。
> 换句话说：**看到"按位置/按名字"合并状态时，先检查这份状态里有没有
> "只对单个实体才有意义"的字段**（方向、速度、上一次高度……）。有，就不能合并。

> 以及：**症状（"第二个脚手架变蜘蛛网"）在两次事故里长得一模一样，
> 原因却是两个** —— 上一次是"落点摆错一列"，这一次是"计数被共用"。
> 所以每次都回到**日志里的数字**去判断，不要凭症状套上一次的结论。

#### 相关：读日志时的"一眼判别法"

| 日志形状 | 结论 |
|---|---|
| 相邻两行的 y 相差十几格、却只隔几十毫秒 | **不是同一个实体** → 查计数是否被共用 |
| 计数以"每 tick +1"的速度涨 | 假翻转 → 查 `lastFlipDir` 之类"只属于实体"的状态是否被共用 |
| "已切换 8 次"后面跟着"已切换 0 次"，且每隔 ~100ms 重复 | 一波实体在共用同一个计数器，会被逐个收走 |
### 14.22 ⛔ 放弃记录：为什么删掉「脚手架 → 地狱疣」，以及下次怎么判断

**决定（2026-09-22）**：删除配方 `scaffolding_to_nether_wart`，
并删除只为它存在的两套机制（`sticky`、跨重生计数 / `position_count_blocks`）。
用户复测确认仍然不行后作出此决定：**不再投入**。

#### 为什么放弃（不是"再试一次就好了"，而是代价已经超过收益）

| 事实 | 含义 |
|---|---|
| 前后十几轮、三套机制（严格同帧 → sticky → 按竖列计数） | 每加一套机制，就多一类失败模式：sticky 把语义放宽成"蹭过一次"，按竖列计数直接引发"同列多个脚手架互相污染、1 秒冲到 8 次全变蜘蛛网" |
| 唯一跑通的一次（13:53）依赖 sticky | 也就是说：**能跑通的那个版本，语义已经不是设定想要的"落在灵魂沙上"** |
| 脚手架是唯一"碰一下就重生"的下落方块 | 它的计数身份天生不稳定；为它做的每件事都是**特例**，而特例会持续消耗维护成本 |
| 同一批配方里别的 45 条都稳 | 对比之下，这条的性价比明显不成立 |

> **判断标准**（下次遇到类似情况直接用）：
> 当一条配方需要**第二套专用机制**才能成立时，先停下来问三个问题 ——
> ① 这套机制会不会放宽/改变原本的设定语义？
> ② 它是不是只为这一条配方存在（特例）？
> ③ 它会引入"共享状态"吗（按位置/按名字合并计数、方向、速度…）？
> 只要 ① 或 ③ 有一个是"会"，就应当考虑放弃这条配方，而不是继续加机制。

#### 现在的脚手架（只剩两条，都稳定）

| 输入 | 次数 | 触发 | 产物 |
|---|---|---|---|
| `scaffolding` | 8 | crossing | `cobweb` |
| `scaffolding` | 4 | landing（`#minecraft:leaves`） | 对应树苗（`@mapped`，掉落物） |

#### 如果将来还想要"地狱疣"这个产物

**不要**再为"落在灵魂沙上"这件事加机制。可行的方向是**换形状**：

- **crossing 形状**：`scaffolding` + N 次切换 → `nether_wart`（交界处直接变）。
  只依赖次数 —— 这是本项目里最稳的一类（沙砾/沙子/红沙/混凝土全是这个形状）。
  但要先想清楚它和现有两条的关系（4 次 landing 树叶那条仍然优先，因为
  landing 在 crossing 之前判定），并且**得接受它与"灵魂沙"无关**。
- **换输入方块**：让"灵魂沙"参与一条**别的主方块**的配方，
  例如 `suspicious_sand`（可疑的沙子）落在灵魂沙上 → 地狱疣 ——
  可疑方块是普通下落方块（不重生），没有计数身份问题。

两条都**没有实现**，等真正想做时再挑一条。

#### 代码里现在的状态（确保没有残留）

- `mirror_config.js`：配方删除，原位置留一段"已放弃"的说明；
- `mirror_n3_recipes.js`：`stickyTouch` / `landingRecipesOf` / `trackStickyTouch` /
  `matchStickyLanding` / `addRecipe` 的 `sticky` 字段 / `clearStickyTouch` 全部删除；
- `gravity.position_count_blocks`、`columnKeyOf`、`clearColumnCount`、
  `BlockEvents.placed` 处理器全部删除；
- mod 侧：`GravityRecipe` / `GravityRecipeData` 的 `sticky` 字段与 JEI 提示删除，
  `gravity_recipes.json` 里 0 条带它；
- `check-recipes.mjs`：反向断言 —— 脚手架必须**正好 2 条**、
  不许出现地狱疣那条、不许出现 `position_count_blocks`、不许有配方用 `sticky`。

