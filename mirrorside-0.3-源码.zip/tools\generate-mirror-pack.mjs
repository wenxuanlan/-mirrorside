#!/usr/bin/env node
/**
 * 镜维度 · 数据包生成器
 * =====================================================================
 * 单一数据源: <实例>/kubejs/config/mirror_dimension.json
 * 产出:
 *   kubejs/data/<ns>/dimension_type/<dimension_type_path>.json
 *   kubejs/data/<ns>/worldgen/biome/<biome_path>.json
 *   kubejs/data/<ns>/dimension/<dimension_path>.json
 *
 * 为什么用生成器:
 *   dimension_type 的 min_y / height / logical_height 三个值必须互相自洽，
 *   biome 的六个颜色值、spawners 的八个类别键也一个都不能少。手写三份 JSON
 *   时任何一处不一致，游戏只会给一句含糊的「无法加载维度」。
 *   生成器把校验前置，并保证三份文件永远同步。
 *
 * 用法:
 *   node tools/generate-mirror-pack.mjs
 *   node tools/generate-mirror-pack.mjs --instance "D:\\path\\to\\镜维度"
 * =====================================================================
 */

import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
// tools/ 的上一级就是实例目录（即 .minecraft/versions/镜维度）
let INSTANCE = resolve(HERE, '..');

const argv = process.argv.slice(2);
const iFlag = argv.indexOf('--instance');
if (iFlag !== -1 && argv[iFlag + 1]) INSTANCE = resolve(argv[iFlag + 1]);

const CONFIG_PATH = join(INSTANCE, 'kubejs', 'config', 'mirror_dimension.json');
// 运行时配置（JS 形式）。世界结构相关的值以它为权威，避免两处不一致。
const RUNTIME_CONFIG_PATH = join(INSTANCE, 'kubejs', 'startup_scripts', 'mirror_config.js');
// 空地形 noise_settings 的模板：从原版 overworld 改出来
// 空地形模板（原版 1.21.1 overworld noise_settings 的骨架，gzip+base64）。
// 内嵌在这里而不是读 _vanilla_ref/，这样生成器是自包含的、可以直接拷贝到别处用。
// 骨架的 noise_router 已全部抹成常数 —— 反正 buildVoidNoiseSettings() 也会再抹一次。
const VOID_TEMPLATE_GZ_B64 =
  'H4sIAAAAAAAACnVRQY7bMAz8C88+ZHsq/Ih+oCgExhorbGXKpSgvsov8vZCSIi22vXGGwwHJeSf+2WSF1QDlc0akeeVcMVExhAOiHztRaifCVs4hQWHsUpRmt4aJMhIv12CssWyhlmYLfvciVm7ZwzmX5QfN7/SFN9BMmygW49Xn6kVBt6d0zU3iP6Us1oUVHDIOZJpPE2mRii7fRMN1UBdIujjNL58+T1TlDeFSTN6KOmeaXx7cAXNZBnN72AQrzWHd7cxm0svTREtRF4V6HTBi98uoYKWOR5wmWkU5hwit4vc1xiH3TcOaS4mIilo/9Opu4DhoUXF52oRX8UtpHr5zSn9MZz54FCYx4c45tr0H0wwDH0jwR04DiobE+xOM2fjEXlLKfba/uNnKC4K1PH7r1/3vKO55TmSoPbPq7Ph/Zt1x51cNzpbgNH/9dvsFd5Nu9okCAAA=';

/* ------------------------------------------------------------------ */
/* 读取运行时配置（mirror_config.js）                                    */
/* ------------------------------------------------------------------ */
/* 不能 import（那是给游戏用的脚本，含 global 赋值），所以用一个极简解析：
 * 找到 `const MIRROR_CONFIG = { ... };` 之后把那段对象字面量 eval 出来。
 * 之所以能这么做：那个文件里除了对象字面量就是注释，没有副作用。
 */
function loadRuntimeConfig() {
  if (!existsSync(RUNTIME_CONFIG_PATH)) {
    console.error(`[警告] 找不到运行时配置：${RUNTIME_CONFIG_PATH}`);
    console.error('        世界结构（高度/玻璃层/镜内范围）将使用内置默认值。');
    return null;
  }
  const src = readFileSync(RUNTIME_CONFIG_PATH, 'utf8').replace(/^\uFEFF/, '');
  const start = src.indexOf('const MIRROR_CONFIG');
  if (start === -1) {
    console.error('[警告] mirror_config.js 里找不到 MIRROR_CONFIG，使用内置默认值。');
    return null;
  }
  const braceStart = src.indexOf('{', start);
  // 花括号配平（跳过字符串与注释里的括号）
  let depth = 0, end = -1, inStr = null, inLine = false, inBlock = false;
  for (let i = braceStart; i < src.length; i++) {
    const c = src[i], n = src[i + 1];
    if (inLine) { if (c === '\n') inLine = false; continue; }
    if (inBlock) { if (c === '*' && n === '/') { inBlock = false; i++; } continue; }
    if (inStr) {
      if (c === '\\') { i++; continue; }
      if (c === inStr) inStr = null;
      continue;
    }
    if (c === '/' && n === '/') { inLine = true; i++; continue; }
    if (c === '/' && n === '*') { inBlock = true; i++; continue; }
    if (c === "'" || c === '"' || c === '`') { inStr = c; continue; }
    if (c === '{') depth++;
    else if (c === '}') { depth--; if (depth === 0) { end = i; break; } }
  }
  if (end === -1) {
    console.error('[警告] mirror_config.js 里的对象字面量括号不配平，使用内置默认值。');
    return null;
  }
  const literal = src.slice(braceStart, end + 1);
  try {
    /* ⚠️ 必须把**对象字面量之前的顶层代码**一起 eval。
     * 早先只 eval 那一段，于是对象里一引用顶层常量就 ReferenceError
     * —— 战利品表 MIRROR_GRAVEL_BRUSH_LOOT / MIRROR_SAND_BRUSH_LOOT /
     * MIRROR_LEAVES_TO_SAPLING 就是这种（它们定义在 const MIRROR_CONFIG 之前）。
     * 更糟的是当时的失败是"静默回退到内置默认值"，于是生成出一份**路径错误**的
     * 数据包（biome 写成 mirror_plain、dimension 指向它），一直到 2026-09-25 才发现。
     * 对象之前的内容只有注释与纯数据常量，eval 没有副作用。 */
    const prologue = src.slice(0, start);
    // eslint-disable-next-line no-new-func
    return new Function(prologue + '\nreturn (' + literal + ');')();
  } catch (e) {
    /* 配置存在、却读不出来 = 真问题。这时候用兜底值继续生成只会产出错的数据包，
     * 所以直接中止（宁可什么都不生成）。 */
    console.error('[错误] 解析 mirror_config.js 失败：' + e.message);
    console.error('       文件: ' + RUNTIME_CONFIG_PATH);
    console.error('       已中止：用兜底值生成数据包会把维度指向错误的路径。');
    process.exit(1);
  }
}

const rt = loadRuntimeConfig();


/* ------------------------------------------------------------------ */
/* 读取配置                                                             */
/* ------------------------------------------------------------------ */

if (!existsSync(CONFIG_PATH)) {
  console.error(`[错误] 找不到配置文件：\n  ${CONFIG_PATH}`);
  process.exit(1);
}

let cfg;
try {
  // 去掉 BOM，兼容被记事本另存过的文件
  const raw = readFileSync(CONFIG_PATH, 'utf8').replace(/^\uFEFF/, '');
  cfg = JSON.parse(raw);
} catch (e) {
  console.error(`[错误] 配置文件不是合法 JSON：\n  ${CONFIG_PATH}\n  ${e.message}`);
  process.exit(1);
}

/* ------------------------------------------------------------------ */
/* 工具与校验                                                           */
/* ------------------------------------------------------------------ */

const errors = [];
const fail = (msg) => errors.push(msg);

// 命名空间/路径以运行时配置（mirror_config.js）为权威，JSON 只作兜底。
// 否则「改了 JS 里的人格名、JSON 没跟着改」会让 biome 文件名与脚本引用对不上。
if (rt) {
  if (rt.namespace) cfg.namespace = rt.namespace;
  if (rt.dimension_path) cfg.dimension_path = rt.dimension_path;
  if (rt.dimension_type_path) cfg.dimension_type_path = rt.dimension_type_path;
  if (rt.biome_path) cfg.biome_path = rt.biome_path;
}

function hexToInt(hex, label) {
  if (typeof hex !== 'string' || !hex.trim()) {
    fail(`${label} 颜色值缺失`);
    return 0;
  }
  const h = hex.trim().replace(/^#/, '');
  if (!/^[0-9a-fA-F]{6}$/.test(h)) {
    fail(`${label} 必须是 6 位十六进制颜色，收到 "${hex}"`);
    return 0;
  }
  return parseInt(h, 16);
}

// 1.21.1 对 dimension_type 有硬性数值约束，写错会导致维度整个加载失败
function checkRange(v, min, max, name) {
  if (typeof v !== 'number' || !Number.isFinite(v)) return fail(`${name} 必须是数字`);
  if (v < min || v > max) fail(`${name} 必须在 ${min}..${max} 之间，收到 ${v}`);
}
function checkMultipleOf16(v, name) {
  if (typeof v !== 'number' || v % 16 !== 0) fail(`${name} 必须是 16 的倍数，收到 ${v}`);
}

const dt = cfg.dimension_type;
const bio = cfg.biome;
const gen = cfg.generator;

checkMultipleOf16(dt.min_y, 'dimension_type.min_y');
checkMultipleOf16(dt.height, 'dimension_type.height');
checkRange(dt.min_y, -2032, 2031, 'dimension_type.min_y');
checkRange(dt.height, 16, 4064, 'dimension_type.height');
if (dt.min_y + dt.height > 2032) {
  fail(`min_y + height 不能超过 2032（当前 ${dt.min_y + dt.height}）`);
}
if (dt.logical_height > dt.height) {
  fail(`logical_height(${dt.logical_height}) 不能大于 height(${dt.height})`);
}
checkRange(dt.coordinate_scale, 1e-5, 3e7, 'dimension_type.coordinate_scale');
checkRange(dt.ambient_light, 0, 1, 'dimension_type.ambient_light');
checkRange(dt.monster_spawn_light_level, 0, 15, 'dimension_type.monster_spawn_light_level');
checkRange(dt.monster_spawn_block_light_limit, 0, 15, 'dimension_type.monster_spawn_block_light_limit');

/* effects 的合法性。
 *
 * 原版只有三个硬编码值（overworld / the_nether / the_end），纯数据包确实无法自定义 ——
 * 但 NeoForge 开了口子：模组可以在 RegisterDimensionSpecialEffectsEvent 里
 * 注册任意 id 的 DimensionSpecialEffects（见
 * MirrorClientSetup.java / MirrorDimensionEffects.java）。
 *
 * 我们用这个口子做"主世界的天空 + 不画云"：原版三个值里没有这种组合
 * （overworld 有云；nether/end 的天空与雾完全变了）。
 * ⚠️ 未注册的 id 不会崩：NeoForge 的 DimensionSpecialEffectsManager.getForType
 *    对未知 id 回退到主世界效果（只是又有云了）。 */
const VALID_EFFECTS = [
  'minecraft:overworld', 'minecraft:the_nether', 'minecraft:the_end',
  'mirrorgravity:mirror',
];
if (!VALID_EFFECTS.includes(dt.effects)) {
  fail(`dimension_type.effects 只能是 ${VALID_EFFECTS.join(' / ')}，收到 "${dt.effects}"`
    + '（要用别的自定义 id，得先在模组的 RegisterDimensionSpecialEffectsEvent 里注册）');
}
if (typeof dt.infiniburn !== 'string' || !dt.infiniburn.startsWith('#')) {
  fail(`dimension_type.infiniburn 必须是以 # 开头的方块标签，收到 "${dt.infiniburn}"`);
}

// 1.21.1 原版只有这 7 个 noise_settings
const VALID_NOISE = [
  'minecraft:overworld', 'minecraft:large_biomes', 'minecraft:amplified',
  'minecraft:caves', 'minecraft:floating_islands', 'minecraft:nether', 'minecraft:end',
];
if (!VALID_NOISE.includes(gen.settings)) {
  fail(`generator.settings 必须是以下之一：\n    ${VALID_NOISE.join('\n    ')}\n  收到 "${gen.settings}"`);
}
// multi_noise 需要 worldgen/multi_noise_biome_source_parameter_list，本骨架暂不生成
if (gen.biome_source_type !== 'minecraft:fixed') {
  fail(`本骨架只支持 generator.biome_source_type = "minecraft:fixed"，收到 "${gen.biome_source_type}"`);
}

const ns = cfg.namespace;
if (typeof ns !== 'string' || !/^[a-z0-9_.-]+$/.test(ns)) {
  fail(`namespace 只能包含小写字母、数字、下划线、点、连字符，收到 "${ns}"`);
}
// 与 KubeJS 脚本里的常量保持一致，改名时两边都要改
if (ns === 'minecraft') fail('namespace 不能占用 minecraft');

const SPAWNER_KEYS = [
  'ambient', 'axolotls', 'creature', 'misc',
  'monster', 'underground_water_creature', 'water_ambient', 'water_creature',
];

function buildSpawnerList(list, label) {
  if (list == null) return [];
  if (!Array.isArray(list)) {
    fail(`${label} 必须是数组`);
    return [];
  }
  return list.map((s, i) => {
    if (!s || typeof s !== 'object') {
      fail(`${label}[${i}] 必须是对象`);
      return null;
    }
    const { type, weight, minCount, maxCount } = s;
    if (typeof type !== 'string' || !type.includes(':')) fail(`${label}[${i}].type 必须是带命名空间的实体 ID`);
    if (typeof weight !== 'number') fail(`${label}[${i}].weight 必须是数字`);
    if (!Number.isInteger(minCount) || minCount < 1) fail(`${label}[${i}].minCount 必须是正整数`);
    if (!Number.isInteger(maxCount) || maxCount < minCount) fail(`${label}[${i}].maxCount 必须是 ≥ minCount 的整数`);
    return { type, weight, minCount, maxCount };
  }).filter(Boolean);
}

if (errors.length) {
  console.error('[配置校验失败] 未写出任何文件：\n');
  for (const e of errors) console.error(`  · ${e}`);
  console.error(`\n请修改：${CONFIG_PATH}`);
  process.exit(1);
}

/* ------------------------------------------------------------------ */
/* 组装「空地形」noise_settings                                          */
/* ------------------------------------------------------------------ */
/* 目标：整个维度没有任何地形方块（设定第 4 条）。
 *
 * 做法：拿原版 overworld.json 当模板（结构一定合法），只改三处：
 *   1. noise.min_y / noise.height 必须与 dimension_type 一致，否则底部露虚空
 *   2. final_density 设成常数 0 —— 它决定「该位置放实心方块还是空气」，
 *      恒为 0/负值即全空气，这是整个方案的关键
 *   3. noise_router 里其余密度函数全部抹成常数，省掉无谓的噪声计算
 * 同时关掉含水层与矿脉，避免凭空生成水/矿石。
 */
function buildVoidNoiseSettings() {
  // 模板是 end.json 改造来的「空世界」骨架，内嵌为 gzip+base64。
  //
  // ⚠️ 两个崩溃教训（务必保持）：
  //   1. surface_rule 必须是 RuleSource **对象**。写成 [] 会让整个维度注册表
  //      加载失败并崩溃：Not a JSON object: []
  //   2. density_function 一律用**裸数字**。数字是「常数密度函数」的简写，
  //      原版 end.json 大量这么写。写成 {"type":"minecraft:constant","value":0}
  //      实测在这条解析路径上报 Not a number / No key argument。
  let nsObj;
  try {
    const buf = gunzipSync(Buffer.from(VOID_TEMPLATE_GZ_B64, 'base64'));
    nsObj = JSON.parse(buf.toString('utf8'));
  } catch (e) {
    fail('内嵌空地形模板解压失败：' + e.message);
    return null;
  }

  // 高度必须与 dimension_type 对齐，否则底部/顶部露虚空
  const L = (rt && rt.layout) || {};
  const minY = L.min_y != null ? L.min_y : -192;
  const height = L.height != null ? L.height : 384;
  nsObj.noise = { ...(nsObj.noise || {}), min_y: minY, height: height };

  // 全空气：final_density 恒为 0（非正数 → 空气）。
  // 其余噪声路由也抹成 0，省掉无谓计算。
  for (const key of Object.keys(nsObj.noise_router)) {
    nsObj.noise_router[key] = 0;
  }
  nsObj.noise_router.final_density = 0;
  nsObj.noise_router.initial_density_without_jaggedness = 0;

  // 关掉会凭空造东西的开关
  nsObj.aquifers_enabled = false;
  nsObj.ore_veins_enabled = false;
  nsObj.disable_mob_generation = true;
  nsObj.sea_level = minY;
  nsObj.surface_rule = { type: 'minecraft:block', result_state: { Name: 'minecraft:air' } };
  nsObj.spawn_target = [];

  return nsObj;
}

/* ------------------------------------------------------------------ */
/* 组装 dimension_type                                                  */
/* ------------------------------------------------------------------ */

const dimensionType = {
  ultrawarm: !!dt.ultrawarm,
  natural: !!dt.natural,
  coordinate_scale: dt.coordinate_scale,
  has_skylight: !!dt.has_skylight,
  has_ceiling: !!dt.has_ceiling,
  ambient_light: dt.ambient_light,
  monster_spawn_light_level: dt.monster_spawn_light_level,
  monster_spawn_block_light_limit: dt.monster_spawn_block_light_limit,
  piglin_safe: !!dt.piglin_safe,
  bed_works: !!dt.bed_works,
  respawn_anchor_works: !!dt.respawn_anchor_works,
  has_raids: !!dt.has_raids,
  logical_height: dt.logical_height,
  min_y: dt.min_y,
  height: dt.height,
  infiniburn: dt.infiniburn,
  effects: dt.effects,
};
// fixed_time 是可选字段：写 null 不合法，必须整个省略（省略 = 正常昼夜循环）
if (dt.fixed_time != null) dimensionType.fixed_time = dt.fixed_time;

// 世界结构以 mirror_config.js 的 layout 为准（那里才是「设定」的落点）。
// JSON 里的 min_y/height 若与它冲突，以 JS 为准并给出提示。
{
  const L = (rt && rt.layout) || {};
  if (L.min_y != null) {
    if (dt.min_y !== L.min_y) {
      console.log(`[提示] min_y 以 mirror_config.js 为准：JSON=${dt.min_y} → JS=${L.min_y}`);
    }
    dimensionType.min_y = L.min_y;
  }
  if (L.height != null) {
    if (dt.height !== L.height) {
      console.log(`[提示] height 以 mirror_config.js 为准：JSON=${dt.height} → JS=${L.height}`);
    }
    dimensionType.height = L.height;
  }
  // logical_height 至少要覆盖整个可建造范围，否则传送/落地高度会被夹
  dimensionType.logical_height = dimensionType.height;
}

/* ------------------------------------------------------------------ */
/* 玻璃层：用世界生成铺，而不是脚本                                      */
/* ------------------------------------------------------------------ */
/* 关键发现：1.21.1 有一个几乎没人用、但正好合用的地物类型
 *     minecraft:fill_layer   配置 { height: int, state: BlockState }
 * 它的实现（FillLayerFeature.place）会遍历该区块内**全部** X/Z，
 * 在指定 height 上 setBlock，且**只在 isAir 时写入**。
 *   · 无遗漏 —— 不像 count+in_square 那样随机撒点留洞
 *   · 不覆盖 —— 玩家自己放的方块不会被冲掉
 *   · 生成期完成 —— 不需要脚本逐区块补，也不需要玩家靠近
 *
 * height 是相对于 min_y 的偏移（FillLayerFeature 用 getMinBuildHeight() + height）。
 */
function buildGlassFeatures(glassLayers) {
  const configured = [];   // [relPath, obj]
  const placed = [];       // [relPath, obj]
  const placedIds = [];    // 供 biome.features 引用的 placed_feature id

  // ⚠️ 文件名只用 ASCII：层名可能是中文（如「镜外上界」），
  //    直接 sanitize 会把整串替换成下划线，导致文件名重复互相覆盖。
  //    所以用「层序号 + 坐标符号」来构造唯一且可读的名字。
  let li = 0;
  for (const layer of glassLayers) {
    li++;
    for (const y of layer.ys) {
      const yTag = y < 0 ? `neg${Math.abs(y)}` : `pos${y}`;
      const stem = `glass_layer_${li}_${yTag}`;
      const cfgId = `${ns}:${stem}`;

      // height 相对 min_y 的偏移（FillLayerFeature 用 getMinBuildHeight() + height）
      const rel = y - minY;
      if (rel < 0 || rel > 4064) {
        fail(`玻璃层 y=${y} 超出 [min_y, min_y+4064] 范围`);
        continue;
      }

      configured.push([`worldgen/configured_feature/${stem}.json`, {
        type: 'minecraft:fill_layer',
        config: {
          height: rel,
          state: { Name: layer.block },
        },
      }]);

      // 每个区块铺一次即可 —— fill_layer 自己会遍历整层的 256 个 X/Z
      placed.push([`worldgen/placed_feature/${stem}.json`, {
        feature: cfgId,
        placement: [
          { type: 'minecraft:count', count: 1 },
          { type: 'minecraft:biome' },
        ],
      }]);

      placedIds.push(cfgId);
    }
  }

  return { configured, placed, placedIds };
}

function sanitize(s) {
  return String(s).replace(/[^a-z0-9_]/gi, '_').toLowerCase();
}

const minY = (rt && rt.layout && rt.layout.min_y != null) ? rt.layout.min_y : -192;
const glassFeatures = buildGlassFeatures(
  (rt && rt.layout && rt.layout.glass_layers) || []
);

/* ------------------------------------------------------------------ */
/* 组装 biome                                                           */
/* 注意 1.21.1 的两个格式陷阱：                                          */
/*   carvers  → 按雕刻类型分组的「对象」；1.21.2(24w33a) 才改成扁平数组   */
/*   features → 11 个 generation step 的「嵌套数组」；任何版本都不是扁平列表 */
/* ------------------------------------------------------------------ */

// 把玻璃层地物放进 TOP_LAYER_MODIFICATION（第 11 步，索引 10），
// 它在所有其它步骤之后执行，是「最后决定这一层长什么样」的位置。
const biomeFeatures = [[], [], [], [], [], [], [], [], [], [], []];
biomeFeatures[10] = glassFeatures.placedIds.slice();

const biome = {
  temperature: bio.temperature,
  downfall: bio.downfall,
  has_precipitation: !!bio.has_precipitation,
  effects: {
    sky_color: hexToInt(bio.sky_color_hex, 'biome.sky_color_hex'),
    fog_color: hexToInt(bio.fog_color_hex, 'biome.fog_color_hex'),
    water_color: hexToInt(bio.water_color_hex, 'biome.water_color_hex'),
    water_fog_color: hexToInt(bio.water_fog_color_hex, 'biome.water_fog_color_hex'),
    grass_color: hexToInt(bio.grass_color_hex, 'biome.grass_color_hex'),
    foliage_color: hexToInt(bio.foliage_color_hex, 'biome.foliage_color_hex'),
    grass_color_modifier: 'none',
    mood_sound: {
      sound: 'minecraft:ambient.cave',
      tick_delay: 6000,
      offset: 2.0,
      block_search_extent: 8,
    },
  },
  // 除此以外不生成任何东西：不雕刻洞穴、不放任何地物。
  // carvers 在 1.21.1 是对象、features 是 11 元素嵌套数组。
  carvers: {},
  features: biomeFeatures,

  // 八个类别键一个都不能少，缺键会让数据包整份失效
  spawners: {
    ambient: buildSpawnerList(bio.spawner_ambient, 'biome.spawner_ambient'),
    axolotls: [],
    creature: buildSpawnerList(bio.spawner_creature, 'biome.spawner_creature'),
    misc: [],
    monster: buildSpawnerList(bio.spawner_monster, 'biome.spawner_monster'),
    underground_water_creature: [],
    water_ambient: [],
    water_creature: [],
  },
  spawn_costs: {},
};

for (const k of SPAWNER_KEYS) {
  if (!(k in biome.spawners)) fail(`biome.spawners 缺少类别键 ${k}`);
}

/* ------------------------------------------------------------------ */
/* 组装 dimension                                                       */
/* ------------------------------------------------------------------ */

const noiseSettingsPath = (rt && rt.noise_settings_path) || 'mirror_void';
// 生成空地形；失败时退回原来的 settings（此时 errors 已有内容，会在下面中止）
const voidNoise = buildVoidNoiseSettings();

const dimension = {
  type: `${ns}:${cfg.dimension_type_path}`,
  generator: {
    type: 'minecraft:noise',
    // 用自定义的空地形设置；它由 buildVoidNoiseSettings() 从原版 overworld 改出来
    settings: voidNoise ? `${ns}:${noiseSettingsPath}` : gen.settings,
    biome_source: {
      type: gen.biome_source_type,
      biome: `${ns}:${cfg.biome_path}`,
    },
  },
};

/* ------------------------------------------------------------------ */
/* 落盘                                                                 */
/* ------------------------------------------------------------------ */

if (errors.length) {
  console.error('[组装阶段发现问题] 未写出任何文件：\n');
  for (const e of errors) console.error(`  · ${e}`);
  process.exit(1);
}

const outRoot = join(INSTANCE, 'kubejs', 'data', ns);
const outputs = [
  [`dimension_type/${cfg.dimension_type_path}.json`, dimensionType],
  [`worldgen/biome/${cfg.biome_path}.json`, biome],
  [`dimension/${cfg.dimension_path}.json`, dimension],
];
// 空地形 noise_settings（设定第 4 条「无任何物块」）
if (voidNoise) {
  outputs.push([`worldgen/noise_settings/${noiseSettingsPath}.json`, voidNoise]);
}
// 玻璃层地物：configured_feature（fill_layer）+ placed_feature
for (const [rel, obj] of glassFeatures.configured) outputs.push([rel, obj]);
for (const [rel, obj] of glassFeatures.placed) outputs.push([rel, obj]);

for (const [rel, obj] of outputs) {
  const full = join(outRoot, rel);
  mkdirSync(dirname(full), { recursive: true });
  // KubeJS 会把 kubejs/data/ 当作永久启用的数据包加载，
  // 且其内部校验要求文件名全小写、无非法字符，这里天然满足。
  writeFileSync(full, JSON.stringify(obj, null, 2) + '\n', 'utf8');
  console.log(`[生成] ${full}`);
}

console.log('');
console.log(`命名空间      : ${ns}`);
console.log(`维度 ID       : ${ns}:${cfg.dimension_path}`);
console.log(`维度类型 ID   : ${ns}:${cfg.dimension_type_path}`);
console.log(`生物群系 ID   : ${ns}:${cfg.biome_path}`);
console.log(`空地形设置 ID : ${ns}:${noiseSettingsPath}`);
console.log(`可建造高度    : y ${dimensionType.min_y} ~ ${dimensionType.min_y + dimensionType.height - 1}`
  + `（共 ${dimensionType.height} 格）`);
if (rt && rt.layout) {
  const L = rt.layout;
  console.log(`镜内范围      : y ${L.inner_min_y} ~ ${L.inner_max_y}；此外为镜外`);
  const layers = (L.glass_layers || [])
    .map((g) => `${g.name} y=[${g.ys.join(',')}] ${g.block.replace('minecraft:', '')}`)
    .join('  |  ');
  console.log(`玻璃层        : ${layers || '(未配置)'}`);
  console.log(`玻璃地物      : ${glassFeatures.placedIds.length} 个 fill_layer（世界生成期铺设，无遗漏、不覆盖已放方块）`);
}
console.log(`渲染 effects  : ${dt.effects}${dt.fixed_time != null ? `  (固定时间 ${dt.fixed_time})` : ''}`);
console.log('');
console.log('进入方式      : /execute in ' + ns + ':' + cfg.dimension_path + ' run tp @s ~ ~ ~');
console.log('生效方式      : 退出世界重新进入（改世界生成后 /reload 无效，见 MC-187938）');

