#!/usr/bin/env node
/**
 * 镜维度 · 进世界验证
 * =====================================================================
 * 用 --quickPlaySingleplayer 直接进入指定世界，验证：
 *   · 服务端脚本（server_scripts）是否加载成功
 *   · /mirror 指令是否注册
 *   · 传送门是否注册
 *   · 有无 KubeJS 报错
 *
 * 用法:
 *   node tools/verify-world.mjs                     # 用默认世界
 *   node tools/verify-world.mjs "镜维度测试" 100     # 指定世界与秒数
 * =====================================================================
 */

import { readFileSync, existsSync, readdirSync, rmSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { dirname, join, resolve, delimiter } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const INSTANCE = resolve(HERE, '..');
const MC = resolve(INSTANCE, '..', '..');
const LIBS = join(MC, 'libraries');
const ASSETS = join(MC, 'assets');
const JAVA = process.env.MIRROR_JAVA ?? 'D:\\App\\java21\\bin\\java.exe';

const WORLD = process.argv[2] ?? '镜维度测试';
const SECONDS = Number(process.argv[3] ?? 100);

const overlayPath = readdirSync(INSTANCE).filter((f) => f.endsWith('.json'))
  .map((f) => join(INSTANCE, f))
  .find((p) => { try { return Array.isArray(JSON.parse(readFileSync(p, 'utf8')).libraries); } catch { return false; } });
const overlay = JSON.parse(readFileSync(overlayPath, 'utf8'));
const baseId = overlay.inheritsFrom;
const base = JSON.parse(readFileSync(join(resolve(INSTANCE, '..'), baseId, `${baseId}.json`), 'utf8'));

const allowed = (lib) => {
  if (!lib.rules) return true;
  let ok = false;
  for (const r of lib.rules) {
    const osOk = !r.os || (r.os.name === 'windows' && process.platform === 'win32')
      || (r.os.name === 'linux' && process.platform === 'linux')
      || (r.os.name === 'osx' && process.platform === 'darwin');
    if (r.action === 'allow' && osOk) ok = true;
    if (r.action === 'disallow' && osOk) ok = false;
  }
  return ok;
};

const cp = [];
const seen = new Set();
for (const src of [base.libraries ?? [], overlay.libraries ?? []]) {
  for (const lib of src) {
    if (!allowed(lib)) continue;
    const p = lib.downloads?.artifact?.path;
    if (!p) continue;
    const full = join(LIBS, p);
    if (seen.has(full)) continue;
    seen.add(full);
    if (existsSync(full)) cp.push(full);
  }
}

let neoVer = null;
const g = overlay.arguments?.game ?? [];
for (let i = 0; i < g.length - 1; i++) if (g[i] === '--fml.neoForgeVersion') neoVer = g[i + 1];
const clientJarName = `neoforge-${neoVer}-client.jar`;
const clientJar = join(LIBS, 'net/neoforged/neoforge', neoVer, clientJarName);

const jvm = (overlay.arguments?.jvm ?? []).map((a) => String(a)
  .replaceAll('${library_directory}', LIBS)
  .replaceAll('${classpath_separator}', delimiter)
  .replaceAll('${version_name}', baseId));
for (let i = 0; i < jvm.length; i++) {
  if (jvm[i].startsWith('-DignoreList=')) {
    if (!jvm[i].slice(13).split(',').includes(clientJarName)) jvm[i] += ',' + clientJarName;
  }
}

const game = [
  ...(overlay.arguments?.game ?? []),
  '--username', 'Verify', '--version', baseId, '--gameDir', INSTANCE,
  '--assetsDir', ASSETS, '--assetIndex', base.assetIndex?.id ?? '17',
  '--uuid', '00000000000000000000000000000000', '--accessToken', '0',
  '--userType', 'legacy', '--versionType', 'release',
  '--quickPlaySingleplayer', WORLD,
];

const args = [...jvm, '-Djava.net.preferIPv4Stack=true',
  '-cp', [clientJar, ...cp].join(delimiter), overlay.mainClass, ...game];

const logDir = join(INSTANCE, 'logs');
if (existsSync(logDir)) for (const f of readdirSync(logDir)) if (f.endsWith('.log')) { try { rmSync(join(logDir, f)); } catch {} }

console.log('进入世界: ' + WORLD + '  运行 ' + SECONDS + ' 秒\n');
const child = spawn(JAVA, args, { cwd: INSTANCE, stdio: ['ignore', 'pipe', 'pipe'] });
let out = '';
child.stdout.on('data', (d) => (out += d));
child.stderr.on('data', (d) => (out += d));
const timer = setTimeout(() => child.kill('SIGKILL'), SECONDS * 1000);

child.on('exit', (code) => {
  clearTimeout(timer);
  const logFile = join(logDir, 'latest.log');
  const lines = (existsSync(logFile) ? readFileSync(logFile, 'utf8') : out).split(/\r?\n/);

  console.log('================ 判定 ================');
  const check = (label, re, want = true) => {
    const hits = lines.filter((l) => re.test(l));
    const ok = want ? hits.length > 0 : hits.length === 0;
    console.log(`${ok ? '✓' : '✗'} ${label}`);
    for (const h of hits.slice(0, 4)) console.log('    ' + h.replace(/^\[[^\]]+\]\s*\[[^\]]+\]\s*\[[^\]]+\]:\s*/, '').slice(0, 190));
  };

  check('startup 脚本无错误', /KubeJS Startup\/.*(ERROR|Exception)/, false);
  check('服务端脚本全部加载', /Loaded [1-9]\d*\/[1-9]\d* KubeJS server scripts/);
  check('服务端脚本无错误', /KubeJS Server\/.*(ERROR|Exception)/, false);
  check('服务端脚本已启用', /\[镜维度\] 服务端脚本已启用/);
  check('传送门已注册', /\[镜维度\] 传送门已注册/);
  check('成功进入世界', /Preparing spawn area|Time elapsed|joined the game|Server thread\/INFO.*Done/);
  check('无 global 赋值报错', /cannot be assigned to in client or server scripts/, false);
  check('无其他 TypeError', /TypeError/, false);

  console.log('\n--- KubeJS 汇总 ---');
  for (const l of lines.filter((l) => /Loaded \d+\/\d+ KubeJS|KubeJS Server\].*\[镜维度\]/.test(l))) {
    console.log('  ' + l.replace(/^\[[^\]]+\]\s*\[[^\]]+\]\s*\[[^\]]+\]:\s*/, '').slice(0, 190));
  }

  console.log('\nexit code:', code, ' 日志行数:', lines.length);
});
