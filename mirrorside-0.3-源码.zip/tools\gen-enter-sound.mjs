#!/usr/bin/env node
/**
 * 镜维度 · 进入提示音生成器（烘焙版）
 * =====================================================================
 * 为什么需要"烘焙"而不是运行时叠加：
 *   原版紫水晶钟声的文件本身轻得离谱 —— 实测
 *       block/amethyst/shimmer.ogg   积分响度 -44.7 LUFS，真峰值 -29.3 dBFS
 *       portal/travel.ogg（地狱门）   积分响度 -13.0 LUFS，真峰值  -0.7 dBFS
 *   再加上 sounds.json 里给钟声写了 "volume": 0.2（再压 14 dB），
 *   而地狱门是 1.0 文件音量 × 0.25 播放音量 = 有效 -25.0 LUFS。
 *   两边差了 30 dB 以上 —— 叠 4 层最多补 12 dB，怎么叠都不够。
 *   ⇒ 必须动音频文件。
 *
 * 这个脚本做的事：
 *   1) 把 shimmer.ogg 复制 4 份、各自微调音高/延迟 → 4 层合唱（用户指定 4 层）
 *   2) 加 8 抽头多抽头延迟混响，左右两路用不同抽头时间 → 立体声宽度
 *   3) 用 loudnorm 的两遍法（第一遍测量、第二遍加**固定增益**）把整段
 *      对齐到 TARGET_LUFS —— 即"和原版地狱传送门一样响"
 *   4) 编码成 ogg 放进模组资源目录
 *
 * 目标值怎么来的（可复算）：
 *   地狱门在 LevelRenderer 里是
 *       SimpleSoundInstance.forLocalAmbience(PORTAL_TRAVEL, pitch 0.8~1.2, volume 0.25)
 *   即 文件响度 -13.0 LUFS + 20*log10(0.25) = **-25.0 LUFS**
 *   （另一个 portal/trigger 是 -17.7 - 12.04 = -29.7 LUFS，比 travel 轻）
 *
 * 用法:  node tools/gen-enter-sound.mjs
 *        node tools/gen-enter-sound.mjs --target -22     # 想更响就调目标
 * =====================================================================
 */

import { spawnSync } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync, openSync, readFileSync, closeSync } from 'node:fs';
import { dirname, join } from 'node:path';

const FFMPEG = 'D:\\App\\ffmpeg\\bin\\ffmpeg.exe';
const INSTANCE = 'D:\\DSHwork\\MC镜维度\\.minecraft\\versions\\镜维度';
const WORK = 'D:\\DSHwork\\MC镜维度\\tools-build\\mirror-audio';
const SOURCE = join(WORK, 'sounds\\block\\amethyst\\shimmer.ogg');
const TMP = join(WORK, 'build');
const MOD_RES = 'D:\\DSHwork\\MC镜维度\\mirror-gravity-mod\\src\\main\\resources\\assets\\mirrorgravity';
const SOUND_NAME = 'enter_echo.ogg';

/* 目标响度。
 *
 * 参考点：原版地狱传送门 travel 音效的有效响度是 -25.0 LUFS
 * （文件 -13.0 LUFS × 播放音量 0.25）。
 *
 * 当前默认 -21.5 = 在地狱门基础上 **+3.5 dB**。
 * 这个数是量出来的，不是拍的：用户在游戏里用 `/mirror sound 2` 试听后
 * 要求"就按这个大小"，而"叠两份"的实际响度取决于两份拷贝的音高差：
 *   · 两份完全相同（完全相干）      → -19.1 LUFS (+6.1 dB)  概率约 16%
 *   · 两份差 ±2~3%（常态、去相关）  → -22.2 LUFS (+3.0 dB)  概率约 84%
 * 按分布加权得 -21.7，取 -21.5 稍留一点余量（用户此前两次反馈"偏小"）。
 */
const TARGET_LUFS = (() => {
  const i = process.argv.indexOf('--target');
  return i !== -1 && process.argv[i + 1] ? Number(process.argv[i + 1]) : -21.5;
})();

/** 真峰值上限（dBTP）。留 1.5 dB 余量，避免 ogg 解码后削顶。 */
const PEAK_CEIL_DB = -1.5;

if (!existsSync(FFMPEG)) {
  console.error('找不到 ffmpeg: ' + FFMPEG);
  console.error('（这脚本需要 ffmpeg 才能重跑；安装位置见 README）');
  process.exit(1);
}
if (!existsSync(SOURCE)) {
  console.error('找不到源音效: ' + SOURCE);
  process.exit(1);
}
mkdirSync(TMP, { recursive: true });
mkdirSync(join(MOD_RES, 'sounds', 'mirror'), { recursive: true });

/* ------------------------------------------------------------------ */
/* 滤镜链                                                              */
/* ------------------------------------------------------------------ */
/* 源是 mono 48kHz。四条支路各自 asetrate 改音高（±3% 以内，听不出变调
 * 但足以避免完全同相），再 amix 成 4 层合唱。
 *
 * 混响用 aecho（前馈多抽头延迟）：左右两路抽头时间不同，
 * pan 到两侧 0.72/0.28，叠起来就有了立体声宽度。
 * 干声保持居中，只让余韵向两边铺开。 */
const LAYER_RATES = [1.000, 1.028, 0.970, 1.013];
const LAYER_DELAY_MS = [0, 11, 23, 34];
const TAPS_L = '70|150|260|400|580|800|1080|1420';
const DECAY_L = '0.50|0.42|0.35|0.28|0.22|0.17|0.13|0.10';
const TAPS_R = '95|190|325|480|690|950|1250|1650';
const DECAY_R = '0.46|0.38|0.31|0.25|0.19|0.15|0.11|0.085';
/* 总长 ~8 秒（源 4.33 + 最长抽头 1.65 + 尾巴），最后 2 秒淡出 */
const PAD_SEC = 8.0;
const FADE_START = 6.0;

const layerFilters = LAYER_RATES.map((r, i) =>
  `[s${i}]asetrate=48000*${r.toFixed(3)},aresample=44100,`
  + `adelay=${LAYER_DELAY_MS[i]}:all=1[a${i}]`).join(';');
const layerInputs = LAYER_RATES.map((_, i) => `[a${i}]`).join('');

const FILTER = [
  `[0:a]asplit=${LAYER_RATES.length}${LAYER_RATES.map((_, i) => `[s${i}]`).join('')}`,
  layerFilters,
  `${layerInputs}amix=inputs=${LAYER_RATES.length}:normalize=0:duration=longest[direct]`,
  `[direct]asplit=3[d0][v1][v2]`,
  `[v1]aecho=0.85:0.9:${TAPS_L}:${DECAY_L},pan=stereo|c0=0.72*c0|c1=0.28*c0[rv1]`,
  `[v2]aecho=0.85:0.9:${TAPS_R}:${DECAY_R},pan=stereo|c0=0.28*c0|c1=0.72*c0[rv2]`,
  `[d0]aformat=channel_layouts=stereo[dm]`,
  `[dm][rv1][rv2]amix=inputs=3:normalize=0:weights=1 1 1[mixed]`,
  `[mixed]apad=whole_dur=${PAD_SEC},afade=t=out:st=${FADE_START}:d=${PAD_SEC - FADE_START}[out]`,
].join(';');

/* ------------------------------------------------------------------ */
/* 工具                                                                */
/* ------------------------------------------------------------------ */

/** 跑 ffmpeg，stderr 写文件（不用管道：沙箱下管道会 EPERM）。 */
function runFfmpeg(args, logName) {
  const logPath = join(TMP, logName);
  const fd = openSync(logPath, 'w');
  const r = spawnSync(FFMPEG, ['-hide_banner', '-nostats', ...args], {
    stdio: ['ignore', 'inherit', fd],
  });
  closeSync(fd);
  if (r.error) throw r.error;
  if (r.status !== 0) {
    console.error(readFileSync(logPath, 'utf8').split('\n').slice(-25).join('\n'));
    throw new Error('ffmpeg 退出码 ' + r.status + '（日志 ' + logPath + '）');
  }
  return readFileSync(logPath, 'utf8');
}

/** 从 ebur128 的汇总里取 I / LRA / 真峰值。
 *
 *  ⚠️ 两个坑：
 *   1) framelog 默认是 info，会每 100ms 打一行 `I: -70.0 LUFS`（开头是静音），
 *      所以必须用 framelog=quiet 只看汇总；
 *   2) 即便如此也取**最后**一个匹配，避免别的行里出现同样的字段。 */
function measure(file, tag) {
  const log = runFfmpeg([
    '-i', file, '-af', 'ebur128=peak=true:framelog=quiet', '-f', 'null', '-',
  ], `ebur_${tag}.txt`);
  const grab = (re) => {
    const all = [...log.matchAll(re)];
    return all.length > 0 ? Number(all[all.length - 1][1]) : NaN;
  };
  return {
    i: grab(/I:\s+(-?[\d.]+)\s+LUFS/g),
    lra: grab(/LRA:\s+(-?[\d.]+)\s+LU/g),
    peak: grab(/Peak:\s+(-?[\d.]+)\s+dBFS/g),
  };
}

const f1 = (n) => (Number.isFinite(n) ? n.toFixed(1) : '?');

/* ------------------------------------------------------------------ */
/* 1) 渲染 → 中间 float WAV（不夹限，保留全部余量）                       */
/* ------------------------------------------------------------------ */

const rawWav = join(TMP, 'enter_raw.wav');
console.log('=== 第 1 步：渲染 4 层合唱 + 多抽头混响 ===');
runFfmpeg([
  '-y', '-i', SOURCE,
  '-filter_complex', FILTER,
  '-map', '[out]',
  '-ar', '44100', '-ac', '2', '-c:a', 'pcm_f32le',
  rawWav,
], 'render_raw.txt');

const raw = measure(rawWav, 'raw');
console.log(`  原始渲染: I=${f1(raw.i)} LUFS, 真峰值=${f1(raw.peak)} dBFS, LRA=${f1(raw.lra)} LU`);

/* ------------------------------------------------------------------ */
/* 2) 两遍法：算出到目标响度需要的**固定增益**，再编码                    */
/* ------------------------------------------------------------------ */
/* 不用 loudnorm 的动态模式：那会压动态，钟声会被压扁。
 * 这里只要一个静态增益 —— 因为这个文件的峰值余量极大（约 30 dB），
 * 加 20 dB 也到不了 0 dBFS，根本不需要压限。 */

const gainDb = TARGET_LUFS - raw.i;
const predictedPeak = raw.peak + gainDb;
console.log('\n=== 第 2 步：对齐到地狱传送门的响度 ===');
console.log(`  目标 I=${f1(TARGET_LUFS)} LUFS，需要增益 ${gainDb >= 0 ? '+' : ''}${f1(gainDb)} dB`);
console.log(`  预计真峰值 ${f1(predictedPeak)} dBFS（上限 ${PEAK_CEIL_DB}）`);

/* 只有在真的会削顶时才挂限制器 —— 正常情况下它是旁路，不碰动态。 */
const needLimiter = predictedPeak > PEAK_CEIL_DB;
const post = needLimiter
  ? `volume=${gainDb.toFixed(2)}dB,alimiter=limit=${Math.pow(10, PEAK_CEIL_DB / 20).toFixed(4)}:level=0`
  : `volume=${gainDb.toFixed(2)}dB`;
if (needLimiter) console.log('  ⚠️ 会削顶，已挂 alimiter（会轻微压限）');

const outOgg = join(MOD_RES, 'sounds', 'mirror', SOUND_NAME);
runFfmpeg([
  '-y', '-i', rawWav,
  '-af', post,
  '-ar', '44100', '-ac', '2',
  '-c:a', 'libvorbis', '-q:a', '5',
  outOgg,
], 'encode.txt');

/* ------------------------------------------------------------------ */
/* 3) 验收：量成品，并和两个地狱门音效并列对比                            */
/* ------------------------------------------------------------------ */

const done = measure(outOgg, 'done');
const travel = measure(join(WORK, 'sounds\\portal\\travel.ogg'), 'travel');
const trigger = measure(join(WORK, 'sounds\\portal\\trigger.ogg'), 'trigger');

const eff = (i, vol) => i + 20 * Math.log10(vol);

console.log('\n=== 验收 ===');
console.log('  文件                                        积分响度     有效响度(含播放音量)');
console.log(`  原版紫水晶钟声(未处理)                       ${f1(-44.7)} LUFS   ${f1(eff(-44.7, 0.2 * 0.95))} LUFS  ← 最早那版`);
console.log(`  原版地狱门 travel (×0.25)                    ${f1(travel.i)} LUFS   ${f1(eff(travel.i, 0.25))} LUFS  ← 原版参照`);
console.log(`  原版地狱门 trigger (×0.25)                   ${f1(trigger.i)} LUFS   ${f1(eff(trigger.i, 0.25))} LUFS`);
console.log(`  本次生成 enter_echo.ogg (×1.0)               ${f1(done.i)} LUFS   ${f1(eff(done.i, 1.0))} LUFS  ← 目标 ${f1(TARGET_LUFS)}`);
console.log(`  真峰值 ${f1(done.peak)} dBFS（上限 ${PEAK_CEIL_DB}）`);
console.log(`  输出: ${outOgg}`);

/* 验收标准是"打到目标值"，而不是"等于地狱门" ——
 * 目标本身是按用户试听结果定的（见文件头 TARGET_LUFS 的说明）。 */
const vsTarget = done.i - TARGET_LUFS;
const vsPortal = eff(done.i, 1.0) - eff(travel.i, 0.25);
console.log(`\n  与目标 ${f1(TARGET_LUFS)} LUFS 的偏差: ${vsTarget >= 0 ? '+' : ''}${f1(vsTarget)} dB`);
console.log(`  与原版地狱门的差值（参考）  : ${vsPortal >= 0 ? '+' : ''}${f1(vsPortal)} dB`);
if (Math.abs(vsTarget) <= 0.5) {
  console.log('  ✓ 已打到目标（误差 ≤ 0.5 dB）');
} else {
  console.log('  ✗ 没打到目标，请检查上面的增益计算');
  process.exitCode = 1;
}
