#!/usr/bin/env node
/**
 * 生成"镜维度传送门"方块的**动态贴图**。
 * =====================================================================
 * 产出两个文件（放在模组资源里）：
 *   assets/mirrorgravity/textures/block/mirror_portal.png
 *       —— 动画条纹图：16 宽 × (16×48) 高，即 48 帧纵向排开
 *   assets/mirrorgravity/textures/block/mirror_portal.png.mcmeta
 *       —— 告诉游戏这是动画贴图、每帧停几 tick
 *
 * ── 为什么用脚本生成而不是画一张图 ─────────────────────────────────
 * 设定要的是"黑白光彩变换的透明状态"：
 *   · 黑白  → 只有亮度，不带颜色
 *   · 光彩变换 → 要有流动的干涉条纹，帧与帧之间必须**严丝合缝地循环**
 *   · 透明  → 需要 alpha 通道（渲染类型用 translucent）
 * 这种"参数化的流动图案"手画几乎不可能做到无缝循环，而脚本只要保证
 * 相位是 2π 的整数倍就天然循环，且任何时候重跑都得到完全一样的文件。
 *
 * ── 图案怎么来的（第二版：把黑↔白过渡做平）───────────────────────
 * 三束行波叠加（干涉），相位全部写成 2π·k·u（u = 帧/总帧数）：
 *     w1 = sin(2π(x/16 + y/16 + u))      斜向
 *     w2 = sin(2π(x/16 - y/16 - u))      反斜向
 *     w3 = sin(2π(y/16 - 2u))            竖向慢漂移
 *     m  = (w1 + w2 + 0.6·w3) / 2.6 ∈ [-1,1]
 *     n  = smoothstep((m+1)/2)           S 形缓动
 *     lum   = 26 + 210·n                 亮度（**不**钳到 0/255）
 *     alpha = 115 + 140·n                0.45 ~ 1.0
 *
 * ⚠️ 第一版有两处让过渡变"硬"的写法，都不要再改回去：
 *   1) 亮度做过 `min(1, n·1.22)` 增益再平方 —— 本意是"波峰纯白、波谷纯黑"，
 *      实际把中间一大片色阶全压到了 0 与 255 两端，看起来是一条条硬边。
 *      现在不做增益、不平方，只在 26~236 之间走，过渡自然连续。
 *   2) 空间周期取了 4 和 8 —— 16 像素里塞进 2~4 条波带，一条带才 2~4 像素宽，
 *      再怎么缓动也是"条纹"。现在周期取满 16（1 个波），相邻像素只差
 *      1/16 个周期，必然是渐变；"动"由相位漂移提供而不是靠高频。
 * 另外帧数从 32 提到 48、frametime 1→2：一轮 4.8 秒，配 interpolate 是
 * 连续流动而不是高频闪烁。
 *
 * ── 纯手工编码 PNG（zlib + CRC32），不依赖任何第三方库 ──────────────
 *
 * 用法:  node tools/gen-portal-texture.mjs
 * =====================================================================
 */

import { writeFileSync, mkdirSync } from 'node:fs';
import { deflateSync } from 'node:zlib';

const OUT_DIR = 'D:\\DSHwork\\MC镜维度\\mirror-gravity-mod\\src\\main\\resources'
  + '\\assets\\mirrorgravity\\textures\\block';
const NAME = 'mirror_portal';

const SIZE = 16;        // 贴图边长（与原版方块贴图一致）
const FRAMES = 48;      // 帧数
const FRAMETIME = 2;    // 每帧停几 tick（2 tick = 0.1 秒 → 48 帧 = 4.8 秒一轮）

/* ------------------------------------------------------------------ */
/* PNG 编码                                                            */
/* ------------------------------------------------------------------ */

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c;
  }
  return t;
})();

function crcOf(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crcOf(Buffer.concat([typeBuf, data])));
  return Buffer.concat([len, typeBuf, data, crc]);
}

/**
 * RGBA 像素数组 → PNG（colorType 6，bitDepth 8）。
 * @param {number} w 宽
 * @param {number} h 高
 * @param {(x:number,y:number)=>number[]} get 返回 [r,g,b,a]
 */
function encodePng(w, h, get) {
  const stride = w * 4;
  const raw = Buffer.alloc(h * (stride + 1));
  let p = 0;
  for (let y = 0; y < h; y++) {
    raw[p++] = 0;                       // 滤波类型 0（None）
    for (let x = 0; x < w; x++) {
      const [r, g, b, a] = get(x, y);
      raw[p++] = r & 0xff;
      raw[p++] = g & 0xff;
      raw[p++] = b & 0xff;
      /* ⚠️ alpha 必须原样写入，不能做任何裁剪 —— 写成 a & 0xff 之类
       * 会把 255 变成 0，贴图在游戏里会整块消失（同类坑踩过）。 */
      raw[p++] = a & 0xff;
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;     // bit depth
  ihdr[9] = 6;     // color type: RGBA
  ihdr[10] = 0;    // compression
  ihdr[11] = 0;    // filter
  ihdr[12] = 0;    // interlace
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/* ------------------------------------------------------------------ */
/* 图案                                                                */
/* ------------------------------------------------------------------ */

const TAU = Math.PI * 2;

/** S 形缓动：两端导数为 0，所以黑↔白的过渡在头尾都"收得住"，不出硬边。 */
function smoothstep(t) {
  const c = Math.min(1, Math.max(0, t));
  return c * c * (3 - 2 * c);
}

/** 取某一帧某一像素的亮度（供图案与自检共用，避免两处公式各写一遍）。 */
function lumaAt(x, ly, u) {
  const w1 = Math.sin(TAU * (x / 16 + ly / 16 + u));
  const w2 = Math.sin(TAU * (x / 16 - ly / 16 - u));
  const w3 = Math.sin(TAU * (ly / 16 - 2 * u));
  const m = (w1 + w2 + 0.6 * w3) / 2.6;   // [-1, 1]
  return smoothstep((m + 1) / 2);         // [0, 1]
}

/** 取某一帧某一像素的 [r,g,b,a]。条纹图的 y 要换算到帧内坐标。 */
function pixel(x, y) {
  const frame = Math.floor(y / SIZE);
  const ly = y % SIZE;
  const u = frame / FRAMES;               // 0..1 的循环相位

  const n = lumaAt(x, ly, u);
  const lum = Math.round(26 + 210 * n);   // 26~236：不触底也不顶格
  /* alpha：暗带 0.45、亮带 1.0 —— 整体能透出后面的方块，符合设定里的
   * "透明状态"；用同一个缓动后的 n，所以透明度变化也是平滑的。 */
  const alpha = Math.round(115 + 140 * n);

  return [lum, lum, lum, alpha];
}

/* ------------------------------------------------------------------ */
/* 输出                                                                */
/* ------------------------------------------------------------------ */

mkdirSync(OUT_DIR, { recursive: true });

const pngPath = OUT_DIR + '\\' + NAME + '.png';
writeFileSync(pngPath, encodePng(SIZE, SIZE * FRAMES, pixel));

const meta = {
  animation: {
    frametime: FRAMETIME,
    interpolate: true,
    frames: Array.from({ length: FRAMES }, (_, i) => i),
  },
};
const metaPath = pngPath + '.mcmeta';
writeFileSync(metaPath, JSON.stringify(meta, null, 2) + '\n', 'utf8');

console.log('=== 生成动态贴图 ===');
console.log(`  图幅   ${SIZE} × ${SIZE * FRAMES}（${FRAMES} 帧，每帧 ${SIZE}×${SIZE}）`);
console.log(`  帧率   frametime=${FRAMETIME} tick → 一轮 ${(FRAMES * FRAMETIME / 20).toFixed(2)} 秒`);
console.log(`  输出   ${pngPath}`);
console.log(`         ${metaPath}`);

/* ------------------------------------------------------------------ */
/* 自检：把生成结果再量一遍                                            */
/* ------------------------------------------------------------------ */

const RAMP = ' .:-=+*#%@';

/** 把某一帧打印成字符画：不用开图片也能看出图案与过渡是否平滑。 */
function preview(frame) {
  console.log(`  ── 第 ${frame} 帧（字符越靠右越亮）──`);
  for (let y = 0; y < SIZE; y++) {
    let line = '   |';
    for (let x = 0; x < SIZE; x++) {
      const [lum] = pixel(x, y + frame * SIZE);
      line += RAMP[Math.min(RAMP.length - 1, Math.floor((lum / 256) * RAMP.length))];
    }
    console.log(line + '|');
  }
}

let minL = 255;
let maxL = 0;
let minA = 255;
let maxA = 0;
let sumA = 0;
let count = 0;
let maxStep = 0;          // 相邻像素的最大亮度差（平滑度）
let maxLoop = 0;          // 首帧与末帧之间的最大亮度差（循环连续性）
let maxFrame = 0;         // 相邻帧之间的最大亮度差（动画连贯性）
for (let f = 0; f < FRAMES; f++) {
  for (let y = 0; y < SIZE; y++) {
    for (let x = 0; x < SIZE; x++) {
      const [r, , , a] = pixel(x, y + f * SIZE);
      minL = Math.min(minL, r);
      maxL = Math.max(maxL, r);
      minA = Math.min(minA, a);
      maxA = Math.max(maxA, a);
      sumA += a;
      count++;
      const right = pixel((x + 1) % SIZE, y + f * SIZE)[0];
      const down = pixel(x, ((y + 1) % SIZE) + f * SIZE)[0];
      maxStep = Math.max(maxStep, Math.abs(r - right), Math.abs(r - down));
      const wrapped = pixel(x, y + ((f + 1) % FRAMES) * SIZE)[0];
      maxFrame = Math.max(maxFrame, Math.abs(r - wrapped));
      if (f === 0) {
        const last = pixel(x, y + (FRAMES - 1) * SIZE)[0];
        maxLoop = Math.max(maxLoop, Math.abs(r - last));
      }
    }
  }
}

console.log('=== 自检 ===');
preview(0);
preview(Math.floor(FRAMES / 4));
console.log(`  亮度范围 ${minL} ~ ${maxL}（要跨得够宽，且**不**触到 0/255）`);
console.log(`  alpha 范围 ${minA} ~ ${maxA}，平均 ${(sumA / count / 255).toFixed(2)}（要明显小于 1 = 透明）`);
console.log(`  相邻像素最大亮度差 ${maxStep}（越小越平滑，> 64 就是硬边条纹）`);
console.log(`  相邻帧最大亮度差 ${maxFrame}（要小，否则动画会"跳"）`);
console.log(`  首末帧最大亮度差 ${maxLoop}（要小，否则循环处会闪一下）`);

const checks = [
  ['黑白跨度够宽', maxL - minL >= 150],
  ['不触纯黑纯白', minL > 0 && maxL < 255],
  ['整体半透明', minA < 150 && maxA === 255 && sumA / count < 235],
  ['过渡平滑', maxStep <= 64],
  ['逐帧连贯', maxFrame <= 32],
  ['循环无缝', maxLoop <= 32],
];
let ok = true;
for (const [what, pass] of checks) {
  console.log(`  ${pass ? '✓' : '✗'} ${what}`);
  if (!pass) ok = false;
}
console.log(ok ? '  ✓ 动态、平滑、无缝、半透明都符合预期' : '  ✗ 图案不符合预期，检查上面的公式');
if (!ok) process.exitCode = 1;
