package work.dsh.mirror.gravity;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.DimensionSpecialEffects;
import org.joml.Matrix4f;

/**
 * 镜维度的视觉效果：<b>与主世界白天完全一样，但不画云</b>。
 *
 * <h2>为什么"去云"要写代码，而不能只改数据包</h2>
 * 维度类型 JSON 里的 {@code effects} 只认三个原版值
 * （{@code minecraft:overworld / the_nether / the_end}），没有"主世界的天空但不要云"这种组合：
 * <ul>
 *   <li>{@code overworld} —— 有云（云高 192，镜维度是虚空 + 白玻璃，云会直接糊住整个画面）</li>
 *   <li>{@code the_nether} / {@code the_end} —— 没云，但天空、雾、光照全变了</li>
 * </ul>
 * 所以这里注册一个自定义的 {@link DimensionSpecialEffects}，让数据包可以写
 * {@code "effects": "mirrorgravity:mirror"}。
 *
 * <h2>为什么要 extends OverworldEffects 而不是从头写</h2>
 * 从头写就得自己实现雾色（{@code getBrightnessDependentFogColor}）、
 * 是否起雾（{@code isFoggyAt}）等等 —— 那些正是"和主世界一致"的部分。
 * 继承主世界那份、只覆盖"画不画云"这一个方法，改动面最小：
 * 天空、雾、光照贴图、太阳颜色全部原样保留。
 *
 * <h2>钩子的语义（NeoForge 官方接口的原文）</h2>
 * <pre>
 *   // IDimensionSpecialEffectsExtension#renderClouds
 *   // @return true to prevent vanilla cloud rendering
 * </pre>
 * 也就是 <b>返回 true = 阻止原版画云</b>（不是"我要自己画"）。
 *
 * <p>⚠️ 本类引用客户端专属类，只能在物理客户端加载：
 * 注册入口在 {@link MirrorClientSetup}，而那里由 {@link MirrorGravity} 按
 * {@code FMLEnvironment.dist} 分流。
 */
public class MirrorDimensionEffects extends DimensionSpecialEffects.OverworldEffects {

    @Override
    public boolean renderClouds(
        ClientLevel level,
        int ticks,
        float partialTick,
        PoseStack poseStack,
        double camX,
        double camY,
        double camZ,
        Matrix4f modelViewMatrix,
        Matrix4f projectionMatrix) {
        /* true = 阻止原版云渲染。镜维度是虚空，云除了挡视线没有别的作用；
         * 天空其余部分（颜色、太阳、雾）仍走主世界那一套。 */
        return true;
    }

    /**
     * 不渲染雨雪（{@code @return true to prevent vanilla snow and rain rendering}）。
     *
     * <p>镜维度的天气已经在服务端被 {@link MirrorWeather} 强制清成晴天，
     * 正常情况下降水根本不会发生。这道钩子只防"别的模组/指令硬把雨塞进来"，
     * 以及维度数据包加载到一半时的瞬时状态。
     */
    @Override
    public boolean renderSnowAndRain(
        ClientLevel level,
        int ticks,
        float partialTick,
        net.minecraft.client.renderer.LightTexture lightTexture,
        double camX,
        double camY,
        double camZ) {
        return true;
    }

    /** 同上：连雨的 tick（音效与粒子）也一并挡掉。 */
    @Override
    public boolean tickRain(ClientLevel level, int ticks, net.minecraft.client.Camera camera) {
        return true;
    }
}
