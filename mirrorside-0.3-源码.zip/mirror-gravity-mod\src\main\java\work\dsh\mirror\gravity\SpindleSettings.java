package work.dsh.mirror.gravity;

import work.dsh.mirror.gravity.internal.Failures;

/**
 * 针尖对麦芒 · 运行时参数。
 *
 * <h2>为什么参数在这里、而不是写进结构 JSON</h2>
 * 本项目的分工是：<b>KubeJS 的 {@code mirror_config.js} 是唯一真相，模组只接收推送</b>。
 * 结构 JSON 里若再写一份半径/长度区间，就变成两处手工保持一致 ——
 * 改一处忘另一处会生成出一套"看起来对但和配置不符"的装置（0.2 期间
 * {@code falling_ref_offset} 就是这么错位的）。
 *
 * <p>所以结构 JSON 只保留原版<b>必须</b>有的字段（{@code biomes} / {@code step} /
 * {@code spawn_overrides} / {@code terrain_adaptation}），
 * 所有可调数字由脚本在服务端启动时通过
 * {@link MirrorGravityApi#setSpindleParams} 推过来。
 * 密度（spacing / separation / salt）例外 —— 它在 structure_set 里，
 * 运行时无法改，只能在 {@code kubejs/data/mirror/worldgen/structure_set/spindle.json} 调，
 * 配置文件里对这个事实有注释说明。
 *
 * <p>这里的默认值必须与配置文件逐项一致，由
 * {@code tools-build/check-param-parity.mjs} 强制对拍。
 */
public final class SpindleSettings {

    private SpindleSettings() {
    }

    /* ---- 与 mirror_config.js 的 spindle 段一一对应 ---- */
    private static volatile double radiusMin = 5.0D;
    private static volatile double radiusMax = 13.0D;
    private static volatile double lengthMin = 64.0D;
    private static volatile double lengthMax = 128.0D;
    private static volatile double insetMin = 2.0D;
    private static volatile double insetMax = 24.0D;
    private static volatile double centerYMin = -11.0D;
    private static volatile double centerYMax = 10.0D;
    private static volatile double pitchMinDeg = 68.0D;
    private static volatile double pitchMaxDeg = 90.0D;
    private static volatile int innerMinY = -64;
    private static volatile int innerMaxY = 63;
    private static volatile int buildMinY = -192;
    private static volatile int buildMaxY = 191;
    /** 波粒块禁止落在的 y（黑玻璃夹层，来自 layout.glass_layers）。 */
    private static volatile int[] coreAvoidYs = {0, 1, -1, -2};

    /** 脚本推过参数没有（没推过时 {@code /mirror diag} 会提示这是兜底值）。 */
    private static volatile boolean pushed = false;

    public static boolean pushed() {
        return pushed;
    }

    /** 快照成几何层要用的规则对象。 */
    public static SpindleGeometry.Rules rules() {
        return new SpindleGeometry.Rules(
            radiusMin, radiusMax,
            lengthMin, lengthMax,
            insetMin, insetMax,
            centerYMin, centerYMax,
            pitchMinDeg, pitchMaxDeg,
            innerMinY, innerMaxY,
            buildMinY, buildMaxY,
            coreAvoidYs);
    }

    /** CSV 顺序即 {@link MirrorGravityApi#setSpindleParams} 的约定，改顺序等于改契约。 */
    public static String describe() {
        return String.format(
            java.util.Locale.ROOT,
            "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d,%d",
            num(radiusMin), num(radiusMax), num(lengthMin), num(lengthMax),
            num(insetMin), num(insetMax), num(centerYMin), num(centerYMax),
            num(pitchMinDeg), num(pitchMaxDeg),
            innerMinY, innerMaxY, buildMinY, buildMaxY);
    }

    /** 黑玻璃夹层 CSV（供指挥命令显示）。 */
    public static String describeAvoidYs() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < coreAvoidYs.length; i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(coreAvoidYs[i]);
        }
        return sb.toString();
    }

    private static String num(double v) {
        if (v == Math.rint(v) && !Double.isInfinite(v)) {
            return String.valueOf((long) v);
        }
        return String.valueOf(v);
    }

    /**
     * 接收脚本推送的全部数值。任何一项不合法就<b>整体拒绝</b>，
     * 保留上一份可用参数并记一次静默失败 —— 半套参数会让锥体和波粒块错位。
     *
     * @param csv 14 个数，顺序见 {@link #describe()}
     * @return 失败原因；成功返回 {@code null}
     */
    static String pushParams(String csv) {
        if (csv == null || csv.isBlank()) {
            return "参数为空";
        }
        String[] parts = csv.split(",");
        if (parts.length != 14) {
            return "需要 14 个数（半径上下限/长度上下限/伸入上下限/高度上下限/俯仰上下限/境内上下界/世界上下界），实际 " + parts.length;
        }
        double[] v = new double[14];
        for (int i = 0; i < 14; i++) {
            try {
                v[i] = Double.parseDouble(parts[i].trim());
            } catch (NumberFormatException e) {
                return "第 " + (i + 1) + " 项不是数字: " + parts[i];
            }
        }
        SpindleGeometry.Rules probe = new SpindleGeometry.Rules(
            v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9],
            (int) v[10], (int) v[11], (int) v[12], (int) v[13], coreAvoidYs);
        String problem = probe.problem();
        if (problem != null) {
            return problem;
        }
        radiusMin = v[0];
        radiusMax = v[1];
        lengthMin = v[2];
        lengthMax = v[3];
        insetMin = v[4];
        insetMax = v[5];
        centerYMin = v[6];
        centerYMax = v[7];
        pitchMinDeg = v[8];
        pitchMaxDeg = v[9];
        innerMinY = (int) v[10];
        innerMaxY = (int) v[11];
        buildMinY = (int) v[12];
        buildMaxY = (int) v[13];
        pushed = true;
        return null;
    }

    /**
     * 波粒块禁止落在的 y。来自布局里的玻璃层 —— 与传送门那边的
     * {@code setMirrorPortalAvoidY} 同一个套路：玻璃在哪一层是布局的职责，
     * 布局的唯一真相在 KubeJS，模组只接收结果。
     */
    static String pushAvoidYs(String csv) {
        if (csv == null || csv.isBlank()) {
            coreAvoidYs = new int[0];
            return null;
        }
        String[] parts = csv.split(",");
        int[] out = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            try {
                out[i] = Integer.parseInt(parts[i].trim());
            } catch (NumberFormatException e) {
                return "第 " + (i + 1) + " 项不是整数: " + parts[i];
            }
        }
        if (out.length >= (innerMaxY - innerMinY + 1)) {
            return "避让表把整个境内都排除了: " + out.length + " 项";
        }
        coreAvoidYs = out;
        return null;
    }

    /** 让任何异常都走一遍静默失败收集器（模组其它地方也是这个约定）。 */
    static void noteFailure(String what, String detail) {
        Failures.note("spindle", new IllegalArgumentException(what + ": " + detail));
    }
}
