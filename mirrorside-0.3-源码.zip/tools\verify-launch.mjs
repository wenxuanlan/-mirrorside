#!/usr/bin/env node
/**
 * 镜维度 · 无人值守启动验证
 * =====================================================================
 * 启动游戏固定时长后强杀，然后读日志判定关键状态。用于改完脚本后
 * 快速验证「脚本有没有报错」，不需要人工盯着游戏窗口。
 *
 * 用法:
 *   node tools/verify-launch.mjs            # 默认跑 90 秒
 *   node tools/verify-launch.mjs 120        # 跑 120 秒
 *   node tools/verify-launch.mjs 90 --grep  # 额外打印匹配 PORTAL PROBE / 镜维度 的行
 * =====================================================================
 */

import { readFileSync, existsSync, readdirSync, rmSync, statSync, mkdirSync, writeFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { dirname, join, resolve, delimiter } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const INSTANCE = resolve(HERE, '..');
const MC = resolve(INSTANCE, '..', '..');
const LIBS = join(MC, 'libraries');
const ASSETS = join(MC, 'assets');
const JAVA = process.env.MIRROR_JAVA ?? 'D:\\App\\java21\\bin\\java.exe';

const SECONDS = Number(process.argv[2] ?? 90);
const GREP = process.argv.includes('--grep');

const overlayPath = readdirSync(INSTANCE).filter((f) => f.endsWith('.json'))
  .map((f) => join(INSTANCE, f))
  .find((p) => { try { return Array.isArray(JSON.parse(readFileSync(p, 'utf8')).libraries); } catch { return false; } });
const overlay = JSON.parse(readFileSync(overlayPath, 'utf8'));
const baseId = overlay.inheritsFrom;
if (!baseId) { console.error('✗ 版本 JSON 缺少 inheritsFrom'); process.exit(1); }
const base = JSON.parse(readFileSync(join(resolve(INSTANCE, '..'), baseId, `${baseId}.json`), 'utf8'));

const allowed = (lib) => {
  if (!lib.rules) return true;
  let ok = false;
  for (const r of lib.rules) {
    const osOk = !r.os || (r.os.name === 'windows' && process.platform === 'win32')
      || (r.os.name === 'linux' && process.platform === 'linux')
      || (r.os.name === 'osx' && process.platform === 'darwin');
    if (r.action === 'allow' && osOk) ok = true;
    if (r.action === 'disallow' && osOk) ok = false;
  }
  return ok;
};

const cp = [];
const seen = new Set();
for (const src of [base.libraries ?? [], overlay.libraries ?? []]) {
  for (const lib of src) {
    if (!allowed(lib)) continue;
    const p = lib.downloads?.artifact?.path;
    if (!p) continue;
    const full = join(LIBS, p);
    if (seen.has(full)) continue;
    seen.add(full);
    if (existsSync(full)) cp.push(full);
  }
}

let neoVer = null;
const g = overlay.arguments?.game ?? [];
for (let i = 0; i < g.length - 1; i++) if (g[i] === '--fml.neoForgeVersion') neoVer = g[i + 1];
const clientJarName = `neoforge-${neoVer}-client.jar`;
const clientJar = join(LIBS, 'net/neoforged/neoforge', neoVer, clientJarName);
if (!existsSync(clientJar)) { console.error('✗ 缺少 ' + clientJar); process.exit(1); }

const jvm = (overlay.arguments?.jvm ?? []).map((a) => String(a)
  .replaceAll('${library_directory}', LIBS)
  .replaceAll('${classpath_separator}', delimiter)
  .replaceAll('${version_name}', baseId));
for (let i = 0; i < jvm.length; i++) {
  if (jvm[i].startsWith('-DignoreList=')) {
    if (!jvm[i].slice(13).split(',').includes(clientJarName)) jvm[i] += ',' + clientJarName;
  }
}

const game = [
  ...(overlay.arguments?.game ?? []),
  '--username', 'Verify', '--version', baseId, '--gameDir', INSTANCE,
  '--assetsDir', ASSETS, '--assetIndex', base.assetIndex?.id ?? '17',
  '--uuid', '00000000000000000000000000000000', '--accessToken', '0',
  '--userType', 'legacy', '--versionType', 'release',
];

const args = [...jvm, '-Djava.net.preferIPv4Stack=true',
  '-cp', [clientJar, ...cp].join(delimiter), overlay.mainClass, ...game];

const logDir = join(INSTANCE, 'logs');
if (existsSync(logDir)) for (const f of readdirSync(logDir)) if (f.endsWith('.log')) { try { rmSync(join(logDir, f)); } catch {} }

const child = spawn(JAVA, args, { cwd: INSTANCE, stdio: ['ignore', 'pipe', 'pipe'] });
let out = '';
child.stdout.on('data', (d) => (out += d));
child.stderr.on('data', (d) => (out += d));
const timer = setTimeout(() => child.kill('SIGKILL'), SECONDS * 1000);

child.on('exit', (code) => {
  clearTimeout(timer);
  const logFile = join(logDir, 'latest.log');
  const text = existsSync(logFile) ? readFileSync(logFile, 'utf8') : out;
  const lines = text.split(/\r?\n/);

  console.log('\n================ 判定 ================');
  const check = (label, re, want = true) => {
    const hits = lines.filter((l) => re.test(l));
    const ok = want ? hits.length > 0 : hits.length === 0;
    console.log(`${ok ? '✓' : '✗'} ${label}`);
    for (const h of hits.slice(0, 5)) console.log('    ' + h.replace(/^\[[^\]]+\]\s*\[[^\]]+\]\s*\[[^\]]+\]:\s*/, '').slice(0, 200));
    return ok;
  };

  check('启动脚本/服务端脚本无错误', /KubeJS (Startup|Server)\/.*(ERROR|Exception)/, false);
  check('startup 脚本全部加载', /Loaded \d+\/\d+ KubeJS startup scripts/, true);
  check('核心就绪', /\[镜维度\] 核心已就绪/);
  check('传送门已注册', /\[镜维度\] 传送门已注册/);
  check('无「跳过传送门注册」', /跳过传送门注册/, false);
  check('无类过滤器报错', /Class is not allowed by class filter/, false);
  check('无 redeclaration 报错', /redeclaration of var/, false);
  check('无 TypeError', /TypeError/, false);
  check('游戏到达世界/主菜单', /Setting user|Preparing spawn area/);

  if (GREP) {
    console.log('\n--- [镜维度] / PP / 探针 ---');
    for (const l of lines.filter((l) => /\[镜维度\]|^PP |PORTAL PROBE|PP /.test(l))) {
      console.log('  ' + l.replace(/^\[[^\]]+\]\s*\[[^\]]+\]\s*\[[^\]]+\]:\s*/, '').slice(0, 220));
    }
  }

  console.log('\nexit code:', code, ' 日志行数:', lines.length);
});
