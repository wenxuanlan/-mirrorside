// =====================================================================
// 镜维度 · 重力下发（决定谁在什么高度受哪个方向的重力）
// =====================================================================
// 这是玩法的核心：每 tick 判断实体应当受哪个方向的重力，并下发。
//
// 分工：
//   · 玩家            → PlayerEvents.tick（本文件）
//   · 其它实体        → ServerEvents.tick 里按间隔扫描（本文件）
//   · 下落的方块      → 交给模组的 BlockPhysics，本文件只做配方判定
//   · 掉落物 / TNT 等 → 本文件下发方向，物理交给原版 + Pondus
//
// ⚠️ 核心规则：**纯看坐标** —— 越过反转线就反向。
//    曾经加过"前方没有方块就不翻转"，那是错的（会让空气中飞行的实体
//    永不翻转，重力反转整体失效）。已删除，不要再加回来。
//
// ⚠️ 所有 try 块内只用 var（Rhino 对 try 里的 const/let 会抛
//    InternalError: TypeError: redeclaration of var xxx）
// =====================================================================

const MirrorGravity = (() => {

  const N0 = global.MirrorDimension.modules.n0;
  const N1 = global.MirrorDimension.modules.n1;
  const N2 = global.MirrorDimension.modules.n2;
  if (N0 === undefined || !N0.ready || N1 === undefined || !N1.ready
      || N2 === undefined || !N2.ready) {
    console.error('[镜维度] 依赖模块未就绪，重力下发模块未启用。');
    return { ready: false };
  }

  /* ⚠️ n3(配方) / n5(镜外) / n6(玻璃层) 一律**延迟解析**（在函数体里取），
   *    不在加载期取引用 —— 见 n0.moduleRef 的说明。
   *    这样本模块的文件名顺序不再重要。 */
  const moduleRef = N0.moduleRef;

  const MD = global.MirrorDimension;
  const cfg = N0.cfg;
  const MG_API = N0.selfModApi;
  const DIR_NAME = N0.dirName;

  const entityKey = N0.entityKey;
  const typeName = N0.typeName;
  const isPlayer = N0.isPlayer;
  const isFallingBlock = N0.isFallingBlock;
  const isNonLivingGravityEntity = N0.isNonLivingGravityEntity;
  const isDroppedItem = N0.isDroppedItem;
  const dirNameAt = N0.dirNameAt;

  /* 掉落物的方向检测间隔（tick，默认 20）。
   * 与 N0.scanInterval（所有非玩家实体）分开 —— 理由见 n0 与本文件扫描器处。 */
  const ITEM_SCAN_INTERVAL = N0.itemScanInterval;

  const lastDir = N1.lastDir;
  const pendingFlip = N1.pendingFlip;

  /* 服务器句柄：供"强制方向"换算时间用。
   * 玩家 tick 第一次跑起来时填上（这是唯一稳定拿得到 server 的时机）。 */
  let serverRef = null;

  /* ------------------------------------------------------------------ */
  /* 防抖参数                                                            */
  /* ------------------------------------------------------------------ */
  /* 交界处防抖有两个措施（详见 README §11.7）：
   *   1) 迟滞带（dead_zone）：带内维持原方向 —— 站在线上不会抖
   *   2) 确认停留（flip_gap）：必须在对面连续停留够久才翻 ——
   *      来回快速穿越根本不会翻，只有真正走过去并留下才翻
   *
   * 按实体类别取不同参数：重力方块下落很快，用生物的确认时间会导致
   * 它还没确认完就已经穿过界线飞走了（表现是"重力方块从不反转"）。 */

  function debounceFor(entity) {
    const g = cfg.gravity;
    if (isNonLivingGravityEntity(entity)) {
      return {
        zone: g.falling_dead_zone != null ? g.falling_dead_zone : 0.3,
        gap: g.falling_flip_gap != null ? g.falling_flip_gap : 0,
        scale: N0.fallingGravityScale,
      };
    }
    if (isPlayer(entity)) {
      return {
        zone: g.player_dead_zone != null ? g.player_dead_zone : 1.5,
        gap: g.player_flip_gap != null ? g.player_flip_gap : 20,
        scale: 1.0,
      };
    }
    return {
      zone: g.entity_dead_zone != null ? g.entity_dead_zone : 0.5,
      gap: g.entity_flip_gap != null ? g.entity_flip_gap : 10,
      scale: 1.0,
    };
  }

  /**
   * 该实体在当前坐标下应当受的方向。
   *
   * 带迟滞：已经朝上时，要高于 splitY + zone 才切回朝下；反之亦然。
   * 带内维持原方向，于是重力成为**恢复力**，实体被推向带中心并稳定下来。
   */
  function dirNameFor(entity, prevDir, zone) {
    if (prevDir == null) return dirNameAt(entity.y);
    const above = prevDir === 'up'
      ? entity.y > (N0.splitY + zone)
      : entity.y > (N0.splitY - zone);
    return above ? DIR_NAME.outer_upper : DIR_NAME.outer_lower;
  }

  /* ------------------------------------------------------------------ */
  /* 强制方向（/mirror gravity up [秒数]）                                */
  /* ------------------------------------------------------------------ */

  function forcedDirName() {
    const g = cfg.gravity;
    if (g.force_direction == null) return null;
    const until = g.force_until_tick != null ? g.force_until_tick : -1;
    if (until >= 0 && forceTick() > until) return null;
    return String(g.force_direction);
  }

  /** 取主世界游戏时间作为"过期时刻"的基准。
   *
   * ⚠️ 不能用 server.getLevel(ResourceKey)：Rhino 会报重载歧义。
   * 遍历 getAllLevels() 逐个比维度名是验证过可行的做法。 */
  function forceTick() {
    try {
      if (serverRef == null) return -1;
      var it = serverRef.getAllLevels().iterator();
      while (it.hasNext()) {
        var lv = it.next();
        if (lv != null && String(lv.dimension().location()) === 'minecraft:overworld') {
          return lv.getGameTime();
        }
      }
      return -1;
    } catch (err) {
      return -1;
    }
  }

  /** 设置/清除强制方向。seconds 为 null 或负数表示不过期。 */
  function setForce(dirName, seconds) {
    const g = cfg.gravity;
    const PONDUS = MD.pondus;
    if (dirName == null || String(dirName) === 'clear' || String(dirName) === '') {
      g.force_direction = null;
      g.force_until_tick = -1;
      return null;
    }
    const d = (PONDUS != null) ? PONDUS.dirOf(dirName) : null;
    if (d == null) return null;
    g.force_direction = String(d.getName());
    g.force_until_tick = (seconds != null && seconds >= 0)
      ? forceTick() + Math.round(seconds * 20) : -1;
    return g.force_direction;
  }

  /* ------------------------------------------------------------------ */
  /* 下发方向                                                            */
  /* ------------------------------------------------------------------ */

  /** 生物走 Pondus 的 API，非生物走自研模组。返回 'applied' / 'error'。 */
  function pushDirection(entity, dirName) {
    if (isNonLivingGravityEntity(entity)) {
      if (MG_API == null) return 'no-mod';
      let ok = false;
      try {
        /* 重力缩放按实体类型分开给（回看历史后的结论）：
         *
         *   · 掉落物（item）→ 用 falling_gravity_scale（0.2）
         *     这是用户**确认过效果正常**的那一版的做法。
         *     曾经改成 1.0（想让"手感恢复正常"），结果交界处的往复幅度
         *     变大、传送距离也变大 —— 因为 0.2 本来就在压小整段运动。
         *
         *   · 下落的方块 → 1.0
         *     它由模组 BlockPhysics 完全接管（自己在世界坐标施加加速度、
         *     并抵消原版重力），这里的缩放再去改"原版那部分重力"
         *     只会与抵消计算打架。
         *
         *   · 其它非生物（TNT / 末影之眼…）→ 1.0，保持原版手感。 */
        var scale = 1.0;
        if (typeName(entity) === 'minecraft:item') {
          scale = N0.fallingGravityScale;
        }
        ok = MG_API.apply(entity, dirName, scale);
      } catch (err) {
        N0.fail('physics', err);
        ok = false;
      }
      return ok ? 'applied' : 'error';
    }

    // 生物：Pondus 自己的 API
    const PONDUS = MD.pondus;
    if (PONDUS == null || !PONDUS.available) return 'no-pondus';
    try {
      var want = PONDUS.dirOf(dirName);
      if (want == null) return 'error';
      /* 方向没变就直接返回 —— Pondus 内部也会拦，但这里先拦能省一次
       * 反射往返，而且避免它每 tick 置 needsSync（同步风暴）。 */
      var cur = PONDUS.API.getBaseGravityDirection(entity);
      if (cur != null && String(cur.getName()) === String(want.getName())) return 'applied';
      PONDUS.API.setBaseGravityDirection(entity, want);
      var after = PONDUS.API.getBaseGravityDirection(entity);
      return (after != null && String(after.getName()) === String(want.getName()))
        ? 'applied' : 'error';
    } catch (err) {
      return 'error';
    }
  }

  /* ------------------------------------------------------------------ */
  /* 对单个实体应用重力                                                   */
  /* ------------------------------------------------------------------ */

  /** 对单个实体应用当前坐标应有的重力。 */
  function applyGravityTo(entity) {
    if (!cfg.gravity.enabled) return null;

    /* ⚠️ 下落的方块在这里**只做配方判定**，方向与物理都交给模组。
     *
     * 模组对它们用的是自己的加速度与阻尼（那套才能实现稳定往复），
     * 而且因为 FallingBlockEntity 不调用 super.tick()，Pondus 对它们
     * 本来就处于半失效状态。所以脚本这边不碰它的速度。
     *
     * ⚠️ 配方判定必须在 return **之前** —— 这里曾经是死代码：
     *    配方钩子写在函数末尾，而下落的方块在上面就 return 了，
     *    结果计数对沙砾永远不执行，配方从未触发过。 */
    if (isFallingBlock(entity)) {
      const N3 = moduleRef('n3');
      if (N3 != null && N3.enabled) {
        N3.trackSwing(entity);
        const hit = N3.process(entity);
        if (hit != null && N3.applyRecipe(entity, hit)) {
          return 'recipe';   // 实体已被替换成方块并移除，不再参与物理
        }
      }
      return null;
    }

    const key = entityKey(entity);
    const rec = lastDir[key];
    const prev = rec != null ? rec.dir : null;
    const dbc = debounceFor(entity);

    const forced = forcedDirName();
    let wantName = forced != null ? forced : dirNameFor(entity, prev, dbc.zone);

    /* ---- 防抖：只挡反向，不挡继续施加同一方向 ----
     *
     * 规则（用户明确要求）：**纯看坐标** —— 越过反转线就反向。
     * 副作用是自由空间里的物体会在分界线两侧来回振荡，
     * 这是该规则的固有结果，用户已知悉并接受（不是 bug）。 */
    let inCooldown = false;
    if (prev != null && prev !== wantName) {
      const need = dbc.gap;
      let pend = pendingFlip[key];
      if (pend == null || pend.dir !== wantName) {
        pendingFlip[key] = { dir: wantName, ticks: 0 };
        pend = pendingFlip[key];
      }
      pend.ticks++;
      const sinceFlip = (rec == null || rec.lastFlipAt == null)
        ? 99999 : (N1.now() - rec.lastFlipAt);
      if (pend.ticks < need || sinceFlip < need) {
        wantName = prev;
        N1.countBlockedFlip();
        inCooldown = true;
      }
    } else if (pendingFlip[key] != null) {
      delete pendingFlip[key];
    }

    const flipped = (prev != null && prev !== wantName);

    // ---- 下发 ----
    const st = pushDirection(entity, wantName);
    N1.setLastAttempt({
      dir: wantName,
      status: inCooldown ? 'cooldown' : st,
      type: typeName(entity),
    });

    /* ---- 记基线：每次都要写，不能只在方向变化时写 ----
     * 只在变化时写会形成死循环：prev 永远为 null → 防抖永不生效。 */
    lastDir[key] = {
      dir: wantName,
      lastFlipAt: flipped ? N1.now() : (rec != null ? rec.lastFlipAt : N1.now()),
    };
    if (flipped) delete pendingFlip[key];

    /* ---- 非下落方块：保留切换计数（不做加工）----
     * 掉落物应当能被捡起，不该烧成方块。 */
    if (isNonLivingGravityEntity(entity)) {
      const N3 = moduleRef('n3');
      if (N3 != null) N3.trackNonBlock(entity);
    }

    return wantName;
  }

  /* ------------------------------------------------------------------ */
  /* 玩家：每 tick                                                       */
  /* ------------------------------------------------------------------ */
  /* 玩家不走实体扫描（扫描里会跳过他们），而是走这个事件 —— 因为这里
   * 还要顺带做"每 20 tick 一次"的区域判定（进出镜外的处理）。 */

  const PD_KEY_REGION = 'mirror_last_region';

  /* 区域判定的节流间隔：**每 20 tick（1 秒）恰好一次**。
   * 区域判定会读持久化数据、必要时切换游戏模式（切模式要发同步包给客户端），
   * 放在每 tick 的路径上既没必要也会在边界来回穿越时反复触发。 */
  const REGION_CHECK_INTERVAL = 20;

  PlayerEvents.tick(event => {
    const player = event.player;
    if (serverRef == null) serverRef = event.server;

    const inMirror = String(player.level.dimension) === N0.dim;
    if (inMirror) {
      applyGravityTo(player);
    }

    /* ⚠️ 节流的基准必须用 N1.now()（服务端 tick 计数），
     *    **不能**用"本处理器被调用的次数"。
     *
     *    原因：PlayerEvents.tick 是**每个玩家每 tick 一次**。
     *    用自增计数器的话，两个玩家在线时计数器一步走 2，
     *    同一名玩家的判定间隔就变成 10 tick —— 不再是"每 20 tick"。
     *
     * ⚠️ 更不能写 `player.age % 20 !== 0`（这里曾经就是这么写的）：
     *    KubeJS 的 ServerPlayer 包装上**没有 age 属性**（探针实测 undefined），
     *    `undefined % 20` 得到 NaN，而 `NaN !== 0` 恒为 true ——
     *    于是每一 tick 都在这一行提前 return，区域判定从未执行过。
     *    症状：飞进镜外（y>63）毫无反应，不切模式也没提示，
     *    而 KubeJS 不为此报任何错。 */
    if (N1.now() % REGION_CHECK_INTERVAL !== 0) return;

    /* ---- 每秒一次的区域判定 ----
     *
     * 区域变化交给镜外模块（n5）处理 —— 本模块只负责"发现变化"并通知，
     * 不关心它具体做什么。这样重力逻辑与"镜外该怎么表现"解耦。 */
    if (!inMirror) {
      restoreGravity(player);
      player.persistentData.putString(PD_KEY_REGION, 'none');

      /* 离开镜维度时也要恢复原游戏模式。
       *
       * 设定原文："当玩家在镜外传送到其他世界时，也将玩家切换回原来的模式。"
       * 这里正是那个场景 —— 玩家已经不在镜维度了。
       *
       * ⚠️ 必须**无条件**调用（不能只在"上次标记为镜外"时调）：
       *    玩家可能在镜内直接传送走，中间没经过一次区域判定；
       *    也可能在镜外时掉线/退出，下次进来时人已在别处。
       *    leaveOuter 自身幂等（存档为空时什么都不做），重复调用无害。 */
      /* ⚠️ 这里**必须用 var，不能写 const**。
       *
       * 事件处理器是被 KubeJS 通过 Java 接口代理回调进来的。在这种调用路径下：
       *   · 处理器函数体**顶层**的 const/let → 正常（上面那几行跑了上万次都没事）
       *   · 处理器里**嵌套块（if/for/try）内**的 const/let → 每次调用都抛
       *         TypeError: redeclaration of var N5o
       * 实测现场就是这个原因：日志里刷了 36 条 `redeclaration of var N5o`，
       * **这一行之后的 leaveOuter() 一次都没执行** ——
       * 表现是「在镜外传送到别的世界时不会恢复原游戏模式」。
       * 而这类异常不会让脚本加载失败，KubeJS 依旧显示 "0 errors"。
       * 同类问题由 tools/lint-scripts.mjs 的「事件处理器内嵌套块审计」兜住。 */
      var N5o = moduleRef('n5');
      if (N5o != null && N2.outerOn) N5o.leaveOuter(player);
      return;
    }

    const y = Math.floor(player.y);
    const regionKey = N0.regionOf(y);
    let last = player.persistentData.getString(PD_KEY_REGION);
    if (last == null || last === '') last = 'none';

    /* 诊断：只在**区域真的变化**时打一行（不再周期性刷屏 ——
     * 服务端线程上的日志 I/O 本身就是卡顿来源之一）。
     * 记的是判定用的原始量：y、regionOf 的结果、持久化键、开关状态。 */
    if (last !== regionKey) {
      try {
        console.info('[镜维度·区域] player=' + player.username
          + ' y=' + y
          + ' region=' + regionKey
          + ' last=' + last
          + ' outerOn=' + N2.outerOn);
      } catch (diagErr) {
        console.error('[镜维度·区域] 诊断失败: ' + diagErr);
      }
    }

    if (regionKey !== last && N2.outerOn) {
      N2.notifyRegionChange(player, regionKey, last);
    }
    player.persistentData.putString(PD_KEY_REGION, regionKey);

    /* 玻璃层兜底铺设（默认关）：由 n5 负责，这里只通知"该给这名玩家
     * 周围的区块排队了"。 */
    const N5 = moduleRef('n5');
    if (N5 != null) N5.enqueueAround(player);
  });

  /* ------------------------------------------------------------------ */
  /* 恢复原版重力（离开维度 / 回到镜内时）                                 */
  /* ------------------------------------------------------------------ */

  function restoreGravity(entity) {
    if (!cfg.gravity.enabled) return;
    try {
      if (isNonLivingGravityEntity(entity)) {
        if (MG_API != null) MG_API.clear(entity);
      } else if (MD.pondus != null && MD.pondus.available) {
        MD.pondus.API.resetGravity(entity);
      }
    } catch (err) {
      N0.fail('physics', err);
      // 忽略：恢复失败不影响其它逻辑
    }
    try {
      if (N0.manageAttr) {
        var inst = entity.getAttribute(N0.Attributes.GRAVITY);
        if (inst != null) {
          inst.setBaseValue(cfg.gravity.normal != null ? cfg.gravity.normal : 0.08);
        }
      }
    } catch (err) {
      N0.fail('physics', err);
      // 忽略
    }
    N1.forgetEntity(entity);
  }

  /* ------------------------------------------------------------------ */
  /* 其它实体：按间隔扫描                                                 */
  /* ------------------------------------------------------------------ */
  /* 镜像维度那一层从"已在镜维度里的玩家"身上取 —— 这是唯一验证过可靠的取法。
   * ⚠️ 不能用 server.getLevel(ResourceKey)（Rhino 重载歧义），
   *    也不能遍历 getAllLevels() + lv.dimension().location()（会抛异常被吞，
   *    导致整个扫描器一次都跑不成）。详见 README §11.6。
   *    关卡查找到 n6 里做了缓存，这里只调用。 */

  let entityTick = 0;

  ServerEvents.tick(event => {
    N1.tick();
    if (!cfg.gravity.enabled) return;
    entityTick++;
    if (entityTick % N0.scanInterval !== 0) return;

    try {
      var server = event.server;
      if (server == null) return;

      /* 关卡查找带缓存（见 n5）—— 不必每 tick 遍历玩家列表。 */
      var N5 = moduleRef('n5');
      if (N5 == null) return;
      var mirrorLevel = N5.mirrorLevelOf(server, N1.now());
      if (mirrorLevel == null) return;
      /* 清扫：每 SWEEP_INTERVAL tick 做一次全量对账。
       * 顺便在这一趟里收集存活实体的 id 集合（扫描本来就要遍历，
       * 额外成本只是往 Set 里塞一个字符串）。 */
      var doSweep = N1.shouldSweep();
      var liveIds = doSweep ? new Set() : null;

      var handled = 0;
      var skipped = 0;
      mirrorLevel.getEntities().forEach(function (ent) {
        try {
          if (ent == null) return;
          /* 玩家不在这里处理 —— 他们走上面的 PlayerEvents.tick
           *（那条路径还要兼顾区域判定）。 */
          if (isPlayer(ent)) return;

          var key = entityKey(ent);

          /* ⚠️ 清扫登记必须放在"是否跳过处理"**之前**。
           *    N1.sweep 会把不在 liveIds 里的实体状态删掉；如果因为
           *    "这一轮跳过掉落物"而不登记，它的防抖状态（lastDir /
           *    pendingFlip）每 SWEEP_INTERVAL tick 就被清一次，
           *    表现是掉落物在交界处判定的行为忽好忽坏。 */
          if (doSweep) liveIds.add(key);

          /* 掉落物按自己的间隔处理（默认每 20 tick 一次）。
           *
           * ⚠️ **首次判定不受间隔限制**：刚丢出来的掉落物还没有方向记录，
           *    如果也让它等下一个 20 拍，在下半镜外（本该朝上）它会先朝下
           *    掉整整一秒才被扭回来 —— 看起来就像"掉出去又弹回来"。
           *    所以规则是「首判立刻，之后每 N tick 复判一次」，
           *    降频省的正是稳态下那些重复判定。
           *
           * 为什么掉落物可以降频而下落的方块不行：掉落物不做加工、
           * 不参与配方计数，方向判定只决定自己往哪飞；下落的方块是
           * "方向 → 穿越次数 → 配方"这条链的源头，必须每 tick 判。
           * 详见 mirror_config.js → gravity.item_scan_interval。 */
          var seen = lastDir[key] != null;
          if (seen && isDroppedItem(ent) && (entityTick % ITEM_SCAN_INTERVAL) !== 0) {
            skipped++;
            return;
          }

          handled++;
          applyGravityTo(ent);
        } catch (err) {
          N0.fail('physics', err);
          // 单个实体失败不影响其它
        }
      });
      N1.setScanStats({ handled: handled, skipped: skipped, changed: 0 });

      if (doSweep) {
        N1.sweep(liveIds);
      }
    } catch (err) {
      /* 不刷屏：只在第一次报错。
       * ⚠️ 这个 catch 曾经把 getAllLevels 的异常吞掉、导致扫描器
       *    一次都没跑成，而日志里只有一条不显眼的记录。 */
      if (N1.scanStats().handled >= 0) {
        N1.setScanStats({ handled: -1, skipped: -1, changed: -1 });
        console.error('[镜维度] 实体扫描失败: ' + err);
      }
    }
  });

  /* ------------------------------------------------------------------ */
  /* 对外导出                                                            */
  /* ------------------------------------------------------------------ */

  const api = {
    ready: true,
    debounce: function () {
      const g = cfg.gravity;
      return {
        zone: g.player_dead_zone != null ? g.player_dead_zone : 1.5,
        gap: g.player_flip_gap != null ? g.player_flip_gap : 20,
        scale: g.falling_gravity_scale != null ? g.falling_gravity_scale : 0.35,
      };
    },
    forced: forcedDirName,
    setForce: setForce,
    dirNameAt: dirNameAt,
    typeName: typeName,
    isNonLivingGravityEntity: isNonLivingGravityEntity,
    /** 读某实体在 Pondus 侧的方向，供指令诊断 */
    readDirs: function (entity) {
      try {
        var PONDUS = MD.pondus;
        if (PONDUS == null || !PONDUS.available) return { base: '?', cur: '?' };
        var b = PONDUS.API.getBaseGravityDirection(entity);
        var c = PONDUS.API.getGravityDirection(entity);
        return {
          base: b == null ? '?' : String(b.getName()),
          cur: c == null ? '?' : String(c.getName()),
        };
      } catch (err) {
        return { base: 'ERR', cur: 'ERR' };
      }
    },
  };

  global.MirrorDimension.modules.n4 = api;
  return api;
})();
