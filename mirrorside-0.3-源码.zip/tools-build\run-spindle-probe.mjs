#!/usr/bin/env node
/**
 * 跑「针尖对麦芒」的离线几何验证。
 *
 * ── 它做什么 ────────────────────────────────────────────────────────────────
 * SpindleProbe.java 要编译真实的 SpindleGeometry.java（无 Minecraft 依赖）
 * 并跑几万个随机样本核对几何不变量。手工敲 javac/java 的路径太啰嗦，
 * 所以这里把"找 JDK、编译、运行"三步封起来，一条命令跑完。
 *
 * ── 为什么不用 Gradle ───────────────────────────────────────────────────────
 * 这个探针**故意**不依赖 Minecraft 类路径：它的价值就在于能在没有游戏、
 * 没有 NeoForge 的环境里独立跑（改一行几何就能立刻验证）。
 * 一旦挂到 Gradle 上，就变成"要启动一整套工具链"才能验证一条公式。
 *
 * 用法：
 *   node tools-build/run-spindle-probe.mjs [样本数] [重样本数]
 * 退出码：0 通过，非 0 失败（可直接接进校验流水线）。
 */
import { spawnSync } from 'node:child_process';
import { existsSync, mkdtempSync, rmSync, copyFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';

const HERE = dirname(fileURLToPath(import.meta.url));
const REPO = join(HERE, '..');
const JAVA_DIR = join(REPO, 'mirror-gravity-mod/src/main/java/work/dsh/mirror/gravity');
const PKG_DIR = 'work/dsh/mirror/gravity';

const CANDIDATES = [
  ['D:\\App\\java21\\bin\\javac.exe', 'D:\\App\\java21\\bin\\java.exe', 'D:\\App\\java21'],
  ['javac', 'java', 'PATH 上的默认 JDK'],
];

let javac = null;
let java = null;
let jdkLabel = null;
for (const [jc, jv, label] of CANDIDATES) {
  const probe = spawnSync(jc, ['-version'], { encoding: 'utf8' });
  if (probe.status === 0 || /javac/i.test((probe.stderr ?? '') + (probe.stdout ?? ''))) {
    javac = jc;
    java = jv;
    jdkLabel = label;
    break;
  }
}
if (!javac) {
  console.error('✗ 找不到 javac。请在 D:\\App\\java21 安装 JDK 21，或把 javac 放进 PATH。');
  process.exit(2);
}

const work = mkdtempSync(join(tmpdir(), 'spindle-probe-'));
try {
  mkdirSync(join(work, PKG_DIR), { recursive: true });
  copyFileSync(join(JAVA_DIR, 'SpindleGeometry.java'), join(work, PKG_DIR, 'SpindleGeometry.java'));
  copyFileSync(join(HERE, 'SpindleProbe.java'), join(work, PKG_DIR, 'SpindleProbe.java'));

  const args = process.argv.slice(2);
  const samples = args[0] ?? '20000';
  const heavy = args[1] ?? '400';

  console.log(`[探针] JDK: ${jdkLabel}`);
  const compile = spawnSync(javac, ['-encoding', 'UTF-8', '-d', work,
    join(work, PKG_DIR, 'SpindleGeometry.java'),
    join(work, PKG_DIR, 'SpindleProbe.java')], { encoding: 'utf8' });
  if (compile.status !== 0) {
    console.error('✗ 编译失败:\n' + (compile.stderr ?? '') + (compile.stdout ?? ''));
    process.exit(2);
  }

  const run = spawnSync(java, ['-Dstdout.encoding=UTF-8', '-Dfile.encoding=UTF-8', '-cp', work,
    'work.dsh.mirror.gravity.SpindleProbe', JAVA_DIR, samples, heavy],
  { encoding: 'utf8' });
  process.stdout.write(run.stdout ?? '');
  process.stderr.write(run.stderr ?? '');
  process.exit(run.status ?? 1);
} finally {
  try { rmSync(work, { recursive: true, force: true }); } catch { /* 临时目录清不掉不影响结论 */ }
}
