package work.dsh.mirror.gravity;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 针尖对麦芒 · 纯几何层。
 *
 * <h2>为什么单独一层，而且禁止 import Minecraft</h2>
 * 这个结构只在"开新档 / 生成新区块"时才会跑一次，而它要验证的结论是
 * <b>数值性</b>的：锥尖到底伸进境内几格、波粒块是不是正好在两尖中点、
 * 锥体会不会捅到 y=0 的黑玻璃、包围盒会强制生成多少区块。
 * 靠进游戏肉眼看"差一格"代价太高，所以几何全部集中在这里，只依赖 {@code java.*}，
 * 由 {@code tools-build/SpindleProbe.java} 用 javac + java **离线**跑断言
 * （几千个随机样本逐例核对不变量）。因此本文件一旦 import 了 Minecraft，
 * 离线验证就没了 —— 这是硬约束。
 *
 * <h2>几何约定（逐条对应「玩法-针尖对麦芒.txt」）</h2>
 * <pre>
 *   上镜外 y≥64        ┌───┐  ← 锥底（半径 5~13）
 *                      │   │
 *                      ╲   ╱     针尖（铁块）/ 麦芒（干草块），谁在上镜外随机
 *                       ╲ ╱
 *   白玻璃 y=62/63  ─ ─ ─ ✕ ─ ─ ─ ← 锥尖穿透玻璃伸进境内（inset 格）
 *   境 内  -64..63        ▮        ← 波粒块：两锥尖连线的中点
 *   白玻璃 y=-64/-65 ─ ─ ─ ✕ ─ ─ ─
 *                       ╱ ╲
 *                      ╱   ╲
 *                      │   │
 *   下镜外 y≤-65       └───┘
 * </pre>
 *
 * <h2>核心推导：为什么波粒块必然落在镜面附近</h2>
 * 设波粒块所在方块为 {@code (coreX, coreY, coreZ)}，它的<b>中心</b>就是两锥尖的中点。
 * 记两锥尖伸进境内的格数为 {@code insetUp} / {@code insetDn}，两尖的 y 坐标为
 * <pre>
 *   tipUpY = innerMaxY + 1.5 - insetUp      // 63.5 是 y=63 那层的块心
 *   tipDnY = innerMinY - 0.5 + insetDn      // -64.5 是 y=-64 那层的块心
 * </pre>
 * 令中点等于 coreY + 0.5：
 * <pre>
 *   (tipUpY + tipDnY) / 2 = coreY + 0.5
 *   ⇒ insetDn - insetUp = 2 * coreY + 1 + (innerMaxY + innerMinY + 1)
 *   ⇒ insetDn - insetUp = 2 * coreY + 1        // 境内高 128，故 innerMaxY+innerMinY+1 = 0
 * </pre>
 * 也就是说：<b>两侧伸入格数之差由波粒块高度唯一决定</b>。想让两侧都只伸进
 * 一小段（2~24 格），coreY 就只能落在 ±11 附近 —— 这就是"波粒块必然在镜面附近"
 * 的由来（用户已确认接受）。这条关系式在 {@link #sample} 里被用来反推另一侧，
 * 在离线测试里被逐例核对。
 *
 * <h2>翻滚角为什么取样却不影响画面</h2>
 * 圆锥绕自身中轴旋转对称，滚转 0° 与 90° 渲染完全相同。参数表里仍然取样
 * （设定写了"翻滚角随机"），但它对几何是恒等变换 —— 写在这里免得后人以为漏了。
 */
public final class SpindleGeometry {

    private SpindleGeometry() {
    }

    /**
     * 中轴"脊线"的半径阈值（格）：锥半径小于它时，每层只放<b>最靠近中轴的那一格</b>。
     *
     * <h2>为什么需要（来自实机反馈"尖不够细，不够尖"）</h2>
     * 正圆锥的半径从中轴上的 0 线性长到底面的 {@code rad}。若一律用
     * "块心到中轴的垂距 ≤ 该处半径"来栅格化，锥尖附近半径不足半格，
     * 倾斜的中轴几乎不可能正好穿过某个方块中心 ⇒ 尖端会缺格，两侧缺口还不对称。
     *
     * <p>早先的对策是把半径下限卡在 0.9 格（常量 TIP_CORE）—— 这确实保证了
     * 锥尖一定有一格，但代价是<b>锥尖变钝</b>：半径不足 0.9 的那一段
     * （长度 0.9·len/rad）整段变成一根 2 格宽的小柱子。
     * 实机那两根锥体里，半径 5.0 / 长度 94.3 的那根，头 17 格都是 2 格宽的钝头
     * —— 看着就是"针尖不尖"。
     *
     * <h2>现在的做法</h2>
     * 半径 ≤ {@code √2/2 ≈ 0.7071} 时改成"每层只写最靠近中轴的那一格"，
     * 即一根 1 格宽的中轴脊线。它一定连续：相邻两层中轴的水平位移是
     * {@code tan(90°-pitch) ≤ tan22° ≈ 0.40} 格，取整后每层至多挪一格。
     * 半径超过阈值后接回正常锥体判定：那一层半径已经 &gt; 0.7071，
     * 最靠近中轴的那一格必然落在锥内，所以脊线与锥体之间没有缝。
     */
    public static final double SPINE_RADIUS = 0.7071D;

    /** 针尖：铁块。 */
    public static final int KIND_NEEDLE = 0;
    /** 麦芒：干草块。 */
    public static final int KIND_AWN = 1;
    /** 波粒块。 */
    public static final int KIND_CORE = 2;

    /** 随机源最小接口：模组侧包装 {@code RandomSource}，离线测试用 {@code java.util.Random}。 */
    public interface Rng {
        double nextDouble();

        int nextInt(int bound);
    }

    /** 方块消费口。{@code kind} 取 {@code KIND_*}。 */
    public interface BlockSink {
        void accept(int x, int y, int z, int kind);
    }

    /**
     * 生成规则。唯一真相在 {@code kubejs/startup_scripts/mirror_config.js} 的
     * {@code spindle} 段，运行时由 {@link MirrorGravityApi#setSpindleParams} 推过来；
     * 这里的取值只是"脚本还没推过来"时的兜底，并与配置逐项对拍
     * （{@code tools-build/check-param-parity.mjs}）。
     */
    public static final class Rules {
        public final double radiusMin;
        public final double radiusMax;
        public final double lengthMin;
        public final double lengthMax;
        public final double insetMin;
        public final double insetMax;
        public final double centerYMin;
        public final double centerYMax;
        public final double pitchMinDeg;
        public final double pitchMaxDeg;
        public final int innerMinY;
        public final int innerMaxY;
        public final int buildMinY;
        public final int buildMaxY;
        /** 波粒块不允许落在这些 y 上（黑玻璃夹层）。 */
        public final int[] coreAvoidYs;

        public Rules(
            double radiusMin, double radiusMax,
            double lengthMin, double lengthMax,
            double insetMin, double insetMax,
            double centerYMin, double centerYMax,
            double pitchMinDeg, double pitchMaxDeg,
            int innerMinY, int innerMaxY,
            int buildMinY, int buildMaxY,
            int[] coreAvoidYs) {
            this.radiusMin = radiusMin;
            this.radiusMax = radiusMax;
            this.lengthMin = lengthMin;
            this.lengthMax = lengthMax;
            this.insetMin = insetMin;
            this.insetMax = insetMax;
            this.centerYMin = centerYMin;
            this.centerYMax = centerYMax;
            this.pitchMinDeg = pitchMinDeg;
            this.pitchMaxDeg = pitchMaxDeg;
            this.innerMinY = innerMinY;
            this.innerMaxY = innerMaxY;
            this.buildMinY = buildMinY;
            this.buildMaxY = buildMaxY;
            this.coreAvoidYs = coreAvoidYs == null ? new int[0] : coreAvoidYs.clone();
        }

        /** 两侧伸入格数之差的上限（由波粒块的高度带决定）。 */
        public double maxInsetSpread() {
            int lo = (int) Math.ceil(centerYMin);
            int hi = (int) Math.floor(centerYMax);
            int a = Math.abs(2 * lo + 1);
            int b = Math.abs(2 * hi + 1);
            return Math.max(a, b);
        }

        /**
         * 规则自检。日志里报错总比生成出一堆错位的方块好 ——
         * 所以 {@link MirrorGravityApi#setSpindleParams} 在推送时就调用它。
         *
         * @return 人类可读的问题描述；全部合法时返回 {@code null}
         */
        public String problem() {
            if (radiusMin <= 0 || radiusMin > radiusMax) {
                return "半径区间非法: " + radiusMin + ".." + radiusMax;
            }
            if (lengthMin < 1 || lengthMin > lengthMax) {
                return "长度区间非法: " + lengthMin + ".." + lengthMax;
            }
            if (insetMin < 1 || insetMin > insetMax) {
                return "伸入格数区间非法: " + insetMin + ".." + insetMax;
            }
            if (centerYMin > centerYMax) {
                return "波粒块高度区间非法: " + centerYMin + ".." + centerYMax;
            }
            if (centerYMin < innerMinY || centerYMax > innerMaxY) {
                return "波粒块高度带越出境内: " + centerYMin + ".." + centerYMax;
            }
            if (pitchMinDeg < 1 || pitchMaxDeg > 90 || pitchMinDeg > pitchMaxDeg) {
                return "俯仰角区间非法: " + pitchMinDeg + ".." + pitchMaxDeg;
            }
            double spread = maxInsetSpread();
            if (spread > insetMax - insetMin) {
                return "伸入格数区间放不下高度带带来的差值: 需要 "
                    + (int) spread + " 格余量，实际只有 " + (int) (insetMax - insetMin);
            }
            /* 顶端/底端能不能装下最长最粗的那根。
             * 最坏情况不是"竖直的 length"，而是中轴长度与底面圆盘在 y 上投影的合成：
             *   最高点 = 锥尖最浅的 y + max( sin(p)*L + cos(p)*rad ) = tipY + √(L²+rad²)
             * 60° 附近两项同时接近最大，所以必须按平方和算，不能只按 length 估。 */
            double worstReach = Math.sqrt(lengthMax * lengthMax + radiusMax * radiusMax);
            double topMax = innerMaxY + 1.5D - insetMin + worstReach;
            if (topMax > buildMaxY + 0.5D) {
                return "上锥会顶出世界高度: 最高方块中心约 " + Math.round(topMax)
                    + "，上限 " + buildMaxY + ".5";
            }
            double bottomMin = innerMinY - 0.5D + insetMin - worstReach;
            if (bottomMin < buildMinY) {
                return "下锥会穿出世界底: 最低方块中心约 " + Math.round(bottomMin)
                    + "，下限 " + buildMinY;
            }
            return null;
        }
    }

    /**
     * 一次生成的完整参数。构造时就把两锥尖、包围盒算出来，之后只读。
     * 所有量都能存进 NBT 再原样重建（结构片段在区块重载时必须复现同样的方块）。
     */
    public static final class Plan {
        /** 波粒块所在方块坐标（它的中心就是两锥尖中点）。 */
        public final int coreX;
        public final int coreY;
        public final int coreZ;
        /** 单位中轴，(ux,uy,uz)；uy &gt; 0 恒成立，指向上镜外那一侧。 */
        public final double ux;
        public final double uy;
        public final double uz;
        /** 两锥尖到波粒块中心的轴向距离（相等 —— 中点定义）。 */
        public final double reach;
        /** 上锥（上镜外）的锥尖与世界坐标；它向 +u 方向张开。 */
        public final double tipUpX;
        public final double tipUpY;
        public final double tipUpZ;
        /** 下锥（下镜外）的锥尖；它向 -u 方向张开。 */
        public final double tipDnX;
        public final double tipDnY;
        public final double tipDnZ;
        /** 上锥的长度/底半径/材质。 */
        public final double upLen;
        public final double upRad;
        public final int upKind;
        /** 下锥的长度/底半径/材质。 */
        public final double dnLen;
        public final double dnRad;
        public final int dnKind;
        /** 两锥尖伸进境内的格数。 */
        public final double insetUp;
        public final double insetDn;
        /** 取样到的三个角（翻滚角对圆锥无视觉效果，仅为参数完整而保留）。 */
        public final double yawDeg;
        public final double pitchDeg;
        public final double rollDeg;
        /** 整个装置的包围盒（含方块范围，闭区间）。 */
        public final int minX;
        public final int minY;
        public final int minZ;
        public final int maxX;
        public final int maxY;
        public final int maxZ;

        public Plan(
            int coreX, int coreY, int coreZ,
            double ux, double uy, double uz, double reach,
            double tipUpX, double tipUpY, double tipUpZ,
            double tipDnX, double tipDnY, double tipDnZ,
            double upLen, double upRad, int upKind,
            double dnLen, double dnRad, int dnKind,
            double insetUp, double insetDn,
            double yawDeg, double pitchDeg, double rollDeg) {
            this.coreX = coreX;
            this.coreY = coreY;
            this.coreZ = coreZ;
            this.ux = ux;
            this.uy = uy;
            this.uz = uz;
            this.reach = reach;
            this.tipUpX = tipUpX;
            this.tipUpY = tipUpY;
            this.tipUpZ = tipUpZ;
            this.tipDnX = tipDnX;
            this.tipDnY = tipDnY;
            this.tipDnZ = tipDnZ;
            this.upLen = upLen;
            this.upRad = upRad;
            this.upKind = upKind;
            this.dnLen = dnLen;
            this.dnRad = dnRad;
            this.dnKind = dnKind;
            this.insetUp = insetUp;
            this.insetDn = insetDn;
            this.yawDeg = yawDeg;
            this.pitchDeg = pitchDeg;
            this.rollDeg = rollDeg;

            /* 包围盒 = 两条"锥尖→底面中心"线段的端点圆盘之并。
             * 正圆锥的半径沿轴线性增长，所以任一坐标的极值必定出现在两个端点之一
             * （沿轴参数是线性的），端点圆盘外扩就是**精确**包围盒。
             *
             * ⚠️ 外扩量必须逐轴算：底面那个圆盘是**垂直于中轴**的，
             * 它在 x 轴上的半宽是 rad*√(1-ux²) 而不是 rad。
             * 早先按"各轴都外扩 rad"写，竖直锥的 y 范围会虚增 ±rad ——
             * 包围盒顶到 203 > 世界顶 191，世界生成时会强制加载一堆空区块。
             */
            double sx = Math.sqrt(Math.max(0.0D, 1.0D - ux * ux));
            double sy = Math.sqrt(Math.max(0.0D, 1.0D - uy * uy));
            double sz = Math.sqrt(Math.max(0.0D, 1.0D - uz * uz));
            double[] box = {
                Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE,
                -Double.MAX_VALUE, -Double.MAX_VALUE, -Double.MAX_VALUE
            };
            grow(box, tipUpX, tipUpY, tipUpZ, upRad * sx, upRad * sy, upRad * sz);
            grow(box, tipUpX + ux * upLen, tipUpY + uy * upLen, tipUpZ + uz * upLen,
                upRad * sx, upRad * sy, upRad * sz);
            grow(box, tipDnX, tipDnY, tipDnZ, dnRad * sx, dnRad * sy, dnRad * sz);
            grow(box, tipDnX - ux * dnLen, tipDnY - uy * dnLen, tipDnZ - uz * dnLen,
                dnRad * sx, dnRad * sy, dnRad * sz);
            grow(box, coreX + 0.5D, coreY + 0.5D, coreZ + 0.5D, 0.5D, 0.5D, 0.5D);

            /* 方块 x 的中心是 x+0.5，所以块心落在 [minD, maxD] 内的整数 x 范围是
             * [ceil(minD-0.5), floor(maxD-0.5)]；两端再各留 1 格纯属保险。 */
            this.minX = (int) Math.ceil(box[0] - 0.5D) - 1;
            this.minY = (int) Math.ceil(box[1] - 0.5D) - 1;
            this.minZ = (int) Math.ceil(box[2] - 0.5D) - 1;
            this.maxX = (int) Math.floor(box[3] - 0.5D) + 1;
            this.maxY = (int) Math.floor(box[4] - 0.5D) + 1;
            this.maxZ = (int) Math.floor(box[5] - 0.5D) + 1;
        }

        private static void grow(double[] box, double x, double y, double z,
                                double rx, double ry, double rz) {
            if (x - rx < box[0]) {
                box[0] = x - rx;
            }
            if (y - ry < box[1]) {
                box[1] = y - ry;
            }
            if (z - rz < box[2]) {
                box[2] = z - rz;
            }
            if (x + rx > box[3]) {
                box[3] = x + rx;
            }
            if (y + ry > box[4]) {
                box[4] = y + ry;
            }
            if (z + rz > box[5]) {
                box[5] = z + rz;
            }
        }

        /** 包围盒横跨的区块数（世界生成时会被强制生成的区块边长）。 */
        public int chunkSpanX() {
            return (maxX >> 4) - (minX >> 4) + 1;
        }

        public int chunkSpanZ() {
            return (maxZ >> 4) - (minZ >> 4) + 1;
        }

        public String describe() {
            return String.format(
                Locale.ROOT,
                "波粒块 (%d,%d,%d) 俯仰 %.1f° 偏航 %.1f° | 上锥 %s 长 %.1f 半径 %.1f 伸入 %.0f"
                    + " | 下锥 %s 长 %.1f 半径 %.1f 伸入 %.0f | 包围盒 %dx%dx%d 跨 %dx%d 区块",
                coreX, coreY, coreZ, pitchDeg, yawDeg,
                upKind == KIND_NEEDLE ? "针尖(铁)" : "麦芒(草)", upLen, upRad, insetUp,
                dnKind == KIND_NEEDLE ? "针尖(铁)" : "麦芒(草)", dnLen, dnRad, insetDn,
                maxX - minX + 1, maxY - minY + 1, maxZ - minZ + 1, chunkSpanX(), chunkSpanZ());
        }
    }

    /**
     * 按规则随机出一份完整方案。
     *
     * <p>取样顺序即随机流顺序 —— <b>改动顺序会改变同一个区块的生成结果</b>，
     * 所以顺序在这里显式写清楚：谁在上 → 翻滚角 → 偏航角 → 俯仰角 →
     * 两根的长度/半径 → 波粒块水平位置 → 波粒块高度 → 伸入格数。
     *
     * @param originX 结构所在区块的最小 x（方块坐标）
     * @param originZ 结构所在区块的最小 z
     */
    public static Plan sample(Rng rng, Rules r, int originX, int originZ) {
        /* 1) 谁在上镜外。 */
        boolean needleUp = rng.nextDouble() < 0.5D;

        /* 2) 翻滚角：取样但不参与任何计算（见类注释）。 */
        double rollDeg = rng.nextDouble() * 360.0D;

        /* 3) 偏航角 + 俯仰角 → 单位中轴。俯仰角按"与水平面的夹角"定义，
         *    所以 90° 是竖直。下限保证 uy 足够大，锥体才不会横跨上千格。 */
        double yawDeg = rng.nextDouble() * 360.0D;
        double pitchDeg = lerp(rng.nextDouble(), r.pitchMinDeg, r.pitchMaxDeg);
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        double horiz = Math.cos(pitch);
        double ux = horiz * Math.cos(yaw);
        double uy = Math.sin(pitch);
        double uz = horiz * Math.sin(yaw);

        /* 4) 两根圆锥各自的长度与底半径（互不相关）。 */
        double needleLen = lerp(rng.nextDouble(), r.lengthMin, r.lengthMax);
        double awnLen = lerp(rng.nextDouble(), r.lengthMin, r.lengthMax);
        double needleRad = lerp(rng.nextDouble(), r.radiusMin, r.radiusMax);
        double awnRad = lerp(rng.nextDouble(), r.radiusMin, r.radiusMax);

        /* 5) 波粒块：水平落在结构区块内，高度在允许带里避开黑玻璃夹层。 */
        int coreX = originX + rng.nextInt(16);
        int coreZ = originZ + rng.nextInt(16);
        int coreY = pickCoreY(rng, r);

        /* 6) 两锥尖伸进境内的格数。先定"更深的一侧"，另一侧由中点关系式反推
         *    （insetDn - insetUp = 2*coreY + 1，推导见类注释）。
         *    把深的一侧取在 [insetMin + |diff|, insetMax] 上，浅的一侧必落在
         *    [insetMin, insetMax] 内 —— 这正是 Rules.problem() 要校验的那条余量。 */
        int diff = 2 * coreY + 1;
        int spread = Math.abs(diff);
        double lo = Math.min(r.insetMin + spread, r.insetMax);
        int deeper = (int) Math.round(lerp(rng.nextDouble(), lo, r.insetMax));
        int insetUp;
        int insetDn;
        if (diff >= 0) {
            insetDn = deeper;
            insetUp = deeper - spread;
        } else {
            insetUp = deeper;
            insetDn = deeper - spread;
        }
        if (insetUp < 1) {
            insetUp = 1;
        }
        if (insetDn < 1) {
            insetDn = 1;
        }

        /* 7) 两锥尖的 y 由"伸进境内多少格"直接给出；x/z 由水平位置沿中轴推出去。 */
        double tipUpY = r.innerMaxY + 1.5D - insetUp;
        double tipDnY = r.innerMinY - 0.5D + insetDn;
        double coreCX = coreX + 0.5D;
        double coreCY = coreY + 0.5D;
        double coreCZ = coreZ + 0.5D;
        double reach = (tipUpY - coreCY) / uy;
        double tipUpX = coreCX + ux * reach;
        double tipUpZ = coreCZ + uz * reach;
        double tipDnX = coreCX - ux * reach;
        double tipDnZ = coreCZ - uz * reach;

        /* 8) 组装。上锥用 +u 张开、下锥用 -u。 */
        double upLen = needleUp ? needleLen : awnLen;
        double upRad = needleUp ? needleRad : awnRad;
        int upKind = needleUp ? KIND_NEEDLE : KIND_AWN;
        double dnLen = needleUp ? awnLen : needleLen;
        double dnRad = needleUp ? awnRad : needleRad;
        int dnKind = needleUp ? KIND_AWN : KIND_NEEDLE;

        return new Plan(
            coreX, coreY, coreZ,
            ux, uy, uz, reach,
            tipUpX, tipUpY, tipUpZ,
            tipDnX, tipDnY, tipDnZ,
            upLen, upRad, upKind,
            dnLen, dnRad, dnKind,
            insetUp, insetDn,
            yawDeg, pitchDeg, rollDeg);
    }

    /** 在允许带里挑一个高度，并把黑玻璃夹层整个剔掉。 */
    private static int pickCoreY(Rng rng, Rules r) {
        int lo = (int) Math.ceil(r.centerYMin);
        int hi = (int) Math.floor(r.centerYMax);
        List<Integer> allowed = new ArrayList<>();
        for (int y = lo; y <= hi; y++) {
            boolean bad = false;
            for (int avoid : r.coreAvoidYs) {
                if (avoid == y) {
                    bad = true;
                    break;
                }
            }
            if (!bad) {
                allowed.add(y);
            }
        }
        if (allowed.isEmpty()) {
            /* 高度带整段落进夹层 —— 规则已经烂了，退化成带的中点，
             * 让 Rules.problem() 去报错，而不是在这里崩世界生成。 */
            return (lo + hi) / 2;
        }
        return allowed.get(rng.nextInt(allowed.size()));
    }

    private static double lerp(double t, double a, double b) {
        return a + (b - a) * t;
    }

    /**
     * 枚举落在给定盒子内的所有方块。
     *
     * <p>为什么按 y 切片而不是遍历整个包围盒：包围盒可以到 90×380×90 ≈ 300 万格，
     * 而锥体本身只占其中 1%~2%。逐 y 求出中轴与该层的交点、再只在交点附近
     * 一圈 x/z 上做精确判定，迭代量就降到和锥体体积同量级。
     * 产出的方块顺序不保证，调用方不应依赖。
     *
     * <p><b>精确判定</b>：方块中心到中轴的垂距 ≤ 该处的锥半径（沿轴线性增长）；
     * 半径小于 {@link #SPINE_RADIUS} 的锥尖段退化成 1 格宽的中轴脊线。
     */
    public static void forEachBlock(
        Plan plan, int minX, int minY, int minZ, int maxX, int maxY, int maxZ, BlockSink sink) {
        int x0 = Math.max(minX, plan.minX);
        int x1 = Math.min(maxX, plan.maxX);
        int y0 = Math.max(minY, plan.minY);
        int y1 = Math.min(maxY, plan.maxY);
        int z0 = Math.max(minZ, plan.minZ);
        int z1 = Math.min(maxZ, plan.maxZ);
        if (x0 > x1 || y0 > y1 || z0 > z1) {
            return;
        }

        /* 波粒块在最中间，先报出去（它可能落在任一区块里）。 */
        if (plan.coreX >= x0 && plan.coreX <= x1
            && plan.coreY >= y0 && plan.coreY <= y1
            && plan.coreZ >= z0 && plan.coreZ <= z1) {
            sink.accept(plan.coreX, plan.coreY, plan.coreZ, KIND_CORE);
        }

        /* 上锥：从锥尖沿 +u 张开。 */
        coneSlice(plan, plan.tipUpX, plan.tipUpY, plan.tipUpZ,
            plan.ux, plan.uy, plan.uz, plan.upLen, plan.upRad, plan.upKind,
            x0, y0, z0, x1, y1, z1, sink);
        /* 下锥：从锥尖沿 -u 张开。 */
        coneSlice(plan, plan.tipDnX, plan.tipDnY, plan.tipDnZ,
            -plan.ux, -plan.uy, -plan.uz, plan.dnLen, plan.dnRad, plan.dnKind,
            x0, y0, z0, x1, y1, z1, sink);
    }

    private static void coneSlice(
        Plan plan,
        double tipX, double tipY, double tipZ,
        double wx, double wy, double wz, double len, double rad, int kind,
        int x0, int y0, int z0, int x1, int y1, int z1,
        BlockSink sink) {
        /* 只防"中轴几乎水平"导致的除零。⚠️ 不能用 `wy <= 0` 判断 ——
         * 下锥的轴向是 -u，它的 wy 本来就是负的（锥体向下张开），
         * 早先用 <= 1e-6 当守卫，把整个下锥判成了空集：
         * 表现是"装置只有一根锥体"，而方块量与理想体积的比值恰好是 0.5。 */
        if (Math.abs(wy) <= 1.0e-6D) {
            return;
        }
        for (int y = y0; y <= y1; y++) {
            double t = (y + 0.5D - tipY) / wy;
            if (t < 0.0D || t > len) {
                continue;
            }
            double axisX = tipX + wx * t;
            double axisZ = tipZ + wz * t;
            double rAt = rad * t / len;

            /* 锥尖段：半径不足一格，改为只写"最靠近中轴的那一格"。
             * 这样锥尖是一条 1 格宽的脊线 —— 最细、最尖，而且是连通的
             * （每层中轴至多横移 0.40 格）。见 SPINE_RADIUS 的说明。 */
            if (rAt <= SPINE_RADIUS) {
                int sx = (int) Math.round(axisX - 0.5D);
                int sz = (int) Math.round(axisZ - 0.5D);
                if (sx >= x0 && sx <= x1 && sz >= z0 && sz <= z1) {
                    sink.accept(sx, y, sz, kind);
                }
                continue;
            }

            /* 块心与轴的水平距离不超过 rAt ⇒ 整数 x/z 必落在下面这个窗口里。 */
            int bx0 = Math.max(x0, (int) Math.floor(axisX - rAt - 0.5D) - 1);
            int bx1 = Math.min(x1, (int) Math.ceil(axisX + rAt + 0.5D) + 1);
            int bz0 = Math.max(z0, (int) Math.floor(axisZ - rAt - 0.5D) - 1);
            int bz1 = Math.min(z1, (int) Math.ceil(axisZ + rAt + 0.5D) + 1);
            for (int x = bx0; x <= bx1; x++) {
                double px = x + 0.5D - tipX;
                for (int z = bz0; z <= bz1; z++) {
                    double pz = z + 0.5D - tipZ;
                    double py = y + 0.5D - tipY;
                    double along = px * wx + py * wy + pz * wz;
                    if (along < 0.0D || along > len) {
                        continue;
                    }
                    double dx = px - wx * along;
                    double dy = py - wy * along;
                    double dz = pz - wz * along;
                    if (dx * dx + dy * dy + dz * dz <= rAt * rAt) {
                        sink.accept(x, y, z, kind);
                    }
                }
            }
        }
    }
}
