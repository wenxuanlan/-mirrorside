package work.dsh.mirror.gravity.jei;

import work.dsh.mirror.gravity.internal.Failures;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import work.dsh.mirror.gravity.MirrorBlocks;
import work.dsh.mirror.gravity.MirrorGravity;

import java.util.List;

/**
 * JEI 分类：重力方块加工。
 *
 * <h2>版面</h2>
 * <pre>
 *   ┌────────────────────────────────────────────┐
 *   │ [镜面] → [输入]      ↓↑        [产物]        │
 *   │ 落在 [落点方块] → 塞入 [物品池]               │
 *   │ 重力切换 N 次后…                              │
 *   │ 补充说明（掉落物形式 / 产物＝落点方块 …）      │
 *   └────────────────────────────────────────────┘
 * </pre>
 *
 * <h2>为什么左边是"镜面"而不是输入方块</h2>
 * JEI 版面的第一个槽惯例是**工作方块**（如工作台的合成、熔炉的烧炼）。
 * 重力方块加工没有工作方块，但"加工发生在镜面上"是这套设定的核心，
 * 所以注册了一个 {@code mirrorgravity:mirror_surface}（镜面）占位方块放在这里。
 * 若把输入方块（沙砾）摆在最左，会让人误以为沙砾是工作台。
 *
 * <h2>落地要求与容器：全部用真实物品槽表达</h2>
 * 早先 landing 配方把要求写成文字（"落在黑色玻璃上"）。文字无法被 JEI
 * 索引，玩家搜"黑色玻璃"也找不到这条配方。现在两类要求都是**真实槽位**：
 * <ul>
 *   <li><b>落点</b>：配置里写标签（{@code #c:storage_blocks}）时，
 *       槽里循环显示标签内所有方块 —— 于是"铁砧落在任意矿物块上"
 *       对每一个成员都能被搜到</li>
 *   <li><b>容器与塞入物</b>：落在陶罐上会往罐里塞一个考古战利品。
 *       陶罐画成落点槽（它就是容器），战利品池画成"塞入"槽，
 *       两样都是可见的物品贴图，而不是一句说明</li>
 * </ul>
 * 槽位能同时装多个物品时 JEI 会自己循环显示，不需要我们排布多格。
 */
public class GravityRecipeCategory implements IRecipeCategory<GravityRecipe> {

    /** 分类唯一 ID。命名空间用本模组的 mod id。 */
    public static final RecipeType<GravityRecipe> TYPE =
        RecipeType.create(MirrorGravity.MOD_ID, "gravity_block_crafting", GravityRecipe.class);

    private static final int WIDTH = 170;
    private static final int HEIGHT = 70;

    /** 行 1 各槽位左上角坐标。 */
    private static final int ROW1_Y = 3;
    private static final int WORKBENCH_X = 3;
    private static final int INPUT_X = 30;
    private static final int OUTPUT_X = 120;
    /** 行 1 中间的"重力反转"示意图位置。 */
    private static final int FLIP_ICON_X = 82;
    private static final int FLIP_ICON_Y = 7;

    /** 行 2（落地要求 + 容器塞入）槽位。 */
    private static final int ROW2_SLOT_Y = 24;
    private static final int ON_SLOT_X = 25;
    private static final int INSERT_SLOT_X = 80;

    /** 文字行。 */
    private static final int CONDITION_Y = 46;
    private static final int NOTE_Y = 57;

    private final IDrawable background;
    private final IDrawable icon;

    public GravityRecipeCategory(IGuiHelper guiHelper) {
        // 纯色底 + 描边，不依赖任何贴图资源
        this.background = guiHelper.createBlankDrawable(WIDTH, HEIGHT);
        // 分类图标用"镜面"方块，一看就知道这个分类属于镜面加工
        this.icon = guiHelper.createDrawableItemLike(iconItem());
    }

    /** 分类图标：优先用注册好的镜面方块，取不到时退回玻璃。 */
    private static ItemLike iconItem() {
        try {
            ItemLike item = MirrorBlocks.MIRROR_SURFACE_ITEM.get();
            if (item != null) {
                return item;
            }
        } catch (Throwable ignored) {
            Failures.note("GravityRecipeCategory.iconItem", ignored);
            // 注册表尚未就绪等异常，退回默认图标即可
        }
        return Items.GLASS;
    }

    @Override
    public RecipeType<GravityRecipe> getRecipeType() {
        return TYPE;
    }

    @Override
    public Component getTitle() {
        return Component.literal("重力方块加工");
    }

    @Override
    public IDrawable getBackground() {
        return background;
    }

    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, GravityRecipe recipe, IFocusGroup focuses) {
        // ---- 工作方块：镜面 ----
        ItemStack workbench = new ItemStack(iconItem());
        builder.addInputSlot(WORKBENCH_X, ROW1_Y)
            .setStandardSlotBackground()
            .addItemStack(workbench);

        // ---- 输入 ----
        addSlotIfAny(builder, INPUT_X, ROW1_Y,
            GravityRecipeItems.resolveAll(List.of(recipe.input()), 1), false);

        // ---- 产物 ----
        /* 产物可能是一组候选（'{@code @landed}' 铁砧变成落点那一块、
         * '{@code @mapped}' 脚手架按落点变树苗）。全塞进一个输出槽，
         * JEI 会循环显示 —— 这样搜"铁块"能找到铁砧那条配方。 */
        addSlotIfAny(builder, OUTPUT_X, ROW1_Y,
            GravityRecipeItems.resolveAll(recipe.outputSpecs(), 1), true);

        // ---- 落地要求：真实方块槽（标签会展开成全部成员） ----
        if (recipe.landing()) {
            addSlotIfAny(builder, ON_SLOT_X, ROW2_SLOT_Y,
                GravityRecipeItems.resolveAll(recipe.on(), 1), false);
        }

        // ---- 落在容器上时塞进去的物品 ----
        if (recipe.hasInsert()) {
            addSlotIfAny(builder, INSERT_SLOT_X, ROW2_SLOT_Y,
                GravityRecipeItems.resolveAll(recipe.insertItems(), recipe.insertCount()), false);
        }
    }

    /** 加一个槽；候选为空时干脆不加，免得版面上留一格空槽。 */
    private static void addSlotIfAny(IRecipeLayoutBuilder builder, int x, int y,
                                     List<ItemStack> stacks, boolean output) {
        if (stacks == null || stacks.isEmpty()) {
            return;
        }
        var slot = output ? builder.addOutputSlot(x, y) : builder.addInputSlot(x, y);
        slot.setStandardSlotBackground();
        if (output) {
            slot.setOutputSlotBackground();
        }
        slot.addItemStacks(stacks);
    }

    /**
     * 画边框、箭头与说明文字。
     *
     * <p>槽位由 JEI 自己绘制，这里只补"不是槽位"的部分。
     */
    @Override
    public void draw(GravityRecipe recipe, IRecipeSlotsView slotsView, GuiGraphics g,
                     double mouseX, double mouseY) {
        // 细边框，让分类看起来像一块独立版面
        g.fill(0, 0, WIDTH, 1, 0xFFC0C0C0);
        g.fill(0, HEIGHT - 1, WIDTH, HEIGHT, 0xFFC0C0C0);
        g.fill(0, 0, 1, HEIGHT, 0xFFC0C0C0);
        g.fill(WIDTH - 1, 0, WIDTH, HEIGHT, 0xFFC0C0C0);

        var font = Minecraft.getInstance().font;

        // 工作方块 → 输入 的小箭头
        g.drawString(font, "\u2192", 22, ROW1_Y + 5, 0xFF606060, false);
        // 中间的"重力反转"示意图（↑↓ 两个箭头，不依赖贴图）
        g.drawString(font, "\u2193\u2191", FLIP_ICON_X, FLIP_ICON_Y, 0xFF404040, false);

        if (recipe.landing()) {
            int textY = ROW2_SLOT_Y + 5;
            g.drawString(font, "落在", 3, textY, 0xFF404040, false);
            /* 塞入物是"落点方块**吃进去**的东西"，所以箭头从落点槽指向物品池：
             *   落在 [陶罐] → 塞入 [战利品]
             * 反过来的话（物品 → 容器）读起来像"把容器放进物品里"。 */
            if (recipe.hasInsert()) {
                g.drawString(font, "\u2192", 50, textY, 0xFF606060, false);
                g.drawString(font, "塞入", 57, textY, 0xFF404040, false);
            }
        }

        // 条件说明
        g.drawString(font, recipe.conditionText(), 4, CONDITION_Y, 0xFF404040, false);

        // 补充说明（掉落物形式 / 产物＝落点方块 / 容器满不满 …）
        String note = recipe.noteText();
        if (!note.isEmpty()) {
            g.drawString(font, note, 4, NOTE_Y, 0xFF3060A0, false);
        }
    }
}
