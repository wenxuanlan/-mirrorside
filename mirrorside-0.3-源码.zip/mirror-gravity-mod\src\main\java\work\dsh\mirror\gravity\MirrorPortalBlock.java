package work.dsh.mirror.gravity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Portal;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.portal.DimensionTransition;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * 镜维度 · 传送门方块。
 *
 * <h2>做法：完全照原版地狱门那一套，不自己造轮子</h2>
 * 原版 {@code NetherPortalBlock} 是这样接进游戏传送系统的：
 * <pre>
 *   public class NetherPortalBlock extends Block implements Portal       // ① 实现 Portal 接口
 *   protected void entityInside(...) {
 *       if (entity.canUsePortal(false)) entity.setAsInsidePortal(this, pos);   // ② 告诉实体"你在门里"
 *   }
 *   public int getPortalTransitionTime(level, entity) { ... }            // ③ 站多久才传
 *   public DimensionTransition getPortalDestination(level, entity, pos)  // ④ 传到哪
 * </pre>
 * 之后**全部由原版接管**（{@code Entity#handlePortal} → {@code PortalProcessor}）：
 * <ul>
 *   <li>站在门里累计 {@code portalTime}，离开时每 tick 衰减 4（所以"蹭一下就出来"不会传）</li>
 *   <li>到点后调 {@link #getPortalDestination} 拿到 {@link DimensionTransition}，
 *       再调 {@code entity.changeDimension(...)} —— 加载界面、位置落点、
 *       传送音效、区块票据都在那里面处理好了</li>
 *   <li>传送完自动上"传送门冷却"（玩家 10 tick、其它实体 300 tick，
 *       来自 {@code Entity#getDimensionChangingDelay}）</li>
 * </ul>
 * 我们只需要提供上面那四个东西。这样写出来的门与原版门在
 * 「计时/冷却/音效/跨维度落点」上的行为完全一致，也不需要 mixin。
 *
 * <h2>与地狱门的差异（都是设定要求的）</h2>
 * <ul>
 *   <li><b>不检查框架</b>：点燃后框架可拆。地狱门每次
 *       {@code updateShape} 都会重新验证黑曜石框，一拆就碎。</li>
 *   <li><b>爆炸能炸掉</b>：硬度 -1（同基岩，生存挖不动、创造可破），
 *       但爆炸抗性给 0.5，TNT 一下就没了。地狱门的抗性是 3600000（炸不动）。</li>
 *   <li><b>不产生"迷失"效果</b>：{@code getLocalTransition()} 返回 {@code NONE}，
 *       站在门里不会有地狱门那种屏幕扭曲。</li>
 *   <li><b>落点自管</b>：不用 {@code PortalForcer}（它是地狱门专用，
 *       只会找 NETHER_PORTAL 兴趣点、找不到就盖黑曜石门）。
 *       这里改成"进镜维度时记住来路，回来时落回原处"。</li>
 * </ul>
 */
public class MirrorPortalBlock extends Block implements Portal {

    public MirrorPortalBlock(Properties properties) {
        super(properties);
    }

    /* ------------------------------------------------------------------ */
    /* 目标维度与坐标映射（由 KubeJS 侧推送，见 mirror_config.js）             */
    /* ------------------------------------------------------------------ */
    /* 与分界线、迟滞带一样的约定：**唯一真相在脚本配置里，模组只接收**。
     * 默认值只是"脚本还没推过来"时的兜底，与当前设置一致。 */

    private static volatile ResourceKey<Level> mirrorDim = ResourceKey.create(
        Registries.DIMENSION, ResourceLocation.fromNamespaceAndPath("mirror", "mirror"));

    /* Y 的映射区间：主世界 [-64, 319] ↔ 镜维度境内 [-64, 63]。
     * 为什么不能照搬 Y：主世界 384 格高，而镜维度境内只有 128 格，
     * 照搬会有大量坐标落在镜外（y>63 或 y<-64）——
     * 那里会把玩家切成冒险/旁观模式，等于把人困住。 */
    private static volatile int owMinY = -64;
    private static volatile int owMaxY = 319;
    private static volatile int mirrorMinY = -64;
    private static volatile int mirrorMaxY = 63;

    /** 到达侧是否自动建门。 */
    private static volatile boolean buildArrival = true;

    public static void setTarget(String dimensionId,
                                 double owMin, double owMax,
                                 double mirrorMin, double mirrorMax) {
        ResourceLocation rl = ResourceLocation.tryParse(dimensionId);
        if (rl != null) {
            mirrorDim = ResourceKey.create(Registries.DIMENSION, rl);
        }
        owMinY = (int) Math.round(owMin);
        owMaxY = (int) Math.round(owMax);
        mirrorMinY = (int) Math.round(mirrorMin);
        mirrorMaxY = (int) Math.round(mirrorMax);
        MirrorGravity.LOGGER.info(
            "[镜维度·传送门] 坐标映射：主世界 Y[{}..{}] ↔ 镜维度 Y[{}..{}]，XZ 按 coordinate_scale 缩放",
            owMinY, owMaxY, mirrorMinY, mirrorMaxY);
    }

    public static void setBuildArrival(boolean value) {
        buildArrival = value;
        MirrorGravity.LOGGER.info("[镜维度·传送门] 到达侧自动建门：{}", value ? "开" : "关");
    }

    /** 回读（诊断用：/mirror portal 会显示它）。 */
    public static String targetDescription() {
        return mirrorDim.location()
            + "  Y[" + owMinY + ".." + owMaxY + "]→[" + mirrorMinY + ".." + mirrorMaxY + "]"
            + "  自动建门=" + (buildArrival ? "开" : "关");
    }

    /* ------------------------------------------------------------------ */
    /* Y 映射                                                              */
    /* ------------------------------------------------------------------ */

    /** 主世界 Y → 镜维度境内 Y（线性压到 [mirrorMinY, mirrorMaxY]）。 */
    static double mapYToMirror(double owY) {
        double span = Math.max(1, owMaxY - owMinY);
        double t = Mth.clamp((owY - owMinY) / span, 0.0D, 1.0D);
        return mirrorMinY + t * (mirrorMaxY - mirrorMinY);
    }

    /** 镜维度 Y → 主世界 Y（上式的逆）。 */
    static double mapYToOverworld(double mirrorY) {
        double span = Math.max(1, mirrorMaxY - mirrorMinY);
        double t = Mth.clamp((mirrorY - mirrorMinY) / span, 0.0D, 1.0D);
        return owMinY + t * (owMaxY - owMinY);
    }

    /* ------------------------------------------------------------------ */
    /* ① 站在门里 → 交给原版的传送计时                                       */
    /* ------------------------------------------------------------------ */

    @Override
    protected void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (entity.canUsePortal(false)) {
            entity.setAsInsidePortal(this, pos);
        }
    }

    /* ------------------------------------------------------------------ */
    /* ③ 站多久才传                                                        */
    /* ------------------------------------------------------------------ */

    @Override
    public int getPortalTransitionTime(ServerLevel level, Entity entity) {
        return MirrorPortalShape.transitionTime(level, entity);
    }

    /* ------------------------------------------------------------------ */
    /* ④ 传到哪                                                            */
    /* ------------------------------------------------------------------ */

    @Nullable
    @Override
    public DimensionTransition getPortalDestination(ServerLevel from, Entity entity, BlockPos pos) {
        boolean fromMirror = from.dimension().equals(mirrorDim);
        ServerLevel target = from.getServer().getLevel(fromMirror ? Level.OVERWORLD : mirrorDim);
        if (target == null) {
            return null;
        }

        /* 传送后要做的事。
         *
         * ⚠️ **不要用原版的 PLAY_PORTAL_SOUND** —— 它给玩家发的是 1032 号
         * 关卡事件，客户端放的是**地狱门那条 travel 音效**，
         * 与我们这条提示音完全是两回事（用户实测反馈："来回传送响的是
         * 地狱门的声音"）。
         *
         * 换成我们自己注册的 MirrorBlocks.MIRROR_ENTER，两个方向都播：
         *   · 目标是主世界 → 在这里（post-transition）播；
         *   · 目标是镜维度 → 不在这里播，交给
         *     {@link MirrorGravity#onPlayerChangedDimension} 统一处理 ——
         *     那条监听"玩家进入镜维度"这个事件，所以**用指令、用
         *     /execute in 进去也一样有声音**，不必在这个类里特判一次。
         *     （两处都播就会响两遍，所以这里必须排除。）
         *
         * PLACE_PORTAL_TICKET 两边都要保留：它保证目的地那一块是加载的。 */
        DimensionTransition.PostDimensionTransition post = fromMirror
            ? (e -> {
                DimensionTransition.PLACE_PORTAL_TICKET.onTransition(e);
                playCueAt(e);
            })
            : DimensionTransition.PLACE_PORTAL_TICKET;

        /* X/Z 缩放：**用原版自己的机制**。
         * DimensionType.getTeleportationScale 返回"源维度 scale / 目标维度 scale"，
         * 地狱门 1:8 就是靠它（下界 dimension_type 的 coordinate_scale = 8）。
         * 镜维度的 coordinate_scale 设成 16 → 镜维度 1 格 = 主世界 16 格。 */
        double scale = net.minecraft.world.level.dimension.DimensionType
            .getTeleportationScale(from.dimensionType(), target.dimensionType());

        double sy = fromMirror ? mapYToOverworld(entity.getY()) : mapYToMirror(entity.getY());
        BlockPos scaled = BlockPos.containing(entity.getX() * scale, sy, entity.getZ() * scale);

        /* ------------------------------------------------------------------
         * ★ 与原版对齐的关键一步：**先找目标维度里已有的门**，再考虑新建。
         * ------------------------------------------------------------------
         * 原版地狱门就是这么做的（PortalForcer#findClosestPortalPosition）：
         * 按缩放后的坐标做 POI 搜索，找到就用**那扇门自己的位置**当落点。
         *
         * 早先这里漏了这一步，直接拿映射坐标当落点，于是回程必然对不上：
         *   · X/Z 靠 entity × scale 反算 —— 玩家站在方块中心（62.5），
         *     乘 16 本该正好回到 1000，可我当时又画蛇添足加了半格单元（+8）；
         *   · Y 靠映射反算 —— 而映射有取整误差，加上建门时为了避让玻璃层
         *     还会挪几格，两者一叠加就能偏出 5 格以上。
         * 用"找到的那扇门"当落点，这些误差全部消失：
         * 门在哪，人就落在哪。
         *
         * 半径沿用原版的思路：目标维度越"稀疏"搜得越远 ——
         * 目标是主世界时 128 格，目标是镜维度（1:16，密）时 16 格。 */
        BlockPos found = findNearestPortal(target, scaled, !fromMirror);

        /* POI 查不到时的兜底：直接扫方块。
         *
         * 为什么还需要这一层：POI 记录是"方块被放下那一刻"写进去的
         * （ServerLevel#onBlockStateChange → PoiManager#add），
         * 而 POI 段的 Valid 标记一旦为真，加载区块时也不会重建
         * （PoiSection#refresh 只在 !isValid 时跑）。
         * 所以**本次更新之前就存在的传送门在 POI 表里没有记录** ——
         * 光靠 POI 搜索会漏掉它，玩家会看到"回程又新建了一座门"。
         * 范围给 ±16 格（XZ）与 ±12 格（Y），足够盖住缩放取整
         * 与高度映射带来的误差；只在 POI 失败时才跑。 */
        if (found == null) {
            found = scanForPortal(target, scaled, 16, 12);
        }

        BlockPos arrival;
        if (found != null) {
            arrival = found;
            MirrorGravity.LOGGER.debug("[镜维度·传送门] 目标侧已有门 {}，直接用", found);
        } else if (buildArrival) {
            arrival = MirrorPortalShape.buildPortal(target, scaled);
        } else {
            arrival = scaled;
        }

        /* 落点：门方块的**中心**、脚底与门同高 —— 与原版一致，
         * 把人放在门里而不是门顶上。
         *
         * 为什么这次改回"放在门里"：门方块不碰撞，中间层周围 8 格是空气，
         * 玩家可以直接从任意一侧走出去；而放在门顶上的话，顶面是实心石英，
         * 反而进不去门 —— 那就等于把回去的路堵死了。
         *
         * 代价与原版相同：落地后有传送冷却（玩家 10 tick），
         * 站着不动约 4 秒会被送回去 —— 走开一步即可。 */
        Vec3 spawn = new Vec3(arrival.getX() + 0.5D, arrival.getY(), arrival.getZ() + 0.5D);
        return new DimensionTransition(target, spawn, Vec3.ZERO,
            entity.getYRot(), entity.getXRot(), post);
    }

    /**
     * 在实体当前位置播一次"穿过镜面"的提示音。
     *
     * <p>用的是模组自己注册的 {@link MirrorBlocks#MIRROR_ENTER}，
     * 也就是那条烘焙好、响度对齐过（-21.6 LUFS）的黑白钟声。
     * 音量给 1.0 —— 客户端会把最终增益夹到 1.0，给更大也不会更响，
     * 而音频文件本身已经标定好了。
     *
     * <p>声道用 {@code AMBIENT}（原版地狱门也是用 ambient 播的那条），
     * 这样"环境"滑块能一起调。
     *
     * <p>两处调用：传送门回主世界的落地后处理，以及
     * {@link MirrorGravity#onPlayerChangedDimension}（任何方式进入镜维度）。
     */
    public static void playCueAt(Entity entity) {
        try {
            if (entity.level() instanceof ServerLevel level) {
                level.playSound(null, entity.getX(), entity.getY(), entity.getZ(),
                    MirrorBlocks.MIRROR_ENTER.get(),
                    net.minecraft.sounds.SoundSource.AMBIENT, 1.0F, 1.0F);
            }
        } catch (Throwable t) {
            MirrorGravity.LOGGER.debug("[镜维度·传送门] 播放提示音失败: {}", t.toString());
        }
    }

    /** 镜维度的维度键（供"玩家进入镜维度"这类判断复用）。 */
    public static ResourceKey<Level> mirrorDimension() {
        return mirrorDim;
    }

    /**
     * POI 搜索失败时的兜底：在目标点附近按方块扫描找我们的门。
     *
     * <p>只在 POI 查不到时调用，属于兜底路径 —— 它的存在是因为
     * POI 记录不会为"本次更新之前就已存在的门"补建（见调用处注释）。
     *
     * @param rXZ 水平半径（格）
     * @param rY  竖直半径（格）
     */
    @Nullable
    private static BlockPos scanForPortal(ServerLevel level, BlockPos around, int rXZ, int rY) {
        try {
            BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
            BlockPos best = null;
            double bestDist = Double.MAX_VALUE;

            int minY = Math.max(level.getMinBuildHeight(), around.getY() - rY);
            int maxY = Math.min(level.getMaxBuildHeight() - 1, around.getY() + rY);
            int cx0 = (around.getX() - rXZ) >> 4;
            int cx1 = (around.getX() + rXZ) >> 4;
            int cz0 = (around.getZ() - rXZ) >> 4;
            int cz1 = (around.getZ() + rXZ) >> 4;

            for (int cx = cx0; cx <= cx1; cx++) {
                for (int cz = cz0; cz <= cz1; cz++) {
                    /* 按区块拿一次，再在区块内读方块 —— 比逐格 getBlockState
                     * 少掉几万次区块查找。区块没加载时这一步会把它加载出来
                     * （传送本来就会加载目标区块，客户端此时也在加载界面）。 */
                    net.minecraft.world.level.chunk.LevelChunk chunk = level.getChunk(cx, cz);
                    int fromX = Math.max(around.getX() - rXZ, cx << 4);
                    int toX = Math.min(around.getX() + rXZ, (cx << 4) + 15);
                    int fromZ = Math.max(around.getZ() - rXZ, cz << 4);
                    int toZ = Math.min(around.getZ() + rXZ, (cz << 4) + 15);
                    for (int x = fromX; x <= toX; x++) {
                        for (int z = fromZ; z <= toZ; z++) {
                            for (int y = minY; y <= maxY; y++) {
                                cursor.set(x, y, z);
                                if (!chunk.getBlockState(cursor).is(MirrorBlocks.MIRROR_PORTAL.get())) {
                                    continue;
                                }
                                double d = cursor.distSqr(around);
                                if (d < bestDist) {
                                    bestDist = d;
                                    best = cursor.immutable();
                                }
                            }
                        }
                    }
                }
            }
            if (best != null) {
                MirrorGravity.LOGGER.info("[镜维度·传送门] POI 未命中，扫描到了已有门 {}", best);
            }
            return best;
        } catch (Throwable t) {
            MirrorGravity.LOGGER.warn("[镜维度·传送门] 扫描已有门失败: {}", t.toString());
            return null;
        }
    }

    /**
     * 在目标维度里找离 {@code around} 最近的镜面传送门（原版那套 POI 搜索）。
     *
     * @param destinationIsOverworld 目标是主世界时用更大的搜索半径（同原版：
     *                               目标是下界 16、目标是主世界 128）
     * @return 找到的门坐标；没找到返回 null
     */
    @Nullable
    private static BlockPos findNearestPortal(ServerLevel level, BlockPos around,
                                              boolean destinationIsOverworld) {
        try {
            int radius = destinationIsOverworld ? 128 : 16;
            net.minecraft.world.entity.ai.village.poi.PoiManager poi = level.getPoiManager();
            /* 先把搜索区加载出来 —— 否则未加载区块里的门查不到。
             * 原版 findClosestPortalPosition 第一步也是这个。 */
            poi.ensureLoadedAndValid(level, around, radius);
            return poi.getInSquare(
                    h -> h.value() == MirrorBlocks.MIRROR_PORTAL_POI.get(),
                    around, radius,
                    net.minecraft.world.entity.ai.village.poi.PoiManager.Occupancy.ANY)
                .map(net.minecraft.world.entity.ai.village.poi.PoiRecord::getPos)
                .min(java.util.Comparator.comparingDouble(p -> p.distSqr(around)))
                .orElse(null);
        } catch (Throwable t) {
            /* 查不到就当没有 —— 后面会退化成"新建一座"，不至于传送失败。 */
            MirrorGravity.LOGGER.warn("[镜维度·传送门] 查找已有门失败（将新建）: {}", t.toString());
            return null;
        }
    }

    /* ------------------------------------------------------------------ */
    /* 站在门里时客户端的表现                                               */
    /* ------------------------------------------------------------------ */

    /** 不做地狱门那种屏幕扭曲（{@code CONFUSION}）。 */
    @Override
    public Portal.Transition getLocalTransition() {
        return Portal.Transition.NONE;
    }

    /**
     * 客户端粒子：黑白流光之外再撒一点白点，让门"在呼吸"。
     *
     * <p>只在客户端调用（{@code Block#animateTick} 本来就是客户端专用口），
     * 用原版 {@code END_ROD} 粒子 —— 白色、无重力、会缓慢上飘，与
     * 黑白流光的贴图是同一路观感。
     */
    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(4) != 0) {
            return;
        }
        double x = pos.getX() + random.nextDouble();
        double y = pos.getY() + random.nextDouble();
        double z = pos.getZ() + random.nextDouble();
        level.addParticle(ParticleTypes.END_ROD, x, y, z,
            (random.nextDouble() - 0.5D) * 0.02D,
            (random.nextDouble() - 0.5D) * 0.02D,
            (random.nextDouble() - 0.5D) * 0.02D);
    }
}
