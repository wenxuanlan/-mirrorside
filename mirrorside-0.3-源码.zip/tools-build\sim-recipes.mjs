/**
 * 在 Node 里**真的跑一遍** mirror_n3_recipes.js —— 不启动游戏，直接驱动配方引擎。
 *
 * ── 为什么要造这个 ────────────────────────────────────────────────
 * "某个配方不生效"这类问题，前两轮都是靠读代码 + 猜摆法，结果连续猜错两次。
 * 读代码只能证明"我以为的那条路径没问题"，而 bug 恰恰在"我以为"之外。
 *
 * 这套模拟器把引擎真正执行起来：给 n3 喂一份假的 Minecraft 世界与实体，
 * 然后问它"这个位置、这个方向、这个切换次数，你匹配到哪条配方"。
 * 于是"引擎有没有 bug"和"摆法对不对"这两件事就被彻底分开了。
 *
 * ── 它模拟了什么 / 没模拟什么 ───────────────────────────────────
 * 模拟：配方匹配、计数（flip 模式）、探针几何、applyRecipe 的产物解析
 * 不模拟：真实物理（模组 BlockPhysics）、渲染、原版的掉落前置条件
 *        —— 位置与重力方向由调用方直接摆，正是为了把它们**排除掉**
 *
 * 用法: node tools-build/sim-recipes.mjs
 */
import { readFileSync } from 'node:fs';

const INST = 'D:/DSHwork/MC镜维度/.minecraft/versions/镜维度';
const CONFIG = `${INST}/kubejs/startup_scripts/mirror_config.js`;
const N3 = `${INST}/kubejs/server_scripts/mirror_n3_recipes.js`;

/* ---------------- 1) 真配置 ---------------- */
const cfgSrc = readFileSync(CONFIG, 'utf8').replace(/^\s*global\.MIRROR_CONFIG\s*=\s*MIRROR_CONFIG\s*;?\s*$/m, '');
const cfg = new Function(cfgSrc + '\n; return MIRROR_CONFIG;')();

/* ---------------- 2) 假世界 ---------------- */
const AIR = 'minecraft:air';

function makeState(id) {
  const block = { __id: id };
  return {
    __id: id,
    getBlock: () => block,
    isAir: () => id === AIR,
    is: (other) => id === (other && other.__id),
  };
}

/** 世界：'x,y,z' -> 方块 ID */
class World {
  constructor() { this.map = new Map(); }
  set(x, y, z, id) { this.map.set(`${x},${y},${z}`, id); return this; }
  at(x, y, z) { return this.map.get(`${x},${y},${z}`) ?? AIR; }
}

/**
 * 一个世界**只有一个** level 对象 —— 同一世界里的所有实体共享它。
 * ⚠️ 这一点很关键：引擎判断"上一个实体还在不在"用的是
 * `level.getEntity(id)`，如果每个实体各自一个 level，
 * 就永远查不到别的实体，判定必然错（这次就踩到了）。
 */
function levelOf(world) {
  if (world.__level == null) world.__level = makeLevel(world);
  return world.__level;
}

function makeLevel(world) {
  return {
    __world: world,
    /** applyRecipe 若走了"放方块"这条路，这里会记下来 ——
     *  用来断言 drop:true 的配方**绝不放方块**。 */
    placed: [],
    /** 世界里"活着"的实体（按 id）—— 引擎用它判断上一个实体还在不在
     *  （见 n3 的 entityStillAlive）。模拟器必须实现这一条，
     *  否则引擎会退回时间窗兜底，测的就不是线上那条分支了。 */
    live: new Map(),
    getBlockState(pos) { return makeState(world.at(pos.getX(), pos.getY(), pos.getZ())); },
    setBlockAndUpdate(pos, state) {
      this.placed.push({ y: pos.getY(), id: state && state.__id });
      return true;
    },
    getEntity(id) { return this.live.get(id) ?? null; },
  };
}

const entries = new Map();   // id -> 产物记录（applyRecipe 时填）

function makeEntity(world, id, stateId) {
  const e = {
    __dir: 'down',
    __id: id,
    __state: stateId,
    x: 0.5, y: 0, z: 0.5,
    level: levelOf(world),
    getId: () => id,
    getX() { return this.x; },
    getY() { return this.y; },
    getZ() { return this.z; },
    getBbHeight: () => 0.98,
    getBlockState: () => makeState(e.__state),
    discard() {
      e.__discarded = true;
      e.level.live.delete(id);      // 实体消失 → 世界里查不到它了
    },
  };
  e.level.live.set(id, e);
  return e;
}

/* ---------------- 3) 假 KubeJS / 模组 API ---------------- */
function makeBlockPos() {
  return {
    containing: (x, y, z) => ({
      getX: () => Math.floor(x),
      getY: () => Math.floor(y),
      getZ: () => Math.floor(z),
    }),
  };
}

function makeBuiltInRegistries() {
  return {
    BLOCK: {
      get: (rl) => ({
        __id: rl && rl.__rl,
        defaultBlockState() { return makeState(rl && rl.__rl); },
      }),
    },
  };
}

const MG_API = {
  blockStateHasTag: (state, tag) => {
    const t = String(tag);
    if (t === '#minecraft:leaves') return String(state.__id).endsWith('_leaves');
    return false;
  },
  /* 模组侧的"具体 ID"判定：与标签那条一样是纯 Java 调用。
   * 模拟器必须实现它，否则脚本会退回字符串比较那条老路，
   * 测的就不是线上真正跑的分支了。 */
  blockStateHasId: (state, want) => String(state.__id) === String(want),
  blockIdExists: () => true,
  currentDirection: (entity) => entity.__dir,
  canInsertIntoContainer: () => false,
  tryInsertIntoContainer: () => false,
  // 记录掉落物产物，而不是真的生成实体
  dropItem: (level, x, y, z, itemId, count) => {
    entries.set(itemId, { itemId, count, x, y, z });
    return true;
  },
};

const checks = [];
function check(name, ok, detail) {
  checks.push({ name, ok, detail });
  console.log(`  ${ok ? '✓' : '✗'} ${name}${detail ? '   ' + detail : ''}`);
}

/* ---------------- 4) 真 n3 源码 ---------------- */
const n3Src = readFileSync(N3, 'utf8');

function loadEngine() {
  const n1 = {
    ready: true,
    recipeState: {}, lastFlipDir: {}, swingRange: {},
    now: () => tick,
    forget(key) {
      delete n1.recipeState[key];
      delete n1.lastFlipDir[key];
        delete n1.swingRange[key];
    },
  };
  const n0 = {
    ready: true,
    cfg,
    selfModApi: MG_API,
    fallingSplit: -1.0,
    splitY: 0,
    entityKey: (e) => String(e.getId()),
    tryLoadClass(name) {
      if (name === 'net.minecraft.core.BlockPos') return makeBlockPos();
      if (name === 'net.minecraft.core.registries.BuiltInRegistries') return makeBuiltInRegistries();
      return null;
    },
    blockIdOf: (obj) => {
      if (obj == null) return null;
      if (obj.__id != null) return obj.__id;
      try { const b = obj.getBlock(); return b ? b.__id : null; } catch { return null; }
    },
    isFallingBlock: () => true,
    moduleRef: () => null,
  };
  const MD = {
    modules: { n0, n1 },
    id: (v) => ({ __rl: String(v) }),
    pondus: { available: false },
  };
  const fakeGlobal = { MirrorDimension: MD };
  /* 捕获引擎的日志行：sticky / 命中 / 报错都要能看见 —— 否则测试失败时
   * 只能看到「没命中」，看不出引擎走到了哪一步。 */
  const logLines = [];
  const fakeConsole = {
    info: (...a) => logLines.push(String(a.join(' '))),
    warn: (...a) => logLines.push('[warn] ' + a.join(' ')),
    error: (...a) => logLines.push('[err] ' + a.join(' ')),
    log() {},
  };
  /* BlockEvents 的最小 mock。引擎已不再注册 placed 处理器（"按竖列计数"
   * 那套连同它一起删掉了），但保留 mock：脚本若哪天再用到，
   * 引擎在加载期就会抛 ReferenceError。 */
  const blockHandlers = {};
  const fakeBlockEvents = {
    placed(fn) { blockHandlers.placed = fn; },
    rightClicked(fn) { blockHandlers.rightClicked = fn; },
  };
  const factory = new Function('global', 'console', 'BlockEvents',
    n3Src + '\n; return MirrorRecipes;');
  const api = factory(fakeGlobal, fakeConsole, fakeBlockEvents);

  /** 模拟"玩家放下某个方块"（触发引擎注册的 placed 处理器）。 */
  function firePlaced(blockId, x, z) {
    const fn = blockHandlers.placed;
    if (fn == null) return false;
    fn({
      getBlock: () => ({
        getBlockState: () => makeState(blockId),
        getX: () => x,
        getY: () => 0,
        getZ: () => z,
      }),
    });
    return true;
  }

  return { api, n1, firePlaced, logLines };
}

/* ---------------- 5) 场景 ---------------- */

console.log('=== 配方引擎模拟（真跑 mirror_n3_recipes.js）===\n');
/* mock 时钟：引擎的「重生交接窗口」按 tick 判定，模拟器要能推它。 */
let tick = 0;
const { api, n1, firePlaced, logLines } = loadEngine();
if (!api || !api.ready) { console.error('引擎未就绪'); process.exit(1); }
console.log(`配方总数: ${api.count()}\n`);

/* 计数键**直接问引擎**（api.keyOf），不在模拟器里复刻一份 ——
 * 复刻的副本会随引擎改动而漂移，这次就正好撞上过一次。 */

/** 把引擎的计数状态清空（原地清，不能重新赋值 —— 引擎持有的是同一对象）。 */
function resetCounts() {
  tick += 1000;          // 时钟留个余量（引擎的重生判定已与时间无关）
  for (const t of [n1.recipeState, n1.lastFlipDir, n1.swingRange]) {
    for (const k of Object.keys(t)) delete t[k];
  }
}

/** 驱动一次方向切换，把 crossings 攒到目标值。 */
function flipsTo(entity, want) {
  // 先给一个基线，再逐个切换
  entity.__dir = entity.__dir === 'up' ? 'down' : 'up';
  api.process(entity);
  let guard = 0;
  while (true) {
    const st = n1.recipeState[api.keyOf(entity)];
    const n = st ? st.crossings : 0;
    if (n >= want || guard++ > 40) break;
    entity.__dir = entity.__dir === 'up' ? 'down' : 'up';
    api.process(entity);
  }
  const st = n1.recipeState[api.keyOf(entity)];
  return st ? st.crossings : 0;
}

resetCounts();
console.log('--- 场景 A：脚手架 + 树叶落点（探针能不能看到它）---');
for (const [label, y, dir, want] of [
  ['贴在下方（天花板上），方向 up，4 次', 2.02, 'up', 4],
  ['贴在上方（地板上），方向 down，4 次', 4.0, 'down', 4],
  ['距离 1.5 格（不接触）', 1.5, 'up', 4],
]) {
  const world = new World();
  world.set(0, 3, 0, 'minecraft:oak_leaves');
  const e = makeEntity(world, 101, 'minecraft:scaffolding');
  e.y = y;
  e.__dir = dir;
  entries.clear();
  let crossings = flipsTo(e, want);
  // 攒够次数后再摆到目标位置判一次
  e.y = y;
  const hit = api.process(e);
  console.log(`  ${label}: y=${y} 切换=${crossings} → ${hit ? hit.recipe.id : '没有匹配'}`);
  void e;
}

resetCounts();
console.log('\n--- 场景 B：把脚手架从下往上逐格扫一遍（3 格天花板）---');
{
  const world = new World();
  world.set(0, 3, 0, 'minecraft:oak_leaves');
  const matchedAt = [];
  for (let y = 0.0; y <= 4.0; y = Math.round((y + 0.1) * 10) / 10) {
    const e = makeEntity(world, 200 + Math.round(y * 10), 'minecraft:scaffolding');
    e.y = y;
    const c = flipsTo(e, 4);
    e.y = y;
    const hit = api.process(e);
    if (hit) matchedAt.push(`${y}→${hit.recipe.id}(切换${c})`);
  }
  console.log('  匹配到的 y：' + (matchedAt.length ? matchedAt.join('  ') : '（一个都没有）'));
}

resetCounts();
console.log('\n--- 场景 C：同样的扫描，落点换成树叶（对照组）---');
{
  const world = new World();
  world.set(0, 3, 0, 'minecraft:oak_leaves');
  const matchedAt = [];
  for (let y = 0.0; y <= 4.0; y = Math.round((y + 0.1) * 10) / 10) {
    const e = makeEntity(world, 300 + Math.round(y * 10), 'minecraft:scaffolding');
    e.y = y;
    const c = flipsTo(e, 4);
    e.y = y;
    const hit = api.process(e);
    if (hit) matchedAt.push(`${y}→${hit.recipe.id}(切换${c})`);
  }
  console.log('  匹配到的 y：' + (matchedAt.length ? matchedAt.join('  ') : '（一个都没有）'));
}

resetCounts();
console.log('\n--- 场景 D：次数没到 4 时会怎样 ---');
{
  const world = new World();
  world.set(0, 3, 0, 'minecraft:oak_leaves');
  const e = makeEntity(world, 400, 'minecraft:scaffolding');
  e.y = 2.02;
  e.__dir = 'up';
  const c = flipsTo(e, 3);
  e.y = 2.02;
  const hit = api.process(e);
  console.log(`  切换=${c}（要求 4）→ ${hit ? hit.recipe.id : '没有匹配（符合预期）'}`);
}

resetCounts();
console.log('\n--- 场景 E：切换 8 次时 crossing 会不会抢在 landing 前面 ---');
{
  const world = new World();
  world.set(0, 3, 0, 'minecraft:oak_leaves');
  const e = makeEntity(world, 500, 'minecraft:scaffolding');
  e.y = 2.02;
  const c = flipsTo(e, 8);
  e.y = 2.02;
  const hit = api.process(e);
  console.log(`  切换=${c} → ${hit ? hit.recipe.id : '没有匹配'}`);
}

resetCounts();
console.log('\n--- 场景 F：applyRecipe 真的执行一遍（脚手架 + 树叶 → 树苗掉落物）---');
{
  /* 用**当前配置**里那条 drop 配方：落点 #minecraft:leaves，产物 @mapped，drop:true。
   * （原先是"灵魂沙 → 地狱疣"，那条已于 2026-09-22 放弃删除，见 README 14.22。） */
  const world = new World();
  world.set(0, 3, 0, 'minecraft:flowering_azalea_leaves');
  const e = makeEntity(world, 600, 'minecraft:scaffolding');
  e.y = 2.02;
  const c = flipsTo(e, 4);
  e.y = 2.02;
  const hit = api.process(e);
  entries.clear();
  const ok = hit ? api.applyRecipe(e, hit) : false;
  console.log(`  切换=${c} 命中=${hit ? hit.recipe.id : '无'} applyRecipe=${ok}`);
  console.log(`  掉落物产物: ${entries.size ? JSON.stringify([...entries.values()]) : '（无）'}`);
  console.log(`  被放下的方块: ${e.level.placed.length ? JSON.stringify(e.level.placed) : '（无）'}`);
  console.log(`  实体被移除: ${e.__discarded === true}`);

  check('命中的是 scaffolding_to_sapling',
    hit != null && hit.recipe.id === 'scaffolding_to_sapling');
  check('@mapped 按落点查表得到对应树苗（杜鹃叶 → 杜鹃树苗）',
    entries.has('minecraft:flowering_azalea'),
    [...entries.keys()].join(','));
  check('以**掉落物**形式弹出（dropItem 被调用）', entries.size === 1);
  check('**没有**往世界里放任何方块（drop:true 不放方块）', e.level.placed.length === 0,
    JSON.stringify(e.level.placed));
  check('实体被移除', e.__discarded === true);
}

resetCounts();
console.log('\n--- 场景 G（对照组）：非 drop 配方应当**放方块、不掉落物** ---');
{
  /* 沙子落在黑色玻璃上 → 石英块：普通配方，应当原地放成方块 */
  const world = new World();
  world.set(0, 3, 0, 'minecraft:black_stained_glass');
  const e = makeEntity(world, 700, 'minecraft:sand');
  e.y = 2.02;
  const c = flipsTo(e, 3);
  e.y = 2.02;
  const hit = api.process(e);
  entries.clear();
  const ok = hit ? api.applyRecipe(e, hit) : false;
  console.log(`  切换=${c} 命中=${hit ? hit.recipe.id : '无'} applyRecipe=${ok}`);
  console.log(`  被放下的方块: ${e.level.placed.length ? JSON.stringify(e.level.placed) : '（无）'}`);
  console.log(`  掉落物产物: ${entries.size ? JSON.stringify([...entries.values()]) : '（无）'}`);
  check('普通配方放方块、不掉落物',
    e.level.placed.length === 1 && e.level.placed[0].id === 'minecraft:quartz_block'
    && entries.size === 0,
    JSON.stringify(e.level.placed));
}

resetCounts();
console.log('\n--- 场景 H：落点 ID 的匹配规则（合成配方，与真配置无关）---');
{
  /* 用**合成配方**验证"具体 ID 的匹配"这件事本身。
   * 世界方块刻意选 stone：真配置里脚手架的两条配方（落点 soul_sand、
   * 8 次的蜘蛛网）都不会命中它，于是本场景的结论只反映 ID 匹配逻辑。 */
  const world = new World();
  world.set(0, 3, 0, 'minecraft:stone');
  const e = makeEntity(world, 800, 'minecraft:scaffolding');
  e.y = 2.02;
  const c = flipsTo(e, 4);
  e.y = 2.02;

  /* H-1：落点写 dirt → 世界里是 stone → 不该命中 */
  api.add({
    id: 'sim_wrong_id', input: 'minecraft:scaffolding',
    output: 'minecraft:nether_wart', crossings: 4, trigger: 'landing',
    on: 'minecraft:dirt', drop: true,
  });
  const hitWrong = api.process(e);
  console.log(`  世界=stone，配方要 dirt：${hitWrong ? hitWrong.recipe.id : '没有匹配 ← 符合预期'}`);

  /* H-2：落点写 stone → 应当命中 */
  api.add({
    id: 'sim_right_id', input: 'minecraft:scaffolding',
    output: 'minecraft:nether_wart', crossings: 4, trigger: 'landing',
    on: 'minecraft:stone', drop: true,
  });
  const hitRight = api.process(e);
  console.log(`  世界=stone，配方要 stone：${hitRight ? hitRight.recipe.id : '没有匹配'}`);

  /* H-3：周围全是空气时，攒到 8 次应当被 crossing 接走（蜘蛛网） */
  const airWorld = new World();
  const e2 = makeEntity(airWorld, 801, 'minecraft:scaffolding');
  e2.y = 2.02;
  const c8 = flipsTo(e2, 8);
  e2.y = 2.02;
  const hit8 = api.process(e2);
  console.log(`  周围全是空气、攒到 ${c8} 次切换：${hit8 ? hit8.recipe.id : '没有匹配'}`);

  check('落点 ID 不匹配时不命中', hitWrong == null || hitWrong.recipe.id !== 'sim_wrong_id');
  check('落点 ID 匹配时命中', hitRight != null && hitRight.recipe.id === 'sim_right_id');
  check('没碰到任何落点方块时，8 次由 crossing 接走变成蜘蛛网',
    hit8 != null && hit8.recipe.id === 'scaffolding_to_cobweb');
  void c;
}

resetCounts();
console.log('\n--- 场景 I：同位置、只换落点方块（配方的落点判定）---');
{
  /* 位置/高度/次数全都不变，只换落点方块 —— 直接对比各落点能不能命中。
   * 用的是 mirror_config.js 里**当前**的配方。
   * ⚠️ 每个落点用**各自的竖列**（x 不同）：计数键是实体，但列开一点更好读。 */
  const atY = 2.02;
  let col = 0;
  for (const [label, blockId, want] of [
    ['落点=橡树树叶（→橡树树苗）', 'minecraft:oak_leaves', true],
    ['落点=杜鹃叶（→杜鹃树苗）', 'minecraft:flowering_azalea_leaves', true],
    /* 灵魂沙曾经是"→ 地狱疣"的落点，那条配方 2026-09-22 已放弃删除；
     * 现在它应当**什么也不触发**（配置里没有以它为落点的配方）。 */
    ['落点=灵魂沙（配方已删除，不该命中）', 'minecraft:soul_sand', false],
    ['落点=下界疣块（从来没有过这条，不该命中）', 'minecraft:nether_wart_block', false],
  ]) {
    resetCounts();
    const x = col++ * 32;
    const world = new World();
    world.set(x, 3, 0, blockId);
    const e = makeEntity(world, 900 + blockId.length, 'minecraft:scaffolding');
    e.x = x + 0.5;
    e.y = atY;
    const c = flipsTo(e, 4);
    e.y = atY;
    const hit = api.process(e);
    console.log(`  ${label}（y=${atY}）: 切换=${c} → ${hit ? hit.recipe.id : '没有匹配'}`);
    check('同一位置 ' + label, want ? hit != null : hit == null);
  }
}
resetCounts();
console.log('\n--- 场景 J：★ 同一竖列里的两个脚手架必须**各算各的**（真实事故的回归）---');
{
  /* 事故（2026-09-22 15:22）：脚手架一度改成"按竖列"计数，于是同一列里的
   * 多个脚手架**共用一个计数器**，连"上一次方向"也共用 —— 两个实体方向相反，
   * 脚本每处理一个就与另一个留下的方向不同，**每 tick 记一次假翻转**：
   *     15:22:28.274  已切换 4 次 … y=14.1   方向=down
   *     15:22:28.323  已切换 5 次 … y=-1.99  方向=up    ← 49ms，y 差 16 格
   *     15:22:28.338  已切换 6 次 … y=13.64  方向=down
   *     15:22:28.373  已切换 8 次 → 蜘蛛网
   * 0→8 只用 1 秒 ⇒ 用户看到"第二个脚手架又变蜘蛛网"，而下界疣那条永远抢不到 4 次。
   *
   * 现在计数键 = 实体 id：两个脚手架各有一份计数与方向状态，互不影响。
   */
  const x = 96;
  const world = new World();
  world.set(x, 30, 0, 'minecraft:soul_sand');   // 远一点，避免干扰计数

  const a = makeEntity(world, 201, 'minecraft:scaffolding');
  a.x = x + 0.5; a.y = 2.02;
  const ca = flipsTo(a, 4);
  const keyA = api.keyOf(a);
  const countA = n1.recipeState[keyA]?.crossings ?? 0;

  /* 同一竖列、同一时刻的第二个脚手架：方向与 A **故意相反** */
  const b = makeEntity(world, 202, 'minecraft:scaffolding');
  b.x = x + 0.5; b.y = 8.02;
  b.__dir = a.__dir === 'up' ? 'down' : 'up';
  api.process(b);
  const keyB = api.keyOf(b);
  const countB = n1.recipeState[keyB]?.crossings ?? 0;

  console.log(`  第一个：切换 ${ca} 次，键=${keyA}，计数 ${countA}`);
  console.log(`  第二个（同列、方向相反）：键=${keyB}，计数 ${countB}`);
  check('两个脚手架拿到**不同**的计数键', keyA !== keyB, `${keyA} / ${keyB}`);
  check('第一个攒到 4 次', countA === 4, String(countA));
  check('第二个**不继承**第一个的进度（计数仍为 0）', countB === 0, String(countB));

  /* 关键：让第二个反复处理，看会不会因为"与另一个方向不同"被记假翻转 */
  let spurious = 0;
  for (let i = 0; i < 6; i++) {
    const before = n1.recipeState[keyB]?.crossings ?? 0;
    api.process(b);                                  // 方向不变
    const after = n1.recipeState[keyB]?.crossings ?? 0;
    if (after !== before) spurious++;
  }
  console.log(`  第二个方向不变地跑 6 tick：假翻转 ${spurious} 次（应为 0）`);
  check('方向不变时不会记假翻转（旧版按竖列时会每 tick 记一次）', spurious === 0,
    String(spurious));
  check('第一个的计数不受第二个影响',
    (n1.recipeState[keyA]?.crossings ?? 0) === 4,
    String(n1.recipeState[keyA]?.crossings ?? 0));
}

/* ---------------- 场景 L：真实事故复现（落点摆到了隔壁列） ---------------- */
resetCounts();
console.log('\n--- 场景 L：★ 灵魂沙摆在"隔壁一列"（2026-09-22 真实事故，读存档量出来的）---');
{
  /* 事故现场（存档实测）：
   *   下落实体在 (-34.5, …, 4.5) → 它那一列 = x=-35, z=4
   *   用户摆的 5 格灵魂沙：(-35,-4,2) (-34,-4,2) (-35,-4,3) (-34,-4,3) (-34,-4,4)
   *                        ← **一格都没在这一列里**
   *   而实体那一列 y=-4 摆的是树叶（所以树叶那条配方每次都触发）
   * 探针只扫实体自己那一列 ⇒ 永远碰不到，现象与"配方坏了"一模一样。 */
  const world = new World();
  const e = makeEntity(world, 900, 'minecraft:scaffolding');
  e.x = -34.5; e.y = -1.11; e.z = 4.5;
  world.set(-35, -4, 4, 'minecraft:flowering_azalea_leaves');
  for (const [x, z] of [[-35, 2], [-34, 2], [-35, 3], [-34, 3], [-34, 4]]) {
    world.set(x, -4, z, 'minecraft:soul_sand');
  }

  const rep = api.probeColumn(e, -6, 18, ['minecraft:soul_sand']);
  const colTxt = rep.column.map((c) => `y=${c.y}=${c.id}`).join('、') || '（空）';
  console.log(`  实体那一列 (${rep.x}, ${rep.z}) 实际有: ${colTxt}`);
  console.log('  3×3 邻域里找到的灵魂沙: ' + rep.nearby
    .map((n) => `(${n.x},${n.y},${n.z}) 差 dx=${n.dx} dz=${n.dz}`).join('；'));
  console.log('  日志里那一句:');
  console.log('    ' + api.columnReportText(rep, ['minecraft:soul_sand']));

  check('竖列坐标解析正确（-34.5,4.5 → x=-35, z=4）',
    rep.x === -35 && rep.z === 4, `${rep.x},${rep.z}`);
  check('这一列里确实没有灵魂沙（只有树叶）',
    !rep.column.some((c) => c.id === 'minecraft:soul_sand'),
    colTxt);
  check('邻域里能揪出"就在隔壁"的 3 格灵魂沙', rep.nearby.length === 3,
    String(rep.nearby.length));
  check('每一格都在 3×3 邻域内（对角也算）',
    rep.nearby.every((n) => Math.abs(n.dx) <= 1 && Math.abs(n.dz) <= 1
      && (n.dx !== 0 || n.dz !== 0)),
    rep.nearby.map((n) => `${n.dx},${n.dz}`).join(' '));
  check('至少有一格是"只差一格"的正交邻居（最该被提示的那种）',
    rep.nearby.some((n) => Math.abs(n.dx) + Math.abs(n.dz) === 1),
    rep.nearby.map((n) => `${n.dx},${n.dz}`).join(' '));
  check('报告文本里写明了"就在隔壁"和补救方法',
    /就在隔壁/.test(api.columnReportText(rep, ['minecraft:soul_sand']))
    && /挪进/.test(api.columnReportText(rep, ['minecraft:soul_sand'])));

  /* 对照：把灵魂沙挪进实体那一列 → 这一列里就有了（配方就能匹配） */
  world.set(-35, -4, 4, 'minecraft:soul_sand');
  const rep2 = api.probeColumn(e, -6, 18, ['minecraft:soul_sand']);
  check('挪进这一列后，列里就有了 y=-4 的灵魂沙',
    rep2.column.some((c) => c.id === 'minecraft:soul_sand' && c.y === -4));
}

console.log('\n--- 引擎采样（诊断表，含新加的「旁边出现过」与「计数键」）---');for (const st of api.diagnostics()) {
  console.log(`  · ${st.id}  处理 ${st.ticks} tick，最高切换 ${st.maxFlips} 次`);
  if (st.lastProbe) console.log(`      ${st.lastProbe}`);
  if (st.lastX != null && st.lastZ != null) {
    console.log(`      落点该摆在哪: x=${st.lastX}, z=${st.lastZ}`
      + (st.recentMinY == null ? '' : `, y=${Math.floor(st.recentMinY) - 1} ~ ${Math.ceil(st.recentMaxY) + 1}`));
  }
  if (st.seen && st.seen.length) {
    console.log(`      旁边出现过: ${st.seen.map((x) => x.id).join('、')}`);
  }
}
{
  /* 这两条断言守的是"仪表本身可信"：脚手架确实见过树叶与灵魂沙，
   * 于是"采样里没有它"就一定能推出"位置/ID 不对"，而不是仪表失灵。 */
  const sc = api.diagnostics().find((d) => d.id === 'minecraft:scaffolding');
  const seenIds = sc && sc.seen ? sc.seen.map((x) => x.id) : [];
  check('「旁边出现过」能列出灵魂沙', seenIds.includes('minecraft:soul_sand'),
    seenIds.join(','));
  check('「旁边出现过」能列出树叶', seenIds.includes('minecraft:oak_leaves'), seenIds.join(','));
  /* ★ 计数键自检。两条真实事故都出在这个"身份键"上：
   *   ① try 块里写 const → Rhino 静默抛错 → 身份键被悄悄换掉；
   *   ② 把脚手架改成"按竖列"记 → 同一列的多个脚手架共用计数与方向状态
   *      → 每 tick 假翻转 → 1 秒冲到 8 次、全变蜘蛛网（场景 J 是它的回归）。
   *   现在**一律按实体 id**：同一竖列的两个实体必须是两个不同的键。
   *   ⚠️ Node 复现不了 Rhino 的 const-in-try，那条归 tools/lint-scripts.mjs。 */
  check('同一竖列的两个脚手架拿到不同的计数键（按实体计，不按竖列）',
    api.keyOf({ getX: () => 5.5, getZ: () => 5.5, getId: () => 701 })
    !== api.keyOf({ getX: () => 5.5, getZ: () => 5.5, getId: () => 702 }));
  /* ★ 落点坐标必须能报出来。下落实体只在竖直方向动 —— 竖列错一格就
   *   永远碰不到，而现象与"配方坏了"完全一样（真实教训：用户摆的灵魂沙
   *   不在下落实体那一列，日志里只能看到"探针一个方块都没见过"）。 */
  check('诊断表给出了下落实体所在的竖列坐标',
    sc != null && Number.isFinite(sc.lastX) && Number.isFinite(sc.lastZ),
    sc ? `x=${sc.lastX} z=${sc.lastZ}` : '(无)');
}

const bad = checks.filter((c) => !c.ok).length;
console.log(`\n断言 ${checks.length} 条，失败 ${bad} 条`);
if (bad > 0) process.exit(1);







