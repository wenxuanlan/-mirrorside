package work.dsh.mirror.gravity.jei;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import work.dsh.mirror.gravity.MirrorGravity;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * 读 {@code /observation_recipes.json}（由 KubeJS 侧的
 * {@code tools/sync-jei-recipes.mjs} 生成，见 src/main/resources）。
 *
 * <h2>为什么读文件而不是在 Java 里算</h2>
 * "什么变成什么"的唯一真相在 {@code mirror_config.js}。模组这边只负责展示，
 * 所以由工具把配置导成 JSON，Java 只解析 —— 与 {@link GravityRecipeData}
 * 同一套路子。这样 JEI 里看到的与游戏里生效的必然一致（同一份数据源）。
 *
 * <h2>容错</h2>
 * 这是展示功能：文件缺失、字段写错、某一项解析失败，都只跳过它并打日志，
 * 绝不让游戏或 JEI 崩掉。
 */
final class ObservationRecipeData {

    private static final String RESOURCE = "/observation_recipes.json";

    private ObservationRecipeData() {
    }

    static List<ObservationRecipe> load() {
        List<ObservationRecipe> out = new ArrayList<>();
        try (InputStream in = ObservationRecipeData.class.getResourceAsStream(RESOURCE)) {
            if (in == null) {
                MirrorGravity.LOGGER.warn(
                    "[镜维度·JEI] 找不到 {}（跑一次 tools/sync-jei-recipes.mjs 并重建模组）", RESOURCE);
                return out;
            }
            JsonElement root = JsonParser.parseReader(
                new InputStreamReader(in, StandardCharsets.UTF_8));
            if (!root.isJsonObject()) {
                MirrorGravity.LOGGER.warn("[镜维度·JEI] {} 的根不是对象", RESOURCE);
                return out;
            }
            JsonElement listEl = root.getAsJsonObject().get("recipes");
            if (listEl == null || !listEl.isJsonArray()) {
                MirrorGravity.LOGGER.warn("[镜维度·JEI] {} 里没有 recipes 数组", RESOURCE);
                return out;
            }
            JsonArray arr = listEl.getAsJsonArray();
            for (JsonElement e : arr) {
                try {
                    if (!e.isJsonObject()) {
                        continue;
                    }
                    JsonObject o = e.getAsJsonObject();
                    List<String> inputs = strings(o, "inputs");
                    List<String> outputs = strings(o, "outputs");
                    if (inputs.isEmpty() || outputs.isEmpty()) {
                        /* 输入或产物空着 = 版面上是个空槽，没有展示价值，
                         * 而且多半意味着导出时出了问题，所以点名记一笔。 */
                        MirrorGravity.LOGGER.debug("[镜维度·JEI] 观测配方 {} 缺输入或产物，已跳过",
                            str(o, "label"));
                        continue;
                    }
                    out.add(new ObservationRecipe(
                        inputs,
                        outputs,
                        strings(o, "below"),
                        bool(o, "belowRequired"),
                        str(o, "label"),
                        str(o, "note")));
                } catch (Throwable one) {
                    MirrorGravity.LOGGER.debug("[镜维度·JEI] 观测配方某一项解析失败，已跳过: {}",
                        one.toString());
                }
            }
        } catch (Throwable t) {
            MirrorGravity.LOGGER.warn("[镜维度·JEI] 读取观测配方失败: {}", t.toString());
        }
        return out;
    }

    private static List<String> strings(JsonObject o, String key) {
        List<String> out = new ArrayList<>();
        JsonElement el = o.get(key);
        if (el == null || !el.isJsonArray()) {
            return out;
        }
        for (JsonElement one : el.getAsJsonArray()) {
            if (one != null && one.isJsonPrimitive()) {
                String s = one.getAsString();
                if (s != null && !s.isBlank()) {
                    out.add(s);
                }
            }
        }
        return out;
    }

    private static String str(JsonObject o, String key) {
        JsonElement el = o.get(key);
        return (el != null && el.isJsonPrimitive()) ? el.getAsString() : null;
    }

    private static boolean bool(JsonObject o, String key) {
        JsonElement el = o.get(key);
        return el != null && el.isJsonPrimitive() && el.getAsBoolean();
    }
}
