/** 把生成器的图案以 ASCII 打出来，用来肉眼确认"黑白流光"长什么样。 */
const TAU = Math.PI * 2;
const FRAMES = 32;
const SIZE = 16;
const ramp = ' .:-=+*#%@';

function lumAlpha(x, ly, f) {
  const u = f / FRAMES;
  const a = Math.sin(TAU * (x / 8 + ly / 8 + u));
  const b = Math.sin(TAU * (x / 8 - ly / 8 - u * 0.7));
  const c = Math.sin(TAU * (x / 4 + u * 1.5));
  const m = (a + b + 0.5 * c) / 2.5;
  const n = (m + 1) / 2;
  const k = Math.min(1, n * 1.22);
  return [Math.round(255 * k * k), Math.round(60 + 195 * Math.min(1, n * 1.3))];
}

for (const f of [0, 8, 16, 24]) {
  console.log('--- 第 ' + f + ' 帧   左=亮度(@最白)  右=透明度(@最实) ---');
  for (let y = 0; y < SIZE; y++) {
    let L = '';
    let A = '';
    for (let x = 0; x < SIZE; x++) {
      const [l, al] = lumAlpha(x, y, f);
      L += ramp[Math.min(9, Math.floor(l / 25.6))];
      A += ramp[Math.min(9, Math.floor(al / 25.6))];
    }
    console.log('  ' + L + '   ' + A);
  }
}
