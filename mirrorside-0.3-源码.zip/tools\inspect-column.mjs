/**
 * 直接读存档：打印某一竖列的方块，或在附近搜索某种方块。
 *
 * 为什么需要它：本项目的规矩是「不启动游戏」，而"配方不生效"最常见的原因就是
 * **世界里那个方块根本不在你以为的位置**。日志里的探针只说"我当时看见了什么"，
 * 而这个工具回答的是"世界里到底有什么" —— 两者一对，摆位问题当场结案。
 *
 * 用法（在实例目录下）：
 *   node tools/inspect-column.mjs --dim mirror --x -35 --z 4
 *   node tools/inspect-column.mjs --dim mirror --x -35 --z 4 --y0 -8 --y1 24
 *   node tools/inspect-column.mjs --dim mirror --x -35 --z 4 --scan soul_sand
 *   node tools/inspect-column.mjs --dim mirror --x -35 --z 4 --scan soul_sand --radius 24
 *
 * --dim 取值：
 *   mirror      → saves/<world>/dimensions/mirror/mirror/region   （镜维度）
 *   overworld   → saves/<world>/region
 *   nether      → saves/<world>/DIM-1/region
 *   其它         → 直接当成 region 目录的相对路径
 *
 * --world 不给时自动取 saves 下**最近修改**的那个世界。
 */
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { inflateSync, gunzipSync } from 'node:zlib';

/* ⚠️ 必须用 fileURLToPath：实例路径里有中文（"镜维度"），
 *    直接读 url.pathname 会拿到百分号编码，fs 找不到目录。 */
const HERE = dirname(fileURLToPath(import.meta.url));
const SAVES = join(HERE, '..', 'saves');

/* ---------------- 参数 ---------------- */
function argOf(name, dflt) {
  const i = process.argv.indexOf('--' + name);
  return i >= 0 && process.argv[i + 1] != null ? process.argv[i + 1] : dflt;
}
const worldArg = argOf('world', null);
const dim = argOf('dim', 'mirror');
const X = Number(argOf('x', '0'));
const Z = Number(argOf('z', '0'));
const Y0 = Number(argOf('y0', '-8'));
const Y1 = Number(argOf('y1', '24'));
const scan = argOf('scan', null);
const radius = Number(argOf('radius', '16'));

function pickWorld() {
  if (worldArg) return join(SAVES, worldArg);
  const dirs = readdirSync(SAVES)
    .map((n) => join(SAVES, n))
    .filter((p) => { try { return statSync(p).isDirectory(); } catch { return false; } })
    .sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs);
  if (dirs.length === 0) throw new Error('saves 下没有世界目录');
  return dirs[0];
}
const WORLD = pickWorld();
function regionDir() {
  if (dim === 'mirror') return join(WORLD, 'dimensions', 'mirror', 'mirror', 'region');
  if (dim === 'overworld') return join(WORLD, 'region');
  if (dim === 'nether') return join(WORLD, 'DIM-1', 'region');
  if (dim === 'end') return join(WORLD, 'DIM1', 'region');
  return join(WORLD, dim);
}

/* ---------------- NBT ---------------- */
class Reader {
  constructor(buf) { this.b = buf; this.i = 0; }
  u1() { return this.b[this.i++]; }
  i1() { const v = this.b.readInt8(this.i); this.i += 1; return v; }
  i2() { const v = this.b.readInt16BE(this.i); this.i += 2; return v; }
  i4() { const v = this.b.readInt32BE(this.i); this.i += 4; return v; }
  i8() { const v = this.b.readBigInt64BE(this.i); this.i += 8; return v; }
  f4() { const v = this.b.readFloatBE(this.i); this.i += 4; return v; }
  f8() { const v = this.b.readDoubleBE(this.i); this.i += 8; return v; }
  str() { const n = this.b.readUInt16BE(this.i); this.i += 2; const s = this.b.toString('utf8', this.i, this.i + n); this.i += n; return s; }
  bytes(n) { const s = this.b.subarray(this.i, this.i + n); this.i += n; return s; }
}

function readPayload(r, type) {
  switch (type) {
    case 1: return r.i1();
    case 2: return r.i2();
    case 3: return r.i4();
    case 4: return r.i8();
    case 5: return r.f4();
    case 6: return r.f8();
    case 7: { const n = r.i4(); return r.bytes(n); }
    case 8: return r.str();
    case 9: {
      const item = r.u1(); const n = r.i4(); const out = [];
      for (let k = 0; k < n; k++) out.push(readPayload(r, item));
      return out;
    }
    case 10: {
      const out = {};
      for (;;) {
        const t = r.u1(); if (t === 0) break;
        const name = r.str();
        out[name] = readPayload(r, t);
      }
      return out;
    }
    case 11: { const n = r.i4(); const out = []; for (let k = 0; k < n; k++) out.push(r.i4()); return out; }
    case 12: { const n = r.i4(); const out = []; for (let k = 0; k < n; k++) out.push(r.i8()); return out; }
    default: throw new Error('未知 NBT 类型 ' + type + ' @' + r.i);
  }
}

function readRegionChunk(regionBuf, chunkX, chunkZ) {
  const lx = ((chunkX % 32) + 32) % 32;
  const lz = ((chunkZ % 32) + 32) % 32;
  const idx = 4 * (lx + lz * 32);
  const off = regionBuf.readUIntBE(idx, 3);
  const cnt = regionBuf.readUInt8(idx + 3);
  if (off === 0 || cnt === 0) return null;
  const start = off * 4096;
  const len = regionBuf.readUInt32BE(start);
  const comp = regionBuf.readUInt8(start + 4);
  const raw = regionBuf.subarray(start + 5, start + 4 + len);
  let data;
  if (comp === 1) data = gunzipSync(raw);
  else if (comp === 2) data = inflateSync(raw);
  else if (comp === 3) data = raw;
  else throw new Error('不支持的压缩类型 ' + comp + '（4=LZ4 需要额外解码）');
  const r = new Reader(data);
  const t = r.u1();
  if (t !== 10) throw new Error('根标签不是 compound');
  r.str();
  return readPayload(r, 10);
}

/* ---------------- 方块取值 ---------------- */
function sectionBlocks(sec) {
  const bs = sec.block_states ?? sec.blockStates;
  if (!bs) return null;
  const palette = (bs.palette ?? []).map((p) => {
    let s = p.Name;
    if (p.Properties) {
      const kv = Object.entries(p.Properties).map(([k, v]) => k + '=' + v).join(',');
      if (kv) s += '[' + kv + ']';
    }
    return s;
  });
  const data = bs.data ?? null;
  const bits = Math.max(4, Math.ceil(Math.log2(Math.max(palette.length, 2))));
  const perLong = Math.floor(64 / bits);
  const mask = (1n << BigInt(bits)) - 1n;
  return {
    palette,
    at(x, y, z) {
      if (data == null) return palette[0] ?? 'minecraft:air';
      const i = (((y & 15) * 16) + (z & 15)) * 16 + (x & 15);
      const li = Math.floor(i / perLong);
      if (li >= data.length) return 'minecraft:air';
      const off = BigInt((i % perLong) * bits);
      const v = Number((BigInt.asUintN(64, data[li]) >> off) & mask);
      return palette[v] ?? 'minecraft:air';
    },
  };
}

function loadChunkColumn(cx, cz) {
  const file = join(regionDir(), `r.${cx >> 5}.${cz >> 5}.mca`);
  if (!existsSync(file)) return { file, chunk: null };
  const buf = readFileSync(file);
  return { file, chunk: readRegionChunk(buf, cx, cz) };
}

function blockAt(chunk, x, y, z) {
  const secs = chunk?.sections ?? [];
  for (const s of secs) {
    const sy = s.Y ?? s.y;
    if (y >= sy * 16 && y < sy * 16 + 16) {
      const b = sectionBlocks(s);
      return b ? b.at(x, y, z) : 'minecraft:air';
    }
  }
  return 'minecraft:air(未生成/无该 section)';
}

/* ---------------- 输出 ---------------- */
console.log(`世界: ${WORLD}`);
console.log(`维度: ${dim}  →  ${regionDir()}`);
const cx = X >> 4; const cz = Z >> 4;
const { file, chunk } = loadChunkColumn(cx, cz);
console.log(`区块: ${cx},${cz}   文件: ${file}`);
if (!chunk) { console.log('（该区块文件不存在或该区块未生成）'); process.exit(0); }
const st = chunk.Status ?? chunk.status;
console.log(`区块状态: ${st}`);

if (scan == null) {
  console.log(`\n竖列 x=${X} z=${Z}  y=${Y0} .. ${Y1}`);
  for (let y = Y1; y >= Y0; y--) {
    const b = blockAt(chunk, X, y, Z);
    const mark = b.includes('air') ? ' ' : '★';
    console.log(`  ${mark} y=${String(y).padStart(4)}  ${b}`);
  }
} else if (scan === 'MAP') {
  /* 俯视图：把一块区域按 y 切片打成字符地图。
   * 字符表按"第一次遇到"顺序分配，图例列在下面 —— 不预设方块表，
   * 这样任何方块（含模组的）都能画出来。 */
  const legend = new Map();
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&*+=?';
  const grid = new Map();
  const cache = new Map();
  const getChunk = (x, z) => {
    const k = (x >> 4) + ',' + (z >> 4);
    if (!cache.has(k)) cache.set(k, loadChunkColumn(x >> 4, z >> 4).chunk);
    return cache.get(k);
  };
  for (let y = Y1; y >= Y0; y--) {
    const rows = [];
    const here = new Set();
    for (let z = Z - radius; z <= Z + radius; z++) {
      let row = '';
      for (let x = X - radius; x <= X + radius; x++) {
        const b = blockAt(getChunk(x, z), x, y, z);
        if (b.startsWith('minecraft:air') || b.includes('未生成')) { row += '.'; continue; }
        const base = b.replace(/^minecraft:/, '').split('[')[0];
        if (!legend.has(base)) legend.set(base, chars[legend.size] ?? '?');
        row += legend.get(base);
        here.add(base);
      }
      rows.push(row);
    }
    console.log(`\n=== y=${y} ===  (列 x=${X - radius}..${X + radius}，行 z=${Z - radius}..${Z + radius}；'.'=空气)`);
    console.log('     ' + rows.join('\n     '));
  }
  console.log('\n图例：');
  for (const [id, ch] of legend) console.log(`  ${ch} = ${id}`);
} else {
  const wants = scan.split(',').map((s) => s.trim());
  const hits = [];
  const minX = X - radius; const maxX = X + radius;
  const minZ = Z - radius; const maxZ = Z + radius;
  /* ⚠️ 注意别写成"对每个 (x,z) 再扫一遍整个盒子" —— 那会把同一批方块
   *    重复计数 N 倍（第一版就是这个 bug，玻璃数出来了 155 万个）。
   *    正确做法：按**区块**遍历一次，在区块与盒子的交集内取每个 y。 */
  const cache = new Map();
  const getChunk = (cx, cz) => {
    const k = cx + ',' + cz;
    if (!cache.has(k)) cache.set(k, loadChunkColumn(cx, cz).chunk);
    return cache.get(k);
  };
  const cx0 = minX >> 4; const cx1 = maxX >> 4;
  const cz0 = minZ >> 4; const cz1 = maxZ >> 4;
  for (let cx2 = cx0; cx2 <= cx1; cx2++) {
    for (let cz2 = cz0; cz2 <= cz1; cz2++) {
      const c = getChunk(cx2, cz2);
      if (!c) continue;
      const x0 = Math.max(minX, cx2 * 16); const x1 = Math.min(maxX, cx2 * 16 + 15);
      const z0 = Math.max(minZ, cz2 * 16); const z1 = Math.min(maxZ, cz2 * 16 + 15);
      for (const s of c.sections ?? []) {
        const sy = s.Y ?? s.y;
        const sb = sectionBlocks(s);
        if (!sb) continue;
        /* 只扫调色板里真的出现过目标 ID 的 section，快很多 */
        if (!sb.palette.some((p) => wants.some((w) => p === w || p.startsWith(w + '[')))) continue;
        for (let y = Math.max(sy * 16, Y0); y < Math.min(sy * 16 + 16, Y1 + 1); y++) {
          for (let z = z0; z <= z1; z++) {
            for (let x = x0; x <= x1; x++) {
              const b = sb.at(x, y, z);
              if (wants.some((w) => b === w || b.startsWith(w + '['))) hits.push({ x, y, z, b });
            }
          }
        }
      }
    }
  }
  console.log(`\n在 x=${minX}..${maxX} z=${minZ}..${maxZ} y=${Y0}..${Y1} 范围内搜索 ${wants.join(' / ')}：`);
  if (hits.length === 0) {
    console.log('  （一个都没有）');
  } else {
    const byId = {};
    for (const h of hits) (byId[h.b] ??= []).push(h);
    for (const [id, list] of Object.entries(byId)) {
      let xmin = Infinity; let xmax = -Infinity; let ymin = Infinity; let ymax = -Infinity;
      let zmin = Infinity; let zmax = -Infinity;
      for (const h of list) {
        if (h.x < xmin) xmin = h.x; if (h.x > xmax) xmax = h.x;
        if (h.y < ymin) ymin = h.y; if (h.y > ymax) ymax = h.y;
        if (h.z < zmin) zmin = h.z; if (h.z > zmax) zmax = h.z;
      }
      console.log(`  ${id}  ×${list.length}`);
      console.log(`      x ${xmin}..${xmax}   y ${ymin}..${ymax}   z ${zmin}..${zmax}`);
      const near = list
        .map((h) => ({ h, d: Math.max(Math.abs(h.x - X), Math.abs(h.z - Z)) }))
        .sort((a, b) => a.d - b.d)
        .slice(0, 12);
      for (const { h, d } of near) {
        console.log(`      (${h.x}, ${h.y}, ${h.z})   水平距目标列 ${d} 格${d === 0 ? '  ← 就在这一列' : ''}`);
      }
      if (list.length > near.length) console.log(`      …还有 ${list.length - near.length} 个`);
    }
  }
}

/* 顺带给一眼这一列附近的实体（掉落物等），方便判断配方有没有产出 */
const entFile = join(dirname(regionDir()), 'entities', `r.${cx >> 5}.${cz >> 5}.mca`);
if (existsSync(entFile)) {
  try {
    const ec = readRegionChunk(readFileSync(entFile), cx, cz);
    const list = (ec?.Entities ?? []).map((e) => {
      const p = e.Pos ?? [0, 0, 0];
      const id = e.id ?? '?';
      const item = e.Item?.id ? ' item=' + e.Item.id : '';
      return `    ${id}${item}   (${p[0].toFixed(2)}, ${p[1].toFixed(2)}, ${p[2].toFixed(2)})`;
    });
    if (list.length) {
      console.log(`\n该区块已保存的实体（${list.length} 个）：`);
      console.log(list.slice(0, 30).join('\n'));
    }
  } catch (e) {
    console.log('\n（实体区块读取失败：' + e.message + '）');
  }
}
