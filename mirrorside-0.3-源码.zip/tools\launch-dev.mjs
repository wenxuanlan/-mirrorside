#!/usr/bin/env node
/**
 * 镜维度 · 开发启动器
 * =====================================================================
 * 直接按 NeoForge 官方的参数结构启动客户端。这是本项目**实测可用**的
 * 启动方式（2026-09-18 验证：7 个模组全部加载、KubeJS 0 错误、
 * 传送门注册成功、游戏进入主界面）。
 *
 * 为什么需要它：
 *   实例是 PCL 建的，它的版本 JSON 是「自包含」形态，把未经 NeoForge
 *   补丁处理的原版混淆客户端当成了版本 jar —— Minecraft 类不在 classpath
 *   上，游戏启动即死。修它要么让启动器重装 NeoForge，要么用这个脚本。
 *
 * 关键三点（缺一不可，都在这里踩过）：
 *   1. 版本 jar = neoforge-<ver>-client.jar（打补丁的 Minecraft 增量）
 *   2. universal **不**手工放进 classpath —— FML 靠 -DlibraryDirectory 自己找
 *   3. 把补丁 client 的产物名加进 -DignoreList
 *      否则它和 universal 会各注册一个 neoforge 模块：
 *        ResolutionException: Module xxx reads more than one module named neoforge
 *
 * 用法:
 *   node tools/launch-dev.mjs                 # 正常启动
 *   node tools/launch-dev.mjs --timeout 120   # 跑 120 秒后自动关闭（无人值守验证用）
 *   node tools/launch-dev.mjs --list          # 只打印将要使用的 classpath，不启动
 * =====================================================================
 */

import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { dirname, join, resolve, delimiter } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
let INSTANCE = resolve(HERE, '..');
const argv = process.argv.slice(2);
const iFlag = argv.indexOf('--instance');
if (iFlag !== -1 && argv[iFlag + 1]) INSTANCE = resolve(argv[iFlag + 1]);
const tFlag = argv.indexOf('--timeout');
const TIMEOUT = tFlag !== -1 ? Number(argv[tFlag + 1]) : 0;
const LIST_ONLY = argv.includes('--list');

const MC = resolve(INSTANCE, '..', '..');
const LIBS = join(MC, 'libraries');
const ASSETS = join(MC, 'assets');
const JAVA = process.env.MIRROR_JAVA ?? 'D:\\App\\java21\\bin\\java.exe';

/* ---------- 读版本 JSON（overlay + 被继承的原版） ---------- */

const overlayPath = readdirSync(INSTANCE)
  .filter((f) => f.endsWith('.json'))
  .map((f) => join(INSTANCE, f))
  .find((p) => {
    try { return Array.isArray(JSON.parse(readFileSync(p, 'utf8')).libraries); } catch { return false; }
  });
if (!overlayPath) { console.error('✗ 实例里找不到含 libraries 的版本 JSON'); process.exit(1); }

const overlay = JSON.parse(readFileSync(overlayPath, 'utf8'));
const baseId = overlay.inheritsFrom;
if (!baseId) {
  console.error('✗ 版本 JSON 缺少 inheritsFrom —— 自包含形态无法用本脚本启动。');
  console.error('  请让启动器重装 NeoForge 生成继承式版本 JSON（见 README 7.0 节）。');
  process.exit(1);
}
const basePath = join(resolve(INSTANCE, '..'), baseId, `${baseId}.json`);
if (!existsSync(basePath)) { console.error('✗ 找不到被继承的原版版本 JSON: ' + basePath); process.exit(1); }
const base = JSON.parse(readFileSync(basePath, 'utf8'));

/* ---------- 组装 classpath ---------- */

function allowed(lib) {
  if (!lib.rules) return true;
  let ok = false;
  for (const r of lib.rules) {
    const osOk = !r.os || (r.os.name === 'windows' && process.platform === 'win32')
      || (r.os.name === 'linux' && process.platform === 'linux')
      || (r.os.name === 'osx' && process.platform === 'darwin');
    if (r.action === 'allow' && osOk) ok = true;
    if (r.action === 'disallow' && osOk) ok = false;
  }
  return ok;
}

const cp = [];
const seen = new Set();
const missing = [];
for (const src of [base.libraries ?? [], overlay.libraries ?? []]) {
  for (const lib of src) {
    if (!allowed(lib)) continue;
    const p = lib.downloads?.artifact?.path;
    if (!p) continue;
    const full = join(LIBS, p);
    if (seen.has(full)) continue;      // 必须去重：重复条目会让 BootstrapLauncher 抛 Duplicate key
    seen.add(full);
    if (existsSync(full)) cp.push(full); else missing.push(p);
  }
}

/* ---------- 定位打补丁的客户端产物 ---------- */

let neoVer = null;
const g = overlay.arguments?.game ?? [];
for (let i = 0; i < g.length - 1; i++) if (g[i] === '--fml.neoForgeVersion') neoVer = g[i + 1];
if (!neoVer) {
  const neo = (overlay.libraries ?? []).find((l) => /^net\.neoforged:neoforge:/.test(l.name ?? ''));
  neoVer = neo ? neo.name.split(':')[2] : null;
}
if (!neoVer) { console.error('✗ 读不到 NeoForge 版本'); process.exit(1); }

const clientJarName = `neoforge-${neoVer}-client.jar`;
const clientJar = join(LIBS, 'net/neoforged/neoforge', neoVer, clientJarName);
if (!existsSync(clientJar)) {
  console.error(`✗ 缺少打补丁的客户端产物：\n    ${clientJar}`);
  console.error('  它只能由 NeoForge 官方安装器生成（AutoRenamingTool + installertools + binarypatcher）。');
  process.exit(1);
}

/* ---------- JVM / 游戏参数 ---------- */

const jvm = (overlay.arguments?.jvm ?? []).map((a) => String(a)
  .replaceAll('${library_directory}', LIBS)
  .replaceAll('${classpath_separator}', delimiter)
  .replaceAll('${version_name}', baseId));

// 【决定性】补丁 client 不能同时被当成 neoforge 模块
let patched = false;
for (let i = 0; i < jvm.length; i++) {
  if (jvm[i].startsWith('-DignoreList=')) {
    const names = jvm[i].slice('-DignoreList='.length).split(',');
    if (!names.includes(clientJarName)) jvm[i] += ',' + clientJarName;
    patched = true;
  }
}
if (!patched) jvm.push('-DignoreList=' + clientJarName);

const game = [
  ...(overlay.arguments?.game ?? []),
  '--username', 'Dev',
  '--version', baseId,
  '--gameDir', INSTANCE,
  '--assetsDir', ASSETS,
  '--assetIndex', base.assetIndex?.id ?? '17',
  '--uuid', '00000000000000000000000000000000',
  '--accessToken', '0',
  '--userType', 'legacy',
  '--versionType', 'release',
];

const args = [
  ...jvm,
  '-Djava.net.preferIPv4Stack=true',
  '-cp', [clientJar, ...cp].join(delimiter),
  overlay.mainClass,
  ...game,
];

/* ---------- 报告 ---------- */

console.log('镜维度 · 开发启动器');
console.log('实例        : ' + INSTANCE);
console.log('版本 jar    : ' + clientJarName + `  (${(statSync(clientJar).size / 1048576).toFixed(2)} MB)`);
console.log('classpath   : ' + (cp.length + 1) + ' 条');
console.log('Java        : ' + JAVA);
if (missing.length) {
  console.log('缺失的库 (' + missing.length + ') —— 游戏可能起不来：');
  for (const m of missing.slice(0, 10)) console.log('  ' + m);
}

if (LIST_ONLY) {
  console.log('\n--- classpath ---');
  for (const p of [clientJar, ...cp]) console.log('  ' + p.replace(MC, '<mc>'));
  process.exit(0);
}

if (!existsSync(JAVA)) {
  console.error(`\n✗ 找不到 Java: ${JAVA}`);
  console.error('  用环境变量 MIRROR_JAVA 指定，例如：');
  console.error('    set MIRROR_JAVA=D:\\path\\to\\java.exe');
  process.exit(1);
}

console.log('\n启动中...' + (TIMEOUT ? `（${TIMEOUT} 秒后自动关闭）` : '（Ctrl+C 结束）') + '\n');

const child = spawn(JAVA, args, { cwd: INSTANCE, stdio: 'inherit' });
if (TIMEOUT > 0) setTimeout(() => child.kill('SIGKILL'), TIMEOUT * 1000);

child.on('exit', (code) => {
  console.log('\n游戏进程结束，exit code = ' + code);
  if (code !== 0 && code !== null) {
    console.log('排查请读 logs/latest.log 与 logs/kubejs/startup.log');
  }
});
process.on('SIGINT', () => { child.kill(); process.exit(0); });
