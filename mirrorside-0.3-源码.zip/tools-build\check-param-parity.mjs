/**
 * 镜维度 · 配置 ↔ 模组 参数一致性自检
 *
 * ── 为什么需要它 ─────────────────────────────────────────────────────────────
 * 这个项目有一条规矩：「**配置是唯一真相，模组只接收**」。
 * 但模组侧总要有一个"脚本还没推之前"的默认值，于是同一个参数天然存在两份：
 *     mirror_config.js 的配置值   ↔   Java 里的 DEFAULT 常量
 * 两份靠人眼保持一致 —— 而"改了这边忘了那边"正是最难查的一类问题
 * （表现是"配置改了却没生效"，且没有报错）。
 *
 * 2026-09-22 实测就抓到一处：`falling_gravity_scale = 0.2`（配置）
 * 与 `ITEM_GRAVITY_SCALE = 0.2D`（Java）是两份**且没有被推送** ——
 * 改配置根本不会影响模组。现在改成可推送，并用这个脚本把两份钉在一起。
 *
 * ── 检查两件事 ───────────────────────────────────────────────────────────────
 *   A. 每一对"配置值 ↔ Java 默认值"必须相等（不等就报错，并指出改哪边）。
 *   B. 每个"模组会用到的配置项"必须在脚本里有对应的 set* 推送点
 *      （只有默认值、没有推送 = 配置改了不生效）。
 *
 * 退出码：全部通过 0，否则 1。
 */
import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const V = 'D:\\DSHwork\\MC镜维度\\.minecraft\\versions\\镜维度';
const JAVA = 'D:\\DSHwork\\MC镜维度\\mirror-gravity-mod\\src\\main\\java\\work\\dsh\\mirror\\gravity';

/* ---------------- 读配置（真跑一遍 startup 脚本） ---------------- */
const cfgSrc = readFileSync(join(V, 'kubejs/startup_scripts/mirror_config.js'), 'utf8');
const cfg = new Function(cfgSrc.replace(/^\s*(const|let)\s+/gm, 'var ') + '\n; return MIRROR_CONFIG;')();

/* ---------------- 读 Java 常量 ---------------- */
function javaConst(file, name) {
  const p = join(JAVA, file);
  if (!existsSync(p)) return undefined;
  const src = readFileSync(p, 'utf8');
  const m = new RegExp(name + '\\s*=\\s*(-?[\\d.]+)[DdFf]?\\s*;').exec(src);
  return m ? Number(m[1]) : undefined;
}

/* ---------------- 读脚本侧的推送点 ---------------- */
const n0 = readFileSync(join(V, 'kubejs/server_scripts/mirror_n0_foundation.js'), 'utf8');
function pushed(setterName) {
  return n0.includes('MG_API.' + setterName + '(') || n0.includes('.' + setterName + '(');
}

let bad = 0;
const fail = (msg) => { bad++; console.log('  ✗ ' + msg); };
const ok = (msg) => console.log('  ✓ ' + msg);
const warn = (msg) => console.log('  · ' + msg);   // 提醒项，不影响退出码

/* ── A. 配置值 ↔ Java 默认值 ───────────────────────────────────────────── */
console.log('=== A. 配置值 ↔ 模组默认值（必须相等）===');
const PAIRS = [
  {
    label: '掉落物重力缩放',
    configPath: 'gravity.falling_gravity_scale',
    configValue: cfg.gravity.falling_gravity_scale,
    javaFile: 'MirrorGravityConfig.java',
    javaConst: 'ITEM_GRAVITY_SCALE_DEFAULT',
    pushSetter: 'setItemGravityScale',
    pushInConfig: 'gravity.falling_gravity_scale',
  },
  {
    label: '下落方块参照线偏移',
    configPath: 'gravity.falling_ref_offset',
    configValue: cfg.gravity.falling_ref_offset,
    javaFile: 'MirrorGravity.java',
    javaConst: 'FALLING_REF_OFFSET',
    pushSetter: 'setFallingRefOffset',
  },
  {
    label: '分界参考线',
    configPath: 'layout.split_y',
    configValue: cfg.layout.split_y,
    javaFile: 'MirrorGravity.java',
    javaConst: 'SPLIT_Y',
    pushSetter: 'setSplitY',
  },
  {
    label: '掉落物位置同步间隔',
    configPath: 'gravity.item_sync_interval',
    configValue: cfg.gravity.item_sync_interval,
    javaFile: 'internal/VelocityFix.java',
    javaConst: 'SYNC_INTERVAL_DEFAULT',
    pushSetter: 'setItemSyncInterval',
  },
  {
    label: '下落方块迟滞带',
    configPath: 'gravity.falling_hysteresis',
    configValue: cfg.gravity.falling_hysteresis,
    javaFile: 'BlockPhysics.java',
    javaConst: 'DIR_HYSTERESIS_DEFAULT',
    pushSetter: 'setHysteresis',
  },
];

for (const p of PAIRS) {
  const jv = javaConst(p.javaFile, p.javaConst);
  if (jv === undefined) {
    fail(`${p.label}: 在 ${p.javaFile} 里找不到常量 ${p.javaConst}`);
    continue;
  }
  if (p.configValue == null) {
    fail(`${p.label}: 配置里缺少 ${p.configPath}`);
    continue;
  }
  if (Number(p.configValue) !== Number(jv)) {
    fail(`${p.label}: 配置 ${p.configPath}=${p.configValue} ≠ 模组 ${p.javaConst}=${jv}`
      + `　→ 两边必须一致（模组那份只是"脚本还没推之前"的默认值）`);
    continue;
  }
  ok(`${p.label.padEnd(18)} ${p.configPath}=${p.configValue} ≡ ${p.javaConst}=${jv}`);
}

/* ── B. 每个"会被模组用到"的配置项都要有推送点 ─────────────────────────── */
console.log('\n=== B. 配置项必须真的推给模组（只有默认值不算）===');
for (const p of PAIRS) {
  if (pushed(p.pushSetter)) {
    ok(`${p.configPath.padEnd(28)} → MG_API.${p.pushSetter}(...) 已接线`);
  } else {
    fail(`${p.configPath} 没有任何 MG_API.${p.pushSetter}(...) 推送点`
      + ' —— 改配置不会影响模组（这正是 ITEM_GRAVITY_SCALE 曾经的问题）');
  }
}

/* ── C. 时间/数值合理性（顺手拦掉明显的写错）──────────────────────────── */
console.log('\n=== C. 数值范围抽查 ===');
const RANGES = [
  ['gravity.falling_gravity_scale', cfg.gravity.falling_gravity_scale, 0.01, 1],
  ['gravity.falling_hysteresis', cfg.gravity.falling_hysteresis, 0.05, 4],
  ['gravity.item_sync_interval', cfg.gravity.item_sync_interval, 1, 40],
  ['gravity.landing_lookahead', cfg.gravity.landing_lookahead, 0, 2],
];
for (const [k, v, lo, hi] of RANGES) {
  if (v == null) { fail(`${k} 缺失`); continue; }
  if (v < lo || v > hi) fail(`${k}=${v} 超出合理范围 [${lo}, ${hi}]`);
  else ok(`${k.padEnd(28)} ${v} ∈ [${lo}, ${hi}]`);
}

/* ── D. 「针尖对麦芒」参数 ───────────────────────────────────────────────
 * 这一段的参数有 14 个，而且是"错一个就生成出畸形装置"的那种。
 * 除了逐项对拍，还额外验证三件事：
 *   1. n0 推给模组的 CSV 顺序必须和 SpindleSettings 的约定一致（顺序错了不会报错，
 *      只会把长度当半径用）；
 *   2. 由这些数字反推的几何必须自洽（这条关系式在模组里是硬约束，见
 *      SpindleGeometry 类注释：insetDn - insetUp = 2*coreY + 1）；
 *   3. 最长的锥体要装得进世界高度。
 * 探针（tools-build/run-spindle-probe.mjs）负责跑真实几何，这里只拦"配置写错"。 */
console.log('\n=== D. 针尖对麦芒参数 ===');
const SP = cfg.spindle;
if (!SP || SP.enabled === false) {
  console.log('  · spindle 关闭或缺失，跳过');
} else {
  const SPD = join(JAVA, 'SpindleSettings.java');
  const spdSrc = readFileSync(SPD, 'utf8');
  /* SpindleSettings.java 里的默认值（用于对拍与几何反推） */
  const spConst = (n) => {
    const m = new RegExp(n + '\\s*=\\s*(-?[\\d.]+)[DdFf]?\\s*;').exec(spdSrc);
    return m ? Number(m[1]) : undefined;
  };

  const SP_PAIRS = [
    ['锥底半径下限', SP.radius[0], 'radiusMin'],
    ['锥底半径上限', SP.radius[1], 'radiusMax'],
    ['锥体长度下限', SP.length[0], 'lengthMin'],
    ['锥体长度上限', SP.length[1], 'lengthMax'],
    ['伸入境内下限', SP.inset[0], 'insetMin'],
    ['伸入境内上限', SP.inset[1], 'insetMax'],
    ['波粒块高度下限', SP.center_y[0], 'centerYMin'],
    ['波粒块高度上限', SP.center_y[1], 'centerYMax'],
    ['俯仰角下限', SP.pitch_deg[0], 'pitchMinDeg'],
    ['俯仰角上限', SP.pitch_deg[1], 'pitchMaxDeg'],
  ];
  for (const [label, cfgV, javaName] of SP_PAIRS) {
    const jv = spConst(javaName);
    if (jv === undefined) { fail(`${label}: SpindleSettings.java 里找不到 ${javaName}`); continue; }
    if (Number(cfgV) !== jv) {
      fail(`${label}: 配置 ${cfgV} ≠ 模组 ${javaName}=${jv}（模组那份只是兜底，必须一致）`);
    } else {
      ok(`${label.padEnd(14)} ${cfgV} ≡ ${javaName}`);
    }
  }

  /* 境内/世界高度：模组默认值应与 layout 对得上 */
  const L = cfg.layout;
  const innerMin = Number(/innerMinY\s*=\s*(-?\d+)/.exec(spdSrc)[1]);
  const innerMax = Number(/innerMaxY\s*=\s*(-?\d+)/.exec(spdSrc)[1]);
  const buildMin = Number(/buildMinY\s*=\s*(-?\d+)/.exec(spdSrc)[1]);
  const buildMax = Number(/buildMaxY\s*=\s*(-?\d+)/.exec(spdSrc)[1]);
  if (innerMin !== L.inner_min_y || innerMax !== L.inner_max_y) {
    fail(`境内范围不一致：layout ${L.inner_min_y}..${L.inner_max_y} ≠ 模组 ${innerMin}..${innerMax}`);
  } else ok(`境内范围 ${innerMin}..${innerMax} ≡ layout`);

  /* n0 推送的 CSV 顺序（顺序错了只会静默算错，不会报错） */
  const pushMatch = /MG_API\.setSpindleParams\(\[([\s\S]*?)\]\.join\(','\)\)/.exec(n0);
  const EXPECTED_ORDER = [
    'SP.radius[0]', 'SP.radius[1]', 'SP.length[0]', 'SP.length[1]',
    'SP.inset[0]', 'SP.inset[1]', 'SP.center_y[0]', 'SP.center_y[1]',
    'SP.pitch_deg[0]', 'SP.pitch_deg[1]',
    'spMirMin', 'spMirMax', 'bMin', 'bMax',
  ];
  if (!pushMatch) {
    fail('n0 里找不到 MG_API.setSpindleParams([...].join(\',\'))');
  } else {
    const terms = pushMatch[1].split(',').map((s) => s.trim()).filter(Boolean);
    if (terms.length !== EXPECTED_ORDER.length) {
      fail(`推送参数个数 ${terms.length} ≠ 约定的 ${EXPECTED_ORDER.length}`);
    } else {
      const diff = terms.findIndex((t, i) => t !== EXPECTED_ORDER[i]);
      if (diff >= 0) {
        fail(`推送顺序第 ${diff + 1} 项是 "${terms[diff]}"，应为 "${EXPECTED_ORDER[diff]}"`
          + '（顺序即契约，错了会把长度当半径用且不报错）');
      } else ok(`推送顺序 ${EXPECTED_ORDER.length} 项全对（半径/长度/伸入/高度/俯仰/境内/世界）`);
    }
  }
  if (!n0.includes('MG_API.setSpindleAvoidY(')) fail('n0 没有推送波粒块避让层');
  else ok('避让层推送点存在');

  /* 几何自洽：两侧伸入格数之差由波粒块高度决定 */
  const spread = Math.max(
    Math.abs(2 * Math.ceil(SP.center_y[0]) + 1),
    Math.abs(2 * Math.floor(SP.center_y[1]) + 1));
  const insetRoom = SP.inset[1] - SP.inset[0];
  if (spread > insetRoom) {
    fail(`高度带 ${SP.center_y} 需要 ${spread} 格伸入余量，但 inset 区间只有 ${insetRoom} 格`
      + ' —— 模组会拒绝参数并记一次静默失败（/mirror diag 可见）');
  } else {
    ok(`几何自洽：高度带最多造成 ${spread} 格不对称 ≤ inset 余量 ${insetRoom} 格`);
  }

  /* 世界高度：最坏情况是"中轴长度 + 底面圆盘在 y 上的投影"的合成 */
  const worst = Math.sqrt(SP.length[1] ** 2 + SP.radius[1] ** 2);
  const topMax = L.inner_max_y + 1.5 - SP.inset[0] + worst;
  const bottomMin = L.inner_min_y - 0.5 + SP.inset[0] - worst;
  if (topMax > buildMax + 0.5) fail(`上锥最高方块中心约 ${topMax.toFixed(1)} > ${buildMax}.5，会被世界顶裁掉`);
  else ok(`上锥最高 ${topMax.toFixed(1)} ≤ ${buildMax}.5`);
  if (bottomMin < buildMin) fail(`下锥最低方块中心约 ${bottomMin.toFixed(1)} < ${buildMin}，会被世界底裁掉`);
  else ok(`下锥最低 ${bottomMin.toFixed(1)} ≥ ${buildMin}`);

  /* 俯仰角下限决定结构横向跨度（世界生成时会一起强制生成覆盖到的区块） */
  const spanX = Math.ceil(2 * (SP.length[1] * Math.cos(SP.pitch_deg[0] * Math.PI / 180) + SP.radius[1]) / 16) + 1;
  if (SP.pitch_deg[0] < 55) {
    warn(`俯仰角下限 ${SP.pitch_deg[0]}° 偏平：包围盒最坏跨约 ${spanX}×${spanX} 区块，`
      + '玩家靠近时那一下世界生成会明显卡顿');
  } else {
    ok(`俯仰角下限 ${SP.pitch_deg[0]}° ⇒ 包围盒最坏跨约 ${spanX}×${spanX} 区块`);
  }
}

/* ── E. 维度视觉效果 id 三处一致 ─────────────────────────────────────────
 * 镜维度用了一个**模组注册的** effects（mirrorgravity:mirror：主世界天空但不画云）。
 * 这个 id 同时出现在三个地方，任何一处对不上都不会报错、只会静默变回"有云"：
 *   · kubejs/config/mirror_dimension.json → dimension_type.effects（数据包输入）
 *   · tools/generate-mirror-pack.mjs 的白名单（写错直接中止生成）
 *   · 模组 MirrorClientSetup.EFFECTS_PATH（真正注册的那个 id）
 * 再加上生成出来的 dimension_type JSON，一共四处对齐。 */
console.log('\n=== E. 维度视觉效果 id ===');
{
  const worldCfgPath = join(V, 'kubejs', 'config', 'mirror_dimension.json');
  const genPath = join(V, 'tools', 'generate-mirror-pack.mjs');
  const setupPath = join(JAVA, 'MirrorClientSetup.java');
  if (!existsSync(worldCfgPath)) {
    warn('找不到 kubejs/config/mirror_dimension.json，跳过');
  } else {
    const effects = JSON.parse(readFileSync(worldCfgPath, 'utf8')).dimension_type?.effects ?? '';
    const genSrc = existsSync(genPath) ? readFileSync(genPath, 'utf8') : '';
    const setupSrc = existsSync(setupPath) ? readFileSync(setupPath, 'utf8') : '';
    const modId = (/MOD_ID\s*=\s*"([^"]+)"/.exec(readFileSync(join(JAVA, 'MirrorGravity.java'), 'utf8')) || [])[1];
    const pathConst = (/EFFECTS_PATH\s*=\s*"([^"]+)"/.exec(setupSrc) || [])[1];

    if (effects.startsWith('minecraft:')) {
      warn(`effects = ${effects}（原版值，本体带云；若要"主世界天空但不画云"应改成模组注册的 id）`);
    } else {
      const expected = `${modId}:${pathConst}`;
      if (effects !== expected) {
        fail(`dimension_type.effects = "${effects}"，但模组注册的是 "${expected}"`
          + '（MirrorClientSetup.EFFECTS_PATH）—— 不匹配时 NeoForge 会静默回退成主世界效果，云又回来了');
      } else {
        ok(`effects = ${effects} ≡ 模组注册 id`);
      }
      if (!genSrc.includes(`'${effects}'`)) {
        fail(`生成器白名单里没有 "${effects}" —— 跑生成器会直接中止`);
      } else {
        ok('生成器白名单包含该 id');
      }
      const generated = join(V, 'kubejs', 'data', 'mirror', 'dimension_type', 'mirror.json');
      if (existsSync(generated)) {
        const ge = JSON.parse(readFileSync(generated, 'utf8')).effects;
        if (ge !== effects) {
          fail(`已生成的数据包里 effects = "${ge}"，与配置 "${effects}" 不一致 —— 需要重跑生成器`);
        } else {
          ok('已生成的数据包 effects 一致');
        }
      }
    }
    /* ambient_light 与设定原文的对应（『同主世界的白天亮度相当』⇒ 主世界是 0） */
    const amb = JSON.parse(readFileSync(worldCfgPath, 'utf8')).dimension_type?.ambient_light;
    if (amb == null) {
      warn('dimension_type.ambient_light 缺失');
    } else if (amb > 0.3) {
      warn(`ambient_light = ${amb} 偏高：它会按 lerp(ambient, 光值, 1.0) 把整个维度拉亮`
        + '（主世界是 0），用户反馈过"天空光太强"');
    } else {
      ok(`ambient_light = ${amb}（主世界 0，越大越"发白"）`);
    }
  }
}

/* ── F. 波粒子参数（道具：右键方块给下坠特性）──────────────────────────────
 * 这一段除了"配置 ↔ 模组默认值"，还查两件容易静默出错的事：
 *   1. n0 推送的 6 个数的**顺序**（错了不会报错，只会把延迟当上限用）；
 *   2. 模组里所有"拒绝原因代码"都要在语言文件里有对应文本 ——
 *      少一条，玩家看到的就是一行 message.mirrorgravity.wave_particle.reject.xxx 原文。 */
console.log('\n=== F. 波粒子参数 ===');
{
  const WP = cfg.waveParticle;
  const wPath = join(JAVA, 'WaveParticleSettings.java');
  if (!WP) {
    warn('配置里没有 waveParticle 段，跳过');
  } else if (!existsSync(wPath)) {
    fail('找不到 WaveParticleSettings.java');
  } else {
    const wsrc = readFileSync(wPath, 'utf8');
    const wBool = (name) => {
      const m = new RegExp(name + '\\s*=\\s*(true|false)').exec(wsrc);
      return m ? m[1] === 'true' : undefined;
    };
    const wInt = (name) => {
      const m = new RegExp(name + '\\s*=\\s*(\\d+)').exec(wsrc);
      return m ? Number(m[1]) : undefined;
    };
    const WPAIRS = [
      ['启用', WP.enabled !== false, 'enabled', wBool],
      ['使用消耗', WP.consume !== false, 'consume', wBool],
      ['下坠延迟(刻)', WP.fall_delay_ticks ?? 2, 'fallDelayTicks', wInt],
      ['允许方块实体', WP.allow_block_entities === true, 'allowBlockEntities', wBool],
      ['允许挖不动的', WP.allow_unbreakable !== false, 'allowUnbreakable', wBool],
      ['每维度上限', WP.max_tags_per_level ?? 8192, 'maxTagsPerLevel', wInt],
      ['行动栏提示', WP.notify !== false, 'notify', wBool],
    ];
    for (const [label, cfgV, javaName, reader] of WPAIRS) {
      const jv = reader(javaName);
      if (jv === undefined) {
        fail(`${label}: WaveParticleSettings.java 里找不到 ${javaName}`);
      } else if (cfgV !== jv) {
        fail(`${label}: 配置 ${cfgV} ≠ 模组 ${javaName}=${jv}`);
      } else {
        ok(`${label.padEnd(14)} ${cfgV} ≡ ${javaName}`);
      }
    }

    const pushMatch = /MG_API\.setWaveParticleParams\(\[([\s\S]*?)\]\.join\(','\)\)/.exec(n0);
    const EXPECTED = [
      'WP.enabled === false ? 0 : 1',
      'WP.consume === false ? 0 : 1',
      'WP.fall_delay_ticks != null ? WP.fall_delay_ticks : 2',
      'WP.allow_block_entities ? 1 : 0',
      'WP.allow_unbreakable === false ? 0 : 1',
      'WP.max_tags_per_level != null ? WP.max_tags_per_level : 8192',
      'WP.notify === false ? 0 : 1',
    ];
    if (!pushMatch) {
      fail("n0 里找不到 MG_API.setWaveParticleParams([...].join(','))");
    } else {
      const terms = pushMatch[1].split(',').map((s) => s.trim()).filter(Boolean);
      if (terms.length !== EXPECTED.length) {
        fail(`推送参数个数 ${terms.length} ≠ 约定的 ${EXPECTED.length}`);
      } else {
        const diff = terms.findIndex((t, i) => t !== EXPECTED[i]);
        if (diff >= 0) fail(`推送顺序第 ${diff + 1} 项是 "${terms[diff]}"，应为 "${EXPECTED[diff]}"`);
        else ok(`推送顺序 ${EXPECTED.length} 项全对（启用/消耗/延迟/方块实体/挖不动的/上限/提示）`);
      }
    }

    /* 拒绝原因 ↔ 语言文件 */
    const taggerPath = join(JAVA, 'GravityTagger.java');
    const zhPath = join('D:\\DSHwork\\MC镜维度\\mirror-gravity-mod\\src\\main\\resources',
      'assets', 'mirrorgravity', 'lang', 'zh_cn.json');
    if (existsSync(taggerPath) && existsSync(zhPath)) {
      const tagger = readFileSync(taggerPath, 'utf8');
      const zh = readFileSync(zhPath, 'utf8');
      const codes = [...tagger.matchAll(/return "([a-z_]+)";/g)].map((m) => m[1]);
      const unique = [...new Set(codes)];
      const missing = unique.filter((c) => !zh.includes(`message.mirrorgravity.wave_particle.reject.${c}`));
      if (!unique.length) warn('GravityTagger 里没解析到拒绝原因代码（改了写法？）');
      else if (missing.length) fail(`这些拒绝原因没有语言条目，玩家会看到原始键名: ${missing.join(', ')}`);
      else ok(`拒绝原因 ${unique.length} 个都有语言条目（${unique.join(', ')}）`);
    }

    /* 数值合理性 */
    const delay = WP.fall_delay_ticks ?? 2;
    const cap = WP.max_tags_per_level ?? 8192;
    if (delay < 0 || delay > 200) fail(`fall_delay_ticks=${delay} 超出 0~200`);
    else ok(`fall_delay_ticks=${delay}（原版同款延迟是 2）`);
    if (cap < 1 || cap > 1000000) fail(`max_tags_per_level=${cap} 超出 1~1000000`);
    else ok(`max_tags_per_level=${cap}`);
  }
}

/* ── G. 天气（镜维度永远晴天）─────────────────────────────────────────────
 * 只有一个开关，但它必须真的推给模组：模组侧的兜底默认值是 true，
 * 而配置里关掉之后如果不推送，游戏里就还是晴天 —— 玩家会以为开关坏了。 */
console.log('\n=== G. 天气 ===');
{
  const W = cfg.weather;
  const n0src = n0;
  if (W == null) {
    warn('配置里没有 weather 段（模组会用兜底值：强制晴天开）');
  } else {
    const want = W.force_clear !== false;
    if (!n0src.includes('MG_API.setForceClearWeather(')) {
      fail('n0 没有调用 MG_API.setForceClearWeather(...) —— 改配置不会影响游戏');
    } else {
      ok(`force_clear=${want} 且有推送点`);
    }
    if (!want) {
      warn('强制晴天已关闭：镜维度会按原版节奏下雨（客户端也不渲染雨，只是状态会变）');
    }
  }
  /* 模组侧默认值应与配置一致 */
  const weatherPath = join(JAVA, 'MirrorWeather.java');
  if (existsSync(weatherPath)) {
    const src = readFileSync(weatherPath, 'utf8');
    const def = /forceClear\s*=\s*(true|false)/.exec(src);
    const want = (W == null) ? true : (W.force_clear !== false);
    if (!def) fail('MirrorWeather.java 里找不到 forceClear 的默认值');
    else if ((def[1] === 'true') !== want) {
      fail(`兜底默认值 ${def[1]} 与配置 ${want} 不一致（脚本没推送时行为会不同）`);
    } else ok(`兜底默认值 ${def[1]} ≡ 配置`);
  } else {
    fail('找不到 MirrorWeather.java');
  }

  /* 实现方式：必须是"挂进原版天气循环"的 mixin，而且必须在 mixins.json 里登记。
   * ⚠️ 这是最容易静默失效的一步：类写好了但忘了登记，mixin 永远不会织入，
   *    表现就是"镜维度又开始下雨"，而且没有任何报错。 */
  const mixinPath = join(JAVA, 'mixin', 'ServerLevelWeatherMixin.java');
  const mixinCfg = join('D:\\DSHwork\\MC镜维度\\mirror-gravity-mod\\src\\main\\resources',
    'mirrorgravity.mixins.json');
  if (!existsSync(mixinPath)) {
    fail('找不到 mixin/ServerLevelWeatherMixin.java（天气锁定应当由它实现）');
  } else if (!existsSync(mixinCfg)) {
    fail('找不到 mirrorgravity.mixins.json');
  } else {
    const src = readFileSync(mixinPath, 'utf8');
    const cfgText = readFileSync(mixinCfg, 'utf8');
    if (!src.includes('advanceWeatherCycle')) {
      fail('ServerLevelWeatherMixin 没有挂 advanceWeatherCycle（原版天气循环入口）');
    } else if (!cfgText.includes('ServerLevelWeatherMixin')) {
      fail('mixins.json 里没有登记 ServerLevelWeatherMixin —— mixin 永远不会织入，'
        + '表现是"镜维度又开始下雨"且无任何报错');
    } else if (!/require\s*=\s*1/.test(src)) {
      fail('ServerLevelWeatherMixin 的注入点应为 require=1（注入失败要大声报错，不能静默失效）');
    } else {
      ok('天气锁定由 mixin 挂在原版 advanceWeatherCycle 上，且已在 mixins.json 登记');
    }
  }
  /* 反向断言：不该再有"每 tick 扫天气"的老实现 */
  const gravitySrc = readFileSync(join(JAVA, 'MirrorGravity.java'), 'utf8');
  if (/MirrorWeather\.tick\(/.test(gravitySrc)) {
    fail('MirrorGravity 里还在每 tick 调 MirrorWeather.tick —— 那是被否决的实现方式');
  } else {
    ok('没有每 tick 的天气检测（由 mixin 接管）');
  }
}

/* ── H. mixin 登记（**每一个** mixin 类都要在 mixins.json 里）────────────
 * 为什么单独做一节：G 节里那条"天气 mixin 有没有登记"的断言，2026-09-25
 * 真的漏掉过一次 —— 新写的 FallingBlockDropMixin 没登记，mixin 静默不织入，
 * 表现是"掉落物里的刷怪笼又空了"，而日志一行错都没有。
 * 这类失效的共同点是**没有任何反馈**，所以必须由脚本兜住：
 *   · 写了类没登记  → 永远不织入（静默失效）
 *   · 登记了不存在的类 → 启动期直接崩
 *   · 注入点没写 require=1 → 织入失败时静默跳过
 */
{
  const mixinDir = join(JAVA, 'mixin');
  const cfgPath = join('D:\\DSHwork\\MC镜维度\\mirror-gravity-mod\\src\\main\\resources',
    'mirrorgravity.mixins.json');
  if (!existsSync(mixinDir)) {
    fail('找不到 java/work/dsh/mirror/gravity/mixin 目录');
  } else if (!existsSync(cfgPath)) {
    fail('找不到 mirrorgravity.mixins.json');
  } else {
    const cfg = JSON.parse(readFileSync(cfgPath, 'utf8'));
    const names = cfg.mixins || [];
    const files = readdirSync(mixinDir).filter((f) => f.endsWith('.java'));
    if (files.length === 0) fail('mixin 目录里没有任何 .java');
    for (const f of files) {
      const cls = f.replace(/\.java$/, '');
      const src = readFileSync(join(mixinDir, f), 'utf8');
      /* 目标是原版还是第三方模组，决定"织入失败"该怎么处理：
       *   · 原版/自有类（net.minecraft.*）→ 必须 require=1。
       *     织入失败意味着我们依赖的原版行为变了，这时**必须大声报错**，
       *     否则表现是"功能莫名其妙不生效"（天气那条就是这么漏的）。
       *   · 第三方模组类（如 Pondus）→ 允许 require=0 主动降级：
       *     对方升级后织入失败只会退化成本来的行为，总好过让游戏崩。
       *     但必须在本类里写明降级理由，不能是一句没解释的 require=0。 */
      const targetMatch = src.match(/@Mixin\(\s*(?:value\s*=\s*)?([A-Za-z_][\w.]*)\.class/);
      const target = targetMatch ? targetMatch[1] : '';
      const thirdParty = target !== '' && !target.startsWith('net.minecraft');
      const documented = /降级|脆弱|对方升级/.test(src);
      if (!names.some((n) => String(n).split('.').pop() === cls)) {
        fail(`mixin/${f} 没有登记进 mirrorgravity.mixins.json —— 它永远不会织入，`
          + '而且不会有任何报错');
      } else if (/require\s*=\s*1/.test(src)) {
        if (!/remap\s*=\s*false/.test(src)) {
          warn(`mixin/${f} 没有写 remap=false（本项目注入的是官方名，应显式关掉重映射）`);
        } else {
          ok(`mixin ${cls} 已登记，注入点 require=1 且 remap=false`);
        }
      } else if (thirdParty && /require\s*=\s*0/.test(src) && documented) {
        ok(`mixin ${cls} 已登记，目标是第三方模组 ${target}`
          + '，按注释写明的理由降级 require=0');
      } else if (!/require\s*=/.test(src)) {
        fail(`mixin/${f} 的注入点没有写 require —— 织入失败时不会有任何反馈，`
          + '原版目标请写 require=1');
      } else {
        fail(`mixin/${f} 用了 require=0 却没有写明降级理由 —— 静默失效正是要避免的`
          + '（原版目标应当用 require=1；只有注入第三方模组才允许降级，且要写明原因）');
      }
    }
    for (const n of names) {
      const short = String(n).split('.').pop();
      if (!existsSync(join(mixinDir, short + '.java'))) {
        fail(`mixins.json 里登记了 ${n}，但 mixin/${short}.java 不存在 —— 启动期会崩`);
      }
    }
  }
}

console.log('\n' + (bad === 0 ? '✓ 参数一致性全部通过' : `✗ ${bad} 项不一致`));
if (bad > 0) process.exit(1);
