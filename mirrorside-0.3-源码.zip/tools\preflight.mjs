#!/usr/bin/env node
/**
 * 镜维度 · 启动前预检
 * =====================================================================
 * 在启动游戏之前把能静态发现的坑全部找出来。它做的事：
 *
 *   1. 逐个读取 mods/ 里的 jar，解析 neoforge.mods.toml
 *   2. 收集「已安装的 modId -> 版本」表
 *   3. 逐条校验每个 mod 声明的 required 依赖是否被满足
 *      （包括 neoforge / minecraft 这两个隐式依赖的版本区间）
 *   4. 检查 kubejs/data 下维度的三份 JSON 是否存在且语法正确
 *   5. 检查 KubeJS 文件名规范（KubeJS 会拒绝大写与非法字符）
 *   6. 报告找到的 Java 版本，1.21.1 需要 Java 21
 *
 * 用法:
 *   node tools/preflight.mjs
 *   node tools/preflight.mjs --instance "D:\\path\\to\\镜维度"
 * =====================================================================
 */

import { readdirSync, readFileSync, existsSync, statSync } from 'node:fs';
import { dirname, join, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { inflateRawSync } from 'node:zlib';

const HERE = dirname(fileURLToPath(import.meta.url));
let INSTANCE = resolve(HERE, '..');
const argv = process.argv.slice(2);
const iFlag = argv.indexOf('--instance');
if (iFlag !== -1 && argv[iFlag + 1]) INSTANCE = resolve(argv[iFlag + 1]);

/* ------------------------------------------------------------------ */
/* 极简 ZIP 读取：只取我们需要的条目，不引第三方依赖                      */
/* ------------------------------------------------------------------ */

function readZipEntries(zipPath) {
  const buf = readFileSync(zipPath);
  // 从尾部找 End of Central Directory (0x06054b50)
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i > buf.length - 65558; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd === -1) throw new Error('不是合法的 zip/jar');

  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);

  const entries = new Map();
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) break;
    const method = buf.readUInt16LE(off + 10);
    const compSize = buf.readUInt32LE(off + 20);
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    const localOff = buf.readUInt32LE(off + 42);
    const name = buf.toString('utf8', off + 46, off + 46 + nameLen);

    entries.set(name, { method, compSize, localOff });
    off += 46 + nameLen + extraLen + commentLen;
  }

  return {
    names: [...entries.keys()],
    read(name) {
      const e = entries.get(name);
      if (!e) return null;
      // 本地文件头长度不固定，必须重新读
      const lhNameLen = buf.readUInt16LE(e.localOff + 26);
      const lhExtraLen = buf.readUInt16LE(e.localOff + 28);
      const dataStart = e.localOff + 30 + lhNameLen + lhExtraLen;
      const raw = buf.subarray(dataStart, dataStart + e.compSize);
      return e.method === 0 ? raw : inflateRawSync(raw);
    },
  };
}

/* ------------------------------------------------------------------ */
/* 版本号比较：支持 "1.21.1"、"21.1.250"、"2101.7.2-build.377" 这类串      */
/* ------------------------------------------------------------------ */

function parseVersion(v) {
  const s = String(v).trim();
  // 取主版本数字段 + 可选的 build/maven 限定符
  const m = s.match(/^(\d+(?:\.\d+)*)(?:[-+.](.*))?$/);
  if (!m) return { nums: [], qualifier: s };
  return {
    nums: m[1].split('.').map((x) => parseInt(x, 10)),
    qualifier: m[2] ?? '',
  };
}

function cmpVersion(a, b) {
  const A = parseVersion(a), B = parseVersion(b);
  const len = Math.max(A.nums.length, B.nums.length);
  for (let i = 0; i < len; i++) {
    const x = A.nums[i] ?? 0, y = B.nums[i] ?? 0;
    if (x !== y) return x < y ? -1 : 1;
  }
  return 0;
}

/** 判断 version 是否落在 maven 风格区间里，例如 "[21.1.220,)" */
function inRange(version, range) {
  const r = String(range).trim();
  // "*" / "" 这类通配区间：装了就满足（例如 Pondus 对 cloth_config 写的是 "*"）
  if (r === '*' || r === '') return true;
  const m = r.match(/^([\[\(])\s*([^,\]\)]*)\s*(?:,\s*([^\]\)]*)\s*)?([\]\)])$/);
  if (!m) return null; // 区间语法不认识，交给调用方决定

  const [, open, loRaw, hiRaw, close] = m;
  const lo = loRaw?.trim() ?? '';
  const hi = hiRaw?.trim() ?? '';

  if (lo) {
    const c = cmpVersion(version, lo);
    if (open === '[' ? c < 0 : c <= 0) return false;
  }
  if (hi) {
    const c = cmpVersion(version, hi);
    if (close === ']' ? c > 0 : c >= 0) return false;
  }
  return true;
}

/* ------------------------------------------------------------------ */
/* 解析 neoforge.mods.toml（只取我们关心的字段，不做完整 TOML 解析）        */
/* ------------------------------------------------------------------ */

function parseModsToml(text) {
  // neoforge.mods.toml 里 [[mods]] 可以有多段；这里取第一段的 modId/version
  const modsBlocks = [...text.matchAll(/\[\[mods\]\]([\s\S]*?)(?=\n\s*\[\[|\n\s*\[[^[]|\s*$)/g)];
  const mods = modsBlocks.map((b) => ({
    modId: (b[1].match(/^\s*modId\s*=\s*"([^"]+)"/m) || [])[1] ?? '',
    version: (b[1].match(/^\s*version\s*=\s*"([^"]+)"/m) || [])[1] ?? '',
    displayName: (b[1].match(/^\s*displayName\s*=\s*"([^"]+)"/m) || [])[1] ?? '',
  })).filter((m) => m.modId);

  const deps = [...text.matchAll(/\[\[dependencies\.([^\]]+)\]\]([\s\S]*?)(?=\n\s*\[\[|\s*$)/g)]
    .map((d) => {
      const body = d[2];
      return {
        owner: d[1],
        modId: (body.match(/^\s*modId\s*=\s*"([^"]+)"/m) || [])[1] ?? '',
        range: (body.match(/^\s*version[Rr]ange\s*=\s*"([^"]*)"/m) || [])[1] ?? '',
        type: (body.match(/^\s*type\s*=\s*"([^"]*)"/m) || [])[1] ?? 'required',
        side: (body.match(/^\s*side\s*=\s*"([^"]*)"/m) || [])[1] ?? 'BOTH',
      };
    })
    .filter((d) => d.modId);

  return { mods, deps };
}

/* ------------------------------------------------------------------ */
/* 开始检查                                                            */
/* ------------------------------------------------------------------ */

const problems = [];
const warnings = [];
const notes = [];

// libraries/ 在 .minecraft 下，也就是实例目录的上两级
const LIB_ROOT = resolve(INSTANCE, '..', '..', 'libraries');

console.log('镜维度 · 启动前预检');
console.log('实例目录: ' + INSTANCE);
console.log('='.repeat(70));

/* --- 0. 实例完整性 -------------------------------------------------
 * 版本 JSON 有两种合法形态：
 *   A) 自包含（老 PCL 生成的）：一个 JSON 里含全部库 + clientVersion
 *   B) 继承式（官方安装器的形态）：
 *        versions/neoforge-21.1.250.json   ← { inheritsFrom: "1.21.1", ... }
 *        versions/1.21.1/1.21.1.json       ← 原版，提供 minecraft 客户端与资源索引
 * 官方安装器用的是 B。B 形态下 NeoForge 的库条目在 overlay 里，
 * javaVersion 等字段要从被继承的原版 JSON 取。
 * ------------------------------------------------------------------ */
const VERSIONS = resolve(INSTANCE, '..');
const versionJson = readdirSync(INSTANCE)
  .filter((f) => f.endsWith('.json'))
  .map((f) => join(INSTANCE, f))
  .find((p) => {
    try { return Array.isArray(JSON.parse(readFileSync(p, 'utf8')).libraries); } catch { return false; }
  });

let mcVersion = null, neoForgeVersion = null, javaRequirement = null;

if (!versionJson) {
  problems.push('实例目录下找不到版本 JSON（含 libraries 的那个），实例不完整');
} else {
  let vj = null;
  try {
    vj = JSON.parse(readFileSync(versionJson, 'utf8'));
  } catch (e) {
    problems.push('版本 JSON 解析失败: ' + e.message);
  }

  if (vj) {
    // NeoForge 版本的三种来源，按可靠性排序：
    //   1. arguments.game 里的 --fml.neoForgeVersion（官方安装器的形态）
    //   2. libraries 里的 net.neoforged:neoforge 条目（手工拼的形态）
    // 继承式版本 JSON **不会**把 neoforge 本体列进 libraries ——
    // 官方安装器不写它，靠启动器机制放进 classpath。所以不能只看 libraries。
    const g = vj.arguments?.game ?? [];
    for (let i = 0; i < g.length - 1; i++) {
      if (g[i] === '--fml.neoForgeVersion') { neoForgeVersion = String(g[i + 1]); break; }
    }
    const neo = (vj.libraries ?? []).find((l) => /^net\.neoforged:neoforge:/.test(l.name ?? ''));
    if (!neoForgeVersion && neo) neoForgeVersion = neo.name.split(':')[2];

    // 解析继承链
    let base = null;
    if (vj.inheritsFrom) {
      const basePath = join(VERSIONS, vj.inheritsFrom, `${vj.inheritsFrom}.json`);
      if (!existsSync(basePath)) {
        problems.push(`版本 JSON 声明 inheritsFrom:"${vj.inheritsFrom}"，但找不到 ${relative(VERSIONS, basePath)}`);
      } else {
        try { base = JSON.parse(readFileSync(basePath, 'utf8')); } catch (e) {
          problems.push('被继承的原版版本 JSON 解析失败: ' + e.message);
        }
      }
    }

    mcVersion = vj.clientVersion ?? base?.clientVersion ?? base?.id ?? vj.inheritsFrom ?? null;
    javaRequirement = vj.javaVersion?.majorVersion ?? base?.javaVersion?.majorVersion ?? null;

    // ---- 关键检查：打补丁的 NeoForge client 产物 ----
    // 官方安装器不会在任何 JSON 里引用它 —— FML 通过在 libraries/ 里按
    // maven 路径查找来定位。所以必须直接检查文件是否存在。
    // 少了它，mixin 会报 ClassNotFoundException: net.minecraft.*，
    // 游戏在 ModLauncher 阶段就死。
    if (neoForgeVersion) {
      const clientJar = join(LIB_ROOT, 'net/neoforged/neoforge', neoForgeVersion, `neoforge-${neoForgeVersion}-client.jar`);
      if (!existsSync(clientJar)) {
        problems.push(
          `缺少 NeoForge 的打补丁客户端产物:\n`
          + `        ${relative(LIB_ROOT, clientJar)}\n`
          + '      这会导致 ClassNotFoundException: net.minecraft.world.level.block.entity.BlockEntityType\n'
          + '      修复：用官方安装器重装（见 README 7.0 节），不要手工拼版本 JSON。'
        );
      } else {
        console.log(`[产物] 打补丁 client  ${(statSync(clientJar).size / 1048576).toFixed(2)} MB  OK`);
      }
      const uniJar = join(LIB_ROOT, 'net/neoforged/neoforge', neoForgeVersion, `neoforge-${neoForgeVersion}-universal.jar`);
      if (!existsSync(uniJar)) {
        problems.push(`缺少 NeoForge universal 产物: ${relative(LIB_ROOT, uniJar)}`);
      }
    }

    // 自包含形态下才需要检查库记录；继承式形态下由 overlay 提供
    if (!vj.inheritsFrom && !neoForgeVersion) {
      problems.push(
        '版本 JSON 是自包含形态，但没有 net.neoforged:neoforge 库条目 —— NeoForge 只装了一半。\n'
        + '      所有模组会一起报 "Missing or unsupported mandatory dependencies"。\n'
        + '      修复：让启动器重装 NeoForge（见 README 7.0 节）。'
      );
    }

    // ---- 检查版本 jar 是不是「未打补丁的原版客户端」 ----
    // 这是本项目遇到过的真实故障：启动器把原版混淆客户端直接当版本 jar，
    // Minecraft 类不在 classpath 上，mixin 于是在极早期报
    // ClassNotFoundException: net.minecraft.world.level.block.entity.BlockEntityType。
    // 判别特征：NeoForge 的 patch 产物里 net/minecraft 类很少（约 1.5k），
    // 而真正的版本 jar 要么是补丁产物，要么至少得含完整的 Minecraft 类。
    const versionJar = join(INSTANCE, '镜维度.jar');
    if (existsSync(versionJar) && !vj.inheritsFrom) {
      let mcClasses = -1;
      try {
        const z = readZipEntries(versionJar);
        mcClasses = z.names.filter((n) => n.startsWith('net/minecraft/') && n.endsWith('.class')).length;
      } catch { /* 读不了就算了 */ }

      if (mcClasses === 0) {
        problems.push(
          '版本 jar 里连一个 net/minecraft 类都没有 —— 这不可能启动。\n'
          + '      实例很可能指向了错误的 jar。'
        );
      } else if (mcClasses > 0 && mcClasses < 400) {
        problems.push(
          `版本 jar 只含 ${mcClasses} 个 net/minecraft 类。\n`
          + '      这看起来是 NeoForge 的【补丁增量】或【反混淆输入】，不是可运行的版本 jar。\n'
          + '      症状会是 ClassNotFoundException: net.minecraft.world.level.block.entity.BlockEntityType。\n'
          + '      修复：让启动器重装 NeoForge（见 README 7.0 节）。'
        );
      } else {
        console.log(`[产物] 版本 jar  net/minecraft 类 ${mcClasses} 个  OK`);
      }
    }

    // 资源索引（继承式形态下由原版提供）
    const assetIdx = vj.assetIndex?.id ?? base?.assetIndex?.id;
    if (assetIdx && !existsSync(join(INSTANCE, '..', '..', 'assets', 'indexes', `${assetIdx}.json`))) {
      warnings.push(`找不到资源索引 assets/indexes/${assetIdx}.json`);
    }
  }
}

console.log(`\n[实例] Minecraft ${mcVersion ?? '?'}  /  NeoForge ${neoForgeVersion ?? '缺失'}`
  + (versionJson && JSON.parse(readFileSync(versionJson, 'utf8')).inheritsFrom ? '（继承式版本 JSON）' : ''));

/* --- 1. 扫描 mods -------------------------------------------------- */
const modsDir = join(INSTANCE, 'mods');
const installed = new Map();   // modId -> {version, file}
const allDeps = [];
let jarCount = 0;

if (!existsSync(modsDir)) {
  problems.push('找不到 mods 目录: ' + modsDir);
} else {
  for (const f of readdirSync(modsDir).filter((x) => x.toLowerCase().endsWith('.jar'))) {
    const full = join(modsDir, f);
    jarCount++;
    let zip;
    try {
      zip = readZipEntries(full);
    } catch (e) {
      problems.push(`${f}: 无法读取 jar（${e.message}）`);
      continue;
    }

    const tomlName = zip.names.find((n) => n === 'META-INF/neoforge.mods.toml')
      ?? zip.names.find((n) => n === 'META-INF/mods.toml');
    if (!tomlName) {
      warnings.push(`${f}: 没有 META-INF/neoforge.mods.toml，可能不是 NeoForge 模组`);
      continue;
    }

    const text = zip.read(tomlName).toString('utf8');
    const { mods, deps } = parseModsToml(text);
    if (!mods.length) {
      warnings.push(`${f}: mods.toml 里没有解析到 modId`);
      continue;
    }
    for (const m of mods) {
      installed.set(m.modId, { version: m.version, file: f });
      console.log(`[模组] ${m.modId.padEnd(24)} ${m.version.padEnd(26)} ${f}`);

      /* 自家 jar 的"文件名版本"必须等于 mods.toml 里声明的版本。
       * 实测踩过：build.gradle 升到 0.3、mods.toml 里还手写着 0.2，
       * 于是 jar 叫 mirrorside-0.3.jar、游戏里却显示 0.2 —— 排查问题时会
       * 以为装错了 jar。现在 mods.toml 写 ${version} 由构建填入，这条检查是兜底。
       * ⚠️ 只查自家 jar：第三方 jar 的文件名版本片段五花八门
       *    （jei-1.21.1-neoforge-19.51.0.418.jar 里的 1.21.1 是 MC 版本），
       *    泛化会刷出一堆假问题。 */
      if (/^(mirrorside|mirrorgravity)-/.test(f)) {
        const fv = (f.match(/(\d+\.\d+(?:\.\d+)?)/) || [])[1];
        if (fv && m.version && fv !== m.version) {
          problems.push(`${f}: 文件名里的版本 ${fv} 与 mods.toml 声明的 ${m.version} 不一致`
            + '（mods.toml 应写 version = "${version}"，由 build.gradle 填入）');
        }
      }
    }

    /* jarJar：NeoForge 允许模组把自己的依赖（jar-in-jar）打进 jar 里，
     * 运行时由 JarJar 加载，因此这类依赖**不需要**单独放进 mods/。
     * 例如 pondus-1.0.1.jar 内嵌 cloth-config-neoforge-15.0.140。
     * 不看这里就会把 cloth_config 误报成「未安装」。
     * 映射规则：artifact "cloth-config-neoforge" -> modId "cloth_config"。
     * 判据取 metadata.json 里的 artifact / artifactVersion。 */
    const jarJarName = zip.names.find((n) => n === 'META-INF/jarjar/metadata.json');
    if (jarJarName) {
      /* jarJar 的 artifact 常常带加载器后缀（cloth-config-neoforge），
       * 而依赖声明用的是纯 modId（cloth_config）。所以除了原样归一化，
       * 再去掉一层加载器后缀作为别名一起登记。 */
      const withAliases = (modId) => {
        const out = [modId];
        const stripped = modId.replace(/_(neoforge|forge|fabric|quilt|common)$/, '');
        if (stripped !== modId) out.push(stripped);
        return out;
      };
      /* ⚠️ 这些名字**不是内嵌模组**，是运行环境本身。
       * Sodium 的 jarJar 元数据里就登记了它依赖的 neoforge，版本号写的是
       * Sodium 自己的版本（0.8.13+mc1.21.1）—— 早先照单全收，
       * 结果 installed 里多出一条 `neoforge = 0.8.13+mc1.21.1`，
       * 把虚拟的 NeoForge 版本覆盖掉，于是所有模组的 neoforge 依赖区间
       * 都被判成"版本不满足"，一次性刷出一堆假问题。
       * 判据：这些 id 的版本由实例（版本 JSON）提供，内嵌的一律忽略。 */
      const ENV_IDS = new Set([
        'neoforge', 'forge', 'minecraft', 'java', 'fml',
        'fabricloader', 'fabric_loader', 'fabric', 'quilt_loader', 'quilt',
      ]);
      try {
        const meta = JSON.parse(zip.read(jarJarName).toString('utf8'));
        for (const j of (meta.jars || [])) {
          const src = j.identifier || {};
          const artifact = src.artifact || src.path || '';
          const key = String(artifact).toLowerCase().replace(/-/g, '_');
          const ver = (j.version && (j.version.artifactVersion
            || (j.version.range || '').replace(/[[\]()]/g, '').split(',')[0])) || '';
          if (!key) continue;
          if (ENV_IDS.has(key)) continue;   // 运行环境，不是内嵌模组
          for (const modId of withAliases(key)) {
            // 已单独安装的同名模组优先，不要被内嵌版本覆盖
            if (installed.has(modId)) continue;
            if (ENV_IDS.has(modId)) continue;
            installed.set(modId, { version: ver, file: `${f} (jarJar 内嵌)` });
            console.log(`[模组] ${modId.padEnd(24)} ${String(ver).padEnd(26)} ${f} [jarJar 内嵌]`);
          }
        }
      } catch (e) {
        warnings.push(`${f}: 解析 META-INF/jarjar/metadata.json 失败（${e.message}）`);
      }
    }

    for (const d of deps) allDeps.push({ ...d, file: f });
  }
}

/* --- 2. 依赖满足性 -------------------------------------------------- */
console.log('\n[依赖核对]');
// neoforge / minecraft 是隐式的，用实例里读到的版本代入
const virtual = new Map();
if (neoForgeVersion) virtual.set('neoforge', neoForgeVersion);
if (mcVersion) virtual.set('minecraft', mcVersion);

const required = allDeps.filter((d) => d.type === 'required');
if (!required.length) console.log('  （没有声明 required 依赖）');

for (const d of required) {
  const inst = installed.get(d.modId) ?? virtual.get(d.modId);
  const label = `${d.modId} ${d.range || '(未写区间)'}`.padEnd(40);

  if (!inst) {
    problems.push(`缺少必需依赖 ${d.modId} ${d.range}（由 ${d.file} 声明）`);
    console.log(`  ✗ ${label} 未安装   ← ${d.file}`);
    continue;
  }
  if (!d.range) {
    console.log(`  · ${label} 已满足 (${inst.version ?? inst})`);
    continue;
  }
  const ok = inRange(inst.version ?? inst, d.range);
  if (ok === null) {
    warnings.push(`${d.file} 对 ${d.modId} 的版本区间 "${d.range}" 无法解析，跳过核对`);
    console.log(`  ? ${label} 区间语法不认识`);
  } else if (ok) {
    console.log(`  ✓ ${label} 已满足 (${inst.version ?? inst})`);
  } else {
    problems.push(`依赖版本不满足: ${d.modId} 需要 ${d.range}，实际 ${inst.version ?? inst}（由 ${d.file} 声明）`);
    console.log(`  ✗ ${label} 实际 ${inst.version ?? inst}   ← ${d.file}`);
  }
}

/* --- 3. 维度数据包文件 ---------------------------------------------- */
console.log('\n[维度数据包]');

/* 标签目录命名检查。
 * ⚠️ 1.21 里实体类型的标签目录是**单数** tags/entity_type/，
 *    而不是 tags/entity_types/。写错的话标签会被静默忽略 ——
 *    没有报错、没有警告，只是那个标签"从来不生效"。
 *    Pondus 自己就踩了这个坑（它的 allowed_special 用了复数路径），
 *    导致所有非生物实体的重力反转被静默拒绝，排查了很久。
 *    所以这里显式检查一遍 KubeJS data 下的标签目录。 */
{
  const tagsRoot = join(INSTANCE, 'kubejs', 'data');
  const badPlural = ['entity_types', 'blocks', 'items', 'fluids', 'biomes'];
  let tagCount = 0;
  if (existsSync(tagsRoot)) {
    const walk = (dir, rel) => {
      let items = [];
      try { items = readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const it of items) {
        const r = rel ? rel + '/' + it.name : it.name;
        if (it.isDirectory()) {
          if (badPlural.includes(it.name)) {
            problems.push(
              `标签目录用了复数 "${r}" —— 1.21 要求单数（如 entity_type）。`
              + ' 标签会被静默忽略，不会报错。');
            console.log(`  ✗ 标签目录命名错误: ${r}（应为单数）`);
          } else {
            walk(join(dir, it.name), r);
          }
        } else if (it.name.endsWith('.json') && r.includes('/tags/')) {
          tagCount++;
          console.log(`  ✓ 标签 ${r}`);
        }
      }
    };
    walk(tagsRoot, '');
  }
  if (tagCount === 0) {
    console.log('  （没有找到任何标签文件——如果用了标签，请检查路径含 /tags/）');
  }
}
const cfgPath = join(INSTANCE, 'kubejs', 'config', 'mirror_dimension.json');
let cfg = null;
if (!existsSync(cfgPath)) {
  problems.push('缺少配置文件 kubejs/config/mirror_dimension.json');
} else {
  try {
    cfg = JSON.parse(readFileSync(cfgPath, 'utf8').replace(/^\uFEFF/, ''));
    console.log(`  配置 OK — 命名空间 ${cfg.namespace}`);
  } catch (e) {
    problems.push('配置文件不是合法 JSON: ' + e.message);
  }
}

// 命名空间/各路径以运行时配置（mirror_config.js）为权威 —— 生成器也是这么做的。
// 否则「改了 JS 没改 JSON」会让预检报出与实际情况不符的缺失/不匹配。
{
  const rtPath = join(INSTANCE, 'kubejs', 'startup_scripts', 'mirror_config.js');
  if (existsSync(rtPath)) {
    const src = readFileSync(rtPath, 'utf8');
    const grab = (key) => {
      const m = src.match(new RegExp(`\\b${key}\\s*:\\s*'([^']+)'`));
      return m ? m[1] : null;
    };
    if (cfg) {
      for (const k of ['namespace', 'dimension_path', 'dimension_type_path', 'biome_path']) {
        const v = grab(k);
        if (v && cfg[k] !== v) {
          console.log(`  （${k} 以 mirror_config.js 为准：JSON=${cfg[k]} -> JS=${v}）`);
          cfg[k] = v;
        }
      }
    }
  }
}

let dimensionId = null;
if (cfg) {
  const ns = cfg.namespace;
  dimensionId = `${ns}:${cfg.dimension_path}`;
  const wanted = [
    ['dimension_type', join(INSTANCE, 'kubejs', 'data', ns, 'dimension_type', cfg.dimension_type_path + '.json')],
    ['worldgen/biome', join(INSTANCE, 'kubejs', 'data', ns, 'worldgen', 'biome', cfg.biome_path + '.json')],
    ['dimension', join(INSTANCE, 'kubejs', 'data', ns, 'dimension', cfg.dimension_path + '.json')],
  ];
  for (const [label, p] of wanted) {
    if (!existsSync(p)) {
      problems.push(`${label} 文件缺失: ${relative(INSTANCE, p)}（跑一次 tools 里的生成器）`);
      console.log(`  ✗ ${label.padEnd(16)} 缺失`);
      continue;
    }
    try {
      JSON.parse(readFileSync(p, 'utf8').replace(/^\uFEFF/, ''));
      console.log(`  ✓ ${label.padEnd(16)} OK  (${statSync(p).size} B)`);
    } catch (e) {
      problems.push(`${label} JSON 语法错误: ${e.message}`);
      console.log(`  ✗ ${label.padEnd(16)} JSON 语法错误`);
    }
  }

  // 交叉引用检查：dimension.type 必须指向存在的 dimension_type
  const dimFile = join(INSTANCE, 'kubejs', 'data', ns, 'dimension', cfg.dimension_path + '.json');
  if (existsSync(dimFile)) {
    try {
      const d = JSON.parse(readFileSync(dimFile, 'utf8'));
      const expectedType = `${ns}:${cfg.dimension_type_path}`;
      if (d.type !== expectedType) {
        problems.push(`dimension 的 type 是 "${d.type}"，但期望 "${expectedType}"`);
      } else {
        console.log(`  ✓ dimension.type -> ${d.type}`);
      }
      const bs = d.generator?.biome_source;
      const expectedBiome = `${ns}:${cfg.biome_path}`;
      if (bs?.biome && bs.biome !== expectedBiome) {
        problems.push(`dimension 的 biome_source.biome 是 "${bs.biome}"，但期望 "${expectedBiome}"`);
      }
    } catch { /* 上面已经报过语法错误 */ }
  }

  /* ---- worldgen/noise_settings 的字段类型校验 ---- */
  /* 本项目在这里崩溃过一次（创建/进入世界时直接 crash）：
   *   1. surface_rule 写成数组 -> "Not a JSON object: []"
   *   2. density_function 用 {"type":"minecraft:constant","value":0}
   *      -> "Not a number" / "No key argument in MapLike[...]"
   * 裸数字才是常数密度函数的稳妥写法（原版 end.json 大量这么用）。
   * 这条校验把这两类错误拦在启动之前。
   */
  const nsDir = join(INSTANCE, 'kubejs', 'data', ns, 'worldgen', 'noise_settings');
  if (existsSync(nsDir)) {
    for (const f of readdirSync(nsDir).filter((x) => x.endsWith('.json'))) {
      const p = join(nsDir, f);
      let ns2 = null;
      try { ns2 = JSON.parse(readFileSync(p, 'utf8').replace(/^\uFEFF/, '')); } catch { continue; }
      const label = `noise_settings/${f}`;

      if (ns2.surface_rule != null) {
        const sr = ns2.surface_rule;
        if (Array.isArray(sr) || typeof sr !== 'object') {
          problems.push(
            `${label}: surface_rule 必须是对象（RuleSource），当前是 ${Array.isArray(sr) ? '数组' : typeof sr}。\n`
            + '      这会让维度注册表加载失败并崩溃：Not a JSON object\n'
            + '      正确写法例：{"type":"minecraft:block","result_state":{"Name":"minecraft:air"}}'
          );
        }
      }

      if (ns2.noise_router != null) {
        for (const [k, v] of Object.entries(ns2.noise_router)) {
          // 合法：裸数字，或带 type 的对象
          const ok = typeof v === 'number'
            || (v !== null && typeof v === 'object' && !Array.isArray(v) && typeof v.type === 'string');
          if (!ok) {
            problems.push(
              `${label}: noise_router.${k} 类型非法（${JSON.stringify(v)}）。\n`
              + '      用裸数字表示常数密度函数最稳；用对象必须是 {"type":"...", ...} 形式。'
            );
          }
        }
      }

      if (ns2.noise != null && cfg) {
        // noise 的 min_y/height 必须与 dimension_type 对齐
        const dtP = join(INSTANCE, 'kubejs', 'data', ns, 'dimension_type', cfg.dimension_type_path + '.json');
        if (existsSync(dtP)) {
          const dt2 = JSON.parse(readFileSync(dtP, 'utf8'));
          if (ns2.noise.min_y !== dt2.min_y || ns2.noise.height !== dt2.height) {
            problems.push(
              `${label}: noise.min_y/height (${ns2.noise.min_y}/${ns2.noise.height})`
              + ` 与 dimension_type (${dt2.min_y}/${dt2.height}) 不一致，底部或顶部会露虚空。`
            );
          }
        }
      }
      console.log(`  ✓ ${label.padEnd(30)} 字段类型 OK`);
    }
  }

  /* ---- 地物交叉引用校验 ---- */
  /* 玻璃层是 configured_feature(fill_layer) + placed_feature，再由 biome.features 引用。
   * 三者任一断链，游戏只在区块生成时静默地不铺玻璃 —— 很难察觉。
   */
  const cfgFeatDir = join(INSTANCE, 'kubejs', 'data', ns, 'worldgen', 'configured_feature');
  const plFeatDir = join(INSTANCE, 'kubejs', 'data', ns, 'worldgen', 'placed_feature');
  const biomeFile = join(INSTANCE, 'kubejs', 'data', ns, 'worldgen', 'biome', cfg.biome_path + '.json');

  if (existsSync(plFeatDir) || existsSync(cfgFeatDir)) {
    const cfgNames = existsSync(cfgFeatDir)
      ? readdirSync(cfgFeatDir).filter((f) => f.endsWith('.json')).map((f) => f.replace('.json', ''))
      : [];
    const plNames = existsSync(plFeatDir)
      ? readdirSync(plFeatDir).filter((f) => f.endsWith('.json')).map((f) => f.replace('.json', ''))
      : [];

    // placed -> configured
    for (const f of plNames) {
      let j = null;
      try { j = JSON.parse(readFileSync(join(plFeatDir, f + '.json'), 'utf8')); } catch { continue; }
      const target = String(j.feature || '').replace(`${ns}:`, '');
      if (target && !cfgNames.includes(target)) {
        problems.push(`${ns}:${f}（placed_feature）指向不存在的 configured_feature "${j.feature}"`);
      }
    }

    // biome -> placed
    if (existsSync(biomeFile)) {
      let bj = null;
      try { bj = JSON.parse(readFileSync(biomeFile, 'utf8')); } catch { /* 上面报过 */ }
      if (bj && Array.isArray(bj.features)) {
        const refs = bj.features.flat().map((x) => String(x).replace(`${ns}:`, ''));
        for (const r of refs) {
          if (!plNames.includes(r)) {
            problems.push(`biome "${cfg.biome_path}" 引用了不存在的 placed_feature "${ns}:${r}"`);
          }
        }
        // 反过来：有 placed_feature 却没被任何群系引用 → 那份玻璃永远不会生成
        const orphan = plNames.filter((p) => !refs.includes(p));
        if (orphan.length) {
          warnings.push(`这些 placed_feature 没有被群系引用，对应玻璃层不会生成: ${orphan.join(', ')}`);
        }
        console.log(`  ✓ 地物链 OK — ${cfgNames.length} configured / ${plNames.length} placed，群系引用 ${refs.length} 个`);
      }
    }
  }
}

/* --- 4. KubeJS 文件名规范 ------------------------------------------- */
console.log('\n[KubeJS 文件名规范]');
const dataRoot = cfg ? join(INSTANCE, 'kubejs', 'data') : null;
if (dataRoot && existsSync(dataRoot)) {
  let bad = 0;
  const walk = (dir) => {
    for (const f of readdirSync(dir, { withFileTypes: true })) {
      const p = join(dir, f.name);
      if (f.isDirectory()) { walk(p); continue; }
      // KubeJS 的 scanForInvalidFiles 会拒绝大写、非 [a-z0-9_.-] 的字符
      if (/[A-Z]/.test(f.name)) { problems.push(`文件名含大写字母（KubeJS 会强制小写化或报错）: ${relative(INSTANCE, p)}`); bad++; }
      if (!/^[a-z0-9_.\-]+$/.test(f.name)) { problems.push(`文件名含非法字符: ${relative(INSTANCE, p)}`); bad++; }
    }
  };
  walk(dataRoot);
  console.log(bad === 0 ? '  ✓ 全部为小写且字符合法' : `  ✗ 发现 ${bad} 个问题文件`);
}

/* --- 5. Java ------------------------------------------------------- */
console.log('\n[Java]');
if (javaRequirement) {
  console.log(`  版本 JSON 要求: Java ${javaRequirement}`);
}

/** 用 spawnSync 读 java -version（它写 stderr 且退出码为 0，execFileSync 处理不好） */
function probeJava(exe) {
  const r = spawnSync(exe, ['-version'], { encoding: 'utf8' });
  const text = (r.stderr ?? '') + (r.stdout ?? '');
  const m = text.match(/version "(\d+)(?:\.(\d+))?/);
  if (!m) return null;
  return { major: parseInt(m[1], 10), text: `Java ${m[1]}${m[2] ? '.' + m[2] : ''}` };
}

// 优先用实例旁边常见的 JDK，再看 PATH
const candidates = [
  ['D:\\App\\java21\\bin\\java.exe', 'D:\\App\\java21'],
  ['java', 'PATH 上的默认 java'],
];
let goodJava = false;
for (const [exe, label] of candidates) {
  const v = probeJava(exe);
  if (v) {
    const ok = javaRequirement ? v.major === javaRequirement : v.major >= 17;
    console.log(`  ${ok ? '✓' : ' '} ${label.padEnd(22)} ${v.text}`);
    if (ok) goodJava = true;
  }
}
if (javaRequirement && !goodJava) {
  warnings.push(`没探测到 Java ${javaRequirement}。Minecraft ${mcVersion ?? '1.21.1'} 需要 Java ${javaRequirement}；`
    + '请在 PCL 的「设置 → 启动 → Java 路径」里指向 D:\\App\\java21');
}
notes.push('PCL 实际用哪个 Java 由启动器设置决定，上面的探测只反映命令行可见的 java。');


/* --- 汇总 ---------------------------------------------------------- */
console.log('\n' + '='.repeat(70));
if (warnings.length) {
  console.log('\n警告:');
  for (const w of warnings) console.log('  ! ' + w);
}
if (problems.length) {
  console.log('\n发现 ' + problems.length + ' 个问题:');
  for (const p of problems) console.log('  ✗ ' + p);
  console.log('');
  process.exit(1);
} else {
  console.log('\n✓ 静态检查全部通过。');
  if (dimensionId) console.log(`  进入方式: /execute in ${dimensionId} run tp @s 0 128 0`);
  console.log('');
  process.exit(0);
}
