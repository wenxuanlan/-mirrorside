package work.dsh.mirror.gravity;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;

/**
 * 镜维度 · 站在传送门里时的**渐现遮罩**（纯客户端）。
 *
 * <h2>要解决的问题</h2>
 * 玩家站进传送门之后要等 {@code getPortalTransitionTime} 那么久才会被传走
 * （默认 80 tick = 4 秒）。这期间如果画面毫无变化，玩家不知道
 * "我到底进来了没有 / 还要站多久"。
 *
 * <h2>做法：照抄原版地狱门遮罩那一套，只把贴图换成我们自己的</h2>
 * 原版是这样做的（1.21.1 源码）：
 * <pre>
 *   // LocalPlayer#tick
 *   handleConfusionTransitionEffect(getActivePortalLocalTransition() == Portal.Transition.CONFUSION);
 *   //   → spinningEffectIntensity 在门里每 tick +0.0125、离开每 tick -0.05（夹 0~1）
 *   // Gui#renderFrame
 *   if (intensity > 0 && !player.hasEffect(CONFUSION)) renderPortalOverlay(gui, intensity);
 *   // Gui#renderPortalOverlay
 *   intensity = intensity⁴ * 0.8 + 0.2;                       // 前段压暗、后段迅速拉满
 *   setColor(1,1,1,intensity);
 *   blit(0, 0, -90, guiWidth, guiHeight, sprite);            // 铺满全屏
 * </pre>
 *
 * <p>三点原版细节值得照抄，所以这里全部沿用：
 * <ol>
 *   <li><b>强度曲线</b>：0.0125 / tick 上升正好 80 tick 到满 ——
 *       与传送门的等待时间同源，玩家看到遮罩铺满时就是快传走的时候。</li>
 *   <li><b>alpha 曲线</b>：{@code a⁴ × 0.8 + 0.2}，前期几乎看不出、
 *       后期迅速变实，不会一进就糊住屏幕。</li>
 *   <li><b>用方块模型的 particleIcon 当贴图</b>：它在方块图集里，
 *       所以**动态贴图会自己动**（直接 blit 一张独立 PNG 是不会动的，
 *       独立纹理走的是 SimpleTexture，没有动画）。</li>
 * </ol>
 *
 * <h2>为什么不直接用原版的 CONFUSION</h2>
 * 返回 {@code CONFUSION} 确实能白拿上面这套，但那样遮罩会渲染**地狱门的
 * 紫色贴图**（原版把 {@code Blocks.NETHER_PORTAL} 写死在
 * {@code Gui#renderPortalOverlay} 里），而且会附带屏幕扭曲。
 * 设定要的是"用这个传送门方块的贴图"，所以这里自己画一遍 ——
 * 强度节奏沿用原版，贴图与效果换成我们自己的。
 *
 * <h2>怎么判断"玩家站在我们的门里"</h2>
 * ⚠️ **不能用客户端侧的 {@code PortalProcessor}** —— 踩过这个坑：
 * 那个对象的清理由 {@code Entity#handlePortal} 负责，而 {@code handlePortal}
 * 的第一行是 {@code if (this.level() instanceof ServerLevel)} ——
 * 也就是**只在服务端清理**。客户端那份一旦被 {@code entityInside} 建出来，
 * 玩家离开后它仍然存在（entryPosition 还指向门方块，方块也还在），
 * 于是"在门里"的判断恒为真，遮罩再也退不掉。
 *
 * <p>所以改成**直接按包围盒查方块**：取玩家包围盒覆盖的方块范围
 * （与原版 {@code Entity#checkInsideBlocks} 用的范围完全一致），
 * 其中有我们的传送门就算在门里。这样客户端的表现与服务端的触发条件
 * 严格同源，进门开始浮现、出门立刻回落。
 */
@EventBusSubscriber(modid = MirrorGravity.MOD_ID,
    bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class MirrorPortalOverlay {

    private MirrorPortalOverlay() {
    }

    /** 原版的上升速率：0.0125 / tick → 80 tick 到满。 */
    private static final float RISE_PER_TICK = 0.0125F;

    /** 原版的衰减速率：0.05 / tick → 20 tick 退干净。 */
    private static final float FALL_PER_TICK = 0.05F;

    private static float intensity = 0.0F;
    private static float oIntensity = 0.0F;

    /** 客户端每 tick：判断是否在门里，按原版速率升/降强度。 */
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        oIntensity = intensity;
        if (player == null || mc.level == null) {
            intensity = 0.0F;
            return;
        }
        boolean inside = isInsideMirrorPortal(player);
        intensity = Mth.clamp(intensity + (inside ? RISE_PER_TICK : -FALL_PER_TICK), 0.0F, 1.0F);
    }

    /**
     * 玩家包围盒覆盖的方块里有没有我们的传送门。
     *
     * <p>采样范围与原版 {@code Entity#checkInsideBlocks} 一致
     * （就是它决定服务端会不会调 {@code entityInside}），所以两端的
     * "在不在门里"是同一个判据。
     */
    private static boolean isInsideMirrorPortal(LocalPlayer player) {
        try {
            net.minecraft.world.phys.AABB box = player.getBoundingBox();
            BlockPos min = BlockPos.containing(box.minX + 1.0E-7D, box.minY + 1.0E-7D, box.minZ + 1.0E-7D);
            BlockPos max = BlockPos.containing(box.maxX - 1.0E-7D, box.maxY - 1.0E-7D, box.maxZ - 1.0E-7D);
            BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
            for (int x = min.getX(); x <= max.getX(); x++) {
                for (int y = min.getY(); y <= max.getY(); y++) {
                    for (int z = min.getZ(); z <= max.getZ(); z++) {
                        cursor.set(x, y, z);
                        if (player.level().getBlockState(cursor).is(MirrorBlocks.MIRROR_PORTAL.get())) {
                            return true;
                        }
                    }
                }
            }
        } catch (Throwable t) {
            return false;
        }
        return false;
    }

    /**
     * 每帧绘制遮罩。用 {@code RenderGuiEvent.Post}，也就是原版画完所有 HUD
     * 之后 —— 与地狱门遮罩同一层级。
     */
    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options != null && mc.options.hideGui) {
            return;   // F1 隐藏界面时也不该有遮罩
        }
        float alpha = currentAlpha(event.getPartialTick());
        if (alpha <= 0.001F) {
            return;
        }

        GuiGraphics gui = event.getGuiGraphics();

        /* 取我们方块模型的 particleIcon：它在方块图集里，
         * 所以贴图自带的 .mcmeta 动画会正常播放。 */
        TextureAtlasSprite sprite = mc.getBlockRenderer().getBlockModelShaper()
            .getParticleIcon(MirrorBlocks.MIRROR_PORTAL.get().defaultBlockState());

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        gui.setColor(1.0F, 1.0F, 1.0F, alpha);
        gui.blit(0, 0, -90, gui.guiWidth(), gui.guiHeight(), sprite);
        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        gui.setColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    /**
     * 插值 + 原版那条 alpha 曲线。
     *
     * @param partialTick 帧间插值用的 DeltaTracker（原版拿它插值强度）
     */
    private static float currentAlpha(net.minecraft.client.DeltaTracker partialTick) {
        float f = Mth.lerp(partialTick.getGameTimeDeltaPartialTick(false), oIntensity, intensity);
        if (f <= 0.0F) {
            return 0.0F;
        }
        float a = f;
        if (a < 1.0F) {
            a = a * a;
            a = a * a;
            a = a * 0.8F + 0.2F;
        }
        return a;
    }
}
