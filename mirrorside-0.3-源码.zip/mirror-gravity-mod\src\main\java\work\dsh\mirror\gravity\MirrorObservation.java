package work.dsh.mirror.gravity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import work.dsh.mirror.gravity.internal.Failures;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 镜维度 · 波粒观测（多方块结构 + 右键加工）。
 *
 * <h2>玩法</h2>
 * 玩家用结构方块搭出「波粒观测」：四个波粒块围住中间那一格，中间放**要观测的方块**，
 * 拿望远镜右键它就完成一次加工 —— 方块→方块 / 方块→物品 / 方块→实体。
 * 等价于"把引力配方手动跑一遍"，不需要真的把它扔下去。
 *
 * <h2>为什么判定与写世界在模组里，而"什么变成什么"在脚本里</h2>
 * 这是本项目的分工线（见开发日志「模块与职责」）：
 * <ul>
 *   <li><b>模组</b>：结构判定、方块属性搬运、生成实体/掉落物 —— 这些必须贴着
 *       {@link BlockState}、{@link Property}、{@code EntityType} 走，
 *       Rhino 里写不出来或者写出来极易踩 API 的坑。</li>
 *   <li><b>KubeJS</b>：配方表（唯一真相在 {@code mirror_config.js}）与右键事件。</li>
 * </ul>
 * 所以本类只认一个动作描述（JSON），不认任何配方：
 * <pre>
 *   {"type":"block","id":"minecraft:gold_block"}          变成方块（尽量保留朝向等属性）
 *   {"type":"item","stack":"{...物品堆 JSON...}"}          原方块消失、弹出物品
 *   {"type":"item","id":"minecraft:nether_wart"}          同上（只给 id 也行）
 *   {"type":"entity","id":"minecraft:allay"}              原方块消失、生成实体
 *   {"type":"recolor","family":"wool"}                    换成同族**另一种颜色**
 * </pre>
 *
 * <h2>结构为什么是"推"进来的</h2>
 * 结构与配色表都由脚本在启动时推送（{@code mirror_config.js} → {@code MG_API.setObservationPattern}），
 * 本类里那份只是**兜底默认值** —— 项目规矩是"配置是唯一真相，模组只接收"。
 * 这里的默认值就是用户用结构方块搭的 boli1，与配置里的生成区完全一致
 * （由 {@code tools/inspect-structure.mjs} 从结构 NBT 直接导出，不靠手抄）。
 *
 * <h2>⚠️ 结构判定是"整座结构完全一致"（用户明确要求）</h2>
 * 三个 3×3×5 的包围盒里，boli1 里**有实体的 21 格**必须与结构完全一致；
 * 其余格子（包括中间靶心那一格、以及靶心正下方那一格）**放什么都行** ——
 * 靶心下那一格正是"接触配方"要用的位置（红沙 + 下面放荧石 → 荧石）。
 */
public final class MirrorObservation {

    private MirrorObservation() {
    }

    /* ------------------------------------------------------------------ */
    /* 结构定义                                                            */
    /* ------------------------------------------------------------------ */

    /** 结构里的一格：相对靶心的偏移 + 必须是哪个方块。 */
    private record Cell(int dx, int dy, int dz, Block block) {
    }

    /**
     * 一份结构定义。
     *
     * @param sx,sy,sz  包围盒尺寸（只为日志与旋转用）
     * @param cells     必须一致的格子（相对**靶心**的偏移）
     */
    private record Plot(int sx, int sy, int sz, List<Cell> cells) {
    }

    /**
     * 兜底结构 = boli1（用户用结构方块搭的「波粒观测」，21 格）。
     *
     * <p>坐标以靶心（中间那格，结构里的 (1,1,2)）为原点。下面这份是从
     * {@code saves/测试3/generated/minecraft/structures/boli1.nbt} 直接读出来的，
     * 逐格核对过（{@code tools-build/inspect-structure.mjs}）：
     * <ul>
     *   <li>4 个波粒块：靶心前后各两个（z = −2, −1, +1, +2）</li>
     *   <li>8 个荧石：四角立柱（x = −1 / +1，z = ±2）的上下三层</li>
     *   <li>8 个紫水晶母岩：上下三层里紧贴靶心的一圈（z = ±1）</li>
     *   <li>1 个小块紫水晶芽在 (−1,−1,−1) —— 整座结构里**唯一不对称**的一格</li>
     * </ul>
     *
     * <p>⚠️ 判定**只比方块种类、不比方块属性**：荧石有 {@code axis}、
     * 晶芽有 {@code facing/waterlogged}，属性取决于玩家摆放时的朝向，
     * 要求它们也一致会让"搭对了但方向不同"莫名其妙不生效。
     */
    private static Plot defaultPlot() {
        List<Cell> cells = new ArrayList<>();
        // 4 个波粒块
        add(cells, 0, 0, -2, "mirrorgravity:wave_particle_block");
        add(cells, 0, 0, -1, "mirrorgravity:wave_particle_block");
        add(cells, 0, 0, 1, "mirrorgravity:wave_particle_block");
        add(cells, 0, 0, 2, "mirrorgravity:wave_particle_block");
        // 8 个荧石（四角立柱的上下三层）
        add(cells, 0, -1, -2, "minecraft:verdant_froglight");
        add(cells, 0, -1, 2, "minecraft:verdant_froglight");
        add(cells, -1, 0, -2, "minecraft:verdant_froglight");
        add(cells, -1, 0, 2, "minecraft:verdant_froglight");
        add(cells, 1, 0, -2, "minecraft:verdant_froglight");
        add(cells, 1, 0, 2, "minecraft:verdant_froglight");
        add(cells, 0, 1, -2, "minecraft:verdant_froglight");
        add(cells, 0, 1, 2, "minecraft:verdant_froglight");
        // 8 个紫水晶母岩（紧贴靶心的一圈，上下三层）
        add(cells, 0, -1, -1, "minecraft:budding_amethyst");
        add(cells, 0, -1, 1, "minecraft:budding_amethyst");
        add(cells, -1, 0, -1, "minecraft:budding_amethyst");
        add(cells, -1, 0, 1, "minecraft:budding_amethyst");
        add(cells, 1, 0, -1, "minecraft:budding_amethyst");
        add(cells, 1, 0, 1, "minecraft:budding_amethyst");
        add(cells, 0, 1, -1, "minecraft:budding_amethyst");
        add(cells, 0, 1, 1, "minecraft:budding_amethyst");
        // 小块紫水晶芽（不对称的那一格）
        add(cells, -1, -1, -1, "minecraft:small_amethyst_bud");
        return new Plot(3, 3, 5, cells);
    }

    /** 波粒块本身：既在结构里，也是"是否值得做完整判定"的预筛依据。 */
    private static final Block WAVE_BLOCK = resolve("mirrorgravity:wave_particle_block");

    private static Block resolve(String fullId) {
        ResourceLocation rl = ResourceLocation.tryParse(fullId);
        if (rl == null || !BuiltInRegistries.BLOCK.containsKey(rl)) {
            return null;
        }
        return BuiltInRegistries.BLOCK.get(rl);
    }

    /**
     * 往结构里加一格。
     *
     * <p>⚠️ 必须写**完整 id**（含命名空间）。这里踩过一次：
     * 早先用 {@code ResourceLocation.withDefaultNamespace(path)} 拼 id，
     * 于是模组自己的 {@code mirrorgravity:wave_particle_block} 被拼成了
     * {@code minecraft:wave_particle_block} —— 查不到，而当时的写法是"查不到就跳过"，
     * 结果**兜底结构里一个波粒块都没有**，而且一声不响。
     * 现在查不到会打一条 WARN，不再静默。
     */
    private static void add(List<Cell> cells, int dx, int dy, int dz, String fullId) {
        Block block = resolve(fullId);
        if (block == null) {
            MirrorGravity.LOGGER.warn("[镜维度·波粒观测] 兜底结构里的方块不存在，已跳过: {}", fullId);
            return;
        }
        cells.add(new Cell(dx, dy, dz, block));
    }

    private static volatile Plot plot = defaultPlot();
    private static volatile boolean pushed = false;

    /** {@link #matchingQuarter} 的两种"不成立"：连波粒块都没有 / 有但不构成结构。 */
    private static final int NO_WAVE_BLOCKS = -2;
    private static final int BAD_PATTERN = -1;

    /**
     * 某个位置上的方块**是否属于**给定的一批标签，返回命中的那些。
     *
     * <p>给脚本用：观测配方的 input 与 on 都可以写标签（{@code '#minecraft:wool'}），
     * 而脚本侧判标签要么绕一大圈 API、要么自己拼注册表 —— 放这里最省事，
     * 而且与结构判定用的是同一份世界读取方式。
     *
     * @param csvTags 逗号分隔的标签名，带不带 {@code #} 都行
     * @return 命中的标签（原样带 {@code #}，逗号分隔）；一个都没命中返回空串
     */
    public static String blockTagsAt(Level level, BlockPos pos, String csvTags) {
        if (level == null || pos == null || csvTags == null || csvTags.isBlank()) {
            return "";
        }
        BlockState state = level.getBlockState(pos);
        StringBuilder sb = new StringBuilder();
        for (String raw : csvTags.split(",")) {
            String one = raw.trim();
            if (one.isEmpty()) {
                continue;
            }
            if (one.startsWith("#")) {
                one = one.substring(1);
            }
            ResourceLocation rl = ResourceLocation.tryParse(one);
            if (rl == null) {
                continue;
            }
            TagKey<Block> key = TagKey.create(Registries.BLOCK, rl);
            if (state.is(key)) {
                if (sb.length() > 0) {
                    sb.append(',');
                }
                sb.append('#').append(rl);
            }
        }
        return sb.toString();
    }

    /** 配色族：族名（'wool'）→ 该族所有方块 id（16 种颜色）。 */
    private static final Map<String, List<Block>> FAMILIES = new ConcurrentHashMap<>();

    /* ------------------------------------------------------------------ */
    /* 配置推送                                                            */
    /* ------------------------------------------------------------------ */

    /**
     * 推送结构定义（唯一真相在 mirror_config.js → observation.pattern）。
     *
     * @param csv 形如 {@code 3,3,5,1,1,2|0,0,-2,minecraft:wave_particle_block|...}
     *            第一段是"包围盒尺寸 + 靶心在盒子里的坐标"，后面每段是一格
     *            {@code dx,dy,dz,方块id}（**相对靶心**的偏移）
     * @return {@code null} = 接受；否则是一句拒绝原因
     */
    public static String pushPattern(String csv) {
        if (csv == null || csv.isBlank()) {
            return "结构定义是空的";
        }
        try {
            int headEnd = csv.indexOf('|');
            String head = (headEnd < 0) ? csv : csv.substring(0, headEnd);
            String[] h = head.split(",");
            if (h.length < 6) {
                return "结构定义的头段应写 包围盒sx,sy,sz,靶心tx,ty,tz（实得 " + h.length + " 个数）";
            }
            int sx = Integer.parseInt(h[0].trim());
            int sy = Integer.parseInt(h[1].trim());
            int sz = Integer.parseInt(h[2].trim());
            int tx = Integer.parseInt(h[3].trim());
            int ty = Integer.parseInt(h[4].trim());
            int tz = Integer.parseInt(h[5].trim());
            if (sx < 1 || sy < 1 || sz < 1 || tx < 0 || tx >= sx || ty < 0 || ty >= sy || tz < 0 || tz >= sz) {
                return "包围盒尺寸或靶心坐标越界: " + head;
            }
            List<Cell> cells = new ArrayList<>();
            List<String> unknown = new ArrayList<>();
            if (headEnd >= 0) {
                String[] parts = csv.substring(headEnd + 1).split("\\|");
                for (String part : parts) {
                    if (part == null || part.isBlank()) {
                        continue;
                    }
                    String[] f = part.split(",");
                    if (f.length < 4) {
                        return "结构里的格子应写 dx,dy,dz,方块id（实得 " + part + "）";
                    }
                    int dx = Integer.parseInt(f[0].trim());
                    int dy = Integer.parseInt(f[1].trim());
                    int dz = Integer.parseInt(f[2].trim());
                    /* 结构里的坐标是"盒子坐标"，这里换成相对靶心的偏移，
                     * 之后判定就只按偏移走，与玩家把结构摆在哪一格无关。 */
                    int ox = dx - tx;
                    int oy = dy - ty;
                    int oz = dz - tz;
                    String id = f[3].trim();
                    ResourceLocation rl = ResourceLocation.tryParse(id);
                    if (rl == null || !BuiltInRegistries.BLOCK.containsKey(rl)) {
                        unknown.add(id);
                        continue;
                    }
                    cells.add(new Cell(ox, oy, oz, BuiltInRegistries.BLOCK.get(rl)));
                }
            }
            if (cells.isEmpty()) {
                return "结构里一格都没有（是不是只推了头段？）";
            }
            if (!unknown.isEmpty()) {
                return "结构里有不存在的方块 id: " + String.join(", ", unknown);
            }
            plot = new Plot(sx, sy, sz, cells);
            pushed = true;
            return null;
        } catch (NumberFormatException e) {
            return "结构定义里有不是数字的坐标: " + e.getMessage();
        } catch (Throwable t) {
            Failures.note("observation", t);
            return "解析结构定义时出错: " + t;
        }
    }

    /**
     * 推送配色族表（唯一真相在 mirror_config.js → observation.color_families，由工具生成）。
     *
     * @param csv 每段一个族：{@code wool=minecraft:white_wool,minecraft:orange_wool,...}
     *            多段用 {@code |} 分隔
     * @return {@code null} = 接受；否则是一句拒绝原因
     */
    public static String pushColorFamilies(String csv) {
        if (csv == null || csv.isBlank()) {
            FAMILIES.clear();
            return null;
        }
        Map<String, List<Block>> next = new LinkedHashMap<>();
        List<String> unknown = new ArrayList<>();
        for (String seg : csv.split("\\|")) {
            if (seg == null || seg.isBlank()) {
                continue;
            }
            int eq = seg.indexOf('=');
            if (eq <= 0) {
                return "配色族应写 族名=方块id,方块id,...（实得 " + seg + "）";
            }
            String family = seg.substring(0, eq).trim();
            List<Block> members = new ArrayList<>();
            for (String id : seg.substring(eq + 1).split(",")) {
                String one = id.trim();
                if (one.isEmpty()) {
                    continue;
                }
                ResourceLocation rl = ResourceLocation.tryParse(one);
                if (rl == null || !BuiltInRegistries.BLOCK.containsKey(rl)) {
                    unknown.add(one);
                    continue;
                }
                members.add(BuiltInRegistries.BLOCK.get(rl));
            }
            if (members.size() >= 2) {
                next.put(family, List.copyOf(members));
            }
        }
        if (!unknown.isEmpty()) {
            return "配色族里有不存在的方块 id: " + String.join(", ", unknown);
        }
        if (next.isEmpty()) {
            return "配色族里一个族都没有";
        }
        FAMILIES.clear();
        FAMILIES.putAll(next);
        return null;
    }

    /** 回读结构摘要（诊断用）。 */
    public static String describe() {
        Plot p = plot;
        return p.sx + "×" + p.sy + "×" + p.sz + " 共 " + p.cells.size() + " 格"
            + "（四个朝向都试；结构含一格不对称的晶芽，所以要转就得整座一起转）"
            + "，配色族 " + FAMILIES.size() + " 个"
            + (pushed ? "" : "（脚本未推送，这是模组兜底值）");
    }

    /** 配色族摘要（诊断用）。 */
    public static String describeFamilies() {
        if (FAMILIES.isEmpty()) {
            return "（没有配色族 —— 脚本没推送，或推送被拒）";
        }
        StringBuilder sb = new StringBuilder();
        FAMILIES.forEach((k, v) -> sb.append(k).append('(').append(v.size()).append(") "));
        return sb.toString().trim();
    }

    /* ------------------------------------------------------------------ */
    /* 结构判定                                                            */
    /* ------------------------------------------------------------------ */

    /**
     * 以 {@code pos} 为靶心，判断"波粒观测"结构成立不成立。
     *
     * @return {@code ok} / {@code not_server} / {@code bad_pattern}
     */
    public static String centerValid(Level level, BlockPos pos) {
        int q = matchingQuarter(level, pos);
        if (q >= 0) {
            return "ok";
        }
        return (q == NO_WAVE_BLOCKS) ? "no_wave_blocks" : "bad_pattern";
    }

    /**
     * 一次调用把脚本需要的东西全给它：结构判定 + 靶心方块 + 靶心正下方方块。
     *
     * <p>为什么不让脚本自己去读方块：脚本侧读一个方块 id 要绕
     * {@code BuiltInRegistries}、还要处理标签查询，而"接触类配方"的判定
     * 必须与结构判定用**同一份世界快照**才说得通。一次调用带回来最省事，
     * 也免得 Rhino 那边猜 API（本项目在脚本侧踩过不少 API 形状的坑）。
     *
     * @return {@code bad_pattern} / {@code not_server}，
     *         或 {@code ok|朝向|靶心方块id|正下方方块id}
     *         （朝向 = 0/1/2/3，结构被整座转过多少个 90°）
     */
    public static String probe(Level level, BlockPos pos) {
        if (!(level instanceof ServerLevel) || pos == null) {
            return "not_server";
        }
        int quarter = matchingQuarter(level, pos);
        if (quarter == NO_WAVE_BLOCKS) {
            /* 连波粒块都没有 —— 玩家多半只是拿望远镜随手点了别处。
             * 这个码要单独给出来：脚本靠它决定"静默"，否则每次随手点方块
             * 都会弹一句"结构不完整"（望远镜是原版道具，点哪都会走到事件里）。 */
            return "no_wave_blocks";
        }
        if (quarter < 0) {
            return "bad_pattern";
        }
        return "ok|" + quarter + "|" + idOf(level.getBlockState(pos))
            + "|" + idOf(level.getBlockState(pos.below()));
    }

    private static String idOf(BlockState state) {
        ResourceLocation rl = BuiltInRegistries.BLOCK.getKey(state.getBlock());
        return (rl == null) ? "" : rl.toString();
    }

    /**
     * 结构成立时返回它匹配的朝向（0~3）；{@link #NO_WAVE_BLOCKS} = 连波粒块都没看到；
     * {@link #BAD_PATTERN} = 有波粒块但不构成结构。
     */
    private static int matchingQuarter(Level level, BlockPos pos) {
        if (!(level instanceof ServerLevel) || pos == null) {
            return BAD_PATTERN;
        }
        Plot p = plot;
        /* 先便宜地筛一遍：只看波粒块在不在。
         * 望远镜是原版道具，玩家随手点任何方块都会走到这里，
         * 直接上 21 格 × 4 个朝向太浪费；而"四个波粒块都不在"这一条
         * 几乎立刻能排除掉绝大多数误触。 */
        int waveHits = 0;
        if (WAVE_BLOCK != null) {
            for (Cell cell : p.cells) {
                if (cell.block == WAVE_BLOCK
                    && level.getBlockState(pos.offset(cell.dx, cell.dy, cell.dz)).getBlock() == WAVE_BLOCK) {
                    waveHits++;
                }
            }
        }
        if (waveHits < 2) {
            return NO_WAVE_BLOCKS;
        }
        /* 四个朝向都试。结构本身是**不对称**的（那个小块紫水晶芽只在一角），
         * 所以"转过 90° 的结构"能不能匹配，取决于玩家有没有把整座一起转 ——
         * 这正是我们要的：整套一致才算数，只转一半当然不该通过。 */
        for (int k = 0; k < 4; k++) {
            if (matches(level, pos, p, k)) {
                return k;
            }
        }
        return BAD_PATTERN;
    }

    /** 按第 {@code quarter} 个 90° 朝向比对整座结构。 */
    private static boolean matches(Level level, BlockPos target, Plot p, int quarter) {
        for (Cell cell : p.cells) {
            int[] o = rotate(cell.dx, cell.dz, quarter);
            BlockPos at = target.offset(o[0], cell.dy, o[1]);
            if (!level.isLoaded(at)) {
                return false;
            }
            if (level.getBlockState(at).getBlock() != cell.block) {
                return false;
            }
        }
        return true;
    }

    /** 绕竖轴把偏移转 {@code quarter} 个 90°。 */
    private static int[] rotate(int dx, int dz, int quarter) {
        switch (quarter & 3) {
            case 1:
                return new int[]{dz, -dx};
            case 2:
                return new int[]{-dx, -dz};
            case 3:
                return new int[]{-dz, dx};
            default:
                return new int[]{dx, dz};
        }
    }

    /* ------------------------------------------------------------------ */
    /* 应用一次观测                                                        */
    /* ------------------------------------------------------------------ */

    /**
     * 把一次观测结果写进世界。
     *
     * @param actionJson 动作描述（见类注释），支持 block / item / entity / recolor
     * @return {@code ok} / {@code not_server} / {@code bad_action} / {@code no_family}
     *         / {@code single_member} / {@code unknown_block} / {@code unknown_entity}
     *         / {@code spawn_failed}
     */
    public static String apply(Level level, BlockPos pos, String actionJson) {
        if (!(level instanceof ServerLevel server) || pos == null || actionJson == null || actionJson.isBlank()) {
            return "not_server";
        }
        try {
            String type = readString(actionJson, "type");
            if (type == null) {
                return "bad_action";
            }
            switch (type) {
                case "block": {
                    String id = readString(actionJson, "id");
                    Block block = blockOf(id);
                    if (block == null) {
                        return "unknown_block";
                    }
                    swapPreservingProperties(server, pos, block);
                    return "ok";
                }
                case "recolor": {
                    String family = readString(actionJson, "family");
                    List<Block> members = (family == null) ? null : FAMILIES.get(family);
                    if (members == null || members.isEmpty()) {
                        return "no_family";
                    }
                    Block now = server.getBlockState(pos).getBlock();
                    List<Block> others = new ArrayList<>();
                    for (Block b : members) {
                        if (b != now) {
                            others.add(b);
                        }
                    }
                    if (others.isEmpty()) {
                        return "single_member";
                    }
                    Block pick = others.get(ThreadLocalRandom.current().nextInt(others.size()));
                    swapPreservingProperties(server, pos, pick);
                    return "ok";
                }
                case "item": {
                    /* 先把原方块清掉再弹物品：顺序反了的话掉落物会与方块重叠、
                     * 看着像"没生效"。 */
                    String stack = readString(actionJson, "stack");
                    if (stack == null) {
                        stack = readString(actionJson, "id");
                    }
                    if (stack == null) {
                        return "bad_action";
                    }
                    /* ⚠️ 用 resolveStack 而不是 resolveFromJson：前者两种形态都认
                     * —— '{...}' 当物品堆 JSON、否则当纯物品 id。
                     * 引力配方的产物 ID 是**纯 id**（'minecraft:oak_sapling'），
                     * 只有 @random 的池子才是 JSON；两种都会走到这里。 */
                    ItemStack made = MirrorContainerInsert.resolveStack(stack, 1, server.registryAccess());
                    if (made.isEmpty()) {
                        return "spawn_failed";
                    }
                    server.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
                    Block.popResource(server, pos, made);
                    return "ok";
                }
                case "entity": {
                    String id = readString(actionJson, "id");
                    ResourceLocation rl = (id == null) ? null : ResourceLocation.tryParse(id);
                    if (rl == null || !BuiltInRegistries.ENTITY_TYPE.containsKey(rl)) {
                        return "unknown_entity";
                    }
                    /* ⚠️ 变量名不能叫 type —— 上面那个 String type 还在作用域里，
                     * 重名会直接编译失败（"已在方法中定义了变量"）。 */
                    EntityType<?> etype = BuiltInRegistries.ENTITY_TYPE.get(rl);
                    Entity spawned = etype.create(server);
                    if (spawned == null) {
                        return "spawn_failed";
                    }
                    server.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
                    spawned.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D,
                        ThreadLocalRandom.current().nextFloat() * 360.0F, 0.0F);
                    if (!server.addFreshEntity(spawned)) {
                        return "spawn_failed";
                    }
                    return "ok";
                }
                default:
                    return "bad_action";
            }
        } catch (Throwable t) {
            Failures.note("observation", t);
            return "bad_action";
        }
    }

    /**
     * 换方块时尽量把**两边都有的属性**带过去。
     *
     * <p>为什么必须带：染色方块里好几个族是靠属性表达的 ——
     * 釉面陶瓦/潜影盒有 {@code facing}、床有 {@code facing/part/occupied}、
     * 蜡烛有 {@code candles/lit/waterlogged}。直接用
     * {@code newBlock.defaultBlockState()} 会把朝向洗成默认值，
     * 玩家看到的是"换个颜色顺手把方块转向了"。
     *
     * <p>只搬运**新方块也有**的属性，所以跨种类（羊毛 → 混凝土）也不会崩。
     */
    private static void swapPreservingProperties(ServerLevel level, BlockPos pos, Block target) {
        BlockState old = level.getBlockState(pos);
        BlockState next = target.defaultBlockState();
        for (Property<?> p : old.getProperties()) {
            if (next.hasProperty(p)) {
                next = copyOne(old, next, p);
            }
        }
        level.setBlock(pos, next, Block.UPDATE_ALL);
    }

    private static <T extends Comparable<T>> BlockState copyOne(BlockState from, BlockState to, Property<T> p) {
        return to.setValue(p, from.getValue(p));
    }

    private static Block blockOf(String id) {
        if (id == null) {
            return null;
        }
        ResourceLocation rl = ResourceLocation.tryParse(id);
        if (rl == null || !BuiltInRegistries.BLOCK.containsKey(rl)) {
            return null;
        }
        Block b = BuiltInRegistries.BLOCK.get(rl);
        return (b == Blocks.AIR && !"minecraft:air".equals(id)) ? null : b;
    }

    /**
     * 从一行 JSON 里取字符串字段。
     *
     * <p>不引 Gson 的树模型：动作描述是我们自己拼的**扁平**对象，
     * 这里只需要取三个键，手写解析比拉一个解析器进来更省事、也不会因为
     * 组件里嵌套的 JSON 被误解析（物品堆 JSON 就在 {@code stack} 的值里，
     * 里面还有引号与转义）。
     *
     * <p>找的是 {@code "key":"value"} 形态，value 允许含转义引号。
     */
    private static String readString(String json, String key) {
        String needle = "\"" + key + "\"";
        int i = json.indexOf(needle);
        if (i < 0) {
            return null;
        }
        int colon = json.indexOf(':', i + needle.length());
        if (colon < 0) {
            return null;
        }
        int q = json.indexOf('"', colon + 1);
        if (q < 0) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (int p = q + 1; p < json.length(); p++) {
            char c = json.charAt(p);
            if (c == '\\' && p + 1 < json.length()) {
                sb.append(json.charAt(++p));
                continue;
            }
            if (c == '"') {
                return sb.toString();
            }
            sb.append(c);
        }
        return null;
    }
}
