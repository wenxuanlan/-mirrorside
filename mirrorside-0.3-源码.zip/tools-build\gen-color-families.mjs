#!/usr/bin/env node
/**
 * 生成"染色方块"的**配色族**表，并写进 mirror_config.js 的生成区。
 *
 * ── 这张表是干什么的 ────────────────────────────────────────────────────
 * 波粒观测的一条规则是：拿望远镜右键一个**染色方块**，它会随机变成
 * **同一种方块、另一种颜色**（用户明确要求："同类型不同颜色"）。
 * 要随机就得先知道"一个族里都有谁" —— 那张族表就是这个。
 *
 * ── 为什么从 jar 里实测，而不是手抄 16×13 个 id ─────────────────────────
 * 手抄 200 多个 id 必然会错，而且错了不报错：族里少一种颜色，表现只是
 * "那个颜色永远随机不到"，没人会发现。这里沿用 derive-gravity-recipes.mjs
 * 的判据 —— **jar 里存在 assets/minecraft/blockstates/<id>.json 才算这个方块存在**。
 * 任何一个族凑不满 16 种颜色就直接报错退出，逼着人来看。
 *
 * ── 族名怎么定 ──────────────────────────────────────────────────────────
 * 原版"染色方块"创造模式标签页里的内容就是"16 种颜色 × 若干后缀"，
 * 后缀就是族名：wool / carpet / concrete / ... 一族 = 一个后缀的 16 种颜色。
 * ⚠️ 族是**按后缀**分的，不是按标签页混在一起的：旗帜与墙旗虽然同属"旗帜"，
 *    但一个是立着的、一个是挂墙上的，混成一族会出现
 *    "立旗随机成了墙旗"这种外形都不对的替换。
 *
 * 用法:
 *   node tools-build/gen-color-families.mjs             只打印不写文件
 *   node tools-build/gen-color-families.mjs --write     写进 mirror_config.js 的生成区
 */

import { readFileSync, writeFileSync, existsSync } from 'node:fs';

const JAR = 'D:\\DSHwork\\MC镜维度\\.minecraft\\versions\\镜维度\\镜维度.jar';
const CFG = 'D:\\DSHwork\\MC镜维度\\.minecraft\\versions\\镜维度'
  + '\\kubejs\\startup_scripts\\mirror_config.js';

/* 生成区哨兵：与 familyRecipes 的生成区同一个套路 —— 中间的东西由工具覆写，
 * 人只该改哨兵外面的部分。 */
const BEGIN = '  /* ===== 配色族数据（生成区，勿手改）===== */';
const END = '  /* ===== 配色族数据结束 ===== */';

const COLORS = [
  'white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink',
  'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black',
];

/* 原版"染色方块"标签页里的后缀。族名 = 后缀名。 */
const SUFFIXES = [
  'wool', 'carpet', 'concrete', 'concrete_powder', 'terracotta',
  'glazed_terracotta', 'stained_glass', 'stained_glass_pane',
  'shulker_box', 'bed', 'banner', 'wall_banner', 'candle',
];

/** 读 zip 的**中央目录**，列出所有条目名。不依赖任何第三方库。 */
function zipNames(path) {
  const buf = readFileSync(path);
  /* 从尾部找 EOCD（0x06054b50）。注释最长 65535，所以只需回扫这么远。 */
  let eocd = -1;
  const from = Math.max(0, buf.length - 66000);
  for (let i = buf.length - 22; i >= from; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd === -1) throw new Error('不是合法 zip: ' + path);
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const names = [];
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) break;
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    names.push(buf.toString('utf8', p + 46, p + 46 + nameLen));
    p += 46 + nameLen + extraLen + commentLen;
  }
  return names;
}

if (!existsSync(JAR)) {
  console.error('找不到版本 jar: ' + JAR);
  process.exit(1);
}

const blocks = new Set(
  zipNames(JAR)
    .filter((n) => n.startsWith('assets/minecraft/blockstates/') && n.endsWith('.json'))
    .map((n) => n.slice('assets/minecraft/blockstates/'.length, -'.json'.length)),
);

console.log(`jar 里共 ${blocks.size} 个方块状态文件。\n`);

const families = [];
let bad = 0;
for (const suffix of SUFFIXES) {
  const members = [];
  const missing = [];
  for (const c of COLORS) {
    const id = `${c}_${suffix}`;
    if (blocks.has(id)) members.push('minecraft:' + id);
    else missing.push(id);
  }
  const mark = members.length === COLORS.length ? '✓' : '✗';
  console.log(`  ${mark} ${suffix.padEnd(22)} ${members.length}/16`
    + (missing.length ? '  缺: ' + missing.join(', ') + '（不是原版方块？还是名字写错了？）' : ''));
  if (members.length !== COLORS.length) bad++;
  families.push([suffix, members]);
}

/* 推送用的 CSV：族名=id,id,... 多族用 | 分隔（与模组侧 pushColorFamilies 约定一致）。 */
const csv = families.map(([name, ids]) => name + '=' + ids.join(',')).join('|');

/* 写进生成区时按族拆行，读起来才不费劲。
 * ⚠️ 每个 id 必须是**独立的数组元素**（各自带引号）。
 *    早先图省事写成每行一个 'a,b,c,d' 字符串 —— 数组就只有 4 个元素，
 *    每个元素是"四个 id 拼起来的一坨"，脚本拿它当方块 id 用，永远查不到。
 *    check-observation.mjs 里那条"族里每个 id 都要以 _族名 结尾"就是为它加的。 */
const lines = families.map(([name, ids]) => {
  const rows = [];
  for (let i = 0; i < ids.length; i += 4) {
    rows.push('      ' + ids.slice(i, i + 4).map((x) => "'" + x + "'").join(', ') + ',');
  }
  return `    ${name}: [\n${rows.join('\n')}\n    ],`;
});

const block = [
  BEGIN,
  '  /* 由 tools-build/gen-color-families.mjs 从版本 jar 生成，勿手改：',
  `   *   ${families.length} 个族 × 16 种颜色 = ${families.length * 16} 个方块。`,
  '   * 判定依据是 jar 里有没有 assets/minecraft/blockstates/<id>.json。',
  '   * 改完记得重跑工具（node tools-build/gen-color-families.mjs --write）。 */',
  '  color_family_members: {',
  ...lines,
  '  },',
  '  /* 推送形态（脚本把它整串交给模组，模组侧不再拼字符串） */',
  '  color_families_csv:',
  "    '" + csv + "',",
  END,
].join('\n');

if (process.argv.includes('--write')) {
  if (bad > 0) {
    console.error('\n✗ 有族凑不满 16 种颜色，拒绝写入（先把上面的缺项弄清楚）。');
    process.exit(1);
  }
  const src = readFileSync(CFG, 'utf8');
  const a = src.indexOf(BEGIN);
  const b = src.indexOf(END);
  if (a < 0 || b < 0 || b < a) {
    console.error('✗ mirror_config.js 里找不到配色族生成区的哨兵：\n  ' + BEGIN + '\n  ' + END);
    process.exit(1);
  }
  const next = src.slice(0, a) + block + src.slice(b + END.length);
  writeFileSync(CFG, next, 'utf8');
  console.log(`\n✓ 已写入生成区（${families.length} 个族）。`);
} else {
  console.log('\n（未加 --write，什么都没改）');
}

if (bad > 0) process.exit(1);
console.log('\n✓ 配色族自检通过。');
