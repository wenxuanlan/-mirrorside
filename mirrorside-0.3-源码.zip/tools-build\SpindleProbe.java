package work.dsh.mirror.gravity;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 针尖对麦芒 · 离线几何验证。
 *
 * <h2>为什么需要它（而不是进游戏看）</h2>
 * 这个装置只在新开档 / 生成新区块时出现，一次成型、横跨几百格、还要穿过玻璃。
 * 想靠肉眼确认"锥尖正好伸进 3 格""波粒块是两尖的严格中点""没捅到黑玻璃"
 * 基本不可能；而几何一旦错了，存档里就已经写坏了。
 *
 * <p>所以几何逻辑全部放在 {@link SpindleGeometry}（无 Minecraft 依赖），
 * 本探针直接编译那个类、跑几万个随机样本，逐例核对不变量。
 * 规则数值从 {@code SpindleSettings.java} 里读出来 ——
 * 测的就是<b>真实默认值</b>，不是在这里另抄一份。
 *
 * <h2>怎么跑</h2>
 * <pre>
 *   node tools-build/run-spindle-probe.mjs            # 推荐（自动找 javac/java）
 *   # 或手工（先编译再运行，两个文件同包）：
 *   javac -d out SpindleGeometry.java SpindleProbe.java
 *   java -cp out work.dsh.mirror.gravity.SpindleProbe &lt;java源码目录&gt; [样本数] [重样本数]
 * </pre>
 *
 * <p>退出码 0 = 全部通过。
 */
public final class SpindleProbe {

    private static int checks = 0;
    private static int fails = 0;

    private SpindleProbe() {
    }

    public static void main(String[] args) throws Exception {
        Path javaDir = Paths.get(args.length > 0
            ? args[0]
            : "mirror-gravity-mod/src/main/java/work/dsh/mirror/gravity");
        int samples = args.length > 1 ? Integer.parseInt(args[1]) : 20000;
        int heavy = args.length > 2 ? Integer.parseInt(args[2]) : 400;

        SpindleGeometry.Rules rules = readRules(javaDir.resolve("SpindleSettings.java"));
        System.out.println("镜维度 · 针尖对麦芒 几何验证");
        System.out.println("=".repeat(72));
        System.out.printf(Locale.ROOT,
            "规则（读自 SpindleSettings.java）: 半径 %.1f~%.1f 长度 %.0f~%.0f 伸入 %.0f~%.0f "
                + "高度 %.0f~%.0f 俯仰 %.0f~%.0f%n",
            rules.radiusMin, rules.radiusMax, rules.lengthMin, rules.lengthMax,
            rules.insetMin, rules.insetMax, rules.centerYMin, rules.centerYMax,
            rules.pitchMinDeg, rules.pitchMaxDeg);
        System.out.printf(Locale.ROOT, "境内 %d..%d  世界 %d..%d  波粒块避让 %s%n",
            rules.innerMinY, rules.innerMaxY, rules.buildMinY, rules.buildMaxY,
            java.util.Arrays.toString(rules.coreAvoidYs));

        String problem = rules.problem();
        check("规则自检通过（Rules.problem()）", problem == null, String.valueOf(problem));
        if (problem != null) {
            report();
            System.exit(1);
            return;
        }

        System.out.println("\n--- 1. 解析不变量（" + samples + " 个随机样本）---");
        analytic(samples, rules);

        System.out.println("\n--- 2. 栅格化不变量（" + heavy + " 个样本，逐方块核对）---");
        raster(rules, heavy);

        System.out.println("\n--- 3. 分区块枚举一致性（20 个样本）---");
        chunkSplit(rules, 20);

        System.out.println("\n--- 4. 样例（前 3 个）---");
        Random rnd = new Random(7L);
        for (int i = 0; i < 3; i++) {
            SpindleGeometry.Plan p = SpindleGeometry.sample(wrap(rnd), rules, i * 512, -i * 512);
            System.out.println("  " + p.describe());
        }

        report();
        System.exit(fails == 0 ? 0 : 1);
    }

    /* ------------------------------------------------------- 1. 解析不变量 */

    private static void analytic(int samples, SpindleGeometry.Rules r) {
        Random rnd = new Random(20261001L);
        double minReach = Double.MAX_VALUE;
        double maxReach = 0;
        double worstSymmetry = 0;
        int needleUpCount = 0;
        int insetMinSeen = Integer.MAX_VALUE;
        int insetMaxSeen = 0;

        for (int i = 0; i < samples; i++) {
            int cx = (rnd.nextInt(2000) - 1000) * 16;
            int cz = (rnd.nextInt(2000) - 1000) * 16;
            SpindleGeometry.Plan p = SpindleGeometry.sample(wrap(rnd), r, cx, cz);

            double norm = Math.sqrt(p.ux * p.ux + p.uy * p.uy + p.uz * p.uz);
            expect(Math.abs(norm - 1.0D) < 1.0e-9D, "中轴不是单位向量", norm);
            expect(p.uy > 0, "中轴 uy 必须为正（一端上镜外、一端下镜外）", p.uy);

            expect(p.pitchDeg >= r.pitchMinDeg - 1.0e-9D && p.pitchDeg <= r.pitchMaxDeg + 1.0e-9D,
                "俯仰角越界", p.pitchDeg);
            expect(p.yawDeg >= 0 && p.yawDeg < 360.0D, "偏航角越界", p.yawDeg);
            expect(p.rollDeg >= 0 && p.rollDeg < 360.0D, "翻滚角越界", p.rollDeg);

            expect(p.coreX >= cx && p.coreX <= cx + 15, "波粒块 x 不在结构区块内", p.coreX - cx);
            expect(p.coreZ >= cz && p.coreZ <= cz + 15, "波粒块 z 不在结构区块内", p.coreZ - cz);
            expect(p.coreY >= Math.ceil(r.centerYMin) && p.coreY <= Math.floor(r.centerYMax),
                "波粒块高度越界", p.coreY);
            expect(p.coreY > r.innerMinY && p.coreY < r.innerMaxY, "波粒块不在境内", p.coreY);
            for (int avoid : r.coreAvoidYs) {
                expect(p.coreY != avoid, "波粒块落在黑玻璃夹层上", p.coreY);
            }

            double coreCX = p.coreX + 0.5D;
            double coreCY = p.coreY + 0.5D;
            double coreCZ = p.coreZ + 0.5D;
            double mx = (p.tipUpX + p.tipDnX) / 2.0D - coreCX;
            double my = (p.tipUpY + p.tipDnY) / 2.0D - coreCY;
            double mz = (p.tipUpZ + p.tipDnZ) / 2.0D - coreCZ;
            double symmetry = Math.max(Math.abs(mx), Math.max(Math.abs(my), Math.abs(mz)));
            worstSymmetry = Math.max(worstSymmetry, symmetry);
            expect(symmetry < 1.0e-9D, "两尖中点与波粒块中心不重合", symmetry);
            expect(p.reach > 0, "reach 必须为正", p.reach);

            double dUp = dist(p.tipUpX, p.tipUpY, p.tipUpZ, coreCX, coreCY, coreCZ);
            double dDn = dist(p.tipDnX, p.tipDnY, p.tipDnZ, coreCX, coreCY, coreCZ);
            expect(Math.abs(dUp - dDn) < 1.0e-9D, "两尖到波粒块距离不等", dUp - dDn);
            expect(Math.abs(dUp - p.reach) < 1.0e-9D, "reach 与实测距离不符", dUp - p.reach);
            minReach = Math.min(minReach, p.reach);
            maxReach = Math.max(maxReach, p.reach);

            expect(inRange(p.insetUp, r.insetMin, r.insetMax), "上锥伸入格数越界", p.insetUp);
            expect(inRange(p.insetDn, r.insetMin, r.insetMax), "下锥伸入格数越界", p.insetDn);
            expect(Math.abs((p.insetDn - p.insetUp) - (2 * p.coreY + 1)) < 1.0e-9D,
                "伸入格数不满足中点关系式", (p.insetDn - p.insetUp) - (2 * p.coreY + 1));
            insetMinSeen = Math.min(insetMinSeen, (int) p.insetUp);
            insetMaxSeen = Math.max(insetMaxSeen, (int) p.insetUp);

            expect(inRange(p.upLen, r.lengthMin, r.lengthMax), "上锥长度越界", p.upLen);
            expect(inRange(p.dnLen, r.lengthMin, r.lengthMax), "下锥长度越界", p.dnLen);
            expect(inRange(p.upRad, r.radiusMin, r.radiusMax), "上锥半径越界", p.upRad);
            expect(inRange(p.dnRad, r.radiusMin, r.radiusMax), "下锥半径越界", p.dnRad);
            expect((p.upKind == SpindleGeometry.KIND_NEEDLE) != (p.dnKind == SpindleGeometry.KIND_NEEDLE),
                "两根圆锥的材质必须一铁一草", p.upKind + "/" + p.dnKind);
            if (p.upKind == SpindleGeometry.KIND_NEEDLE) {
                needleUpCount++;
            }

            expect(p.minY >= r.buildMinY && p.maxY <= r.buildMaxY,
                "包围盒越出世界高度", p.minY + ".." + p.maxY);
        }

        System.out.printf(Locale.ROOT, "  两尖到波粒块的距离 %.1f ~ %.1f 格%n", minReach, maxReach);
        System.out.printf(Locale.ROOT, "  中点最大偏差 %.2e 格（浮点误差量级）%n", worstSymmetry);
        System.out.printf(Locale.ROOT, "  上锥伸入境内 %d ~ %d 格%n", insetMinSeen, insetMaxSeen);
        System.out.printf(Locale.ROOT, "  针尖在上镜外的比例 %.1f%%（应接近 50%%）%n",
            100.0D * needleUpCount / samples);
    }

    /* --------------------------------------------------- 2. 栅格化不变量 */

    private static void raster(SpindleGeometry.Rules r, int samples) {
        Random rnd = new Random(4242L);
        long totalBlocks = 0;
        int maxBlocks = 0;
        int minBlocks = Integer.MAX_VALUE;
        int maxSpanX = 0;
        int maxSpanZ = 0;
        int worstInside = 0;
        int clipped = 0;
        int spineLayerTotal = 0;
        double volumeRatioSum = 0;

        for (int i = 0; i < samples; i++) {
            SpindleGeometry.Plan p = SpindleGeometry.sample(wrap(rnd), r, i * 16, -i * 16);

            List<int[]> collected = new ArrayList<>();
            SpindleGeometry.forEachBlock(p, p.minX, p.minY, p.minZ, p.maxX, p.maxY, p.maxZ,
                (x, y, z, kind) -> collected.add(new int[]{x, y, z, kind}));

            Set<Long> seen = new HashSet<>();
            Map<Integer, Integer> upPerLayer = new HashMap<>();
            int coreHits = 0;
            int upMinY = Integer.MAX_VALUE;
            int dnMaxY = Integer.MIN_VALUE;
            int upInside = 0;
            int upTotal = 0;
            int dnTotal = 0;

            for (int[] b : collected) {
                int x = b[0];
                int y = b[1];
                int z = b[2];
                int kind = b[3];

                if (x < p.minX || x > p.maxX || y < p.minY || y > p.maxY || z < p.minZ || z > p.maxZ) {
                    clipped++;
                }
                expect(y >= r.buildMinY && y <= r.buildMaxY, "方块越出世界高度", y);
                expect(seen.add(key(x, y, z)), "同一格被写了两次（两锥重叠或压住波粒块）",
                    x + "," + y + "," + z);

                if (kind == SpindleGeometry.KIND_CORE) {
                    coreHits++;
                    expect(x == p.coreX && y == p.coreY && z == p.coreZ, "波粒块坐标不对",
                        x + "," + y + "," + z);
                    continue;
                }
                expect(kind == SpindleGeometry.KIND_NEEDLE || kind == SpindleGeometry.KIND_AWN,
                    "未知方块种类", kind);
                for (int avoid : r.coreAvoidYs) {
                    expect(y != avoid, "锥体落在黑玻璃夹层上（会把镜面交界捅出洞）", y);
                }

                double rel = (x + 0.5D - (p.coreX + 0.5D)) * p.ux
                    + (y + 0.5D - (p.coreY + 0.5D)) * p.uy
                    + (z + 0.5D - (p.coreZ + 0.5D)) * p.uz;
                if (rel > 0) {
                    upTotal++;
                    upMinY = Math.min(upMinY, y);
                    upPerLayer.merge(y, 1, Integer::sum);
                    if (y <= r.innerMaxY) {
                        upInside++;
                    }
                } else {
                    dnTotal++;
                    dnMaxY = Math.max(dnMaxY, y);
                }
            }

            expect(coreHits == 1, "波粒块数量不为 1", coreHits);
            expect(upTotal > 0 && dnTotal > 0, "某一根圆锥是空的", upTotal + "/" + dnTotal);

            /* 锥尖恰好停在预定层：上锥最低一格 = 境内顶 - (inset - 1) */
            int expectUpMinY = r.innerMaxY + 1 - (int) Math.round(p.insetUp);
            expect(upMinY == expectUpMinY, "上锥尖端没有停在预定高度", upMinY + " 期望 " + expectUpMinY);
            int expectDnMaxY = r.innerMinY - 1 + (int) Math.round(p.insetDn);
            expect(dnMaxY == expectDnMaxY, "下锥尖端没有停在预定高度", dnMaxY + " 期望 " + expectDnMaxY);

            /* "大部分在镜外"：留在境内的方块占比 */
            worstInside = Math.max(worstInside, (int) Math.round(100.0D * upInside / upTotal));

            /* 锥尖必须"细且尖"（来自实机反馈）：半径不足 SPINE_RADIUS 的那些层，
             * 每层应当**恰好 1 格**。这是"尖"的可验证形式 ——
             * 早先用半径下限 0.9 的做法，这些层会是 2~3 格宽的小柱子。 */
            int spineLayers = 0;
            for (Map.Entry<Integer, Integer> layer : upPerLayer.entrySet()) {
                int y = layer.getKey();
                double t = (y + 0.5D - p.tipUpY) / p.uy;
                if (t < 0 || t > p.upLen) {
                    continue;
                }
                if (p.upRad * t / p.upLen <= SpindleGeometry.SPINE_RADIUS) {
                    spineLayers++;
                    expect(layer.getValue() == 1, "锥尖段某层不是 1 格宽（尖不够细）",
                        "y=" + y + " 有 " + layer.getValue() + " 格");
                }
            }
            expect(spineLayers > 0, "没有任何脊线段（尖被削平或半径区间异常）", spineLayers);
            spineLayerTotal += spineLayers;

            double ideal = Math.PI * (p.upRad * p.upRad * p.upLen + p.dnRad * p.dnRad * p.dnLen) / 3.0D;
            double ratio = (upTotal + dnTotal) / ideal;
            volumeRatioSum += ratio;
            expect(ratio > 0.6D && ratio < 1.2D, "锥体方块量与理想圆锥体积相差过大", ratio);

            int total = collected.size();
            totalBlocks += total;
            maxBlocks = Math.max(maxBlocks, total);
            minBlocks = Math.min(minBlocks, total);
            maxSpanX = Math.max(maxSpanX, p.chunkSpanX());
            maxSpanZ = Math.max(maxSpanZ, p.chunkSpanZ());
        }

        expect(clipped == 0, "有方块落在包围盒之外", clipped);
        System.out.printf(Locale.ROOT, "  单座方块量 %d ~ %d（含波粒块），平均 %.0f%n",
            minBlocks, maxBlocks, (double) totalBlocks / samples);
        System.out.printf(Locale.ROOT, "  栅格化/理想体积比 平均 %.3f（接近 1 说明形状确实是标准圆锥）%n",
            volumeRatioSum / samples);
        System.out.printf(Locale.ROOT, "  包围盒最大跨 %d×%d 区块（世界生成时会一起强制生成）%n",
            maxSpanX, maxSpanZ);
        System.out.printf(Locale.ROOT, "  最差样本里，锥体仍有 %.1f%% 的方块在镜外%n", 100.0D - worstInside);
        System.out.printf(Locale.ROOT, "  锥尖脊线共 %d 层，每层恰好 1 格宽（细且尖）%n", spineLayerTotal);
    }

    /* --------------------------------------------- 3. 分区块枚举一致性 */

    /**
     * 分区块枚举 = 真实生成时走的那条路径（每个区块只写落在自己那一格里的方块）。
     * 把包围盒切成区块大小的盒子分别枚举，再与"整体枚举"比对集合是否一致 ——
     * 不一致就说明分块路径会漏方块或重复写。
     */
    private static void chunkSplit(SpindleGeometry.Rules r, int samples) {
        Random rnd = new Random(99L);
        for (int i = 0; i < samples; i++) {
            SpindleGeometry.Plan p = SpindleGeometry.sample(wrap(rnd), r, i * 16, i * 16);

            Set<Long> whole = new HashSet<>();
            SpindleGeometry.forEachBlock(p, p.minX, p.minY, p.minZ, p.maxX, p.maxY, p.maxZ,
                (x, y, z, kind) -> whole.add(key(x, y, z) * 4 + kind));

            Set<Long> split = new HashSet<>();
            for (int cx = p.minX >> 4; cx <= (p.maxX >> 4); cx++) {
                for (int cz = p.minZ >> 4; cz <= (p.maxZ >> 4); cz++) {
                    int x0 = Math.max(p.minX, cx << 4);
                    int x1 = Math.min(p.maxX, (cx << 4) + 15);
                    int z0 = Math.max(p.minZ, cz << 4);
                    int z1 = Math.min(p.maxZ, (cz << 4) + 15);
                    /* 真实生成时 y 范围是整个可建造高度 */
                    SpindleGeometry.forEachBlock(p, x0, r.buildMinY, z0, x1, r.buildMaxY, z1,
                        (x, y, z, kind) -> split.add(key(x, y, z) * 4 + kind));
                }
            }

            boolean same = whole.size() == split.size();
            expect(same, "分区块枚举与整体枚举不一致", whole.size() + " vs " + split.size());
            if (!same) {
                List<Long> missing = new ArrayList<>();
                for (Long k : whole) {
                    if (!split.contains(k)) {
                        missing.add(k);
                    }
                }
                System.out.println("    整体枚举多出的前 3 个键: "
                    + missing.subList(0, Math.min(3, missing.size())));
            }
        }
        System.out.println("  分区块枚举与整体枚举逐格一致（" + samples + " 个样本）");
    }

    /**
     * 精确编码一格坐标（不是哈希）：x/z 各 26 位、y 12 位。
     * 用哈希会偶发碰撞，把"两锥重叠"误报出来。
     */
    private static long key(int x, int y, int z) {
        return ((long) (x + 33554432) << 38) | ((long) (y + 2048) << 26) | (z + 33554432);
    }

    /* ---------------------------------------------------------- 工具方法 */

    /** 从 SpindleSettings.java 里读默认值 —— 测真实默认值，不在探针里另抄一份。 */
    private static SpindleGeometry.Rules readRules(Path settingsFile) throws Exception {
        String src = new String(Files.readAllBytes(settingsFile), StandardCharsets.UTF_8);
        Matcher im = Pattern.compile("innerMinY\\s*=\\s*(-?\\d+)").matcher(src);
        Matcher ix = Pattern.compile("innerMaxY\\s*=\\s*(-?\\d+)").matcher(src);
        Matcher bm = Pattern.compile("buildMinY\\s*=\\s*(-?\\d+)").matcher(src);
        Matcher bx = Pattern.compile("buildMaxY\\s*=\\s*(-?\\d+)").matcher(src);
        Matcher av = Pattern.compile("coreAvoidYs\\s*=\\s*\\{([^}]*)\\}").matcher(src);
        if (!im.find() || !ix.find() || !bm.find() || !bx.find() || !av.find()) {
            throw new IllegalStateException("SpindleSettings.java 里的整数默认值解析失败: " + settingsFile);
        }
        String[] parts = av.group(1).split(",");
        int[] avoid = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            avoid[i] = Integer.parseInt(parts[i].trim());
        }
        return new SpindleGeometry.Rules(
            num(src, "radiusMin"), num(src, "radiusMax"),
            num(src, "lengthMin"), num(src, "lengthMax"),
            num(src, "insetMin"), num(src, "insetMax"),
            num(src, "centerYMin"), num(src, "centerYMax"),
            num(src, "pitchMinDeg"), num(src, "pitchMaxDeg"),
            Integer.parseInt(im.group(1)), Integer.parseInt(ix.group(1)),
            Integer.parseInt(bm.group(1)), Integer.parseInt(bx.group(1)), avoid);
    }

    private static double num(String src, String name) {
        Matcher m = Pattern.compile(name + "\\s*=\\s*(-?[\\d.]+)[DdFf]?\\s*;").matcher(src);
        if (!m.find()) {
            throw new IllegalStateException("SpindleSettings.java 里找不到 " + name);
        }
        return Double.parseDouble(m.group(1));
    }

    private static SpindleGeometry.Rng wrap(Random rnd) {
        return new SpindleGeometry.Rng() {
            @Override
            public double nextDouble() {
                return rnd.nextDouble();
            }

            @Override
            public int nextInt(int bound) {
                return rnd.nextInt(bound);
            }
        };
    }

    private static double dist(double ax, double ay, double az, double bx, double by, double bz) {
        return Math.sqrt(sq(ax - bx) + sq(ay - by) + sq(az - bz));
    }

    private static boolean inRange(double v, double lo, double hi) {
        return v >= lo - 1.0e-9D && v <= hi + 1.0e-9D;
    }

    private static double sq(double v) {
        return v * v;
    }

    private static void expect(boolean cond, String what, Object detail) {
        checks++;
        if (!cond) {
            fails++;
            if (fails <= 20) {
                System.out.println("  ✗ " + what + "  （实测 " + detail + "）");
            }
        }
    }

    private static void check(String what, boolean cond, String detail) {
        expect(cond, what, detail);
        System.out.println((cond ? "  ✓ " : "  ✗ ") + what + (cond ? "" : "  ← " + detail));
    }

    private static void report() {
        System.out.println("\n" + "=".repeat(72));
        System.out.println(fails == 0
            ? "✓ 几何验证全部通过（断言 " + checks + " 次）"
            : "✗ " + fails + " 项失败 / 共 " + checks + " 次断言");
    }
}
