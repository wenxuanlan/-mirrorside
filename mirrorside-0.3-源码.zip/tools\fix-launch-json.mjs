#!/usr/bin/env node
/**
 * 镜维度 · 修复启动器生成的版本 JSON
 * =====================================================================
 * 背景：本项目的实例曾因「启动器把 NeoForge 装了一半」而完全无法启动。
 * 完整链路是：
 *
 *   症状 A  Mod ID: 'neoforge' / 'minecraft'  Actual version: '[MISSING]'
 *           -> 版本 JSON 里没有 net.neoforged:neoforge 库
 *   症状 B  ClassNotFoundException: net.minecraft.world.level.block.entity.BlockEntityType
 *           -> 版本 jar 是未经补丁处理的原版混淆客户端
 *   症状 C  ResolutionException: Module xxx reads more than one module named neoforge
 *           -> 打补丁的 client 产物与 universal 都被当成 neoforge 模块
 *
 * 症状 C 是最难的一个：NeoForge 的官方安装器**不会**把补丁 client 的路径
 * 写进任何版本 JSON，官方启动器靠自己的机制处理。手工拼 classpath 时，
 * 补丁 client（含 neoforge 元数据）和 universal（真正的 mod 定义）会
 * 各自注册成 neoforge 模块，直接崩。
 *
 * 解法：把补丁 client 的**产物名**加进 -DignoreList。
 * 它仍在 classpath 上提供 Minecraft 类，但不再被当成 neoforge 模块。
 * 这是实测唯一能跑通的组合（见 README 7.0 节）。
 *
 * 本脚本做的事（幂等，可重复运行）：
 *   1. 找出实例的版本 JSON
 *   2. 去掉手工加的 net.neoforged:neoforge 库条目（它会导致模块重复）
 *   3. 把版本 jar 指向打补丁的 neoforge-<ver>-client.jar
 *   4. 给 -DignoreList 补上补丁 client 的产物名
 *
 * 用法:
 *   node tools/fix-launch-json.mjs            # 修复
 *   node tools/fix-launch-json.mjs --dry-run  # 只看要做什么
 * =====================================================================
 */

import { readFileSync, writeFileSync, existsSync, readdirSync, copyFileSync, statSync } from 'node:fs';
import { dirname, join, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
let INSTANCE = resolve(HERE, '..');
const iFlag = process.argv.indexOf('--instance');
if (iFlag !== -1 && process.argv[iFlag + 1]) INSTANCE = resolve(process.argv[iFlag + 1]);
const DRY = process.argv.includes('--dry-run');

const MC = resolve(INSTANCE, '..', '..');           // .minecraft
const LIBS = join(MC, 'libraries');
const VERSIONS = resolve(INSTANCE, '..');

const log = (...a) => console.log(...a);
const problems = [];

/* ------------------------------------------------------------------ */
/* 1. 找版本 JSON 与 NeoForge 版本                                      */
/* ------------------------------------------------------------------ */

const versionJsonPath = readdirSync(INSTANCE)
  .filter((f) => f.endsWith('.json'))
  .map((f) => join(INSTANCE, f))
  .find((p) => {
    try { return Array.isArray(JSON.parse(readFileSync(p, 'utf8')).libraries); } catch { return false; }
  });

if (!versionJsonPath) {
  console.error('✗ 实例目录里找不到含 libraries 的版本 JSON');
  process.exit(1);
}

const vj = JSON.parse(readFileSync(versionJsonPath, 'utf8'));
log('实例      : ' + INSTANCE);
log('版本 JSON : ' + relative(MC, versionJsonPath));

// NeoForge 版本：先看 arguments，再看库条目
let neoVer = null;
for (const a of vj.arguments?.game ?? []) {
  if (neoVer) { neoVer = String(a); break; }
  if (a === '--fml.neoForgeVersion') neoVer = '__NEXT__';
}
if (neoVer === '__NEXT__' || !neoVer) {
  const neo = (vj.libraries ?? []).find((l) => /^net\.neoforged:neoforge:/.test(l.name ?? ''));
  neoVer = neo ? neo.name.split(':')[2] : null;
}
if (!neoVer) {
  console.error('✗ 读不到 NeoForge 版本（既没有 --fml.neoForgeVersion，也没有 neoforge 库条目）');
  process.exit(1);
}
log('NeoForge  : ' + neoVer);

const clientJarName = `neoforge-${neoVer}-client.jar`;
const clientJar = join(LIBS, 'net', 'neoforged', 'neoforge', neoVer, clientJarName);

if (!existsSync(clientJar)) {
  console.error(`\n✗ 找不到打补丁的客户端产物：\n    ${relative(MC, clientJar)}`);
  console.error('\n  这个文件必须由 NeoForge 官方安装器生成，无法手工拼出来。');
  console.error('  请先让启动器重装 NeoForge，或运行官方安装器（见 README 7.0 节）。');
  process.exit(1);
}
log('补丁 client: ' + (statSync(clientJar).size / 1048576).toFixed(2) + ' MB  OK');

/* ------------------------------------------------------------------ */
/* 2. 计算改动                                                          */
/* ------------------------------------------------------------------ */

const changes = [];

// 2a. 去掉手工加的 neoforge 库条目（它和补丁 client 会各注册一个 neoforge 模块）
const libs = vj.libraries ?? [];
const withoutNeo = libs.filter((l) => !/^net\.neoforged:neoforge:/.test(l.name ?? ''));
if (withoutNeo.length !== libs.length) {
  changes.push(`删除 ${libs.length - withoutNeo.length} 个 net.neoforged:neoforge 库条目（避免 neoforge 模块重复注册）`);
}

// 2b. ignoreList 里补上补丁 client 的产物名
let ignorePatched = false;
const args = vj.arguments ?? {};
args.jvm = (args.jvm ?? []).map((a) => {
  if (typeof a === 'string' && a.startsWith('-DignoreList=')) {
    if (a.split('=')[1].split(',').includes(clientJarName)) { ignorePatched = true; return a; }
    changes.push(`-DignoreList 追加 ${clientJarName}`);
    return a + ',' + clientJarName;
  }
  return a;
});
if (!args.jvm.some((a) => typeof a === 'string' && a.startsWith('-DignoreList='))) {
  args.jvm.push('-DignoreList=' + clientJarName);
  changes.push(`新增 -DignoreList=${clientJarName}`);
}
vj.arguments = args;

// 2c. 自包含形态下，版本 jar 应当是补丁 client
if (!vj.inheritsFrom) {
  const jarName = readdirSync(INSTANCE).find((f) => f.endsWith('.jar'));
  if (jarName) {
    changes.push(`版本 jar 当前是 ${jarName}（启动器生成的原版混淆客户端）`);
    changes.push(`  -> 应替换为 ${relative(INSTANCE, clientJar)}`);
    problems.push(
      '自包含版本 JSON 无法直接使用补丁 client：路径在 libraries/ 下，\n'
      + '      而启动器的 ${classpath} 只包含版本目录里的 jar。\n'
      + '      这条路线需要启动器配合，请让启动器重装 NeoForge 生成继承式版本 JSON。'
    );
  }
} else {
  log('版本形态  : 继承式（inheritsFrom: ' + vj.inheritsFrom + '）');
}

/* ------------------------------------------------------------------ */
/* 3. 落盘                                                            */
/* ------------------------------------------------------------------ */

log('');
if (!changes.length) {
  log('✓ 版本 JSON 已经是正确状态，无需改动。');
  process.exit(0);
}

log('将要做的改动：');
for (const c of changes) log('  · ' + c);

if (problems.length) {
  log('\n⚠ 注意：');
  for (const p of problems) log('  ' + p);
}

if (DRY) {
  log('\n(dry-run) 未写入任何文件。');
  process.exit(problems.length ? 1 : 0);
}

const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const backup = `${versionJsonPath}.bak-${stamp}`;
copyFileSync(versionJsonPath, backup);

vj.libraries = withoutNeo;
writeFileSync(versionJsonPath, JSON.stringify(vj, null, 2), 'utf8');

log(`\n备份 -> ${relative(MC, backup)}`);
log(`已写入 ${relative(MC, versionJsonPath)}`);
log('\n✓ 完成。跑一次 tools/preflight.mjs 复核，然后启动游戏。');
