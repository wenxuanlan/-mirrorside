package work.dsh.mirror.gravity;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.RegisterDimensionSpecialEffectsEvent;

/**
 * 镜维度 · 客户端专属注册（只在物理客户端加载）。
 *
 * <h2>为什么单独一个类，而不是写在 MirrorGravity 里</h2>
 * 本类引用的 {@link RegisterDimensionSpecialEffectsEvent} 与
 * {@link MirrorDimensionEffects} 都是客户端专属类型。若把它们直接写进主类，
 * 专用服务端在加载主类时就会 {@code NoClassDefFoundError}。
 * 拆出来以后，只要调用方按物理端分流，服务端永远不会加载这个类。
 *
 * <h2>为什么用显式 {@code modBus.addListener} 而不是 @EventBusSubscriber</h2>
 * 注解要写 {@code bus = EventBusSubscriber.Bus.MOD}，而那个枚举在当前
 * NeoForge 版本里已经标记为"待删除"（编译会出弃用警告）。
 * 显式注册没有这个问题，而且"这个监听器挂在哪条总线上"变成了代码里看得见的一行，
 * 不用去猜注解默认值。
 *
 * <p>时机是安全的：模组构造函数在模组加载期执行，而
 * {@code RegisterDimensionSpecialEffectsEvent} 由
 * {@code ClientHooks.initClientHooks} 在 Minecraft 构造期间触发
 * （1.21.1 源码 ClientHooks 第 1034 行调用 {@code DimensionSpecialEffectsManager.init()}），
 * 一定晚于构造函数。
 *
 * <p>另外这个注册是<b>可选</b>的：NeoForge 的
 * {@code DimensionSpecialEffectsManager.getForType} 对未注册的 id 会回退到主世界效果
 * （源码里 {@code EFFECTS.getOrDefault(type, DEFAULT_EFFECTS)}，
 * 默认值就是 {@code OverworldEffects}）。所以万一注册没生效，
 * 镜维度只是"又有云了"，不会崩。
 */
public final class MirrorClientSetup {

    private MirrorClientSetup() {
    }

    /**
     * 数据包里引用的视觉效果 id 的路径部分。
     * 唯一真相在 {@code kubejs/config/mirror_dimension.json → dimension_type.effects}，
     * 那里写的是 {@code mirrorgravity:mirror}；改这里必须同时改那边
     * （{@code tools/generate-mirror-pack.mjs} 里有白名单校验，写错会直接报错）。
     */
    public static final String EFFECTS_PATH = "mirror";

    /** 由 {@link MirrorGravity} 的构造函数在客户端分支里调用。 */
    public static void register(IEventBus modBus) {
        modBus.addListener(MirrorClientSetup::onRegisterDimensionEffects);
    }

    private static void onRegisterDimensionEffects(RegisterDimensionSpecialEffectsEvent event) {
        event.register(
            ResourceLocation.fromNamespaceAndPath(MirrorGravity.MOD_ID, EFFECTS_PATH),
            new MirrorDimensionEffects());
        MirrorGravity.LOGGER.info("[镜维度·视觉] 已注册维度视觉效果 {}:{} —— 与主世界白天一致，但不画云",
            MirrorGravity.MOD_ID, EFFECTS_PATH);
    }
}
