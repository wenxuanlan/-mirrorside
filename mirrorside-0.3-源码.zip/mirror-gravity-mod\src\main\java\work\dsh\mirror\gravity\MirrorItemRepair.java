package work.dsh.mirror.gravity;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import work.dsh.mirror.gravity.internal.Failures;

/**
 * 修掉存档里**非法**的 {@code minecraft:block_entity_data} 组件。
 *
 * <h2>为什么需要这个"补丁的补丁"</h2>
 * 0.3 的第一版把下落实体的方块实体 NBT 用 {@code saveWithoutMetadata} 存下来，
 * 又原样塞进掉落物的 {@code block_entity_data} 组件 —— 而那个组件的编码器
 * {@code CustomData.CODEC_WITH_ID} 要求标签里必须有 String 类型的 {@code id}：
 * <pre>
 *   "Missing id for entity in: {Items:[...]}"
 * </pre>
 * 缺了它，这个物品**根本没法序列化**：玩家存档时 {@code ItemStack.save} 抛异常，
 * 整个 `Saving entity NBT` 流程崩掉（用户实测就是捡起箱子后崩溃）。
 *
 * <p>模组本身已经改成 {@code saveWithId} 了，但**已经在手里的那个箱子**
 * 不会自己变好 —— 只要它还在背包里，之后每次存档都会再崩一次。
 * 所以登录时扫一遍背包，把这半个组件修成合法的：
 * <ul>
 *   <li>能判断出方块实体类型 → 补上 {@code id}（内容物原样保留，物品变回正常）</li>
 *   <li>判断不出来（理论上不会）→ **移除**这个组件（宁可丢内容物，也不能让存档崩）</li>
 * </ul>
 *
 * <h2>为什么挂在登录事件上</h2>
 * 这是个"一次性修补"，不是每 tick 的检查（本项目明确不要每 tick 轮询）：
 * 玩家进世界时扫一遍自己的背包就够 —— 出问题的物品只可能来自 0.3 那一版，
 * 而它必然在某个玩家的背包里。
 *
 * <p>只修背包（含快捷栏与副手）：世界里的掉落物不扫（那要遍历实体，
 * 代价与收益不成比例）；真遇到了，捡起来再进一次世界就会被修好。
 */
@EventBusSubscriber(modid = MirrorGravity.MOD_ID)
public final class MirrorItemRepair {

    private MirrorItemRepair() {
    }

    @SubscribeEvent
    public static void onLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        try {
            Inventory inv = player.getInventory();
            int fixed = 0;
            int stripped = 0;
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack stack = inv.getItem(i);
                if (stack == null || stack.isEmpty()) {
                    continue;
                }
                CustomData data = stack.get(net.minecraft.core.component.DataComponents.BLOCK_ENTITY_DATA);
                if (data == null) {
                    continue;
                }
                CompoundTag tag = data.copyTag();
                /* 8 = TAG_String，与 CustomData.CODEC_WITH_ID 的校验条件一致。 */
                if (tag.contains("id", 8)) {
                    continue;
                }
                String id = blockEntityIdFor(stack);
                if (id == null) {
                    stack.remove(net.minecraft.core.component.DataComponents.BLOCK_ENTITY_DATA);
                    stripped++;
                    MirrorGravity.LOGGER.warn(
                        "[镜维度·修复] 背包第 {} 格的 {} 带着无法修复的方块实体数据，"
                            + "已移除该组件（不修就会在存档时崩）", i, stack.getItem());
                } else {
                    tag.putString("id", id);
                    stack.set(net.minecraft.core.component.DataComponents.BLOCK_ENTITY_DATA,
                        CustomData.of(tag));
                    fixed++;
                }
                inv.setItem(i, stack);
            }
            if (fixed > 0 || stripped > 0) {
                MirrorGravity.LOGGER.warn(
                    "[镜维度·修复] 已修补 {} 个、移除 {} 个非法的方块实体数据（0.3 首版遗留）",
                    fixed, stripped);
            }
        } catch (Throwable t) {
            /* 修补失败绝不能反过来把进世界搞崩 —— 记一笔静默失败就好。 */
            Failures.note("item_repair", t);
        }
    }

    /**
     * 从物品推出它的方块实体类型 id。
     *
     * <p>不能用"物品 id = 方块实体 id"这种猜测：多数情况下确实一样
     * （chest / barrel / furnace），但墙上的旗帜、告示牌这类不是
     * （{@code minecraft:wall_sign} 的方块实体类型是 {@code minecraft:sign}）。
     * 所以老实遍历注册表，用 {@link BlockEntityType#isValid(BlockState)} 问它认不认。
     */
    private static String blockEntityIdFor(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return null;
        }
        BlockState state = blockItem.getBlock().defaultBlockState();
        for (BlockEntityType<?> type : BuiltInRegistries.BLOCK_ENTITY_TYPE) {
            if (type.isValid(state)) {
                ResourceLocation rl = BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(type);
                return (rl == null) ? null : rl.toString();
            }
        }
        return null;
    }
}
