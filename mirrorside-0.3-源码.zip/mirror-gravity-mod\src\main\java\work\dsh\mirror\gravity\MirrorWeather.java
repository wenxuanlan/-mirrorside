package work.dsh.mirror.gravity;

import net.minecraft.server.level.ServerLevel;

/**
 * 镜维度天气：**永远晴天**。实现方式是"跳过原版天气循环"，
 * 也就是把地狱/末地的那条路径搬到镜维度上（挂钩点在
 * {@link work.dsh.mirror.gravity.mixin.ServerLevelWeatherMixin}）。
 *
 * <h2>为什么原版地狱/末地不下雨</h2>
 * {@code ServerLevel#advanceWeatherCycle()} 的整段天气逻辑都在
 * {@code if (this.dimensionType().hasSkyLight())} 里，
 * 而地狱/末地是 {@code has_skylight: false} ⇒ **根本不执行**。
 * 不是"每 tick 清理"，是"压根不跑"。
 *
 * <h2>镜维度为什么不能直接关掉天空光</h2>
 * 会连带改掉整个维度的照明（天空光层停用，只能靠方块光 + ambient_light），
 * 而设定要求"自然亮度，同主世界的白天亮度相当" —— 那正是靠天空光来的。
 * 所以保留天空光，只把天气那一段跳过。
 *
 * <h2>本类只放状态与判定</h2>
 * 全部逻辑挂在原版自己的每 tick 调用上（mixin），这里只提供：
 *   · 开关（唯一真相在 {@code mirror_config.js → weather.force_clear}）
 *   · "这个维度要不要跳过"的判定
 *   · 首次生效时的日志 + 清一次存档里残留的降水状态
 *
 * <p>之前那版"每服务端 tick 扫所有维度、发现下雨就 setWeatherParameters"已经删掉：
 * 既多余（每 tick 判定），又治标不治本（清完原版计时器还会再抽到下雨）。
 */
public final class MirrorWeather {

    private MirrorWeather() {
    }

    /**
     * 清一次天气后给"多久之后可以再下雨"的时间（刻）。
     * 只在"存档里带着下雨状态进来"时用一次；正常情况根本不需要清，
     * 因为镜像维度的天气循环已经被跳过、rainLevel 永远是 0。
     */
    private static final int CLEAR_TICKS = 2_400_000;

    private static volatile boolean forceClear = true;

    /** mixin 是否真的生效过（首次被调用时置位）。只用于日志与诊断。 */
    private static volatile boolean hooked = false;

    public static boolean forceClear() {
        return forceClear;
    }

    public static boolean hooked() {
        return hooked;
    }

    static void setForceClear(boolean value) {
        forceClear = value;
        MirrorGravity.LOGGER.info("[镜维度·天气] 跳过原版天气循环已{}", value ? "开启" : "关闭");
    }

    /** 由 mixin 调用：这个维度要不要跳过原版天气循环。 */
    public static boolean shouldSkipWeatherCycle(ServerLevel level) {
        return forceClear && level != null
            && MirrorPortalBlock.mirrorDimension().equals(level.dimension());
    }

    /**
     * 由 mixin 调用：决定跳过之后走这里。
     *
     * <p>正常路径上只做一次布尔读取（{@code isRaining()} 本身就是读字段），
     * 因为跳过之后 rainLevel 恒为 0，判定立刻返回。
     */
    public static void onWeatherCycleSkipped(ServerLevel level) {
        if (!hooked) {
            hooked = true;
            MirrorGravity.LOGGER.info("[镜维度·天气] 已接管原版天气循环（mixin 生效）："
                + "镜维度不会再有降水与雷暴");
        }
        if (level.isRaining() || level.isThundering()) {
            /* 存档带着下雨状态进来（或者有别的模组/指令硬塞了天气）——清一次。
             * 之后循环被跳过，不会再被抽到。 */
            MirrorGravity.LOGGER.info("[镜维度·天气] 清除残留的降水/雷暴状态");
            level.setWeatherParameters(CLEAR_TICKS, 0, false, false);
        }
    }
}
