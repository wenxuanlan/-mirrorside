package work.dsh.mirror.gravity.jei;

import java.util.List;

/**
 * 一条重力方块加工配方（JEI 展示用）。
 *
 * <h2>为什么单独建这个模型</h2>
 * JEI 的 {@code IRecipeCategory<T>} 需要一个具体的配方类型。它**不必**是
 * 原版的 {@code Recipe} —— 重力方块加工不是合成台配方，没有配方书、
 * 也不参与服务端合成，所以用一个只读的记录类即可，
 * 无需为它实现 Codec / Serializer（那样反而会污染配方注册表）。
 *
 * <h2>字段与实际配置的对应</h2>
 * 每个字段都对应 {@code mirror_config.js} 里 {@code gravityBlockRecipes.list}
 * 的一项，见 {@code tools/sync-jei-recipes.mjs}：
 * <ul>
 *   <li>{@code input}       输入方块（物品形式）</li>
 *   <li>{@code flips}       需要发生几次重力方向切换</li>
 *   <li>{@code landing}     true = 还要落在指定方块上才变；false = 交界处直接变</li>
 *   <li>{@code on}          落点要求，元素是方块 ID 或 {@code #标签}
 *                           （如 {@code #c:storage_blocks}）。可能有多条 ——
 *                           父标签聚合不到的东西（AnvilCraft 的粗矿块）要另外列</li>
 *   <li>{@code outputs}     产物的**候选列表**，元素同样是 ID 或 {@code #标签}。
 *                           动态产物（{@code @landed} / {@code @mapped}）会有多个候选，
 *                           JEI 会在一个槽里循环显示它们 —— 这样"铁砧落在任意矿物块上
 *                           变成那一块"在 JEI 里就能被搜到，而不是只写一句文字</li>
 *   <li>{@code drop}        true = 产物以**掉落物**形式弹出，而不是原地放成方块</li>
 *   <li>{@code insertItems} 「落在容器上时往容器里塞物品」的候选池；空表示没这个机制</li>
 * </ul>
 *
 * <p>{@code output} 只在<b>日志与排查</b>时用到（它保留配置里的原始写法，
 * 可能是 {@code @landed} 这种占位符）；JEI 版面一律用 {@code outputs}，
 * 因为占位符本身没法画成物品。
 */
public record GravityRecipe(
    String input,
    String output,
    List<String> outputs,
    int flips,
    boolean landing,
    List<String> on,
    boolean drop,
    List<String> insertItems,
    int insertCount,
    boolean insertForce
) {

    /** 是否带「往容器里塞物品」的机制。 */
    public boolean hasInsert() {
        return insertItems != null && !insertItems.isEmpty();
    }

    /**
     * 要画进 JEI 槽位的产物清单。
     *
     * <p>动态产物（{@code @landed} / {@code @mapped}）的候选由同步脚本算好放进
     * {@code outputs}；静态产物则退回到 {@code output} 本身。
     * 以 {@code @} 开头的占位符**不能**直接当物品 ID 解析，所以这里挡掉。
     */
    public List<String> outputSpecs() {
        if (outputs != null && !outputs.isEmpty()) {
            return outputs;
        }
        if (output != null && !output.startsWith("@")) {
            return List.of(output);
        }
        return List.of();
    }

    /** 展示用的条件描述（中文）。 */
    public String conditionText() {
        if (landing) {
            return "重力切换 " + flips + " 次后，落在下方方块上";
        }
        return "重力切换 " + flips + " 次后于交界处";
    }

    /**
     * 补充说明（一行，可能为空）。
     *
     * <p>刻意写成很短的小词并用「；」串起来：JEI 版面宽度是固定的，
     * 长句子会被画到边框外面。这里每一段都控制在 5 个字以内。
     */
    public String noteText() {
        StringBuilder sb = new StringBuilder();
        if (drop) {
            /* 措辞必须写死"不放方块"：这套机制里"产物是物品还是方块"很容易被误解 ——
             * 地狱疣既能当物品、也能种成方块，只写"掉落物形式"会让人不确定是哪种。 */
            append(sb, "产物掉落物弹出（不放方块）");
        }
        if ("@landed".equals(output)) {
            append(sb, "产物＝落点方块");
        } else if ("@mapped".equals(output)) {
            append(sb, "产物随落点");
        }
        if (hasInsert()) {
            append(sb, insertForce ? "容器满也触发" : "容器满则不触发");
        }
        return sb.toString();
    }

    private static void append(StringBuilder sb, String part) {
        if (sb.length() > 0) {
            sb.append('；');
        }
        sb.append(part);
    }

    /** 给落地要求槽用的提示文字。 */
    public String landingHintText() {
        return "需要落在：";
    }
}
