// =====================================================================
// 镜维度 · 实体状态表（所有按实体累积的可变状态都在这里）
// =====================================================================
// 为什么单独一个模块放这些表：
//   它们被区域判定、重力下发、配方加工三处共用。如果各自维护一份，
//   就会出现"同一个概念有两个副本、且只有一个被清理"的典型问题。
//   集中一处之后，"有哪些表、谁会写、谁负责清理"是看得清的。
//
// 调用约定：
//   · 表是普通对象（entityKey -> 值），直接读写即可
//   · **删实体时必须调用 forget(key)**，不要只删自己关心的那张表
//   · 周期性对账由 sweep(liveIds) 负责（见文件末尾说明）
//
// ⚠️ 所有 try 块内只用 var（Rhino 对 try 里的 const/let 会抛
//    InternalError: TypeError: redeclaration of var xxx）
// =====================================================================

const MirrorState = (() => {

  const N0 = global.MirrorDimension.modules.n0;
  if (N0 === undefined || !N0.ready) {
    console.error('[镜维度] 基础层未就绪，状态表未启用。');
    return { ready: false };
  }

  const entityKey = N0.entityKey;

  /* ------------------------------------------------------------------ */
  /* 状态表                                                              */
  /* ------------------------------------------------------------------ */

  /** entityId -> { dir, lastFlipAt }
   *  该实体当前的重力基线方向，以及上一次真正翻转的时刻（tick）。
   *
   *  ⚠️ 必须"每次下发都写"，不能只在方向变化时写。
   *     只在变化时写会形成死循环：prev 永远为 null → 防抖永不生效。
   *     这个坑排查了很久，详见 README §11.7。 */
  const lastDir = {};

  /** entityId -> { dir, ticks }
   *  正在等待"确认停留"的反向。ticks 是已经连续停留在反向的 tick 数。 */
  const pendingFlip = {};

  /** entityId -> { crossings }
   *  重力方向切换的累计次数，供重力方块配方使用。 */
  const recipeState = {};

  /* ⛔ lastHalf（entityId → 'upper'|'lower'，旧的"跨线计数"用的半区表）
   *    已随 n3 的 trackCrossing 一起删除 —— 现在只有一种计数方式：
   *    读模组给出的实际方向（见下面的 lastFlipDir）。 */

  /** entityId -> 方向名
   *  上一次读到的模组实际方向。flip 模式的计数靠它判断"方向是否变了"。 */
  const lastFlipDir = {};

  /** entityId -> { min, max, n, crossings }
   *  下落方块的 y 区间统计，用于回答"它到底有没有越过某条线、摆幅多大"。
   *  这是排查摆幅问题时唯一能替代肉眼观察的数据来源。 */
  const swingRange = {};

  /* ------------------------------------------------------------------ */
  /* 计时与计数器                                                        */
  /* ------------------------------------------------------------------ */

  /** 全局 tick 计数（防抖用它算"距离上次翻转过了多久"）。 */
  let gravityTick = 0;

  /** 被防抖挡下的翻转次数，供 /mirror gravity 展示。 */
  let blockedFlips = 0;

  /** 最近一次下发尝试的记录，供 /mirror gravity 展示。 */
  let lastAttempt = null;

  /** 实体扫描的统计，供 /mirror info 展示。handled<0 表示上次扫描出错了。
   *  skipped = 本轮因"没到自己的检测间隔"而跳过的掉落物个数。 */
  let scanStats = { handled: -1, skipped: -1, changed: -1 };

  function tick() {
    gravityTick++;
  }

  function now() {
    return gravityTick;
  }

  function countBlockedFlip() {
    blockedFlips++;
  }

  /* ------------------------------------------------------------------ */
  /* 统一的实体状态清理                                                  */
  /* ------------------------------------------------------------------ */

  /* ⚠️ 新增任何"以 entityKey 为键"的表时，必须同时加进这个列表。
   *    漏了就会随实体总数缓慢增长（长期挂机时表现为内存只涨不降）。 */
  const TABLES = {
    lastDir: lastDir,
    pendingFlip: pendingFlip,
    recipeState: recipeState,
    lastFlipDir: lastFlipDir,
    swingRange: swingRange,
  };

  /** 清掉一个实体的全部状态。实体消失时应当调用这个，而不是逐个 delete。 */
  function forget(key) {
    if (key == null) return;
    for (const name in TABLES) {
      if (Object.prototype.hasOwnProperty.call(TABLES, name)) {
        delete TABLES[name][key];
      }
    }
  }

  /* ⛔ tableOf()（按名字取状态表）与 shortId() 同类：全项目没有任何调用点，
   *    0.3 的契约收紧时删除。要按名字取表时，用下面的 tableNames() + TABLES 直接取。 */

  /** 状态表名字清单（诊断与调试用）。 */
  function tableNames() {
    const out = [];
    for (const name in TABLES) {
      if (Object.prototype.hasOwnProperty.call(TABLES, name)) out.push(name);
    }
    return out;
  }

  /** 当前记录了状态的实体数（诊断用）。 */
  function trackedEntityCount() {
    let n = 0;
    for (const name in TABLES) {
      if (Object.prototype.hasOwnProperty.call(TABLES, name)) {
        for (const k in TABLES[name]) {
          if (Object.prototype.hasOwnProperty.call(TABLES[name], k)) { n++; break; }
        }
      }
    }
    return n;
  }

  /* ------------------------------------------------------------------ */
  /* 周期性对账清扫                                                      */
  /* ------------------------------------------------------------------ */
  /* ⚠️ 为什么需要它：KubeJS 的实体事件里**没有** removal
   * （EntityEvents 只有 DEATH / SPAWNED / BEFORE_HURT / AFTER_HURT /
   *   CHECK_SPAWN / ENTITY_DROPS），所以无法在实体消失的那一刻清理。
   * 用一个低频全量对账代替 —— 400 tick（20 秒）一次，开销可忽略。
   *
   * 为什么不用 KubeJS 的 kjs$getEntityByUUID 做逐个 O(1) 查存活：
   * 那个方法要的是 UUID，而 entityKey 用的是 entity.getId()（整数）。
   * 混用两套标识容易出错，而调用方本来就要遍历镜维度的实体，
   * 顺带收集一份存活 id 集合几乎零成本。 */

  const SWEEP_INTERVAL = 400;
  let sweepCounter = 0;

  /** 本 tick 是否该做对账（调用方据此决定要不要收集 liveIds）。 */
  function shouldSweep() {
    sweepCounter++;
    return (sweepCounter % SWEEP_INTERVAL) === 0;
  }

  /**
   * 把已经不存在的实体从所有状态表里删掉。
   *
   * @param liveIds Set<string>，当前存活实体的 entityKey 集合
   */
  function sweep(liveIds) {
    try {
      var keys = [];
      for (const name in TABLES) {
        if (!Object.prototype.hasOwnProperty.call(TABLES, name)) continue;
        var t = TABLES[name];
        for (const k in t) {
          if (Object.prototype.hasOwnProperty.call(t, k)) keys.push(k);
        }
      }
      if (keys.length === 0) return;

      var removed = 0;
      for (const k of keys) {
        if (!liveIds.has(k)) {
          forget(k);
          removed++;
        }
      }
      if (removed > 0) {
        console.info('[镜维度·清理] 清掉 ' + removed + ' 条已消失实体的状态记录');
      }
    } catch (err) {
      N0.fail('state', err);
      // 清理失败不影响玩法
    }
  }

  /* ------------------------------------------------------------------ */
  /* 对外导出                                                            */
  /* ------------------------------------------------------------------ */

  const api = {
    ready: true,

    // 表（直接读写）
    lastDir: lastDir,
    pendingFlip: pendingFlip,
    recipeState: recipeState,
    lastFlipDir: lastFlipDir,
    swingRange: swingRange,

    // 计时与统计
    tick: tick,
    now: now,
    countBlockedFlip: countBlockedFlip,
    blockedFlips: function () { return blockedFlips; },
    setLastAttempt: function (v) { lastAttempt = v; },
    lastAttempt: function () { return lastAttempt; },
    setScanStats: function (v) { scanStats = v; },
    scanStats: function () { return scanStats; },

    // 清理
    forget: forget,
    tableNames: tableNames,
    trackedEntityCount: trackedEntityCount,
    shouldSweep: shouldSweep,
    sweep: sweep,

    // 便捷：按实体清理
    forgetEntity: function (entity) { forget(entityKey(entity)); },
  };

  global.MirrorDimension.modules.n1 = api;
  return api;
})();
