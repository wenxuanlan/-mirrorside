// =====================================================================
// 镜维度 · 波粒观测（0.3 新玩法：把引力配方"手动"跑一遍）
// =====================================================================
// 玩法：四个波粒块围住中间那格，中间放**要观测的方块**，拿望远镜右键它：
//   · 方块 → 方块（红沙直接变金块，不必真扔下去）
//   · 方块 → 物品（灵魂沙 → 地狱疣）
//   · 方块 → 实体（蛋糕 → 悦灵）
//   · 染色方块 → 同族的随机另一种颜色
//
// ── 这个文件只做"规则"，不做世界写操作 ────────────────────────────────
//   结构判定、换方块（要搬运朝向等属性）、弹物品、生成实体，全在模组的
//   work.dsh.mirror.gravity.MirrorObservation 里 —— 那些必须贴着
//   BlockState / Property / EntityType 走，Rhino 里写不出来。
//   这里负责：推送结构与族表、把靶心方块对上配方、把结果交给模组。
//
// ── 匹配顺序（重要）────────────────────────────────────────────────────
//   1) 专用配方 observation.recipes          （用户点名的新配方）
//   2) 引力配方（若 reuse_gravity_recipes）  （接触类优先于穿越类）
//   3) 染色方块随机换色（兜底）
//   "专用优先"意味着：羊毛→蜘蛛网 这条一写，羊毛就不会再随机换色了。
//
// ── 事件来源 ───────────────────────────────────────────────────────────
//   KubeJS 的 BlockEvents.rightClicked 挂的是 NeoForge 的
//   PlayerInteractEvent.RightClickBlock，它在 ServerPlayerGameMode#useItemOn
//   的**最开始**触发，所以手持望远镜右键方块一样会进来（望远镜"开镜"是
//   物品的 use 行为，发生在方块交互之后）。这一条在传送门那边已经查证过。
//
// ⚠️ 所有 try 块内只用 var（Rhino 对 try 里的 const/let 会抛
//    InternalError: TypeError: redeclaration of var xxx）
// =====================================================================

const MirrorObservationModule = (() => {

  const MD = global.MirrorDimension;
  const N0 = MD.modules.n0;
  if (N0 === undefined || !N0.ready) {
    console.error('[镜维度] 基础层未就绪，波粒观测模块未启用。');
    return { ready: false };
  }

  const cfg = N0.cfg;
  const P = (cfg.observation != null) ? cfg.observation : {};

  /* ⚠️ 这里**故意没有**给玩家发消息的函数（用户要求：加工过程不要聊天栏提示）。
   * 反馈只走粒子 + 音效（见 effectFeedback），要排查就看服务端日志
   * 里那一行「[镜维度·波粒观测] …观测成…」或 /mirror diag。 */

  function effectsOn(what) {
    const e = P.effects;
    return !(e == null || e[what] === false);
  }

  /* ------------------------------------------------------------------ */
  /* 一、把结构与配色族推给模组                                          */
  /* ------------------------------------------------------------------ */

  function pushToMod() {
    try {
      var MG = N0.selfModApi;
      if (MG == null) {
        console.warn('[镜维度·波粒观测] 自研模组未接入，观测不会生效。');
        return;
      }
      MG.setObservationPattern(String(P.pattern != null ? P.pattern : ''));
      MG.setObservationColorFamilies(String(P.color_families_csv != null ? P.color_families_csv : ''));
    } catch (err) {
      N0.fail('observation', err);
    }
  }

  pushToMod();

  /* ------------------------------------------------------------------ */
  /* 二、专用配方：整理 + 加载期自检                                     */
  /* ------------------------------------------------------------------ */

  /* 专用配方索引：input（方块 id 或 '#标签'）→ 该输入的配方列表。
   * 用索引而不是每次遍历，是因为引力配方有 500 多条 ——
   * 右键是玩家动作，不该顺手扫一遍全表（本项目有一条"别做无谓的遍历"的教训）。 */
  const specialByInput = {};
  let specialCount = 0;

  function addSpecial(one) {
    if (one == null || one.input == null) {
      console.error('[镜维度·波粒观测] 专用配方缺少 input: ' + JSON.stringify(one));
      return;
    }
    if (one.output == null && one.entity == null) {
      console.error('[镜维度·波粒观测] 专用配方 ' + one.id
        + ' 既没有 output 也没有 entity —— 它永远不会产生任何结果。');
      return;
    }
    const input = String(one.input);
    const r = {
      id: String(one.id != null ? one.id : input),
      input: input,
      output: one.output != null ? String(one.output) : null,
      entity: one.entity != null ? String(one.entity) : null,
      drop: one.drop === true,
      on: one.on != null ? String(one.on) : null,
    };
    specialCount++;

    /* 加载期自检：产物到底存不存在。
     * 为什么值得查：产物 id 写错了不会在加载期报错，只会在玩家第一次
     * 试这个配方时"什么都没发生" —— 那是本项目最贵的一类排查。
     * 模组那两个口子（blockIdExists / validateStackSpec）就是为这个留的。 */
    try {
      var MG = N0.selfModApi;
      if (MG != null && r.output != null) {
        var isBlock = (MG.blockIdExists != null) && MG.blockIdExists(r.output) === true;
        if (!isBlock || r.drop) {
          var why = (MG.validateStackSpec != null)
            ? MG.validateStackSpec('{"id":"' + r.output + '"}')
            : null;
          if (why != null) {
            console.error('[镜维度·波粒观测] 专用配方 ' + r.id + ' 的产物 ' + r.output
              + ' 既不是方块也不是物品：' + why);
          } else if (!isBlock) {
            console.warn('[镜维度·波粒观测] 专用配方 ' + r.id + ' 的产物 ' + r.output
              + ' 是物品（世界里没有同名方块），会以掉落物弹出。');
          }
        }
      }
    } catch (err) {
      N0.fail('observation', err);
    }

    if (specialByInput[input] == null) {
      specialByInput[input] = [];
    }
    specialByInput[input].push(r);
  }

  (P.recipes != null ? P.recipes : []).forEach(addSpecial);

  /* ------------------------------------------------------------------ */
  /* 三、配色族：方块 id → 族名（随机换色兜底要用）                      */
  /* ------------------------------------------------------------------ */

  const familyOf = {};
  let familyCount = 0;

  (function () {
    var members = P.color_family_members;
    if (members == null) return;
    for (var name in members) {
      if (!Object.prototype.hasOwnProperty.call(members, name)) continue;
      var ids = members[name];
      if (ids == null || ids.length < 2) continue;
      familyCount++;
      for (var i = 0; i < ids.length; i++) {
        familyOf[String(ids[i])] = name;
      }
    }
  })();

  /* ------------------------------------------------------------------ */
  /* 四、引力配方：按 input 建索引（**懒建**，见下面的顺序坑）            */
  /* ------------------------------------------------------------------ */

  /* ⚠️ 顺序坑（踩过）：脚本按**文件名**顺序加载，
   *    'mirror_n10_…' 排在 'mirror_n3_…' **前面**（'1' < '3'）。
   *    所以加载期 MD.modules.n3 还不存在 —— 早先在这里直接取 n3，
   *    结果引力配方索引永远是空的，而表现只是"观测里 500 多条配方全都不生效，
   *    只剩 4 条专用配方"，日志里只有一条 warn。
   *    改成第一次真正要用的时候再取，顺便把标签表也一起建出来。 */
  let gravityByInput = null;
  let gravityCount = 0;
  let TAG_CSV = '';

  function ensureGravityIndex() {
    if (gravityByInput != null) return;
    gravityByInput = {};
    const N3 = MD.modules.n3;
    if (P.reuse_gravity_recipes !== false && N3 != null && N3.ready && N3.list != null) {
      try {
        var all = N3.list();
        for (var i = 0; i < all.length; i++) {
          var r = all[i];
          if (r == null || r.input == null) continue;
          var key = String(r.input);
          if (gravityByInput[key] == null) gravityByInput[key] = [];
          gravityByInput[key].push(r);
          gravityCount++;
        }
      } catch (err) {
        N0.fail('observation', err);
      }
    } else if (P.reuse_gravity_recipes !== false) {
      console.warn('[镜维度·波粒观测] 引力配方模块（n3）未就绪，本次只认专用配方。');
    }
    TAG_CSV = collectTags();
  }

  /* ------------------------------------------------------------------ */
  /* 五、标签：把所有可能要查的标签收集起来，一次问模组                   */
  /* ------------------------------------------------------------------ */

  /* 为什么要收集：靶心与靶心下方各查一次标签，如果按配方逐条问，
   * 一次右键就是几十次跨语言调用。这里把所有用到的标签拼成一行，
   * 模组一次回一组命中结果（见 MirrorGravityApi.blockTagsAt）。 */
  function collectTags() {
    var seen = {};
    var out = [];
    function want(one) {
      if (one == null) return;
      var s = String(one);
      if (s.charAt(0) !== '#') return;
      if (seen[s] === true) return;
      seen[s] = true;
      out.push(s);
    }
    for (var k in specialByInput) {
      if (!Object.prototype.hasOwnProperty.call(specialByInput, k)) continue;
      want(k);
      var list = specialByInput[k];
      for (var i = 0; i < list.length; i++) want(list[i].on);
    }
    for (var g in gravityByInput) {
      if (!Object.prototype.hasOwnProperty.call(gravityByInput, g)) continue;
      want(g);
      var gl = gravityByInput[g];
      for (var j = 0; j < gl.length; j++) {
        var onList = gl[j].onList;
        if (onList == null) continue;
        for (var m = 0; m < onList.length; m++) want(onList[m]);
      }
    }
    return out.join(',');
  }

  /** 问模组某个位置命中了哪些标签，返回数组（元素形如 '#minecraft:wool'）。 */
  function tagsAt(level, pos) {
    if (TAG_CSV === '') return [];
    try {
      var MG = N0.selfModApi;
      if (MG == null || MG.blockTagsAt == null) return [];
      var hit = String(MG.blockTagsAt(level, pos, TAG_CSV));
      return (hit === '') ? [] : hit.split(',');
    } catch (err) {
      N0.fail('observation', err);
      return [];
    }
  }

  /* ------------------------------------------------------------------ */
  /* 六、匹配                                                            */
  /* ------------------------------------------------------------------ */

  /** 一个"要求"（方块 id 或 '#标签'）与"实际情况"（id + 命中标签）是否相符。 */
  function fits(want, id, tags) {
    if (want == null) return true;
    var w = String(want);
    if (w.charAt(0) === '#') {
      for (var i = 0; i < tags.length; i++) {
        if (tags[i] === w) return true;
      }
      return false;
    }
    return w === id;
  }

  /**
   * 专用配方：input 对上靶心，且 on（若有）对上靶心正下方。
   */
  function matchSpecial(targetId, targetTags, belowId, belowTags) {
    var cands = [];
    if (specialByInput[targetId] != null) {
      cands = cands.concat(specialByInput[targetId]);
    }
    for (var k in specialByInput) {
      if (!Object.prototype.hasOwnProperty.call(specialByInput, k)) continue;
      if (k.charAt(0) !== '#') continue;
      if (fits(k, targetId, targetTags)) {
        cands = cands.concat(specialByInput[k]);
      }
    }
    for (var i = 0; i < cands.length; i++) {
      var r = cands[i];
      if (!fits(r.on, belowId, belowTags)) continue;
      if (r.entity != null) {
        return { type: 'entity', id: r.entity, from: r.id };
      }
      if (r.drop) {
        return { type: 'item', stack: r.output, from: r.id };
      }
      return { type: 'block', id: r.output, from: r.id };
    }
    return null;
  }

  /**
   * 引力配方：接触类（landing）优先于穿越类（crossing）。
   *
   * <p>为什么是这个顺序：接触类多一个"下面是什么"的条件，条件更多的先判，
   * 语义才与引力系统里一致（那边也是先试 landing）。反过来的话，
   * "红沙 → 金块"这条会把"红沙放在荧石上 → 荧石"这条永远盖住。
   */
  function matchGravity(targetId, targetTags, belowId, belowTags, level, pos) {
    ensureGravityIndex();
    if (gravityCount === 0) return null;
    var N3 = MD.modules.n3;
    if (N3 == null || N3.observationAction == null) return null;

    var cands = [];
    if (gravityByInput[targetId] != null) {
      cands = cands.concat(gravityByInput[targetId]);
    }
    for (var k in gravityByInput) {
      if (!Object.prototype.hasOwnProperty.call(gravityByInput, k)) continue;
      if (k.charAt(0) !== '#') continue;
      if (fits(k, targetId, targetTags)) {
        cands = cands.concat(gravityByInput[k]);
      }
    }

    var order = ['landing', 'crossing'];
    for (var oi = 0; oi < order.length; oi++) {
      for (var i = 0; i < cands.length; i++) {
        var r = cands[i];
        if (String(r.trigger) !== order[oi]) continue;
        if (order[oi] === 'landing') {
          var okOn = false;
          var onList = r.onList;
          for (var j = 0; j < (onList != null ? onList.length : 0); j++) {
            if (fits(onList[j], belowId, belowTags)) { okOn = true; break; }
          }
          if (!okOn) continue;
        }
        var action = N3.observationAction(r, belowId);
        if (action == null) continue;
        action.from = String(r.id);
        return action;
      }
    }
    return null;
  }

  /* ------------------------------------------------------------------ */
  /* 七、动作描述 → 一行 JSON（手工拼，不用 JSON.stringify）             */
  /* ------------------------------------------------------------------ */

  /* ⚠️ 为什么手工拼：Rhino 的 JSON.stringify 会把整数写成 "1.0"，
   * 而模组侧解析物品堆 JSON 用的原版 ItemStack.CODEC 要求 count 是 int ——
   * 骨块→山羊角那次 7 次"生成失败"就是这么来的。这里虽然只有 id / stack
   * 两个字段，但规矩照旧：不把整数交给 Rhino 去序列化。 */
  function actionJson(a) {
    if (a == null) return '';
    if (a.type === 'block') {
      return '{"type":"block","id":' + JSON.stringify(String(a.id)) + '}';
    }
    if (a.type === 'item') {
      /* stack 里可能本身就是物品堆 JSON（@random 的池子），
       * 交给 JSON.stringify 转义引号，模组侧会反转义回来。 */
      return '{"type":"item","stack":' + JSON.stringify(String(a.stack)) + '}';
    }
    if (a.type === 'entity') {
      return '{"type":"entity","id":' + JSON.stringify(String(a.id)) + '}';
    }
    if (a.type === 'recolor') {
      return '{"type":"recolor","family":' + JSON.stringify(String(a.family)) + '}';
    }
    return '';
  }

  /* ------------------------------------------------------------------ */
  /* 八、反馈（粒子 / 音效 / 文字）                                      */
  /* ------------------------------------------------------------------ */

  function effectFeedback(level, pos) {
    try {
      var x = pos.getX();
      var y = pos.getY();
      var z = pos.getZ();
      if (effectsOn('particles') && level.spawnParticles != null) {
        level.spawnParticles('minecraft:end_rod', x + 0.5, y + 0.5, z + 0.5, 12, 0.35, 0.35, 0.35, 0.02);
      }
      if (effectsOn('sound') && level.playSound != null) {
        level.playSound(null, x + 0.5, y + 0.5, z + 0.5,
          'minecraft:block.amethyst_block.chime', 'blocks', 0.7, 1.4);
      }
    } catch (err) {
      /* 纯表现，失败不影响玩法；但仍然记一笔，免得"特效没了"查无实据。 */
      N0.fail('observation', err);
    }
  }

  /* ------------------------------------------------------------------ */
  /* 九、右键事件                                                        */
  /* ------------------------------------------------------------------ */

  BlockEvents.rightClicked(event => {
    if (P.enabled === false) return;

    var want = String(P.item != null ? P.item : 'minecraft:spyglass');
    var held;
    try {
      held = String(event.item.id);
    } catch (err) {
      return;
    }
    if (held !== want) return;

    var MG = N0.selfModApi;
    if (MG == null || MG.observationProbe == null) return;

    var level = event.block.level;
    var pos = event.block.pos;

    var probe;
    try {
      probe = String(MG.observationProbe(level, pos));
    } catch (err) {
      N0.fail('observation', err);
      return;
    }

    /* 三种"不算数"的情况：
     *   not_server     —— 客户端那一侧也会进来，静默
     *   no_wave_blocks —— 连波粒块都没有，玩家只是拿望远镜随手点了别处，静默
     *   bad_pattern    —— 有波粒块但结构不完整（搭错了），记一条日志，
     *                     但**不给玩家发消息**（用户要求删掉聊天栏提示） */
    if (probe === 'not_server' || probe === 'no_wave_blocks') return;
    if (probe.indexOf('ok|') !== 0) {
      console.info('[镜维度·波粒观测] 结构不完整 @ ' + pos);
      return;
    }

    var parts = probe.split('|');
    var targetId = String(parts[2]);
    var belowId = String(parts[3]);

    if (targetId === 'minecraft:air' || targetId === '') {
      console.info('[镜维度·波粒观测] 靶心是空的 @ ' + pos);
      return;
    }

    /* 第一次右键时把引力配方索引与标签表建起来（见"顺序坑"）。 */
    ensureGravityIndex();

    var targetTags = tagsAt(level, pos);
    /* 靶心正下方那一格：接触类配方（红沙 + 荧石 → 荧石）就是看它。
     * 它也在 3×3×5 的包围盒里，但属于"放什么都行"的位置 —— 这正是
     * 用户要求"其余格子不受约束"的原因。 */
    var belowTags = tagsAt(level, pos.below());

    var hit = matchSpecial(targetId, targetTags, belowId, belowTags);
    if (hit == null) {
      hit = matchGravity(targetId, targetTags, belowId, belowTags, level, pos);
    }
    /* 兜底：染色方块 → 同族的随机另一种颜色（用户要求：同类型不同颜色） */
    if (hit == null && P.recolor != null && P.recolor.enabled !== false) {
      var fam = familyOf[targetId];
      if (fam != null) {
        hit = { type: 'recolor', family: fam, from: 'recolor:' + fam };
      }
    }

    if (hit == null) {
      console.info('[镜维度·波粒观测] 靶心 ' + targetId + '（下方 ' + belowId + '）没有命中的配方 @ ' + pos);
      return;
    }

    var code;
    try {
      code = String(MG.applyObservation(level, pos, actionJson(hit)));
    } catch (err) {
      N0.fail('observation', err);
      return;
    }

    if (code === 'not_server') return;
    if (code !== 'ok') {
      console.info('[镜维度·波粒观测] 加工失败: ' + code + '（' + describe(code) + '）@ ' + pos);
      return;
    }

    /* 反馈只有粒子与音效 —— 用户要求不发聊天栏消息。 */
    effectFeedback(level, pos);
    console.info('[镜维度·波粒观测] ' + event.player.username + ' 在 ' + pos
      + ' 把 ' + targetId + '（下方 ' + belowId + '）观测成 ' + describeAction(hit)
      + '（配方 ' + (hit.from != null ? hit.from : '?') + '）');
  });

  /* ------------------------------------------------------------------ */
  /* 十、文案                                                            */
  /* ------------------------------------------------------------------ */

  /** 结果码的中文说明由模组统一提供，这里只做兜底（避免两处维护同一批文案）。 */
  function describe(code) {
    try {
      var MG = N0.selfModApi;
      if (MG != null && MG.describeObservationResult != null) {
        return String(MG.describeObservationResult(code));
      }
    } catch (err) {
      N0.fail('observation', err);
    }
    return code;
  }

  function shortId(id) {
    var s = String(id);
    var i = s.indexOf(':');
    return i >= 0 ? s.slice(i + 1) : s;
  }

  function describeAction(a) {
    if (a.type === 'block') return shortId(a.id);
    if (a.type === 'item') return shortId(a.stack) + '（掉落物）';
    if (a.type === 'entity') return shortId(a.id) + '（实体）';
    if (a.type === 'recolor') return '同族的随机另一种颜色';
    return '?';
  }

  /* ------------------------------------------------------------------ */
  /* 对外导出                                                            */
  /* ------------------------------------------------------------------ */

  const api = {
    ready: true,
    enabled: function () { return P.enabled !== false; },
    /** 诊断用：专用配方 / 引力配方 / 配色族各有几条。 */
    counts: function () {
      ensureGravityIndex();
      return { special: specialCount, gravity: gravityCount, families: familyCount,
        tags: TAG_CSV === '' ? 0 : TAG_CSV.split(',').length };
    },
    familyOf: function (blockId) { return familyOf[String(blockId)]; },
  };

  global.MirrorDimension.modules.n10 = api;

  console.info('[镜维度·波粒观测] 已就绪 — 用 '
    + String(P.item != null ? P.item : 'minecraft:spyglass')
    + ' 右键结构中心：专用配方 ' + specialCount + ' 条、配色族 ' + familyCount
    + ' 个（引力配方在第一次使用时接入）'
    + (P.enabled === false ? '（**配置里关掉了**）' : ''));

  return api;
})();
