#!/usr/bin/env node
/**
 * 从 KubeJS 配置导出「重力方块加工」配方，供 JEI 展示。
 *
 * ── 为什么要这一步 ────────────────────────────────────────────────
 * 真正决定加工行为的是：
 *     <实例>/kubejs/startup_scripts/mirror_config.js → gravityBlockRecipes
 *
 * 而 JEI 的配方注册发生在**客户端启动期**（世界还没加载），
 * 那时 KubeJS 脚本还没跑；加上 KubeJS 脚本**无法写文件**
 * （classfilter 拦掉了 java.nio.file，也没有现成的 Path 入口），
 * 所以不能指望"运行时导出"。
 *
 * 于是把这份配置**派生成**模组 jar 内的资源文件：
 *     mirror-gravity-mod/src/main/resources/gravity_recipes.json
 * Java 侧在 JEI 注册配方时读它（见 GravityRecipeData）。
 *
 * ── 关键改动：把配置**真的跑一遍** ────────────────────────────────
 * 早先这里是拿正则去"读"配置文本的，结果是残缺的：
 *   · 文件末尾用循环生成的 32 条混凝土配方**一条都没导出**（只认字面量）
 *   · 落点标签（on: '#c:storage_blocks'）、容器插入池（insert.items）、
 *     动态产物（@landed）全部丢失
 * 于是 JEI 里只有最初手写的那两条，看起来就是"配方没进 JEI"。
 *
 * 现在改为 `new Function(src)` 直接执行配置脚本、取回 MIRROR_CONFIG。
 * mirror_config.js 本来就是**纯数据 + 一个循环**（不依赖任何游戏 API，
 * 这也是它当初能写成脚本的原因），所以在 Node 里跑得通，
 * 导出的内容与运行时**逐字段一致**。tools-build/check-recipes.mjs
 * 一直就是这么干的 —— 这里只是把同一招用在导出上。
 *
 * ── 用法 ─────────────────────────────────────────────────────────
 *     cd <实例目录>
 *     node tools/sync-jei-recipes.mjs
 *     # 然后重新构建模组，新配方才会进 JEI
 *
 * 改完 mirror_config.js 的配方记得跑一次。
 * 忘了也不会出危险：游戏逻辑始终以 mirror_config.js 为准，
 * 只是 JEI 里显示的内容会与实际的脱节。
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const instanceRoot = resolve(here, '..');

const CONFIG = join(instanceRoot, 'kubejs', 'startup_scripts', 'mirror_config.js');

/*
 * 模组工程的位置。
 *
 * 目录结构（相对本脚本）：
 *   <实例>/tools/sync-jei-recipes.mjs      ← 本脚本
 *   <实例>                                   ← 上一层
 *   <工程根>/.minecraft/versions/<实例>       ← 再上两层
 *   <工程根>/mirror-gravity-mod              ← 模组工程
 * 所以从实例根往上三层才是工程根。
 */
const PROJECT_ROOT = resolve(instanceRoot, '..', '..', '..');
const OUT = process.argv[2]
  ? resolve(process.argv[2])
  : join(PROJECT_ROOT, 'mirror-gravity-mod', 'src', 'main', 'resources', 'gravity_recipes.json');

if (!existsSync(CONFIG)) {
  console.error(`找不到配置文件：${CONFIG}`);
  process.exit(1);
}

mkdirSync(dirname(OUT), { recursive: true });

/* ------------------------------------------------------------------ */
/* 1) 执行配置脚本，拿到真正的配方表                                     */
/* ------------------------------------------------------------------ */

const src = readFileSync(CONFIG, 'utf8');

/**
 * 配置脚本最后一行是 `global.MIRROR_CONFIG = MIRROR_CONFIG;`。
 * Node 里没有那个 `global` 语义（会在严格模式下报错），
 * 也不该往真 global 上挂东西，所以去掉它、直接 return 变量。
 */
const cleaned = src.replace(/^\s*global\.MIRROR_CONFIG\s*=\s*MIRROR_CONFIG\s*;?\s*$/m, '');

let cfg;
try {
  cfg = new Function(cleaned + '\n; return MIRROR_CONFIG;')();
} catch (err) {
  console.error('执行 mirror_config.js 失败（它必须保持"纯数据 + 无游戏 API"）：');
  console.error('  ' + err.message);
  process.exit(1);
}

const gbr = cfg != null ? cfg.gravityBlockRecipes : null;
const list = Array.isArray(gbr) ? gbr : (gbr != null && Array.isArray(gbr.list) ? gbr.list : []);

if (list.length === 0) {
  console.error('⚠️  配置里没有解析出任何配方 —— 请检查 mirror_config.js 的 gravityBlockRecipes.list');
  process.exit(1);
}

/* ------------------------------------------------------------------ */
/* 2) 转成 JEI 展示用的形状                                             */
/* ------------------------------------------------------------------ */

/** 统一成"字符串数组"：on 允许写一条，也允许写一组。 */
function asList(v) {
  if (v == null) return [];
  if (Array.isArray(v)) return v.map(String);
  return [String(v)];
}

/** 去重（保持顺序）。 */
function uniq(arr) {
  const seen = new Set();
  const out = [];
  for (const x of arr) {
    if (!seen.has(x)) {
      seen.add(x);
      out.push(x);
    }
  }
  return out;
}

const recipes = [];
const warnings = [];

for (const spec of list) {
  if (spec == null || spec.input == null || spec.output == null) continue;

  const input = String(spec.input);
  const output = String(spec.output);
  const trigger = spec.trigger != null ? String(spec.trigger) : 'crossing';
  const landing = trigger === 'landing';
  const flips = Math.max(1, Number(spec.crossings != null ? spec.crossings : 1));
  const onList = asList(spec.on);
  const map = (spec.map != null && typeof spec.map === 'object') ? spec.map : null;
  const drop = spec.drop === true;

  /* 产物候选（JEI 要画成真实物品槽，所以必须是能解析的东西）：
   *   @landed —— 产物就是落点，候选即落点那一组
   *   @mapped —— 产物由 map 表决定，候选即表里的全部取值
   *   其它    —— 就是产物本身
   * 以 '@' 开头的占位符不能直接当物品 ID 解析，所以这里必须换掉。 */
  let outputs;
  if (output === '@landed') {
    outputs = onList;
    if (onList.length === 0) {
      warnings.push(`${input}: 产物是 @landed 但没有 on，JEI 里产物槽会是空的`);
    }
  } else if (output === '@mapped') {
    if (map == null) {
      warnings.push(`${input}: 产物是 @mapped 但没有 map，JEI 里产物槽会是空的`);
      outputs = [];
    } else {
      outputs = uniq(Object.values(map).map(String));
    }
  } else if (output === '@random') {
    /* @random：候选就是 pool。pool 元素可能是**物品堆对象**
     * （山羊角 8 种 = 同一物品 + 不同 instrument 组件），JEI 只能画物品，
     * 所以取它的 id 字段；重复的 id 会去重（JEI 里 8 个槽都画山羊角即可）。 */
    const pool = Array.isArray(spec.pool) ? spec.pool : null;
    if (pool == null || pool.length === 0) {
      warnings.push(`${input}: 产物是 @random 但没有 pool，JEI 里产物槽会是空的`);
      outputs = [];
    } else {
      outputs = uniq(pool
        .map((one) => (one != null && typeof one === 'object' ? String(one.id ?? '') : String(one)))
        .filter((x) => x !== ''));
    }
  } else {
    outputs = [output];
  }

  const r = { input, output, flips };
  if (outputs.length > 0) r.outputs = outputs;
  if (landing) {
    r.landing = true;
    if (onList.length > 0) r.on = onList;
  }
  if (drop) r.drop = true;
  if (spec.insert != null && Array.isArray(spec.insert.items)) {
    r.insert = {
      items: spec.insert.items.map(String),
      count: spec.insert.count != null ? Math.max(1, Number(spec.insert.count)) : 1,
      force: spec.insert.force === true,
    };
  }
  recipes.push(r);

  if (landing && onList.length === 0) {
    warnings.push(`${input}: landing 配方没有 on，永远不会触发`);
  }
}

/* ------------------------------------------------------------------ */
/* 3) 写文件                                                            */
/* ------------------------------------------------------------------ */

const payload = {
  _comment: [
    '本文件由 tools/sync-jei-recipes.mjs 从 kubejs/startup_scripts/mirror_config.js 生成。',
    '仅供 JEI 展示；实际加工逻辑以 mirror_config.js 为准。',
    '手工修改会在下次同步时被覆盖。',
    'on / outputs 里的元素可以是方块 ID，也可以是 #标签（JEI 侧会展开成全部成员）。',
  ],
  recipes,
};

writeFileSync(OUT, JSON.stringify(payload, null, 2) + '\n', 'utf8');

/* ------------------------------------------------------------------ */
/* 2b) 顺带导出"波粒观测"的 JEI 数据                                    */
/* ------------------------------------------------------------------ */
/*
 * 波粒观测（四个波粒块围住靶心 + 望远镜右键）**复用全部引力配方**，
 * 所以它的 JEI 内容 = 这批引力配方（换个说法：穿越类只要放对靶心、
 * 接触类还要放对靶心正下方）+ 配置里的专用配方 + 染色方块随机换色。
 *
 * ⚠️ 为什么必须是"顺带"导在同一份数据源上：
 *    分开维护两份列表迟早漂移，而漂移的表现是"JEI 里有这条、游戏里没用"，
 *    这种不一致比没有 JEI 更糟。
 *
 * 实体产物（蛋糕→悦灵）在 JEI 里用**刷怪蛋**展示 —— JEI 的槽位只能放物品，
 * 生物没法画；刷怪蛋是原版对"会生成什么生物"最直接的表达。
 */
const OBS_OUT = join(dirname(OUT), 'observation_recipes.json');
const observation = [];

/* (1) 引力配方 → 观测配方 */
for (const r of recipes) {
  const outs = (r.outputs != null && r.outputs.length > 0)
    ? r.outputs
    : (String(r.output).startsWith('@') ? [] : [String(r.output)]);
  if (outs.length === 0) continue;      // 动态产物算不出候选的，观测里同样没得展示
  const notes = [];
  if (r.drop) notes.push('产物以掉落物弹出');
  if (String(r.output) === '@landed') notes.push('产物＝下方方块');
  else if (String(r.output) === '@mapped') notes.push('产物随下方方块');
  const entry = {
    inputs: [String(r.input)],
    outputs: outs.map(String),
    label: `${r.input}→${r.output}`,
  };
  if (r.landing === true && Array.isArray(r.on) && r.on.length > 0) {
    entry.below = r.on.map(String);
    entry.belowRequired = true;
  }
  if (notes.length > 0) entry.note = notes.join('；');
  observation.push(entry);
}

/* (2) 专用配方（配置 observation.recipes）*/
const obsCfg = (cfg != null && cfg.observation != null) ? cfg.observation : null;
const specials = (obsCfg != null && Array.isArray(obsCfg.recipes)) ? obsCfg.recipes : [];
for (const s of specials) {
  if (s == null || s.input == null) continue;
  const entry = {
    inputs: [String(s.input)],
    outputs: [],
    label: String(s.id != null ? s.id : s.input),
  };
  if (s.entity != null) {
    /* 生物 → 刷怪蛋。命名约定是原版的，check-observation.mjs 会核对它真的存在。 */
    entry.outputs = ['minecraft:' + String(s.entity).replace(/^minecraft:/, '') + '_spawn_egg'];
    entry.note = '生成实体（消失的是靶心方块）';
  } else if (s.output != null) {
    entry.outputs = [String(s.output)];
    if (s.drop === true) entry.note = '产物以掉落物弹出';
  }
  if (s.on != null) {
    entry.below = [String(s.on)];
    entry.belowRequired = true;
    entry.note = (entry.note != null ? entry.note + '；' : '') + '需要下方方块';
  }
  if (entry.outputs.length > 0) observation.push(entry);
}

/* (3) 染色方块随机换色：一个族一条，输入与产物都是那一族的 16 种颜色。
 *     为什么按族拆而不是合成一条：换色**只在族内**发生（不会把羊毛变成混凝土），
 *     一条"输入 208 种、产物 208 种"的配方会让人误以为可以跨族。 */
const famMembers = (obsCfg != null && obsCfg.color_family_members != null)
  ? obsCfg.color_family_members : null;
if (famMembers != null) {
  for (const name of Object.keys(famMembers)) {
    const ids = (famMembers[name] || []).map(String);
    if (ids.length < 2) continue;
    observation.push({
      inputs: ids,
      outputs: ids,
      label: 'recolor:' + name,
      note: '同族随机换色（同类型不同颜色）',
    });
  }
}

const obsPayload = {
  _comment: [
    '本文件由 tools/sync-jei-recipes.mjs 从 kubejs/startup_scripts/mirror_config.js 生成。',
    '仅供 JEI 展示"波粒观测"能加工出什么；实际判定在 MirrorObservation + mirror_n10_observation.js。',
    '手工修改会在下次同步时被覆盖。',
    '条目来自三处：引力配方（全部复用）、配置里的专用配方、染色方块随机换色。',
  ],
  recipes: observation,
};
writeFileSync(OBS_OUT, JSON.stringify(obsPayload, null, 2) + '\n', 'utf8');
console.log(`已导出 ${observation.length} 条观测配方 → ${OBS_OUT}`);
console.log(`  其中需要"下方方块"的 ${observation.filter((r) => r.belowRequired === true).length} 条，`
  + `随机换色 ${observation.filter((r) => String(r.label).startsWith('recolor:')).length} 条，`
  + `专用配方 ${specials.length} 条`);

const tagRefs = new Set();
for (const r of recipes) {
  for (const v of [...(r.on ?? []), ...(r.outputs ?? [])]) {
    if (String(v).startsWith('#')) tagRefs.add(v);
  }
}

console.log(`已导出 ${recipes.length} 条配方 → ${OUT}`);
console.log(`  其中 landing ${recipes.filter((r) => r.landing).length} 条，`
  + `掉落物形式 ${recipes.filter((r) => r.drop).length} 条，`
  + `往容器塞物品 ${recipes.filter((r) => r.insert).length} 条`);
console.log(`  用到的标签 ${tagRefs.size} 个：${[...tagRefs].join('  ')}`);

for (const w of warnings) {
  console.warn('⚠️  ' + w);
}

/* 抽样打印，方便一眼核对关键条目 */
const sampleKeys = ['minecraft:anvil', 'minecraft:scaffolding', 'minecraft:pointed_dripstone',
  'minecraft:suspicious_sand', 'minecraft:suspicious_gravel'];
console.log('\n关键条目:');
for (const r of recipes) {
  if (!sampleKeys.includes(r.input)) continue;
  const bits = [`${r.input} → ${r.output}`, `×${r.flips}`, r.landing ? 'landing' : 'crossing'];
  if (r.on) bits.push('on ' + r.on.join(' + '));
  if (r.outputs && r.output.startsWith('@')) bits.push(`产物候选 ${r.outputs.length} 项`);
  if (r.drop) bits.push('掉落物');
  if (r.insert) bits.push(`塞入 ${r.insert.items.length} 选 1${r.insert.force ? '（满也触发）' : ''}`);
  console.log('  · ' + bits.join('  '));
}

console.log('\n提示：需要重新构建模组（gradlew build）后，JEI 才会看到新配方。');
