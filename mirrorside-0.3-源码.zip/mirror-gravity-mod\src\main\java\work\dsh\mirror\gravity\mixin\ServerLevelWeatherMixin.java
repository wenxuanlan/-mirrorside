package work.dsh.mirror.gravity.mixin;

import net.minecraft.server.level.ServerLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import work.dsh.mirror.gravity.MirrorWeather;

/**
 * 镜维度：跳过原版的天气循环 —— <b>走的正是地狱/末地那条路</b>。
 *
 * <h2>原版是怎么做到"地狱不下雨"的</h2>
 * 1.21.1 的 {@code ServerLevel#advanceWeatherCycle()}（源码第 650 行起）整段天气逻辑
 * —— 推进下雨/打雷计时器、增减 {@code rainLevel} / {@code thunderLevel} ——
 * 全都写在：
 * <pre>
 *   private void advanceWeatherCycle() {
 *       boolean flag = this.isRaining();
 *       if (this.dimensionType().hasSkyLight()) {   // ← 地狱/末地在这里就是 false
 *           ... 全部天气逻辑 ...
 *       }
 *   }
 * </pre>
 * 对比原版三个维度类型：主世界 {@code has_skylight: true}，
 * **地狱/末地 {@code has_skylight: false}** ⇒ 它们连一行天气代码都不执行，
 * 降水/雷暴永远停在 0。**不是"每 tick 去清"，而是"根本不跑"**。
 *
 * <h2>为什么镜维度不能照抄 has_skylight:false</h2>
 * 关掉天空光会连带把维度照明一起改掉（天空光层整个停用，只能靠方块光 +
 * {@code ambient_light}）—— 而设定要求"世界有自然亮度，同主世界的白天亮度相当"，
 * 那正是靠天空光实现的。所以我们保留天空光，改在**同一个方法上挂钩**：
 * 对镜维度同样跳过整段天气逻辑。
 *
 * <h2>为什么挂在原版方法上，而不是自己每 tick 检查</h2>
 * 这个方法本来就是原版每 tick 自己调的 —— 挂上去等于"把地狱的行为搬过来"，
 * 我们**没有新增任何轮询**；反过来还省掉了镜维度原本要跑的整段天气计算。
 * 之前那版"每服务端 tick 扫一遍所有维度、发现下雨就清掉"是多余的：
 * 它每 tick 都在做判定，而且清完还会被原版计时器再抽到下雨。
 *
 * <h2>关于 remap</h2>
 * {@code remap = false}：NeoForge 1.20.2 起运行时用的就是官方（Mojang）名字，
 * 本类里写的 {@code advanceWeatherCycle} 与运行时一致，不需要 refmap 重映射
 * （与 {@code PondusPositionMixin} 同样的处理，原因见 mirrorgravity.mixins.json 的注释）。
 *
 * <p>{@code require = 1} 是**故意**的：注入点找不到时必须**大声失败**
 * （启动报错），而不是静默失效 —— 静默失效的表现是"镜维度又开始下雨了"，
 * 那种问题不会有任何日志。
 */
@Mixin(ServerLevel.class)
public abstract class ServerLevelWeatherMixin {

    @Inject(method = "advanceWeatherCycle", at = @At("HEAD"), cancellable = true,
        require = 1, remap = false)
    private void mirrorgravity$skipMirrorWeatherCycle(CallbackInfo ci) {
        ServerLevel self = (ServerLevel) (Object) this;
        if (MirrorWeather.shouldSkipWeatherCycle(self)) {
            /* 首次生效时打一行日志；顺手清一次存档里可能残留的下雨状态。 */
            MirrorWeather.onWeatherCycleSkipped(self);
            ci.cancel();
        }
    }
}
