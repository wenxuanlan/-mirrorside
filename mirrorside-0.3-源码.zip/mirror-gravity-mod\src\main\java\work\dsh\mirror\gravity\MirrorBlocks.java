package work.dsh.mirror.gravity;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 镜维度 · 方块注册。
 *
 * <h2>为什么需要一个"镜面"方块</h2>
 * 重力方块加工**没有工作方块** —— 它是靠来回穿越重力交界处完成的。
 * 但 JEI 的分类需要一张"配方类型图标"和一个"催化剂"（告诉玩家
 * 右键什么能看到这个分类）。原本临时把输入方块（沙砾/沙子）当图标用，
 * 那样会让人误以为沙砾是工作台。
 *
 * <p>于是注册一个专用方块 {@code mirrorgravity:mirror_surface}（镜面）
 * 充当占位符：它表示"加工发生在镜面上"这件事本身。
 * 它同时也能被正常放置，未来如果想做实体化的加工台可以直接用它。
 */
public final class MirrorBlocks {

    private MirrorBlocks() {
    }

    public static final DeferredRegister.Blocks BLOCKS =
        DeferredRegister.createBlocks(MirrorGravity.MOD_ID);

    public static final DeferredRegister.Items ITEMS =
        DeferredRegister.createItems(MirrorGravity.MOD_ID);

    /**
     * 镜面方块。
     *
     * <p>属性选择说明：
     * <ul>
     *   <li>{@code mapColor} 用 {@code SNOW}，地图上是接近白的颜色</li>
     *   <li>{@code lightLevel} 给一点自发光（亮度 3）—— 镜面本身不该发亮，
     *       但纯白方块在暗处完全看不见，给一点点更容易分辨</li>
     *   <li>{@code noOcclusion} 关掉：它是完整实体方块，应该遮挡后面的面</li>
     * </ul>
     */
    public static final DeferredBlock<Block> MIRROR_SURFACE = BLOCKS.registerSimpleBlock(
        "mirror_surface",
        BlockBehaviour.Properties.of()
            .mapColor(MapColor.SNOW)
            .strength(0.6F, 6.0F)          // 硬度接近玻璃，抗爆略高
            .sound(SoundType.GLASS)
            .lightLevel(state -> 3)
            .pushReaction(PushReaction.NORMAL));

    /** 对应的物品形态（放不进背包的话 JEI 的分类图标也拿不到它）。 */
    public static final DeferredItem<net.minecraft.world.item.BlockItem> MIRROR_SURFACE_ITEM =
        ITEMS.registerSimpleBlockItem("mirror_surface", MIRROR_SURFACE);

    /**
     * 波粒块。「针尖对麦芒」装置正中间那一块，也是那个装置唯一的奖品。
     *
     * <p>属性逐条对应设定：
     * <ul>
     *   <li>{@code requiresCorrectToolForDrops()} —— 工具不对就<b>什么都不掉</b>。
     *       判定在 {@code Player.hasCorrectToolForDrops}：
     *       {@code !state.requiresCorrectToolForDrops() || 手上工具.isCorrectToolForDrops(state)}
     *       （1.21.1 源码第 785 行）。而"钻石镐及以上"由两个方块标签给出
     *       （见 {@code data/minecraft/tags/block/}）：
     *       {@code mineable/pickaxe} 说明它归镐管，{@code needs_diamond_tool}
     *       说明必须钻石级 —— 于是低级镐挖得动、但颗粒无收，正是设定要的效果。</li>
     *   <li>{@code lightLevel 7} —— 粉紫自发光。设定写了"粉紫色平滑融合"，
     *       用户另外选了"平滑渐变 + 自发光 + 环境粒子"，粒子在
     *       {@link WaveParticleBlock#animateTick}。</li>
     *   <li>{@code sound(AMETHYST)} —— 水晶质感，与粉紫晶体外观相配。</li>
     *   <li>硬度 2.5 / 抗爆 9 —— 比石头硬一点，但远不到基岩级：
     *       它是可采的奖品，不该变成拆不掉的东西。</li>
     * </ul>
     *
     * <p>⚠️ 掉落表不在 Java 里，在
     * {@code data/mirrorgravity/loot_table/blocks/wave_particle_block.json}。
     * 少了它方块会"挖了但什么都不掉"—— 本模组另外两个方块确实没有掉落表
     * （镜面是 JEI 占位物、传送门不可采），那是有意的，这里不能照抄。
     */
    public static final DeferredBlock<Block> WAVE_PARTICLE_BLOCK = BLOCKS.register(
        "wave_particle_block",
        () -> new WaveParticleBlock(BlockBehaviour.Properties.of()
            .mapColor(MapColor.COLOR_PINK)
            .strength(2.5F, 9.0F)
            .sound(SoundType.AMETHYST)
            .lightLevel(state -> 7)
            .requiresCorrectToolForDrops()));

    /** 物品形态：设定要求"能用钻石镐破坏并掉落"，掉的就是它自己。 */
    public static final DeferredItem<net.minecraft.world.item.BlockItem> WAVE_PARTICLE_BLOCK_ITEM =
        ITEMS.registerSimpleBlockItem("wave_particle_block", WAVE_PARTICLE_BLOCK);

    /**
     * 波粒子：右键一个方块，给它加上下坠特性（与沙子同款）。
     *
     * <p>机制不在这个类里 —— 道具只是入口。真正的"哪些位置被改造过"记在
     * {@link GravityTagData}（每维度一份、存进存档），判定与下坠在
     * {@link GravityTagger}（复刻原版 {@code FallingBlock} 的调度时机与判据）。
     *
     * <p>属性：
     * <ul>
     *   <li>{@code rarity(RARE)} —— 物品名显示成稀有颜色，与它的来历相配；</li>
     *   <li>{@code fireResistant()} —— 下界之星同款待遇，掉进岩浆不会烧掉
     *       （它是"波粒"道具，本来也不该被火毁掉）；</li>
     *   <li>{@code stacksTo(64)} —— 每次使用消耗 1 个，允许成叠携带。</li>
     * </ul>
     *
     * <p>⚠️ 现在<b>只有创造模式物品栏</b>能拿到（用户选择：先做机制、产出以后再说）。
     * 将来要做掉落/合成时，在这里或数据包里加即可，机制层不用动。
     */
    public static final DeferredItem<Item> WAVE_PARTICLE = ITEMS.register(
        "wave_particle",
        () -> new WaveParticleItem(new Item.Properties()
            .stacksTo(64)
            .rarity(Rarity.RARE)
            .fireResistant()));

    /**
     * 波：波粒块拆开得到的第一级材料（贴图仿照腐肉那种撕裂状块）。
     *
     * <p>它没有行为，只是合成链上的一环：波粒块 → 波 → 粒 → 波粒子，
     * 三正三逆共六条无序配方（见 mirror_config.js → craftingRecipes）。
     */
    public static final DeferredItem<Item> WAVE = ITEMS.register(
        "wave", () -> new Item(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON)));

    /**
     * 粒：第二级材料（贴图仿照重锤核心那个方块的外观）。
     *
     * <p>⚠️ id 是 {@code mirrorgravity:particle}，与最终的 {@code wave_particle}
     * 是两个不同的物品 —— 名字顺序就是合成链的顺序（波粒块 → 波 → 粒 → 波粒子）。
     */
    public static final DeferredItem<Item> PARTICLE = ITEMS.register(
        "particle", () -> new Item(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON)));

    /**
     * 镜维度传送门方块。
     *
     * <p>属性逐条对应设定要求，括号里是原版参照物 ——
     * 除了"爆炸能炸掉"这一条，其余都是**照抄地狱门**：
     * <ul>
     *   <li>{@code noCollission()} —— 可以走进去（地狱门同样）</li>
     *   <li>{@code lightLevel 11} —— 自己发光（地狱门同样）</li>
     *   <li>{@code strength(-1.0F, 0.5F)} —— 硬度 -1：生存模式**挖不动**
     *       （{@code getDestroyProgress} 对 -1 直接返回 0），但创造模式走的是
     *       "立即破坏"分支，绕开硬度判定，所以创造能打掉（基岩同理）。
     *       爆炸抗性给 0.5 而不是地狱门的 3600000，这样 TNT 能炸掉它。</li>
     *   <li>{@code randomTicks()} —— 与地狱门一致（原版靠它做环境音；
     *       我们暂时没加，但保留这个标记以便以后补）</li>
     *   <li>{@code pushReaction(BLOCK)} —— 活塞推不动（地狱门同样）</li>
     * </ul>
     *
     * <p>⚠️ 不注册物品形态：它是"结构 + 点燃"生成的世界方块，不是可携带物品。
     * 需要测试时用 {@code /setblock} 或 {@code /mirror portal}。
     */
    public static final DeferredBlock<Block> MIRROR_PORTAL = BLOCKS.register(
        "mirror_portal",
        () -> new MirrorPortalBlock(BlockBehaviour.Properties.of()
            .mapColor(MapColor.COLOR_BLACK)
            .noCollission()
            .noOcclusion()
            .lightLevel(state -> 11)
            .strength(-1.0F, 0.5F)
            .sound(SoundType.GLASS)
            .randomTicks()
            .pushReaction(PushReaction.BLOCK)));

    /**
     * 传送门方块对应的**兴趣点（POI）类型**。
     *
     * <h2>为什么必须登记 POI</h2>
     * 原版找"另一侧的门"靠的是 POI 系统，不是扫方块：
     * <pre>
     *   // PortalForcer#findClosestPortalPosition —— 地狱门就是这么找到出口的
     *   poiManager.ensureLoadedAndValid(level, targetPos, radius);   // 先把搜索区加载出来
     *   poiManager.getInSquare(r -&gt; r.is(PoiTypes.NETHER_PORTAL), targetPos, radius, ANY)
     *            .min(比较与 targetPos 的距离);
     * </pre>
     * POI 表由区块数据维护（{@code ServerLevel#onBlockStateChange} 会自动增删），
     * 所以查询是"按区块索引"的，不需要真的去遍历几万个方块，
     * 也不会因为区块没加载而漏掉门。
     *
     * <p>参数沿用原版地狱门那一组：{@code maxTickets = 0}（不参与村民职业）、
     * {@code validRange = 1}（1 格内就算"在点位上"，门只有一格）。
     *
     * <p>⚠️ 之前没登记 POI，于是回程只能靠坐标硬算 ——
     * 那正是"从镜维度回来不会出现在自己的门那里"的根因。
     */
    public static final DeferredRegister<net.minecraft.world.entity.ai.village.poi.PoiType> POI_TYPES =
        DeferredRegister.create(net.minecraft.core.registries.Registries.POINT_OF_INTEREST_TYPE,
            MirrorGravity.MOD_ID);

    public static final DeferredHolder<net.minecraft.world.entity.ai.village.poi.PoiType,
        net.minecraft.world.entity.ai.village.poi.PoiType> MIRROR_PORTAL_POI =
        POI_TYPES.register("mirror_portal",
            () -> new net.minecraft.world.entity.ai.village.poi.PoiType(
                java.util.Set.of(MIRROR_PORTAL.get().defaultBlockState()), 0, 1));

    /**
     * 进入提示音（那条烘焙好的黑白钟声）。
     *
     * <h2>为什么要在这里"注册"一次</h2>
     * 音频文件与 {@code sounds.json} 早就在这个 jar 里了，KubeJS 侧一直用
     * {@code SoundEvent.createVariableRangeEvent(资源位置)} 按位置现场造一个
     * 事件来播 —— 对脚本来说那样最省事。
     * 但模组代码里要播同一条，最好走注册表：
     * <ul>
     *   <li>得到一个稳定的 {@link SoundEvent} 实例，不用每次造；</li>
     *   <li>事件会随注册表同步给客户端，语义与其它模组音效一致；</li>
     *   <li>{@code /playsound mirrorgravity:block.mirror_enter} 也能直接用。</li>
     * </ul>
     * 注册方式照抄原版 {@code SoundEvents.register}：用
     * {@code createVariableRangeEvent}（可变距离 = 16 格基础半径），
     * 与文件里 {@code sounds.json} 的 {@code attenuation_distance: 24} 配合。
     *
     * <p>⚠️ 响度是烘焙进音频文件的（-21.6 LUFS），所以这里播放音量必须给
     * 1.0（客户端会把最终增益夹到 1.0，超过也没用），否则就对不上标定的响度。
     */
    public static final DeferredRegister<net.minecraft.sounds.SoundEvent> SOUNDS =
        DeferredRegister.create(net.minecraft.core.registries.Registries.SOUND_EVENT,
            MirrorGravity.MOD_ID);

    public static final DeferredHolder<net.minecraft.sounds.SoundEvent,
        net.minecraft.sounds.SoundEvent> MIRROR_ENTER =
        SOUNDS.register("block.mirror_enter",
            () -> net.minecraft.sounds.SoundEvent.createVariableRangeEvent(
                net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(
                    MirrorGravity.MOD_ID, "block.mirror_enter")));

    /**
     * 创造模式物品栏。
     *
     * <h2>为什么另起一个物品栏标签</h2>
     * 本模组会持续加入自己的方块（目前是镜面，之后还有加工产物等）。
     * 若不加，这些方块只能靠搜索找到，玩家不知道模组到底提供了什么。
     *
     * <p>用 NeoForge 标准写法：往创造栏注册表登记一个
     * {@link CreativeModeTab}，内容由 {@code displayItems} 填充。
     *
     * <h2>为什么用 builder.displayItems 而不是 forTab</h2>
     * 后者要求每个物品在注册时就知道自己属于哪个标签，会让物品注册
     * 反过来依赖标签；前者集中一处声明，加物品时只改这一个列表。
     */
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
        DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MirrorGravity.MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MIRROR_TAB =
        CREATIVE_TABS.register("mirror", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.mirrorgravity.mirror"))
            // 图标就是镜面方块本身
            .icon(() -> new ItemStack(MIRROR_SURFACE_ITEM.get()))
            /* 该标签里显示哪些物品。
             * 目前只有镜面；以后加了方块就往这里补一行，
             * 顺序即游戏内的排列顺序。 */
            .displayItems((params, output) -> {
                output.accept(MIRROR_SURFACE_ITEM.get());
                output.accept(WAVE_PARTICLE_BLOCK_ITEM.get());
                output.accept(WAVE.get());
                output.accept(PARTICLE.get());
                output.accept(WAVE_PARTICLE.get());
            })
            .build());

    /**
     * 注册到模组事件总线。
     *
     * <p>必须在模组构造函数里调用 —— DeferredRegister 只是"登记表"，
     * 真正写入注册表要等 NeoForge 的注册事件。
     */
    public static void register(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        POI_TYPES.register(modBus);
        SOUNDS.register(modBus);
        CREATIVE_TABS.register(modBus);
    }
}
