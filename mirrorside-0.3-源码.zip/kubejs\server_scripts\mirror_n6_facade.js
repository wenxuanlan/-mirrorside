// =====================================================================
// 镜维度 · 组装门面（MirrorSetting）
// =====================================================================
// 这个文件是 server 侧各模块的**唯一对外出口**。
//
// 为什么需要它：
//   mirror_server.js（指令层）在字母序上加载得更早，运行时要通过
//   global.MirrorDimension.runtime.setting 拿到本对象。
//   把各模块的公开接口在这里汇总成原来的形状，
//   指令层就不必知道内部拆成了几个文件。
//
// ⚠️ **本对象的字段名是契约**：mirror_server.js 依赖
//    ready / layout / splitY / regionOf / gravity.* / recipes.*
//    改名前请先核对那个文件。
//
// 模块职责一览（文件名前缀即加载顺序）：
//   n0 基础层    配置、几何常量、实体判定、通用工具
//   n1 状态表    按实体累积的可变状态 + 周期性清理
//   n2 开关      全局闸门、GameType、区域切换通知钩子
//   n3 配方      重力方块加工的注册、计数、替换
//   n4 重力      方向下发、防抖、玩家与实体的每 tick 处理
//   n5 镜外      镜外区域/游戏模式、关卡查找、玻璃层铺设
//   n6 门面      本文件
//   n9 工作台    无序合成配方（发光地衣 + 沙/沙砾 → 可疑方块）
//
// ⚠️ n9 排在门面**之后**，所以 n6 不能直接拿它 ——
//    对外给的是取值函数 setting.crafting()（内部走 n0.moduleRef）。
//
// ⚠️ 模块之间一律用 n0.moduleRef('nX') 在**运行时**取引用，
//    不要在加载期 `const NX = modules.nX` —— 那样会依赖文件名顺序。
//
// ⚠️ 所有 try 块内只用 var（Rhino 对 try 里的 const/let 会抛
//    InternalError: TypeError: redeclaration of var xxx）
// =====================================================================

const MirrorSetting = (() => {

  const MD = global.MirrorDimension;
  if (MD === undefined || !MD.isLoaded) {
    console.error('[镜维度] 核心未就绪，设定逻辑未启用。');
    return { ready: false };
  }

  const MODULES = MD.modules;
  const N0 = MODULES.n0;
  const N1 = MODULES.n1;
  const N2 = MODULES.n2;
  const N3 = MODULES.n3;
  const N4 = MODULES.n4;
  const N5 = MODULES.n5;

  /* 逐个校验：缺哪个模块就报出哪个，而不是让整份设定静默失效。
   * 拆分之后模块之间是有依赖的，出问题时"缺了谁"比"没工作"有用得多。 */
  const missing = [];
  if (N0 === undefined || !N0.ready) missing.push('n0 基础层');
  if (N1 === undefined || !N1.ready) missing.push('n1 状态表');
  if (N2 === undefined || !N2.ready) missing.push('n2 开关');
  if (N3 === undefined || !N3.ready) missing.push('n3 配方');
  if (N4 === undefined || !N4.ready) missing.push('n4 重力');
  if (N5 === undefined || !N5.ready) missing.push('n5 镜外');
  if (missing.length > 0) {
    console.error('[镜维度] 以下模块未就绪，设定逻辑未启用: ' + missing.join('、'));
    return { ready: false };
  }

  const L = N0.layout;
  const cfg = N0.cfg;

  console.info('[镜维度] 设定逻辑已启用 — 高度 ' + L.min_y + '~' + (L.min_y + L.height - 1)
    + '，镜内 ' + N0.innerMin + '~' + N0.innerMax
    + '，重力分界 y=' + N0.splitY
    + '，玻璃层 ' + N0.glassYs.length + ' 层'
    + '，重力反转 ' + (N2.gravityOn ? '开' : '关')
    + '，自研模组 ' + (N0.selfModApi != null ? '已接入' : '未接入')
    + '，重力方块配方 ' + N3.count() + ' 条'
    + '，镜外模式 ' + (N2.outerOn ? '开' : '关'));

  /* ------------------------------------------------------------------ */
  /* 对外契约                                                            */
  /* ------------------------------------------------------------------ */

  const setting = {
    ready: true,
    layout: L,
    /** 原始配置（供指令层/调试读取，等价于原来导出的 raw 配置） */
    config: cfg,

    // 几何
    regionOf: N0.regionOf,
    isInner: N0.isInner,
    halfOf: N0.halfOf,
    dirNameAt: N0.dirNameAt,
    glassLayers: N0.glassLayers,
    innerMin: N0.innerMin,
    innerMax: N0.innerMax,
    splitY: N0.splitY,
    rawSplitY: N0.rawSplitY,
    fallingSplit: N0.fallingSplit,

    /** 供指令 / 调试读取的重力状态 */
    gravity: {
      selfModLoaded: N0.selfModApi != null,
      /** 自研模组的类本身，供指令直接调用 */
      selfModApi: N0.selfModApi,
      scanInterval: N2.scanInterval,
      /** 掉落物的方向检测间隔（tick，默认 4）= gravity.item_scan_interval */
      itemScanInterval: N0.itemScanInterval,
      blockedFlips: N1.blockedFlips,
      scanStats: N1.scanStats,
      lastAttempt: N1.lastAttempt,
      debounce: N4.debounce,
      forced: N4.forced,
      setForce: N4.setForce,
      dirNameAt: N4.dirNameAt,
      readDirs: N4.readDirs,

      /** 状态表现状（诊断用：能看到记录了多个实体） */
      stateTables: N1.tableNames,
      trackedEntities: N1.trackedEntityCount,
    },

    /** 重力方块配方：公开接口，供其它脚本注册 */
    recipes: {
      add: N3.add,
      list: N3.list,
      count: N3.count,
      enabled: function () { return N3.enabled; },
      states: N3.states,
      countMode: N3.countMode,
      /** 排查采样：每种方块被当过多少次下落实体、最高切换次数、最近探针 */
      diagnostics: N3.diagnostics,
    },
    onRegisterRecipes: N3.onRegisterRecipes,

    /* 工作台配方（无序合成）：n9 的文件名排在**本文件之后**，
     * 加载期它还不存在，所以这里给的是**取值函数**而不是模块本身
     * （n0.moduleRef 在运行时解析，拿不到返回 null）。
     * 直接写 N9 = MODULES.n9 会得到 undefined 并被 n6 的就绪检查拦下。 */
    crafting: function () { return N0.moduleRef('n9'); },
  };

  /* 挂到 startup 层建立的共享容器上，供 mirror_server.js 读取。
   * 非 startup 脚本不能给 global 赋值（会整份失效），
   * 但改已存在对象的属性可以。 */
  if (MD.runtime) {
    MD.runtime.setting = setting;
  } else {
    console.info('[镜维度] 共享容器 runtime 不存在，重力诊断指令会读不到状态。');
  }

  MODULES.n6 = setting;
  return setting;
})();
