/**
 * 在 Node 里**真的跑一遍** mirror_n3_recipes.js —— 不启动游戏，直接驱动配方引擎。
 *
 * ── 为什么要造这个 ────────────────────────────────────────────────
 * "某个配方不生效"这类问题，前两轮都是靠读代码 + 猜摆法，结果连续猜错两次。
 * 读代码只能证明"我以为的那条路径没问题"，而 bug 恰恰在"我以为"之外。
 *
 * 这套模拟器把引擎真正执行起来：给 n3 喂一份假的 Minecraft 世界与实体，
 * 然后问它"这个位置、这个方向、这个切换次数，你匹配到哪条配方"。
 * 于是"引擎有没有 bug"和"摆法对不对"这两件事就被彻底分开了。
 *
 * ── 它模拟了什么 / 没模拟什么 ───────────────────────────────────
 * 模拟：配方匹配、计数（flip 模式）、探针几何、applyRecipe 的产物解析
 * 不模拟：真实物理（模组 BlockPhysics）、渲染、原版的掉落前置条件
 *        —— 位置与重力方向由调用方直接摆，正是为了把它们**排除掉**
 *
 * 用法: node tools-build/sim-recipes.mjs
 */
import { readFileSync } from 'node:fs';

const INST = 'D:/DSHwork/MC镜维度/.minecraft/versions/镜维度';
const CONFIG = `${INST}/kubejs/startup_scripts/mirror_config.js`;
const N3 = `${INST}/kubejs/server_scripts/mirror_n3_recipes.js`;

/* ---------------- 1) 真配置 ---------------- */
const cfgSrc = readFileSync(CONFIG, 'utf8').replace(/^\s*global\.MIRROR_CONFIG\s*=\s*MIRROR_CONFIG\s*;?\s*$/m, '');
const cfg = new Function(cfgSrc + '\n; return MIRROR_CONFIG;')();

/* ---------------- 2) 假世界 ---------------- */
const AIR = 'minecraft:air';

function makeState(id) {
  const block = { __id: id };
  return {
    __id: id,
    getBlock: () => block,
    isAir: () => id === AIR,
    is: (other) => id === (other && other.__id),
  };
}

/** 世界：'x,y,z' -> 方块 ID */
class World {
  constructor() { this.map = new Map(); }
  set(x, y, z, id) { this.map.set(`${x},${y},${z}`, id); return this; }
  at(x, y, z) { return this.map.get(`${x},${y},${z}`) ?? AIR; }
}

/**
 * 一个世界**只有一个** level 对象 —— 同一世界里的所有实体共享它。
 * ⚠️ 这一点很关键：引擎判断"上一个实体还在不在"用的是
 * `level.getEntity(id)`，如果每个实体各自一个 level，
 * 就永远查不到别的实体，判定必然错（这次就踩到了）。
 */
function levelOf(world) {
  if (world.__level == null) world.__level = makeLevel(world);
  return world.__level;
}

function makeLevel(world) {
  return {
    __world: world,
    /** applyRecipe 若走了"放方块"这条路，这里会记下来 ——
     *  用来断言 drop:true 的配方**绝不放方块**。 */
    placed: [],
    /** 世界里"活着"的实体（按 id）—— 引擎用它判断上一个实体还在不在
     *  （见 n3 的 entityStillAlive）。模拟器必须实现这一条，
     *  否则引擎会退回时间窗兜底，测的就不是线上那条分支了。 */
    live: new Map(),
    getBlockState(pos) { return makeState(world.at(pos.getX(), pos.getY(), pos.getZ())); },
    setBlockAndUpdate(pos, state) {
      this.placed.push({ y: pos.getY(), id: state && state.__id });
      return true;
    },
    getEntity(id) { return this.live.get(id) ?? null; },
  };
}

const entries = new Map();   // id -> 产物记录（applyRecipe 时填）

function makeEntity(world, id, stateId) {
  const e = {
    __dir: 'down',
    __id: id,
    __state: stateId,
    x: 0.5, y: 0, z: 0.5,
    level: levelOf(world),
    getId: () => id,
    getX() { return this.x; },
    getY() { return this.y; },
    getZ() { return this.z; },
    getBbHeight: () => 0.98,
    getBlockState: () => makeState(e.__state),
    discard() {
      e.__discarded = true;
      e.level.live.delete(id);      // 实体消失 → 世界里查不到它了
    },
  };
  e.level.live.set(id, e);
  return e;
}

/* ---------------- 3) 假 KubeJS / 模组 API ---------------- */
function makeBlockPos() {
  return {
    containing: (x, y, z) => ({
      getX: () => Math.floor(x),
      getY: () => Math.floor(y),
      getZ: () => Math.floor(z),
    }),
  };
}

function makeBuiltInRegistries() {
  return {
    BLOCK: {
      get: (rl) => ({
        __id: rl && rl.__rl,
        defaultBlockState() { return makeState(rl && rl.__rl); },
      }),
    },
  };
}

const MG_API = {
  blockStateHasTag: (state, tag) => {
    const t = String(tag);
    if (t === '#minecraft:leaves') return String(state.__id).endsWith('_leaves');
    return false;
  },
  /* 模组侧的"具体 ID"判定：与标签那条一样是纯 Java 调用。
   * 模拟器必须实现它，否则脚本会退回字符串比较那条老路，
   * 测的就不是线上真正跑的分支了。 */
  blockStateHasId: (state, want) => String(state.__id) === String(want),
  blockIdExists: () => true,
  /* 标签成员：给 '@mapped' 的 fallback_pool 与木材形态链的标签输入用。
   * 只实现配置里真正用到的标签；其余返回空串 = "本整合包没有这个标签"，
   * 于是"标签取不到"那条路径同样被测到（它必须是**不加工**，不是报错崩掉）。
   *
   * ⚠️ 木材那几个标签的成员是**照着真实 jar 抄的**（Quark 的台阶叫
   *    azalea_planks_slab、暮色森林的木头前缀各不相同、Quark 还往 #planks 里
   *    塞了 vertical_oak_planks）—— 场景 N 要验的正是这些"命名不规整"的情形。 */
  tagMembers: (tag, limit) => {
    const t = String(tag);
    const cap = Math.max(1, limit);
    if (t === '#minecraft:saplings') {
      /* ⚠️ 这一串要**照着真实整合包**写（#minecraft:saplings 是原版标签，
       * 模组会把自家树苗登记进去）。场景 F3 要验的正是"表外树叶同种对应"，
       * 所以这里必须同时有原版树苗、夸克的两种、暮色森林的三种 ——
       * 其中 twilightforest:dark_leaves → darkwood_sapling 是"名字不一样"的硬例子。 */
      return ['minecraft:oak_sapling', 'minecraft:spruce_sapling', 'minecraft:birch_sapling',
        'minecraft:jungle_sapling',
        'quark:ancient_sapling', 'quark:blue_blossom_sapling',
        'twilightforest:sorting_sapling', 'twilightforest:time_sapling',
        'twilightforest:darkwood_sapling'].slice(0, cap).join(',');
    }
    const WOOD_TAGS = {
      '#minecraft:wooden_trapdoors': ['minecraft:oak_trapdoor', 'minecraft:spruce_trapdoor', 'quark:azalea_trapdoor'],
      '#minecraft:wooden_doors': ['minecraft:oak_door', 'minecraft:spruce_door', 'quark:azalea_door'],
      '#minecraft:fence_gates': ['minecraft:oak_fence_gate', 'minecraft:spruce_fence_gate', 'quark:azalea_fence_gate'],
      '#minecraft:wooden_fences': ['minecraft:oak_fence', 'minecraft:spruce_fence',
        'minecraft:dark_oak_fence', 'quark:azalea_fence', 'twilightforest:dark_fence'],
      '#minecraft:wooden_slabs': ['minecraft:oak_slab', 'minecraft:spruce_slab',
        'minecraft:dark_oak_slab', 'quark:azalea_planks_slab', 'twilightforest:dark_slab'],
      '#minecraft:wooden_stairs': ['minecraft:oak_stairs', 'minecraft:spruce_stairs',
        'minecraft:dark_oak_stairs', 'quark:azalea_planks_stairs', 'twilightforest:dark_stairs'],
      '#minecraft:planks': ['minecraft:oak_planks', 'minecraft:spruce_planks',
        'quark:azalea_planks', 'quark:vertical_oak_planks'],
    };
    const list = WOOD_TAGS[t];
    return (list == null) ? '' : list.slice(0, cap).join(',');
  },
  currentDirection: (entity) => entity.__dir,
  canInsertIntoContainer: () => false,
  tryInsertIntoContainer: () => false,
  // 记录掉落物产物，而不是真的生成实体
  dropItem: (level, x, y, z, itemId, count) => {
    entries.set(itemId, { itemId, count, x, y, z });
    return true;
  },
};

const checks = [];
function check(name, ok, detail) {
  checks.push({ name, ok, detail });
  console.log(`  ${ok ? '✓' : '✗'} ${name}${detail ? '   ' + detail : ''}`);
}

/* ---------------- 4) 真 n3 源码 ---------------- */
const n3Src = readFileSync(N3, 'utf8');

function loadEngine() {
  const n1 = {
    ready: true,
    recipeState: {}, lastFlipDir: {}, swingRange: {},
    now: () => tick,
    forget(key) {
      delete n1.recipeState[key];
      delete n1.lastFlipDir[key];
        delete n1.swingRange[key];
    },
  };
  const n0 = {
    ready: true,
    cfg,
    selfModApi: MG_API,
    fallingSplit: -1.0,
    splitY: 0,
    entityKey: (e) => String(e.getId()),
    tryLoadClass(name) {
      if (name === 'net.minecraft.core.BlockPos') return makeBlockPos();
      if (name === 'net.minecraft.core.registries.BuiltInRegistries') return makeBuiltInRegistries();
      return null;
    },
    blockIdOf: (obj) => {
      if (obj == null) return null;
      if (obj.__id != null) return obj.__id;
      try { const b = obj.getBlock(); return b ? b.__id : null; } catch { return null; }
    },
    isFallingBlock: () => true,
    moduleRef: () => null,
  };
  const MD = {
    modules: { n0, n1 },
    id: (v) => ({ __rl: String(v) }),
    pondus: { available: false },
  };
  const fakeGlobal = { MirrorDimension: MD };
  /* 捕获引擎的日志行：sticky / 命中 / 报错都要能看见 —— 否则测试失败时
   * 只能看到「没命中」，看不出引擎走到了哪一步。 */
  const logLines = [];
  const fakeConsole = {
    info: (...a) => logLines.push(String(a.join(' '))),
    warn: (...a) => logLines.push('[warn] ' + a.join(' ')),
    error: (...a) => logLines.push('[err] ' + a.join(' ')),
    log() {},
  };
  /* BlockEvents 的最小 mock。引擎已不再注册 placed 处理器（"按竖列计数"
   * 那套连同它一起删掉了），但保留 mock：脚本若哪天再用到，
   * 引擎在加载期就会抛 ReferenceError。 */
  const blockHandlers = {};
  const fakeBlockEvents = {
    placed(fn) { blockHandlers.placed = fn; },
    rightClicked(fn) { blockHandlers.rightClicked = fn; },
  };
  const factory = new Function('global', 'console', 'BlockEvents',
    n3Src + '\n; return MirrorRecipes;');
  const api = factory(fakeGlobal, fakeConsole, fakeBlockEvents);

  /** 模拟"玩家放下某个方块"（触发引擎注册的 placed 处理器）。 */
  function firePlaced(blockId, x, z) {
    const fn = blockHandlers.placed;
    if (fn == null) return false;
    fn({
      getBlock: () => ({
        getBlockState: () => makeState(blockId),
        getX: () => x,
        getY: () => 0,
        getZ: () => z,
      }),
    });
    return true;
  }

  return { api, n1, firePlaced, logLines };
}

/* ---------------- 5) 场景 ---------------- */

console.log('=== 配方引擎模拟（真跑 mirror_n3_recipes.js）===\n');
/* mock 时钟：引擎的「重生交接窗口」按 tick 判定，模拟器要能推它。 */
let tick = 0;
const { api, n1, firePlaced, logLines } = loadEngine();
if (!api || !api.ready) { console.error('引擎未就绪'); process.exit(1); }
console.log(`配方总数: ${api.count()}\n`);

/* 计数键**直接问引擎**（api.keyOf），不在模拟器里复刻一份 ——
 * 复刻的副本会随引擎改动而漂移，这次就正好撞上过一次。 */

/** 把引擎的计数状态清空（原地清，不能重新赋值 —— 引擎持有的是同一对象）。 */
function resetCounts() {
  tick += 1000;          // 时钟留个余量（引擎的重生判定已与时间无关）
  for (const t of [n1.recipeState, n1.lastFlipDir, n1.swingRange]) {
    for (const k of Object.keys(t)) delete t[k];
  }
}

/** 驱动一次方向切换，把 crossings 攒到目标值。 */
function flipsTo(entity, want) {
  // 先给一个基线，再逐个切换
  entity.__dir = entity.__dir === 'up' ? 'down' : 'up';
  api.process(entity);
  let guard = 0;
  while (true) {
    const st = n1.recipeState[api.keyOf(entity)];
    const n = st ? st.crossings : 0;
    if (n >= want || guard++ > 40) break;
    entity.__dir = entity.__dir === 'up' ? 'down' : 'up';
    api.process(entity);
  }
  const st = n1.recipeState[api.keyOf(entity)];
  return st ? st.crossings : 0;
}

resetCounts();
console.log('--- 场景 A：脚手架 + 树叶落点（探针能不能看到它）---');
for (const [label, y, dir, want] of [
  ['贴在下方（天花板上），方向 up，4 次', 2.02, 'up', 4],
  ['贴在上方（地板上），方向 down，4 次', 4.0, 'down', 4],
  ['距离 1.5 格（不接触）', 1.5, 'up', 4],
]) {
  const world = new World();
  world.set(0, 3, 0, 'minecraft:oak_leaves');
  const e = makeEntity(world, 101, 'minecraft:scaffolding');
  e.y = y;
  e.__dir = dir;
  entries.clear();
  let crossings = flipsTo(e, want);
  // 攒够次数后再摆到目标位置判一次
  e.y = y;
  const hit = api.process(e);
  console.log(`  ${label}: y=${y} 切换=${crossings} → ${hit ? hit.recipe.id : '没有匹配'}`);
  void e;
}

resetCounts();
console.log('\n--- 场景 B：把脚手架从下往上逐格扫一遍（3 格天花板）---');
{
  const world = new World();
  world.set(0, 3, 0, 'minecraft:oak_leaves');
  const matchedAt = [];
  for (let y = 0.0; y <= 4.0; y = Math.round((y + 0.1) * 10) / 10) {
    const e = makeEntity(world, 200 + Math.round(y * 10), 'minecraft:scaffolding');
    e.y = y;
    const c = flipsTo(e, 4);
    e.y = y;
    const hit = api.process(e);
    if (hit) matchedAt.push(`${y}→${hit.recipe.id}(切换${c})`);
  }
  console.log('  匹配到的 y：' + (matchedAt.length ? matchedAt.join('  ') : '（一个都没有）'));
}

resetCounts();
console.log('\n--- 场景 C：同样的扫描，落点换成树叶（对照组）---');
{
  const world = new World();
  world.set(0, 3, 0, 'minecraft:oak_leaves');
  const matchedAt = [];
  for (let y = 0.0; y <= 4.0; y = Math.round((y + 0.1) * 10) / 10) {
    const e = makeEntity(world, 300 + Math.round(y * 10), 'minecraft:scaffolding');
    e.y = y;
    const c = flipsTo(e, 4);
    e.y = y;
    const hit = api.process(e);
    if (hit) matchedAt.push(`${y}→${hit.recipe.id}(切换${c})`);
  }
  console.log('  匹配到的 y：' + (matchedAt.length ? matchedAt.join('  ') : '（一个都没有）'));
}

resetCounts();
console.log('\n--- 场景 D：次数没到 4 时会怎样 ---');
{
  const world = new World();
  world.set(0, 3, 0, 'minecraft:oak_leaves');
  const e = makeEntity(world, 400, 'minecraft:scaffolding');
  e.y = 2.02;
  e.__dir = 'up';
  const c = flipsTo(e, 3);
  e.y = 2.02;
  const hit = api.process(e);
  console.log(`  切换=${c}（要求 4）→ ${hit ? hit.recipe.id : '没有匹配（符合预期）'}`);
}

resetCounts();
console.log('\n--- 场景 E：切换 8 次时 crossing 会不会抢在 landing 前面 ---');
{
  const world = new World();
  world.set(0, 3, 0, 'minecraft:oak_leaves');
  const e = makeEntity(world, 500, 'minecraft:scaffolding');
  e.y = 2.02;
  const c = flipsTo(e, 8);
  e.y = 2.02;
  const hit = api.process(e);
  console.log(`  切换=${c} → ${hit ? hit.recipe.id : '没有匹配'}`);
}

resetCounts();
console.log('\n--- 场景 F：applyRecipe 真的执行一遍（脚手架 + 树叶 → 树苗掉落物）---');
{
  /* 用**当前配置**里那条 drop 配方：落点 #minecraft:leaves，产物 @mapped，drop:true。
   * （原先是"灵魂沙 → 地狱疣"，那条已于 2026-09-22 放弃删除，见 README 14.22。） */
  const world = new World();
  world.set(0, 3, 0, 'minecraft:flowering_azalea_leaves');
  const e = makeEntity(world, 600, 'minecraft:scaffolding');
  e.y = 2.02;
  const c = flipsTo(e, 4);
  e.y = 2.02;
  const hit = api.process(e);
  entries.clear();
  const ok = hit ? api.applyRecipe(e, hit) : false;
  console.log(`  切换=${c} 命中=${hit ? hit.recipe.id : '无'} applyRecipe=${ok}`);
  console.log(`  掉落物产物: ${entries.size ? JSON.stringify([...entries.values()]) : '（无）'}`);
  console.log(`  被放下的方块: ${e.level.placed.length ? JSON.stringify(e.level.placed) : '（无）'}`);
  console.log(`  实体被移除: ${e.__discarded === true}`);

  check('命中的是 scaffolding_to_sapling',
    hit != null && hit.recipe.id === 'scaffolding_to_sapling');
  check('@mapped 按落点查表得到对应树苗（杜鹃叶 → 杜鹃树苗）',
    entries.has('minecraft:flowering_azalea'),
    [...entries.keys()].join(','));
  check('以**掉落物**形式弹出（dropItem 被调用）', entries.size === 1);
  check('**没有**往世界里放任何方块（drop:true 不放方块）', e.level.placed.length === 0,
    JSON.stringify(e.level.placed));
  check('实体被移除', e.__discarded === true);
}

resetCounts();
console.log('\n--- 场景 F2：表外的树叶（模组树叶）走 fallback_pool 兜底 ---');
{
  /* 0.3 批次八：map 表只覆盖原版 10 种树叶，模组新增的树叶不在表里。
   * 没有兜底时它们的表现是"落上去什么都不发生" —— 正是本项目最讨厌的那类静默失效。
   *
   * ⚠️ 场景 F3 覆盖"同种优先"；这里先用一个**模拟器 mock 里没有对应树苗**的落点，
   *    验的是"认不出同种时仍然会掉出一种树苗"这条保底路径。 */
  const SAPLINGS = ['minecraft:oak_sapling', 'minecraft:spruce_sapling',
    'minecraft:birch_sapling', 'minecraft:jungle_sapling',
    'quark:ancient_sapling', 'quark:blue_blossom_sapling',
    'twilightforest:sorting_sapling', 'twilightforest:time_sapling',
    'twilightforest:darkwood_sapling'];
  const world = new World();
  world.set(0, 3, 0, 'quark:blossom_leaves');
  const e = makeEntity(world, 650, 'minecraft:scaffolding');
  e.y = 2.02;
  const c = flipsTo(e, 4);
  e.y = 2.02;
  const hit = api.process(e);
  entries.clear();
  const ok = hit ? api.applyRecipe(e, hit) : false;
  const got = [...entries.keys()];
  console.log(`  切换=${c} 命中=${hit ? hit.recipe.id : '无'} applyRecipe=${ok}`
    + ` 产物=${got.length ? got.join(',') : '（无）'}`);
  check('表外树叶（quark:blossom_leaves）仍然命中 scaffolding_to_sapling',
    hit != null && hit.recipe.id === 'scaffolding_to_sapling');
  check('认不出同种时产物仍然来自 fallback_pool（#minecraft:saplings 的成员）',
    got.length === 1 && SAPLINGS.includes(got[0]), got.join(','));
  check('兜底产物同样以掉落物形式弹出、不放方块',
    entries.size === 1 && e.level.placed.length === 0);

  /* 对照：兜底也拿不到成员时（标签不存在）必须"不加工"，而不是崩掉或变成空气。
   * ⚠️ 用一个**配置里没有配方**的输入方块，否则会先命中配置里那条
   *    scaffolding_to_sapling（顺序在前），测到的就不是这条对照配方了。 */
  const world2 = new World();
  world2.set(0, 3, 0, 'quark:azalea_leaves');
  const e2 = makeEntity(world2, 651, 'minecraft:white_wool');
  e2.y = 2.02;
  flipsTo(e2, 4);
  e2.y = 2.02;
  api.add({
    id: 'sim_no_fallback', input: 'minecraft:white_wool', output: '@mapped',
    crossings: 4, trigger: 'landing', on: '#minecraft:leaves',
    map: { 'minecraft:oak_leaves': 'minecraft:oak_sapling' },
    fallback_pool: '#sim:not_a_tag', drop: true,
  });
  const hitNo = api.process(e2);
  entries.clear();
  const okNo = hitNo ? api.applyRecipe(e2, hitNo) : false;
  console.log(`  标签取不到成员时：命中=${hitNo ? hitNo.recipe.id : '无'}`
    + ` applyRecipe=${okNo} 产物=${entries.size ? [...entries.keys()].join(',') : '（无）'}`
    + ` 实体被移除=${e2.__discarded === true}`);
  check('命中对照配方 sim_no_fallback',
    hitNo != null && hitNo.recipe.id === 'sim_no_fallback');
  check('兜底标签取不到成员时**不加工**、也不移除实体',
    okNo === false && entries.size === 0 && e2.__discarded !== true);
}

resetCounts();
console.log('\n--- 场景 F3：表外树叶要**同种**对应（用户报的"分类树叶 → 雪喇叭树苗"）---');
{
  /* 用户 2026-09-27 的原话："我下面放分类树叶，变成的是雪喇叭树苗。似乎没有正确对应。"
   * 根因：兜底当时只有"从标签里随机抽一种"，与落点毫无关系。
   * 现在兜底**先按最长公共前缀认同种**（与木材形态链 @same_material 同一条规则），
   * 认不出才随机。下面这些落点都不在 map 表里（都是模组树叶），
   * 断言产物必须是它自己的那一种。 */
  const cases = [
    ['twilightforest:sorting_leaves', 'twilightforest:sorting_sapling',
      '暮色森林：分类树叶 → 分类树苗'],
    ['twilightforest:time_leaves', 'twilightforest:time_sapling',
      '暮色森林：时光树叶 → 时光树苗'],
    ['twilightforest:dark_leaves', 'twilightforest:darkwood_sapling',
      '暮色森林：深色树叶 → 深色木树苗（名字不是简单加后缀，靠前缀认出来）'],
    ['quark:ancient_leaves', 'quark:ancient_sapling', '夸克：远古树叶 → 远古树苗'],
    ['quark:blue_blossom_leaves', 'quark:blue_blossom_sapling', '夸克：蓝花树叶 → 蓝花树苗'],
  ];
  for (const [leaf, expect, why] of cases) {
    resetCounts();
    const world = new World();
    world.set(0, 3, 0, leaf);
    const e = makeEntity(world, 4000 + leaf.length, 'minecraft:scaffolding');
    e.y = 2.02;
    flipsTo(e, 4);
    e.y = 2.02;
    const hit = api.process(e);
    entries.clear();
    const ok = hit ? api.applyRecipe(e, hit) : false;
    const got = [...entries.keys()];
    console.log(`  ${leaf} → ${got.length ? got[0] : '（无）'}`);
    check(why, hit != null && ok === true && got.length === 1 && got[0] === expect,
      got.join(','));
  }
  /* 前缀并列时**不硬挑**：quark:blossom_leaves 与 5 种花色树苗的前缀一样长，
   * 认不出是哪一种颜色 ⇒ 退回随机，但产物仍必须是树苗之一。 */
  {
    resetCounts();
    const world = new World();
    world.set(0, 3, 0, 'quark:blossom_leaves');
    const e = makeEntity(world, 4100, 'minecraft:scaffolding');
    e.y = 2.02;
    flipsTo(e, 4);
    e.y = 2.02;
    const hit = api.process(e);
    entries.clear();
    const ok = hit ? api.applyRecipe(e, hit) : false;
    const got = [...entries.keys()];
    const SAP = ['minecraft:oak_sapling', 'minecraft:spruce_sapling',
      'minecraft:birch_sapling', 'minecraft:jungle_sapling', 'quark:blue_blossom_sapling'];
    console.log(`  quark:blossom_leaves → ${got.length ? got[0] : '（无）'}（前缀并列 ⇒ 随机兜底）`);
    check('前缀并列时不硬挑一个（退回随机，产物仍是树苗）',
      ok === true && got.length === 1 && SAP.includes(got[0]), got.join(','));
  }
  /* 观测台必须与坠落用同一条判定：同一个落点 → 同一个产物 */
  {
    const list = api.list();
    const rec = list.find((r) => r.id === 'scaffolding_to_sapling');
    const act = api.observationAction(rec, 'twilightforest:sorting_leaves', 'minecraft:scaffolding');
    console.log(`  观测台：分类树叶 → ${act ? act.id : '（无）'}`);
    check('观测台的表外树叶同样同种对应',
      act != null && act.id === 'twilightforest:sorting_sapling');
  }
}

resetCounts();
console.log('\n--- 场景 G（对照组）：非 drop 配方应当**放方块、不掉落物** ---');
{
  /* 沙子落在黑色玻璃上 → 石英块：普通配方，应当原地放成方块 */
  const world = new World();
  world.set(0, 3, 0, 'minecraft:black_stained_glass');
  const e = makeEntity(world, 700, 'minecraft:sand');
  e.y = 2.02;
  const c = flipsTo(e, 3);
  e.y = 2.02;
  const hit = api.process(e);
  entries.clear();
  const ok = hit ? api.applyRecipe(e, hit) : false;
  console.log(`  切换=${c} 命中=${hit ? hit.recipe.id : '无'} applyRecipe=${ok}`);
  console.log(`  被放下的方块: ${e.level.placed.length ? JSON.stringify(e.level.placed) : '（无）'}`);
  console.log(`  掉落物产物: ${entries.size ? JSON.stringify([...entries.values()]) : '（无）'}`);
  check('普通配方放方块、不掉落物',
    e.level.placed.length === 1 && e.level.placed[0].id === 'minecraft:quartz_block'
    && entries.size === 0,
    JSON.stringify(e.level.placed));
}

resetCounts();
console.log('\n--- 场景 H：落点 ID 的匹配规则（合成配方，与真配置无关）---');
{
  /* 用**合成配方**验证"具体 ID 的匹配"这件事本身。
   * 世界方块刻意选 stone：真配置里脚手架的两条配方（落点 soul_sand、
   * 8 次的蜘蛛网）都不会命中它，于是本场景的结论只反映 ID 匹配逻辑。 */
  const world = new World();
  world.set(0, 3, 0, 'minecraft:stone');
  const e = makeEntity(world, 800, 'minecraft:scaffolding');
  e.y = 2.02;
  const c = flipsTo(e, 4);
  e.y = 2.02;

  /* H-1：落点写 dirt → 世界里是 stone → 不该命中 */
  api.add({
    id: 'sim_wrong_id', input: 'minecraft:scaffolding',
    output: 'minecraft:nether_wart', crossings: 4, trigger: 'landing',
    on: 'minecraft:dirt', drop: true,
  });
  const hitWrong = api.process(e);
  console.log(`  世界=stone，配方要 dirt：${hitWrong ? hitWrong.recipe.id : '没有匹配 ← 符合预期'}`);

  /* H-2：落点写 stone → 应当命中 */
  api.add({
    id: 'sim_right_id', input: 'minecraft:scaffolding',
    output: 'minecraft:nether_wart', crossings: 4, trigger: 'landing',
    on: 'minecraft:stone', drop: true,
  });
  const hitRight = api.process(e);
  console.log(`  世界=stone，配方要 stone：${hitRight ? hitRight.recipe.id : '没有匹配'}`);

  /* H-3：周围全是空气时，攒到 8 次应当被 crossing 接走（蜘蛛网） */
  const airWorld = new World();
  const e2 = makeEntity(airWorld, 801, 'minecraft:scaffolding');
  e2.y = 2.02;
  const c8 = flipsTo(e2, 8);
  e2.y = 2.02;
  const hit8 = api.process(e2);
  console.log(`  周围全是空气、攒到 ${c8} 次切换：${hit8 ? hit8.recipe.id : '没有匹配'}`);

  check('落点 ID 不匹配时不命中', hitWrong == null || hitWrong.recipe.id !== 'sim_wrong_id');
  check('落点 ID 匹配时命中', hitRight != null && hitRight.recipe.id === 'sim_right_id');
  check('没碰到任何落点方块时，8 次由 crossing 接走变成蜘蛛网',
    hit8 != null && hit8.recipe.id === 'scaffolding_to_cobweb');
  void c;
}

resetCounts();
console.log('\n--- 场景 I：同位置、只换落点方块（配方的落点判定）---');
{
  /* 位置/高度/次数全都不变，只换落点方块 —— 直接对比各落点能不能命中。
   * 用的是 mirror_config.js 里**当前**的配方。
   * ⚠️ 每个落点用**各自的竖列**（x 不同）：计数键是实体，但列开一点更好读。 */
  const atY = 2.02;
  let col = 0;
  for (const [label, blockId, want] of [
    ['落点=橡树树叶（→橡树树苗）', 'minecraft:oak_leaves', true],
    ['落点=杜鹃叶（→杜鹃树苗）', 'minecraft:flowering_azalea_leaves', true],
    /* 灵魂沙曾经是"→ 地狱疣"的落点，那条配方 2026-09-22 已放弃删除；
     * 现在它应当**什么也不触发**（配置里没有以它为落点的配方）。 */
    ['落点=灵魂沙（配方已删除，不该命中）', 'minecraft:soul_sand', false],
    ['落点=下界疣块（从来没有过这条，不该命中）', 'minecraft:nether_wart_block', false],
  ]) {
    resetCounts();
    const x = col++ * 32;
    const world = new World();
    world.set(x, 3, 0, blockId);
    const e = makeEntity(world, 900 + blockId.length, 'minecraft:scaffolding');
    e.x = x + 0.5;
    e.y = atY;
    const c = flipsTo(e, 4);
    e.y = atY;
    const hit = api.process(e);
    console.log(`  ${label}（y=${atY}）: 切换=${c} → ${hit ? hit.recipe.id : '没有匹配'}`);
    check('同一位置 ' + label, want ? hit != null : hit == null);
  }
}
resetCounts();
console.log('\n--- 场景 J：★ 同一竖列里的两个脚手架必须**各算各的**（真实事故的回归）---');
{
  /* 事故（2026-09-22 15:22）：脚手架一度改成"按竖列"计数，于是同一列里的
   * 多个脚手架**共用一个计数器**，连"上一次方向"也共用 —— 两个实体方向相反，
   * 脚本每处理一个就与另一个留下的方向不同，**每 tick 记一次假翻转**：
   *     15:22:28.274  已切换 4 次 … y=14.1   方向=down
   *     15:22:28.323  已切换 5 次 … y=-1.99  方向=up    ← 49ms，y 差 16 格
   *     15:22:28.338  已切换 6 次 … y=13.64  方向=down
   *     15:22:28.373  已切换 8 次 → 蜘蛛网
   * 0→8 只用 1 秒 ⇒ 用户看到"第二个脚手架又变蜘蛛网"，而下界疣那条永远抢不到 4 次。
   *
   * 现在计数键 = 实体 id：两个脚手架各有一份计数与方向状态，互不影响。
   */
  const x = 96;
  const world = new World();
  world.set(x, 30, 0, 'minecraft:soul_sand');   // 远一点，避免干扰计数

  const a = makeEntity(world, 201, 'minecraft:scaffolding');
  a.x = x + 0.5; a.y = 2.02;
  const ca = flipsTo(a, 4);
  const keyA = api.keyOf(a);
  const countA = n1.recipeState[keyA]?.crossings ?? 0;

  /* 同一竖列、同一时刻的第二个脚手架：方向与 A **故意相反** */
  const b = makeEntity(world, 202, 'minecraft:scaffolding');
  b.x = x + 0.5; b.y = 8.02;
  b.__dir = a.__dir === 'up' ? 'down' : 'up';
  api.process(b);
  const keyB = api.keyOf(b);
  const countB = n1.recipeState[keyB]?.crossings ?? 0;

  console.log(`  第一个：切换 ${ca} 次，键=${keyA}，计数 ${countA}`);
  console.log(`  第二个（同列、方向相反）：键=${keyB}，计数 ${countB}`);
  check('两个脚手架拿到**不同**的计数键', keyA !== keyB, `${keyA} / ${keyB}`);
  check('第一个攒到 4 次', countA === 4, String(countA));
  check('第二个**不继承**第一个的进度（计数仍为 0）', countB === 0, String(countB));

  /* 关键：让第二个反复处理，看会不会因为"与另一个方向不同"被记假翻转 */
  let spurious = 0;
  for (let i = 0; i < 6; i++) {
    const before = n1.recipeState[keyB]?.crossings ?? 0;
    api.process(b);                                  // 方向不变
    const after = n1.recipeState[keyB]?.crossings ?? 0;
    if (after !== before) spurious++;
  }
  console.log(`  第二个方向不变地跑 6 tick：假翻转 ${spurious} 次（应为 0）`);
  check('方向不变时不会记假翻转（旧版按竖列时会每 tick 记一次）', spurious === 0,
    String(spurious));
  check('第一个的计数不受第二个影响',
    (n1.recipeState[keyA]?.crossings ?? 0) === 4,
    String(n1.recipeState[keyA]?.crossings ?? 0));
}

/* ---------------- 场景 L：真实事故复现（落点摆到了隔壁列） ---------------- */
resetCounts();
console.log('\n--- 场景 L：★ 灵魂沙摆在"隔壁一列"（2026-09-22 真实事故，读存档量出来的）---');
{
  /* 事故现场（存档实测）：
   *   下落实体在 (-34.5, …, 4.5) → 它那一列 = x=-35, z=4
   *   用户摆的 5 格灵魂沙：(-35,-4,2) (-34,-4,2) (-35,-4,3) (-34,-4,3) (-34,-4,4)
   *                        ← **一格都没在这一列里**
   *   而实体那一列 y=-4 摆的是树叶（所以树叶那条配方每次都触发）
   * 探针只扫实体自己那一列 ⇒ 永远碰不到，现象与"配方坏了"一模一样。 */
  const world = new World();
  const e = makeEntity(world, 900, 'minecraft:scaffolding');
  e.x = -34.5; e.y = -1.11; e.z = 4.5;
  world.set(-35, -4, 4, 'minecraft:flowering_azalea_leaves');
  for (const [x, z] of [[-35, 2], [-34, 2], [-35, 3], [-34, 3], [-34, 4]]) {
    world.set(x, -4, z, 'minecraft:soul_sand');
  }

  const rep = api.probeColumn(e, -6, 18, ['minecraft:soul_sand']);
  const colTxt = rep.column.map((c) => `y=${c.y}=${c.id}`).join('、') || '（空）';
  console.log(`  实体那一列 (${rep.x}, ${rep.z}) 实际有: ${colTxt}`);
  console.log('  3×3 邻域里找到的灵魂沙: ' + rep.nearby
    .map((n) => `(${n.x},${n.y},${n.z}) 差 dx=${n.dx} dz=${n.dz}`).join('；'));
  console.log('  日志里那一句:');
  console.log('    ' + api.columnReportText(rep, ['minecraft:soul_sand']));

  check('竖列坐标解析正确（-34.5,4.5 → x=-35, z=4）',
    rep.x === -35 && rep.z === 4, `${rep.x},${rep.z}`);
  check('这一列里确实没有灵魂沙（只有树叶）',
    !rep.column.some((c) => c.id === 'minecraft:soul_sand'),
    colTxt);
  check('邻域里能揪出"就在隔壁"的 3 格灵魂沙', rep.nearby.length === 3,
    String(rep.nearby.length));
  check('每一格都在 3×3 邻域内（对角也算）',
    rep.nearby.every((n) => Math.abs(n.dx) <= 1 && Math.abs(n.dz) <= 1
      && (n.dx !== 0 || n.dz !== 0)),
    rep.nearby.map((n) => `${n.dx},${n.dz}`).join(' '));
  check('至少有一格是"只差一格"的正交邻居（最该被提示的那种）',
    rep.nearby.some((n) => Math.abs(n.dx) + Math.abs(n.dz) === 1),
    rep.nearby.map((n) => `${n.dx},${n.dz}`).join(' '));
  check('报告文本里写明了"就在隔壁"和补救方法',
    /就在隔壁/.test(api.columnReportText(rep, ['minecraft:soul_sand']))
    && /挪进/.test(api.columnReportText(rep, ['minecraft:soul_sand'])));

  /* 对照：把灵魂沙挪进实体那一列 → 这一列里就有了（配方就能匹配） */
  world.set(-35, -4, 4, 'minecraft:soul_sand');
  const rep2 = api.probeColumn(e, -6, 18, ['minecraft:soul_sand']);
  check('挪进这一列后，列里就有了 y=-4 的灵魂沙',
    rep2.column.some((c) => c.id === 'minecraft:soul_sand' && c.y === -4));
}

/* ---------------- 场景 N：木材形态链标签化 + @same_material ---------------- */
resetCounts();
console.log('\n--- 场景 N：★ 木材形态链（标签进 / 同材质出，不串材质）---');
{
  /* 0.3 批次八：前 7 级改成"标签进 + @same_material 出"。要验三件事：
   *   ① 标签真的能匹配到**任意**木材（含模组木材）；
   *   ② 产物是**同材质**的那一个（橡木栅栏 → 橡木台阶，不是云杉的）；
   *   ③ 模组命名不规整时（Quark 的 azalea_planks_slab）也挑得对；
   *      而"认不出同材质"时（Quark 的 vertical_oak_planks）**不加工**，
   *      绝不能随便挑一个别的材质。
   * 注释里的"真实 jar"指 2026-09-27 对 Quark 4.1-485 与暮色森林 4.8.3345
   * 的 data/minecraft/tags/block/*.json 实测读到的成员（与上面的 mock 一致）。 */
  const cases = [
    /* [输入方块, 期望产物, 说明] */
    ['minecraft:oak_fence', 'minecraft:oak_slab', '原版：橡木栅栏 → 橡木台阶'],
    ['minecraft:spruce_fence', 'minecraft:spruce_slab', '原版：云杉栅栏 → 云杉台阶（不串成橡木）'],
    ['minecraft:dark_oak_fence', 'minecraft:dark_oak_slab', '原版：深色橡木（前缀更长的那一个）'],
    ['quark:azalea_fence', 'quark:azalea_planks_slab', '模组：Quark 的台阶叫 azalea_planks_slab'],
    ['twilightforest:dark_fence', 'twilightforest:dark_slab', '模组：暮色森林 dark_*'],
  ];
  for (const [input, expect, why] of cases) {
    resetCounts();
    const world = new World();
    const e = makeEntity(world, 3000 + input.length, input);
    e.y = 2.02;
    const c = flipsTo(e, 8);
    e.y = 2.02;
    const hit = api.process(e);
    entries.clear();
    const ok = hit ? api.applyRecipe(e, hit) : false;
    const got = e.level.placed.length ? e.level.placed[0].id : '（没放方块）';
    console.log(`  ${input} 切换=${c} 命中=${hit ? hit.recipe.id : '无'} → ${got}`);
    check(`形态链：${why}`, hit != null && hit.recipe.id === 'wooden_fence_to_slab'
      && ok === true && got === expect, got);
  }

  /* 反向：4 次穿越 + 落在工作台上 → 更精细的那一级（台阶 → 栅栏） */
  {
    resetCounts();
    const world = new World();
    world.set(0, 3, 0, 'minecraft:crafting_table');
    const e = makeEntity(world, 3100, 'quark:azalea_planks_slab');
    e.y = 2.02;
    flipsTo(e, 4);
    e.y = 2.02;
    const hit = api.process(e);
    entries.clear();
    const ok = hit ? api.applyRecipe(e, hit) : false;
    const got = e.level.placed.length ? e.level.placed[0].id : '（没放方块）';
    console.log(`  quark:azalea_planks_slab（落工作台）命中=${hit ? hit.recipe.id : '无'} → ${got}`);
    check('形态链反向：模组台阶 → 同材质栅栏（azalea_planks_slab → azalea_fence）',
      hit != null && hit.recipe.id === 'wooden_slab_to_fence' && ok === true
      && got === 'quark:azalea_fence', got);
  }

  /* ★ 认不出同材质时必须**不加工**：
   *   quark:vertical_oak_planks 也在 #minecraft:planks 里，但任何 Quark 台阶
   *   与它的公共前缀都只到 'quark:' ⇒ 规则要求"前缀必须长过命名空间"，于是拒绝。
   *   旧写法（后缀替换）会算出一个不存在的 id，或者更糟 —— 串到别的木材上。 */
  {
    resetCounts();
    const world = new World();
    world.set(0, 3, 0, 'minecraft:crafting_table');
    const e = makeEntity(world, 3200, 'quark:vertical_oak_planks');
    e.y = 2.02;
    flipsTo(e, 4);
    e.y = 2.02;
    const hit = api.process(e);
    entries.clear();
    const ok = hit ? api.applyRecipe(e, hit) : false;
    console.log(`  quark:vertical_oak_planks 命中=${hit ? hit.recipe.id : '无'}`
      + ` applyRecipe=${ok} 放下的方块=${e.level.placed.length}`);
    check('认不出同材质时不加工、不放方块（宁可不动也不串材质）',
      hit != null && ok === false && e.level.placed.length === 0
      && e.__discarded !== true);
  }

  /* 观测台与引力用**同一条**判定：同一个输入必须得到同一个产物 */
  {
    const list = api.list();
    const rec = list.find((r) => r.id === 'wooden_fence_to_slab');
    const act = api.observationAction(rec, '', 'quark:azalea_fence');
    const actOak = api.observationAction(rec, '', 'minecraft:oak_fence');
    console.log(`  观测台：quark:azalea_fence → ${act ? act.id : '（无）'}`
      + `；minecraft:oak_fence → ${actOak ? actOak.id : '（无）'}`);
    check('观测台用同一条规则（模组木材 → 同材质台阶）',
      act != null && act.id === 'quark:azalea_planks_slab');
    check('观测台：橡木栅栏 → 橡木台阶', actOak != null && actOak.id === 'minecraft:oak_slab');
  }
}

console.log('\n--- 引擎采样（诊断表，含新加的「旁边出现过」与「计数键」）---');for (const st of api.diagnostics()) {
  console.log(`  · ${st.id}  处理 ${st.ticks} tick，最高切换 ${st.maxFlips} 次`);
  if (st.lastProbe) console.log(`      ${st.lastProbe}`);
  if (st.lastX != null && st.lastZ != null) {
    console.log(`      落点该摆在哪: x=${st.lastX}, z=${st.lastZ}`
      + (st.recentMinY == null ? '' : `, y=${Math.floor(st.recentMinY) - 1} ~ ${Math.ceil(st.recentMaxY) + 1}`));
  }
  if (st.seen && st.seen.length) {
    console.log(`      旁边出现过: ${st.seen.map((x) => x.id).join('、')}`);
  }
}
{
  /* 这两条断言守的是"仪表本身可信"：脚手架确实见过树叶与灵魂沙，
   * 于是"采样里没有它"就一定能推出"位置/ID 不对"，而不是仪表失灵。 */
  const sc = api.diagnostics().find((d) => d.id === 'minecraft:scaffolding');
  const seenIds = sc && sc.seen ? sc.seen.map((x) => x.id) : [];
  check('「旁边出现过」能列出灵魂沙', seenIds.includes('minecraft:soul_sand'),
    seenIds.join(','));
  check('「旁边出现过」能列出树叶', seenIds.includes('minecraft:oak_leaves'), seenIds.join(','));
  /* ★ 计数键自检。两条真实事故都出在这个"身份键"上：
   *   ① try 块里写 const → Rhino 静默抛错 → 身份键被悄悄换掉；
   *   ② 把脚手架改成"按竖列"记 → 同一列的多个脚手架共用计数与方向状态
   *      → 每 tick 假翻转 → 1 秒冲到 8 次、全变蜘蛛网（场景 J 是它的回归）。
   *   现在**一律按实体 id**：同一竖列的两个实体必须是两个不同的键。
   *   ⚠️ Node 复现不了 Rhino 的 const-in-try，那条归 tools/lint-scripts.mjs。 */
  check('同一竖列的两个脚手架拿到不同的计数键（按实体计，不按竖列）',
    api.keyOf({ getX: () => 5.5, getZ: () => 5.5, getId: () => 701 })
    !== api.keyOf({ getX: () => 5.5, getZ: () => 5.5, getId: () => 702 }));
  /* ★ 落点坐标必须能报出来。下落实体只在竖直方向动 —— 竖列错一格就
   *   永远碰不到，而现象与"配方坏了"完全一样（真实教训：用户摆的灵魂沙
   *   不在下落实体那一列，日志里只能看到"探针一个方块都没见过"）。 */
  check('诊断表给出了下落实体所在的竖列坐标',
    sc != null && Number.isFinite(sc.lastX) && Number.isFinite(sc.lastZ),
    sc ? `x=${sc.lastX} z=${sc.lastZ}` : '(无)');
}

const bad = checks.filter((c) => !c.ok).length;
console.log(`\n断言 ${checks.length} 条，失败 ${bad} 条`);
if (bad > 0) process.exit(1);







