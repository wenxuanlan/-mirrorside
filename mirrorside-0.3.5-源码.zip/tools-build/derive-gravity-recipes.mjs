#!/usr/bin/env node
/**
 * 从原版版本 jar 里**实测**出重力方块配方要用的方块 id，并核对它们真的存在。
 *
 * ── 为什么需要这个工具 ───────────────────────────────────────────────────────
 * 木材 11 种 × 整条链、铜 10 类 × 8 态、石材按"系"展开 —— 一共几百条配方。
 * 这些 id 全靠拼名字得到（"exposed_cut_copper" 还是 "cut_exposed_copper"？），
 * 拼错的后果和本项目反复踩的坑一样：**配方静默失效**（能注册、能显示，永不触发）。
 * 所以用一个工具从 jar 里把真实存在的方块列出来，逐条核对。
 *
 * ── 判据 ─────────────────────────────────────────────────────────────────────
 * 方块是否存在：jar 里有没有 assets/minecraft/blockstates/<id>.json。
 * 用 blockstates 而不是物品模型，是因为配方作用的对象是**世界里的方块**。
 *
 * 用法：
 *   node tools-build/derive-gravity-recipes.mjs                # 全部报告
 *   node tools-build/derive-gravity-recipes.mjs --copper       # 只看铜
 *   node tools-build/derive-gravity-recipes.mjs --wood         # 只看木材
 *   node tools-build/derive-gravity-recipes.mjs --stone        # 只看石材候选
 * 退出码：发现"推导出来的 id 不存在"时非零。
 */
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { inflateRawSync } from 'node:zlib';

const JAR = 'D:\\DSHwork\\MC镜维度\\.minecraft\\versions\\镜维度\\镜维度.jar';

/* ---- 极简 ZIP 中央目录读取（只取文件名） ---- */
function zipNames(path) {
  const buf = readFileSync(path);
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i > buf.length - 65558; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd === -1) throw new Error('不是合法 zip: ' + path);
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const names = [];
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) break;
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    names.push(buf.toString('utf8', off + 46, off + 46 + nameLen));
    off += 46 + nameLen + extraLen + commentLen;
  }
  return names;
}

if (!existsSync(JAR)) {
  console.error('找不到版本 jar: ' + JAR);
  process.exit(2);
}
const blocks = new Set(
  zipNames(JAR)
    .filter((n) => n.startsWith('assets/minecraft/blockstates/') && n.endsWith('.json'))
    .map((n) => n.slice('assets/minecraft/blockstates/'.length, -'.json'.length)),
);
/* 物品表：配方产物允许是**物品**（掉落物形式），例如山羊角。
 * 判据用 models/item/<id>.json —— 与方块表用 blockstates 同理。 */
const items = new Set(
  zipNames(JAR)
    .filter((n) => n.startsWith('assets/minecraft/models/item/') && n.endsWith('.json'))
    .map((n) => n.slice('assets/minecraft/models/item/'.length, -'.json'.length)),
);
console.log(`原版方块总数: ${blocks.size}，物品模型总数: ${items.size}`);

const args = process.argv.slice(2);
const only = (flag) => args.length === 0 || args.includes(flag);
let missing = 0;
const check = (id, why) => {
  if (blocks.has(id)) return true;
  console.log(`  ✗ 不存在: minecraft:${id}   （${why}）`);
  missing++;
  return false;
};

/* ------------------------------------------------------------------ 木材 */
/* 每种的链条（从最加工到最原始）：活板门 → 门 → 栅栏门 → 栅栏 → 台阶 → 楼梯
 * → 木板 → 去皮木 → 去皮原木 → 木 → 原木。竹子没有"木"这一级，链条短一级。 */
const WOODS = [
  { name: '橡木', prefix: 'oak' },
  { name: '云杉', prefix: 'spruce' },
  { name: '白桦', prefix: 'birch' },
  { name: '丛木', prefix: 'jungle' },
  { name: '金合欢', prefix: 'acacia' },
  { name: '深色橡木', prefix: 'dark_oak' },
  { name: '红树', prefix: 'mangrove' },
  { name: '樱花', prefix: 'cherry' },
  { name: '绯红', prefix: 'crimson' },
  { name: '诡异', prefix: 'warped' },
  { name: '竹子', prefix: 'bamboo' },
];
/** 完整链条的 11 级（log 与 wood 两级用占位符，按木种替换） */
const WOOD_CHAIN_FULL = [
  '{p}_trapdoor', '{p}_door', '{p}_fence_gate', '{p}_fence', '{p}_slab',
  '{p}_stairs', '{p}_planks', 'stripped_{p}_wood', 'stripped_{p}_log',
  '{p}_wood', '{p}_log',
];
/** 竹子：没有 {p}_wood，且"原木"级叫 bamboo_block、"去皮原木"叫 stripped_bamboo_block */
const BAMBOO_CHAIN = [
  'bamboo_trapdoor', 'bamboo_door', 'bamboo_fence_gate', 'bamboo_fence',
  'bamboo_slab', 'bamboo_stairs', 'bamboo_planks', 'stripped_bamboo_block', 'bamboo_block',
];

/* ------------------------------------------------------------------ */
/* 木材·形态链：**标签版**（0.3 批次八）                                 */
/* ------------------------------------------------------------------ */
/* 链条前 7 级（活板门→门→栅栏门→栅栏→台阶→楼梯→木板）命名规整，
 * 而且原版为每一级都建了**方块标签** ⇒ 输入判定改写成标签，
 * 产物由引擎的 '@same_material' 按输入材质现挑（橡木栅栏 → 橡木台阶）。
 * 两个好处，都是用户点名的：
 *   · 模组木材自动适配 —— Quark / 暮色森林都往这些原版标签里登记了自己那一套，
 *     不用我们改配置；
 *   · 一条配方顶 11 条（木材越多省得越多），而且**不可能串材质**。
 *
 * ⚠️ 标签名是**实查**的（见下面的核对），不是猜的：
 *    原版有 fence_gates，**没有** wooden_fence_gates；
 *    活板门是 wooden_trapdoors（不是 trapdoors —— 那个含铁活板门）。
 *    写错的表现是"这一级永不触发"，且没有任何报错。
 *
 * ⚠️ 后 4 级（去皮木/去皮原木/木/原木）**没有**任何标签，命名也不规律
 *    （绯红/诡异是 hyphae/stem，竹子是 stripped_bamboo_block/bamboo_block）
 *    ⇒ 这一段仍然按木材逐个列出（log_tails）。
 */
const WOOD_SHAPE = [
  { name: 'trapdoor', tag: 'minecraft:wooden_trapdoors' },
  { name: 'door', tag: 'minecraft:wooden_doors' },
  { name: 'fence_gate', tag: 'minecraft:fence_gates' },
  { name: 'fence', tag: 'minecraft:wooden_fences' },
  { name: 'slab', tag: 'minecraft:wooden_slabs' },
  { name: 'stairs', tag: 'minecraft:wooden_stairs' },
  { name: 'planks', tag: 'minecraft:planks' },
];

/* ---- 读 jar 里某个条目的内容（核对标签成员用）----
 * 与 zipNames 同一套中央目录解析，只是多走一步：定位到本地头、
 * 取出压缩数据、按压缩方式解压。只需要 deflate 与 stored 两种。 */
function zipReadText(path, want) {
  const buf = readFileSync(path);
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i > buf.length - 65558; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd === -1) throw new Error('不是合法 zip: ' + path);
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) break;
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    const name = buf.toString('utf8', off + 46, off + 46 + nameLen);
    if (name === want) {
      const method = buf.readUInt16LE(off + 10);
      const compSize = buf.readUInt32LE(off + 20);
      const localOff = buf.readUInt32LE(off + 42);
      /* 本地头的长度不固定（name/extra 长度都在本地头里），照它自己的字段算 */
      const lNameLen = buf.readUInt16LE(localOff + 26);
      const lExtraLen = buf.readUInt16LE(localOff + 28);
      const start = localOff + 30 + lNameLen + lExtraLen;
      const data = buf.subarray(start, start + compSize);
      if (method === 0) return data.toString('utf8');
      if (method === 8) return inflateRawSync(data).toString('utf8');
      throw new Error('不支持的压缩方式 ' + method + '（' + want + '）');
    }
    off += 46 + nameLen + extraLen + commentLen;
  }
  return null;
}

/** 某个方块标签的成员（直接写死的那些；嵌套标签也一并展开）。 */
function blockTagMembers(rawTag, seen = new Set()) {
  if (seen.has(rawTag)) return [];
  seen.add(rawTag);
  const text = zipReadText(JAR, 'data/minecraft/tags/block/' + rawTag.replace('minecraft:', '') + '.json');
  if (text == null) return null;                 // 标签不存在
  const out = [];
  for (const v of (JSON.parse(text).values || [])) {
    const id = String(v);
    if (id.startsWith('#')) out.push(...blockTagMembers(id.slice(1), seen));
    else out.push(id.replace('minecraft:', ''));
  }
  return out;
}

if (only('--wood') || only('--families')) {
  console.log('\n=== 木材链条核对（形态链 = 标签版 / 原木链 = 逐木材列出）===');
  /* ① 形态链的 7 个标签必须真的存在，而且每一级里都要有这 11 种木材对应的那一个。
   *    这是"标签化"的护栏：标签名写错（原版是 fence_gates，**没有**
   *    wooden_fence_gates），表现就是那一级永不触发，而游戏里不报任何错。 */
  const tagMembers = new Map();
  for (const lv of WOOD_SHAPE) {
    const members = blockTagMembers(lv.tag);
    if (members == null) {
      console.log(`  ✗ 标签不存在: #${lv.tag}（形态链的 ${lv.name} 这一级靠它判定）`);
      missing++;
      tagMembers.set(lv.tag, []);
      continue;
    }
    tagMembers.set(lv.tag, members);
    console.log(`  #${lv.tag.padEnd(28)} ${String(members.length).padStart(3)} 个成员`);
  }
  for (const w of WOODS) {
    const chain = woodChainOf(w);
    let ok = 0;
    for (const id of chain) if (check(id, w.name + ' 链条')) ok++;
    let inTag = 0;
    for (let i = 0; i < WOOD_SHAPE.length; i++) {
      const members = tagMembers.get(WOOD_SHAPE[i].tag) || [];
      if (members.includes(chain[i])) inTag++;
      else console.log(`  ✗ ${w.name} 的 ${chain[i]} 不在 #${WOOD_SHAPE[i].tag} 里`
        + `（形态链第 ${i + 1} 级 —— 配方会永不触发）`);
    }
    if (inTag !== WOOD_SHAPE.length) missing++;
    console.log(`  ${w.name.padEnd(5)} 链条 ${ok}/${chain.length} 级存在，`
      + `形态链 ${inTag}/${WOOD_SHAPE.length} 落在对应标签里，`
      + `原木链 ${chain.length - WOOD_SHAPE.length} 级（逐木材列出）`);
  }
}

/* ------------------------------------------------------------------ 铜 */
/* 8 态顺序：铜块 → 斑驳 → 锈蚀 → 氧化 → 涂蜡 → 涂蜡斑驳 → 涂蜡锈蚀 → 涂蜡氧化。
 * 命名不规则（exposed_copper 但 exposed_cut_copper；铜块那一类只有状态 4 才带 _block），
 * 所以这里把每类的 8 个名字**写全**再逐个核对，而不是用模板拼。 */
const COPPER_TYPES = [
  ['铜块', ['copper_block', 'exposed_copper', 'weathered_copper', 'oxidized_copper',
    'waxed_copper_block', 'waxed_exposed_copper', 'waxed_weathered_copper', 'waxed_oxidized_copper']],
  ['切制铜块', ['cut_copper', 'exposed_cut_copper', 'weathered_cut_copper', 'oxidized_cut_copper',
    'waxed_cut_copper', 'waxed_exposed_cut_copper', 'waxed_weathered_cut_copper', 'waxed_oxidized_cut_copper']],
  ['切制铜台阶', ['cut_copper_stairs', 'exposed_cut_copper_stairs', 'weathered_cut_copper_stairs',
    'oxidized_cut_copper_stairs', 'waxed_cut_copper_stairs', 'waxed_exposed_cut_copper_stairs',
    'waxed_weathered_cut_copper_stairs', 'waxed_oxidized_cut_copper_stairs']],
  ['切制铜半砖', ['cut_copper_slab', 'exposed_cut_copper_slab', 'weathered_cut_copper_slab',
    'oxidized_cut_copper_slab', 'waxed_cut_copper_slab', 'waxed_exposed_cut_copper_slab',
    'waxed_weathered_cut_copper_slab', 'waxed_oxidized_cut_copper_slab']],
  ['雕纹铜块', ['chiseled_copper', 'exposed_chiseled_copper', 'weathered_chiseled_copper',
    'oxidized_chiseled_copper', 'waxed_chiseled_copper', 'waxed_exposed_chiseled_copper',
    'waxed_weathered_chiseled_copper', 'waxed_oxidized_chiseled_copper']],
  ['铜格栅', ['copper_grate', 'exposed_copper_grate', 'weathered_copper_grate',
    'oxidized_copper_grate', 'waxed_copper_grate', 'waxed_exposed_copper_grate',
    'waxed_weathered_copper_grate', 'waxed_oxidized_copper_grate']],
  ['铜灯', ['copper_bulb', 'exposed_copper_bulb', 'weathered_copper_bulb',
    'oxidized_copper_bulb', 'waxed_copper_bulb', 'waxed_exposed_copper_bulb',
    'waxed_weathered_copper_bulb', 'waxed_oxidized_copper_bulb']],
  ['铜门', ['copper_door', 'exposed_copper_door', 'weathered_copper_door', 'oxidized_copper_door',
    'waxed_copper_door', 'waxed_exposed_copper_door', 'waxed_weathered_copper_door',
    'waxed_oxidized_copper_door']],
  ['铜活板门', ['copper_trapdoor', 'exposed_copper_trapdoor', 'weathered_copper_trapdoor',
    'oxidized_copper_trapdoor', 'waxed_copper_trapdoor', 'waxed_exposed_copper_trapdoor',
    'waxed_weathered_copper_trapdoor', 'waxed_oxidized_copper_trapdoor']],
];

if (only('--copper')) {
  console.log('\n=== 铜 8 态核对 ===');
  for (const [label, ids] of COPPER_TYPES) {
    let ok = 0;
    for (const id of ids) if (check(id, label)) ok++;
    console.log(`  ${label.padEnd(6)} ${ok}/8`);
  }
  console.log('\n  jar 里所有含 copper 且未被上面覆盖的方块（供人工确认有没有漏类）：');
  const covered = new Set(COPPER_TYPES.flatMap(([, ids]) => ids));
  for (const id of [...blocks].filter((b) => b.includes('copper') && !covered.has(b)).sort()) {
    console.log('    ' + id + (id.includes('ore') || id.includes('raw') ? '   （矿石/原料，不是建筑方块）' : ''));
  }
}

/* ------------------------------------------------------------------ 石材 */
/* "不跨系"：每个系一个基准，系内的装饰变体 / 台阶 / 楼梯 / 墙 4 次切换变回基准。
 *
 * 基准怎么定（用户给的例子里"雕纹深板岩 → 深板岩圆石"就是答案）：
 *   基准 = 该系的**粗石形态** —— 用镐不带精准采集挖这种石头得到的那一块。
 *   深板岩 → 深板岩圆石；石头 → 圆石；花岗岩没有粗形态，就是它自己。
 *
 * 成员怎么定（机械展开，不靠手抄）：每个系给一组"名字主干"，
 * 逐个主干去 jar 里找它自己和它的 _stairs/_slab/_wall 变体。
 * 主干自己就是基准时会被自动排除（不能有 input == output 的配方）。 */
const STONE_FAMILIES = [
  {
    name: '石头/圆石',
    base: 'cobblestone',
    stems: ['stone', 'smooth_stone', 'stone_bricks', 'cracked_stone_bricks',
      'chiseled_stone_bricks', 'mossy_stone_bricks', 'mossy_cobblestone'],
  },
  {
    name: '深板岩',
    base: 'cobbled_deepslate',
    stems: ['deepslate', 'polished_deepslate', 'chiseled_deepslate', 'deepslate_bricks',
      'cracked_deepslate_bricks', 'deepslate_tiles', 'cracked_deepslate_tiles'],
  },
  { name: '花岗岩', base: 'granite', stems: ['granite', 'polished_granite'] },
  { name: '闪长岩', base: 'diorite', stems: ['diorite', 'polished_diorite'] },
  { name: '安山岩', base: 'andesite', stems: ['andesite', 'polished_andesite'] },
  {
    name: '凝灰岩',
    base: 'tuff',
    stems: ['tuff', 'polished_tuff', 'chiseled_tuff', 'tuff_bricks', 'chiseled_tuff_bricks'],
  },
  {
    name: '砂岩',
    base: 'sandstone',
    stems: ['sandstone', 'chiseled_sandstone', 'cut_sandstone', 'smooth_sandstone'],
  },
  {
    name: '红砂岩',
    base: 'red_sandstone',
    stems: ['red_sandstone', 'chiseled_red_sandstone', 'cut_red_sandstone', 'smooth_red_sandstone'],
  },
  {
    name: '石英',
    base: 'quartz_block',
    /* ⚠️ 形状不带 _block：整块叫 quartz_block，台阶却叫 quartz_slab。
     * 所以额外给一个 'quartz' 主干，靠 expandStem 去 jar 里挑出真实存在的形状。 */
    stems: ['quartz_block', 'quartz', 'chiseled_quartz_block', 'quartz_bricks', 'quartz_pillar', 'smooth_quartz'],
  },
  { name: '海晶石', base: 'prismarine', stems: ['prismarine', 'prismarine_bricks', 'dark_prismarine'] },
  {
    name: '黑石',
    base: 'blackstone',
    stems: ['blackstone', 'polished_blackstone', 'chiseled_polished_blackstone',
      'polished_blackstone_bricks', 'cracked_polished_blackstone_bricks'],
  },
  { name: '玄武岩', base: 'basalt', stems: ['basalt', 'polished_basalt', 'smooth_basalt'] },
  {
    name: '下界砖',
    base: 'nether_bricks',
    stems: ['nether_bricks', 'chiseled_nether_bricks', 'cracked_nether_bricks'],
  },
  { name: '末地石', base: 'end_stone', stems: ['end_stone', 'end_stone_bricks'] },
  /* ⚠️ 形状不带 _block：整块 purpur_block，台阶 purpur_slab */
  { name: '紫珀', base: 'purpur_block', stems: ['purpur_block', 'purpur', 'purpur_pillar'] },
  { name: '红下界砖', base: 'red_nether_bricks', stems: ['red_nether_bricks'] },
  { name: '泥砖', base: 'packed_mud', stems: ['packed_mud', 'mud_bricks'] },
];

/** 形状后缀：只取台阶/楼梯/墙（用户选定：完整方块 + 台阶/楼梯/墙）。 */
const SHAPE_SUFFIX = ['', '_stairs', '_slab', '_wall'];

/** 主干 → 它自己 + 存在的形状变体。形状只取台阶/楼梯/墙（用户选定）。
 *
 * ⚠️ 原版命名里"整块"是复数、形状是单数：
 *      mossy_stone_bricks（整块） / mossy_stone_brick_slab（台阶）
 *      polished_blackstone_bricks / polished_blackstone_brick_wall
 *    只按主干原样拼形状后缀会**静默漏掉**这些台阶/楼梯/墙
 *    （第一版就是这么漏的：mossy_stone_brick_* 与 polished_blackstone_brick_*
 *     六条形状一个都没进来，而"漏了"在游戏里的表现就是"那几个方块不掉"）。
 *    所以复数主干要额外试一遍单数形式。 */
function stemsOf(stem) {
  const list = [stem];
  if (stem.endsWith('_bricks')) list.push(stem.slice(0, -1));
  if (stem.endsWith('_tiles')) list.push(stem.slice(0, -1));
  return list;
}

function expandStem(stem) {
  const out = [];
  for (const s of stemsOf(stem)) {
    for (const suffix of SHAPE_SUFFIX) {
      const id = s + suffix;
      if (blocks.has(id) && !out.includes(id)) out.push(id);
    }
  }
  return out;
}

if (only('--stone') || only('--families')) {
  console.log('\n=== 石材系（基准 + 成员，全部实测存在）===');
  let total = 0;
  for (const fam of STONE_FAMILIES) {
    check(fam.base, fam.name + ' 基准');
    const members = [];
    for (const stem of fam.stems) {
      for (const id of expandStem(stem)) {
        if (id === fam.base) continue;          // 基准自己不进配方
        if (members.includes(id)) continue;
        members.push(id);
      }
    }
    if (members.length === 0) {
      console.log(`  · ${fam.name.padEnd(6)} 基准 minecraft:${fam.base}（没有可转换的变体，跳过）`);
      continue;
    }
    total += members.length;
    console.log(`  ${fam.name.padEnd(6)} 基准 minecraft:${fam.base}  ←  ${members.length} 个成员`);
    for (const m of members) console.log('      ' + m);
  }
  console.log(`  合计 ${total} 条"变体 → 基准"配方`);
}

if (only('--stone')) {
  console.log('\n=== 反向核对：jar 里还有哪些"像石材但没被任何系覆盖"的方块 ===');
  const covered = new Set(STONE_FAMILIES.flatMap((f) => [f.base, ...f.stems.flatMap(expandStem)]));
  const MODS = ['chiseled_', 'polished_', 'cracked_', 'mossy_', 'smooth_', 'cut_'];
  /* ⚠️ 判据要比"含某个修饰词"宽：形状后缀也算候选 —— 否则
   * stone_brick_stairs 这种既不含修饰词、又不以 _bricks 结尾的方块会静默漏掉。 */
  const leftovers = [...blocks].filter((b) => {
    if (covered.has(b)) return false;
    if (b.includes('copper') || b.includes('wood') || b.includes('log') || b.includes('planks')) return false;
    if (b.includes('_ore') || b.startsWith('raw_') || b.startsWith('infested_')) return false;
    return MODS.some((m) => b.includes(m))
      || b.endsWith('_bricks') || b.endsWith('_tiles')
      || b.endsWith('_stairs') || b.endsWith('_slab') || b.endsWith('_wall');
  }).sort();
  for (const b of leftovers) console.log('    ' + b);
  console.log(`    共 ${leftovers.length} 个（人工确认是否需要归入某个系）`);
}

/** 某种木材的完整链条（含竹子与菌类的特例）。 */
function woodChainOf(w) {
  if (w.prefix === 'bamboo') return BAMBOO_CHAIN;
  if (w.prefix === 'crimson' || w.prefix === 'warped') {
    /* 绯红/诡异：原木=stem、木=hyphae */
    return WOOD_CHAIN_FULL.map((t) => t
      .replace('stripped_{p}_wood', 'stripped_{p}_hyphae')
      .replace('stripped_{p}_log', 'stripped_{p}_stem')
      .replace('{p}_wood', '{p}_hyphae')
      .replace('{p}_log', '{p}_stem')
      .replace(/\{p\}/g, w.prefix));
  }
  return WOOD_CHAIN_FULL.map((t) => t.replace(/\{p\}/g, w.prefix));
}

/** 某石材系展开后的成员（去掉基准自己）。 */
function stoneMembersOf(fam) {
  const members = [];
  for (const stem of fam.stems) {
    for (const id of expandStem(stem)) {
      if (id === fam.base || members.includes(id)) continue;
      members.push(id);
    }
  }
  return members;
}

/** 生成三张数据表（配置片段文本）。--emit-config 与 --write 共用。 */
function buildTables() {
  const q = (s) => `'${s}'`;
  const lines = [];
  lines.push('    /* ---- 木材 ----------------------------------------------------------');
  lines.push('     * 形态链（活板门 → 门 → 栅栏门 → 栅栏 → 台阶 → 楼梯 → 木板）：**标签版**。');
  lines.push('     * 每一级给一个原版方块标签，引擎据此认输入，并用 @same_material');
  lines.push('     * 按**输入材质**挑同材质的下一级（橡木栅栏 → 橡木台阶）。');
  lines.push('     * 模组木材自己会往这些原版标签里登记（Quark / 暮色森林实测都登记了）');
  lines.push('     * ⇒ 自动适配，且不可能串材质。');
  lines.push('     * 原木链（去皮木 → 去皮原木 → 木 → 原木）原版命名不规律、也没有标签');
  lines.push('     * （绯红/诡异是 hyphae/stem，竹子是 bamboo_block）⇒ 逐木材列出。 ---- */');
  lines.push('    wood: {');
  lines.push('      forward: 8,');
  lines.push('      reverse: 4,');
  lines.push("      reverse_on: 'minecraft:crafting_table',");
  lines.push('      shape: [');
  for (const lv of WOOD_SHAPE) {
    lines.push(`        { name: ${q(lv.name)}, tag: ${q('#' + lv.tag)} },`);
  }
  lines.push('      ],');
  lines.push('      /* 原木链（**逐木材列出**）：每项从"木板"开始 —— [木板, 去皮木,');
  lines.push('       * 去皮原木, 木, 原木]（竹子短一级，绯红/诡异是 hyphae/stem）。');
  lines.push('       * 木板那一级由上面形态链的 @same_material 覆盖（标签进、同材质出），');
  lines.push('       * 这一级之后命名不再规整、也没有标签可用，所以只能逐木材写出来。 */');
  lines.push('      log_chains: {');
  for (const w of WOODS) {
    const chain = woodChainOf(w);
    lines.push(`        ${w.prefix}: [`);
    lines.push('          ' + chain.slice(WOOD_SHAPE.length - 1).map((id) => q('minecraft:' + id)).join(', '));
    lines.push('        ],');
  }
  lines.push('      },');
  lines.push('    },');
  lines.push('');
  lines.push('    /* ---- 铜：每类一条 8 态链条（铜块→斑驳→锈蚀→氧化→涂蜡→涂蜡斑驳→涂蜡锈蚀→涂蜡氧化）---- */');
  lines.push('    copper: {');
  lines.push('      forward: 8,');
  lines.push('      reverse: 4,');
  lines.push("      reverse_on: 'minecraft:slime_block',");
  lines.push('      chains: {');
  for (const [label, ids] of COPPER_TYPES) {
    lines.push(`        ${q(label)}: [`);
    lines.push('          ' + ids.map((id) => q('minecraft:' + id)).join(', '));
    lines.push('        ],');
  }
  lines.push('      },');
  lines.push('    },');
  lines.push('');
  lines.push('    /* ---- 石材：每系一个基准 + 成员（装饰变体与台阶/楼梯/墙，均实测存在于原版）---- */');
  lines.push('    stone: {');
  lines.push('      crossings: 4,');
  lines.push('      families: [');
  for (const fam of STONE_FAMILIES) {
    const members = stoneMembersOf(fam);
    if (members.length === 0) continue;
    lines.push(`        { name: ${q(fam.name)}, base: ${q('minecraft:' + fam.base)},`);
    lines.push('          members: [');
    for (let i = 0; i < members.length; i += 3) {
      lines.push('            ' + members.slice(i, i + 3).map((m) => q('minecraft:' + m)).join(', ') + ',');
    }
    lines.push('          ] },');
  }
  lines.push('      ],');
  lines.push('    },');
  return lines.join('\n');
}

/* ------------------------------------------------------------------ 导出 */
/* 把上面三张表导出成**可直接粘进 mirror_config.js 的 JS 片段**。
 * 命名逻辑留在这个工具里（它读得到 jar），配置里只放纯数据 —— 这样
 * "拼名字"这件事只有一个地方会出错，而且出错必被上面的 check() 拦住。 */
if (args.includes('--emit-config')) {
  console.log('\n===== 配置片段开始 =====');
  console.log(buildTables());
  console.log('===== 配置片段结束 =====');
}
/* ------------------------------------------------------------------ 反向核对 */
/* 读**已经写好的** mirror_config.js，把它展开后的重力配方列表拉出来，
 * 再逐条回到 jar 核对。这是最后一道关：配置里手抄/粘错一个 id，
 * 在游戏里的表现是"那条配方永不触发"，没有任何报错。 */
if (args.includes('--verify-config')) {
  const CFG = 'D:\\DSHwork\\MC镜维度\\.minecraft\\versions\\镜维度\\kubejs\\startup_scripts\\mirror_config.js';
  if (!existsSync(CFG)) {
    console.error('找不到 mirror_config.js: ' + CFG);
    process.exit(2);
  }
  const src = readFileSync(CFG, 'utf8');
  let cfg = null;
  try {
    cfg = new Function(src.replace(/^\s*(const|let)\s+/gm, 'var ') + '\n; return MIRROR_CONFIG;')();
  } catch (e) {
    console.error('配置求值失败: ' + e.message);
    process.exit(2);
  }
  const list = (cfg.gravityBlockRecipes && cfg.gravityBlockRecipes.list) || [];
  console.log(`\n=== 反向核对：配置里的重力配方共 ${list.length} 条 ===`);

  const ids = new Map();
  const byTrigger = new Map();
  /* 落点里出现的**模组方块 ID**（非 minecraft 命名空间）—— 原版 jar 里当然没有，
   * 收集起来最后报一句，交给 check-recipes.mjs 对着模组 jar 核对。 */
  const moddedOns = [];
  let bad = 0;
  const fail = (m) => { bad++; console.log('  ✗ ' + m); };

  for (const r of list) {
    if (ids.has(r.id)) fail(`配方 id 重复: ${r.id}`);
    ids.set(r.id, true);
    for (const [field, value] of [['input', r.input], ['output', r.output]]) {
      const raw = String(value);
      if (raw.startsWith('@')) continue;                                // 动态产物占位符
      if (raw.startsWith('#')) continue;                                // 标签，不在这里校验
      const id = raw.replace('minecraft:', '');
      if (!blocks.has(id)) fail(`${r.id}: ${field} 不存在于原版方块表 → ${raw}`);
    }
    /* @random 的 pool：每条候选都要能解析成真实物品（或方块）。
     * pool 元素可以是物品 ID，也可以是物品堆 JSON（山羊角带 instrument 组件）。 */
    if (String(r.output) === '@random') {
      const pool = Array.isArray(r.pool) ? r.pool : null;
      if (pool == null || pool.length === 0) {
        fail(`${r.id}: 产物是 @random 但没有 pool`);
      } else {
        if (r.drop !== true) fail(`${r.id}: 产物是 @random 但没有 drop:true（物品放不成方块）`);
        for (const one of pool) {
          let id;
          let components = null;
          if (one != null && typeof one === 'object') {
            id = String(one.id ?? '').replace('minecraft:', '');
            components = (one.components != null) ? one.components : null;
          } else {
            id = String(one).replace('minecraft:', '');
          }
          if (id === '') { fail(`${r.id}: pool 里有条目没有 id`); continue; }
          if (!items.has(id) && !blocks.has(id)) fail(`${r.id}: pool 里的 ${id} 既不是物品也不是方块`);
          /* 组件里的 instrument 之类不在这里展开核对（那是原版数据包注册表），
           * 但至少要确认名空间写全了 —— 少写名空间在运行时是静默失败。 */
          if (components != null) {
            for (const v of Object.values(components)) {
              if (typeof v === 'string' && !v.includes(':')) {
                fail(`${r.id}: pool 条目 ${id} 的组件值 "${v}" 少了名空间前缀`);
              }
            }
          }
        }
      }
    }
    /* ⚠️ on 允许三种写法：单条 ID、单个标签、以及**一组**（数组）。
     * 早先这里只写了 String(r.on) —— 数组会被拍成
     * "#c:storage_blocks,#c:storage_blocks/raw_lead,…,cataclysm:enderite_block"，
     * 因为它以 '#' 开头就整条被当成标签跳过了：**数组里的每一个 ID 都没被核对**
     * （而"落点 ID 写错"正是本项目最典型的静默失效）。现在逐个元素查。
     *
     * ⚠️ 元素允许是标签（#minecraft:leaves、#c:storage_blocks…）—— 引擎按标签
     * 匹配落点，拿它去方块表里查会误报"不存在"。
     * ⚠️ 也允许是**模组方块**（cataclysm:enderite_block…）—— 它们来自别的模组的
     * jar，不在原版方块表里。这里只对 minecraft: 命名空间的落点做"必须存在"的
     * 硬核对（写错一个字母就是永不触发），模组方块交给
     * tools-build/check-recipes.mjs 对着模组 jar 核对。 */
    const onEach = Array.isArray(r.on) ? r.on.map(String) : (r.on != null ? [String(r.on)] : []);
    for (const rawOn of onEach) {
      if (rawOn.startsWith('#')) continue;
      if (rawOn.startsWith('minecraft:')) {
        if (!blocks.has(rawOn.replace('minecraft:', ''))) {
          fail(`${r.id}: on（落点方块）不存在 → ${rawOn}`);
        }
      } else {
        moddedOns.push(rawOn);
      }
    }
    if (String(r.input) === String(r.output)) fail(`${r.id}: 输入与输出相同（自己变自己）`);
    if (r.trigger === 'landing' && r.on == null) fail(`${r.id}: trigger=landing 但没写 on（落点方块）`);
    if (r.trigger !== 'landing' && r.trigger !== 'crossing') fail(`${r.id}: trigger 非法 → ${r.trigger}`);
    if (!(r.crossings >= 1)) fail(`${r.id}: crossings 非法 → ${r.crossings}`);

    /* ⚠️ 同一个输入**允许**有两条配方 —— 只要触发方式不同：
     *   木材链上"橡木门"既是 8 次穿越→栅栏门 的输入，
     *   也是 4 次穿越+落工作台→活板门 的输入。
     * 引擎按 trigger 分流（落点先于穿越判定），所以这不是冲突。
     * 真正的冲突是"同输入 + 同触发 + 同落点" —— 那才会出现"哪条生效看顺序"。 */
    const key = `${r.input}|${r.trigger}|${r.on ?? ''}`;
    if (byTrigger.has(key)) {
      fail(`同一输入 + 同一触发有两条配方: ${key}（${byTrigger.get(key)} 与 ${r.output}）`);
    } else {
      byTrigger.set(key, r.output);
    }
  }
  const dynamic = list.filter((r) => String(r.output).startsWith('@')).length;
  console.log(`  含动态产物（@landed/@mapped/@random/@same_material）${dynamic} 条；静态配方输入唯一性已检查`);

  /* ---- 木材的标签化（0.3 批次八）------------------------------------------
   * 形态链靠**标签**认输入、靠 '@same_material' 挑同材质产物。这两件事
   * 任何一处写错，游戏里的表现都是"那一级永不触发"，不会有任何报错，
   * 所以在这里逐条对着 jar 核对。 */
  const FR = cfg.familyRecipes;
  const W = (FR != null) ? FR.wood : null;
  if (W == null) {
    console.log('  · 没有 familyRecipes.wood（这套玩法关着？跳过木材核对）');
  } else {
    if (W.chains != null) {
      fail('familyRecipes.wood.chains 还在 —— 木材形态链已改成 shape（标签版），'
        + '旧的整条 chains 应当删掉，否则同一级会被生成两遍（配方冲突）');
    }
    const shape = Array.isArray(W.shape) ? W.shape : null;
    if (shape == null || shape.length < 2) {
      fail('familyRecipes.wood.shape（形态链）缺失或少于两级');
    } else {
      const names = new Set();
      for (const lv of shape) {
        if (lv == null || lv.name == null || lv.tag == null) {
          fail('形态链里有级别缺少 name/tag: ' + JSON.stringify(lv));
          continue;
        }
        if (names.has(lv.name)) fail('形态链里有重名的级别: ' + lv.name);
        names.add(lv.name);
        const tag = String(lv.tag);
        if (!tag.startsWith('#')) {
          fail(`形态链 ${lv.name} 的 tag 必须是标签（# 开头），实际 ${tag}`);
          continue;
        }
        if (blockTagMembers(tag.slice(1)) == null) {
          fail(`形态链 ${lv.name} 的标签不存在: ${tag}（这一级会永不触发）`);
        }
      }
      const fromTags = list.filter((r) => String(r.output) === '@same_material');
      const expected = (shape.length - 1) * 2;      // 每对相邻级别：正向 + 反向
      if (fromTags.length !== expected) {
        fail(`@same_material 配方应有 ${expected} 条（形态链 ${shape.length} 级 × 2 个方向），`
          + `实际 ${fromTags.length} 条`);
      } else {
        console.log(`  ✓ 木材形态链 ${shape.length} 级（全标签）→ @same_material 配方 ${fromTags.length} 条`);
      }
      for (const r of fromTags) {
        const mt = (r.material_target != null) ? String(r.material_target) : null;
        if (mt == null) { fail(`${r.id}: @same_material 但没有 material_target`); continue; }
        if (!mt.startsWith('#')) { fail(`${r.id}: material_target 必须是标签，实际 ${mt}`); continue; }
        if (blockTagMembers(mt.slice(1)) == null) fail(`${r.id}: material_target 标签不存在: ${mt}`);
        if (!String(r.input).startsWith('#')) {
          fail(`${r.id}: @same_material 的输入应当是标签（否则模组木材适配不了），实际 ${r.input}`);
        }
      }
    }
    /* 原木链：逐木材列出（含木板那一级的起点），每条 id 都必须真的存在 */
    const tails = (W.log_chains != null) ? W.log_chains : null;
    if (tails == null) {
      fail('familyRecipes.wood.log_chains 缺失（原木链没有数据了）');
    } else {
      const plankMembers = blockTagMembers('minecraft:planks') || [];
      let n = 0;
      for (const [wood, chain] of Object.entries(tails)) {
        if (!Array.isArray(chain) || chain.length < 2) {
          fail(`log_chains.${wood} 少于两级（相邻转换至少要两级）`);
          continue;
        }
        for (const id of chain) {
          const short = String(id).replace('minecraft:', '');
          if (!blocks.has(short)) fail(`log_chains.${wood} 里的 ${id} 不存在于原版方块表`);
          n++;
        }
        /* 第一级必须是**木板**（形态链的出口），否则这一段的入口就断了 */
        if (!plankMembers.includes(String(chain[0]).replace('minecraft:', ''))) {
          fail(`log_chains.${wood} 的第一级 ${chain[0]} 不在 #minecraft:planks 里 ——`
            + '它是形态链的出口，应当是这种木材的木板');
        }
      }
      console.log(`  ✓ 原木链逐木材列出 ${Object.keys(tails).length} 种、共 ${n} 级，`
        + '入口都在 #minecraft:planks 里，全部存在');
    }
  }

  if (moddedOns.length > 0) {
    console.log(`  · 落点里的模组方块 ${moddedOns.length} 个（原版 jar 里查不到，属正常）：`
      + [...new Set(moddedOns)].join('、'));
    console.log('    它们由 tools-build/check-recipes.mjs 对着模组 jar 逐个核对。');
  }
  console.log(bad === 0 ? '  ✓ 配置里的配方全部可用' : `  ✗ ${bad} 项有问题`);
  process.exit(bad === 0 && missing === 0 ? 0 : 1);
}

/* ------------------------------------------------------------------ 写入 */
/* 把生成的数据表写进 mirror_config.js 的**哨兵注释区**之间。
 * 为什么要写回而不是让人手抄：这是一百多行、几百个方块 id，
 * 手抄必错，而错了就是"那条配方永不触发"。哨兵之间整段替换，
 * 以后升版本只要重跑这个命令。 */
if (args.includes('--write')) {
  const CFG = 'D:\\DSHwork\\MC镜维度\\.minecraft\\versions\\镜维度\\kubejs\\startup_scripts\\mirror_config.js';
  const BEGIN = '  /* ===== 家族配方数据（生成区，勿手改）===== */';
  const END = '  /* ===== 家族配方数据结束 ===== */';
  const src = readFileSync(CFG, 'utf8');
  const bCount = src.split(BEGIN).length - 1;
  const eCount = src.split(END).length - 1;
  if (bCount !== 1 || eCount !== 1) {
    console.error(`哨兵注释必须各出现一次（现在 开始=${bCount} 结束=${eCount}）。`
      + ' 首次使用请先手工把这两行放进 mirror_config.js 的 familyRecipes 段。');
    process.exit(2);
  }
  const bIdx = src.indexOf(BEGIN);
  const eIdx = src.indexOf(END);
  if (eIdx < bIdx) {
    console.error('哨兵顺序反了');
    process.exit(2);
  }
  const tables = buildTables();
  const next = src.slice(0, bIdx + BEGIN.length) + '\n' + tables + '\n' + src.slice(eIdx);
  writeFileSync(CFG, next);
  console.log(`\n已写入 ${CFG}`);
  console.log(`  数据段 ${tables.split('\n').length} 行`);
  process.exit(missing === 0 ? 0 : 1);
}

console.log('\n' + (missing === 0
  ? '✓ 推导出的方块 id 全部存在'
  : `✗ ${missing} 个 id 不存在（上面的 ✗ 行）`));
process.exit(missing === 0 ? 0 : 1);
