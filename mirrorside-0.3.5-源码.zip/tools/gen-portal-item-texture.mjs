/**
 * 生成"镜面传送门"的**物品图标**（16×16 静态图）。
 * =====================================================================
 * 产出：
 *   assets/mirrorgravity/textures/item/mirror_portal.png
 *
 * ── 为什么要脚本生成 ────────────────────────────────────────────────
 * 与方块贴图同一个理由（见 gen-portal-texture.mjs 开头）：图案是**参数化**的，
 * 手画对不齐、重跑还不一致；脚本生成则任何时候重跑都得到逐字节相同的文件。
 *
 * ── 图标长什么样（三句话）────────────────────────────────────────────
 *   ① 外圈 1 像素：**银色边框**（镜面那块板材的颜色，银蓝冷调渐变）；
 *   ② 内部 14×14：传送门那张黑白流动图案，**固定在第 12 帧的相位**上；
 *   ③ 内部做成**不透明**（方块那张是半透明的）—— 物品栏里半透明图标会
 *      透出格子底色，看不清图案；方块是透过它看世界，两种情况要求相反。
 *
 * ⚠️ 图案公式与 gen-portal-texture.mjs 是**同一套**（三束行波叠加 + S 形缓动）。
 *    那边改了图案，这边要跟着改 —— 两处都写明了这一点，改一处时请搜索
 *    "三束行波"。之所以不 import：那个脚本在模块顶层就会写文件、跑自检，
 *    被 import 时会连带执行一遍（改它不值得，代价比这条注释大）。
 *
 * 用法:  node tools/gen-portal-item-texture.mjs
 * =====================================================================
 */
import { writeFileSync, mkdirSync, existsSync, readFileSync } from 'node:fs';
import { deflateSync } from 'node:zlib';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

/* ------------------------------------------------------------------ */
/* PNG 编码（与 gen-portal-texture.mjs 同一份实现）                      */
/* ------------------------------------------------------------------ */

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c;
  }
  return t;
})();

function crcOf(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crcOf(body), 0);
  return Buffer.concat([len, body, crc]);
}

/**
 * RGBA 像素数组 → PNG（colorType 6，bitDepth 8）。
 * @param {number} w 宽
 * @param {number} h 高
 * @param {(x:number,y:number)=>number[]} get 返回 [r,g,b,a]
 */
function encodePng(w, h, get) {
  const stride = w * 4;
  const raw = Buffer.alloc(h * (stride + 1));
  let p = 0;
  for (let y = 0; y < h; y++) {
    raw[p++] = 0;                       // 滤波类型 0（None）
    for (let x = 0; x < w; x++) {
      const [r, g, b, a] = get(x, y);
      raw[p++] = r & 0xff;
      raw[p++] = g & 0xff;
      raw[p++] = b & 0xff;
      /* ⚠️ alpha 原样写入，不做任何裁剪 —— 见 gen-portal-texture.mjs 的注释：
       * 裁一下会把 255 变成 0，贴图整块消失。 */
      raw[p++] = a & 0xff;
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;     // bit depth
  ihdr[9] = 6;     // color type: RGBA
  ihdr[10] = 0;    // compression
  ihdr[11] = 0;    // filter
  ihdr[12] = 0;    // interlace
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/* ------------------------------------------------------------------ */
/* 图案                                                                */
/* ------------------------------------------------------------------ */

const SIZE = 16;
/** 图标取这一帧的相位（0 ~ 47）。12 落在"由暗转亮"的中段，明暗都在画面里。 */
const FRAME = 12;
const FRAMES = 48;

const TAU = Math.PI * 2;

function smoothstep(t) {
  const c = Math.min(1, Math.max(0, t));
  return c * c * (3 - 2 * c);
}

/** 传送门图案的亮度（0~1）。**三束行波**：与方块贴图 gen-portal-texture.mjs 同源。 */
function lumaAt(x, y, u) {
  const w1 = Math.sin(TAU * (x / 16 + y / 16 + u));
  const w2 = Math.sin(TAU * (x / 16 - y / 16 - u));
  const w3 = Math.sin(TAU * (y / 16 - 2 * u));
  const m = (w1 + w2 + 0.6 * w3) / 2.6;
  return smoothstep((m + 1) / 2);
}

/** 银色边框（镜面那块板材的配色）：左上亮、右下压暗，四边收得住。 */
function silver(t) {
  const k = Math.min(1, Math.max(0, t));
  const r = 0x2c + (0xff - 0x2c) * k;
  const g = 0x33 + (0xff - 0x33) * k;
  const b = 0x3d + (0xff - 0x3d) * k;
  return [Math.round(r), Math.round(g), Math.round(b), 255];
}

const INNER = SIZE - 2;   // 去掉外圈 1 像素

function pixel(x, y) {
  const u = FRAME / FRAMES;
  /* 外圈：边框。受光从左上来，右下压到 0.45 —— 一眼能看出是"一块带框的板子" */
  if (x === 0 || y === 0 || x === SIZE - 1 || y === SIZE - 1) {
    let t = 0.95 - 0.42 * ((x + y) / (2 * (SIZE - 1)));
    if (x === SIZE - 1 || y === SIZE - 1) t -= 0.10;
    return silver(t);
  }
  /* 内圈：传送门图案（不透明 —— 见开头第 ③ 条） */
  const n = lumaAt(x - 1, y - 1, u);
  const lum = Math.round(26 + 210 * n);
  return [lum, lum, lum, 255];
}

/* ------------------------------------------------------------------ */
/* 输出                                                                */
/* ------------------------------------------------------------------ */

/* 目录层级与 gen-mirror-textures.mjs 一致（相对本脚本上溯 4 层到工程根）。
 * ⚠️ 是 4 层不是 3 层 —— 写错会把文件写进一个并不存在的 .minecraft 副本目录，
 *    而且不会报错。改这里时对着 gen-mirror-textures.mjs 的注释数一遍。 */
const here = dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = join(here, '..', '..', '..', '..');
const RES = join(PROJECT_ROOT, 'mirror-gravity-mod', 'src', 'main', 'resources');
const OUT = join(RES, 'assets', 'mirrorgravity', 'textures', 'item', 'mirror_portal.png');
const BLOCK_PNG = join(RES, 'assets', 'mirrorgravity', 'textures', 'block', 'mirror_portal.png');

mkdirSync(dirname(OUT), { recursive: true });
const png = encodePng(SIZE, SIZE, pixel);
writeFileSync(OUT, png);

console.log('=== 生成传送门物品图标 ===');
console.log(`  图幅   ${SIZE} × ${SIZE}（静态，方块那张是 ${FRAMES} 帧动画）`);
console.log(`  相位   第 ${FRAME} 帧（u=${(FRAME / FRAMES).toFixed(3)}）`);
console.log(`  输出   ${OUT}  ${png.length}B`);

/* ------------------------------------------------------------------ */
/* 自检：不用开图片也能看出画的是什么                                    */
/* ------------------------------------------------------------------ */

const RAMP = ' .:-=+*#%@';
console.log('  ── 字符画预览（越靠右越亮）──');
for (let y = 0; y < SIZE; y++) {
  let line = '   |';
  for (let x = 0; x < SIZE; x++) {
    line += RAMP[Math.min(RAMP.length - 1, Math.floor((pixel(x, y)[0] / 256) * RAMP.length))];
  }
  console.log(line + '|');
}

const checks = [];
/* ① 边框必须四边连着、且不透明 */
{
  let frameOk = true;
  for (let i = 0; i < SIZE; i++) {
    for (const [x, y] of [[i, 0], [i, SIZE - 1], [0, i], [SIZE - 1, i]]) {
      if (pixel(x, y)[3] !== 255) frameOk = false;
    }
  }
  checks.push(['外圈边框四边都在、且不透明', frameOk]);
}
/* ② 内部图案要跨得够宽（否则图标是一坨灰）、且不透明 */
{
  let min = 255;
  let max = 0;
  let opaque = true;
  for (let y = 1; y < SIZE - 1; y++) {
    for (let x = 1; x < SIZE - 1; x++) {
      const [lum, , , a] = pixel(x, y);
      min = Math.min(min, lum);
      max = Math.max(max, lum);
      if (a !== 255) opaque = false;
    }
  }
  console.log(`  内部亮度 ${min} ~ ${max}，与边框对比明显`);
  checks.push(['内部黑白跨度够宽（≥120）', max - min >= 120]);
  checks.push(['内部不透明（物品栏里要看得清）', opaque]);
}
/* ③ 与方块贴图对得上：那边必须还是"16 宽 × 16×48 高"的动画图。
 *    这里不复制它的图案，只确认它还在、尺寸还是这套约定 —— 两边一起改的信号。 */
{
  let same = false;
  let note = '（方块贴图不存在，先跑 tools/gen-portal-texture.mjs）';
  if (existsSync(BLOCK_PNG)) {
    const b = readFileSync(BLOCK_PNG);
    const w = b.readUInt32BE(16);
    const h = b.readUInt32BE(20);
    same = (w === SIZE && h === SIZE * FRAMES);
    note = `（方块贴图 ${w}×${h}）`;
  }
  checks.push(['方块贴图仍是 ' + SIZE + ' × ' + (SIZE * FRAMES) + ' 的动画图 ' + note, same]);
}

let ok = true;
for (const [what, pass] of checks) {
  console.log(`  ${pass ? '✓' : '✗'} ${what}`);
  if (!pass) ok = false;
}
if (!ok) process.exitCode = 1;
