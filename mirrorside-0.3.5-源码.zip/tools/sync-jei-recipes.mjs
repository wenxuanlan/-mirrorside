#!/usr/bin/env node
/**
 * 从 KubeJS 配置导出「重力方块加工」配方，供 JEI 展示。
 *
 * ── 为什么要这一步 ────────────────────────────────────────────────
 * 真正决定加工行为的是：
 *     <实例>/kubejs/startup_scripts/mirror_config.js → gravityBlockRecipes
 *
 * 而 JEI 的配方注册发生在**客户端启动期**（世界还没加载），
 * 那时 KubeJS 脚本还没跑；加上 KubeJS 脚本**无法写文件**
 * （classfilter 拦掉了 java.nio.file，也没有现成的 Path 入口），
 * 所以不能指望"运行时导出"。
 *
 * 于是把这份配置**派生成**模组 jar 内的资源文件：
 *     mirror-gravity-mod/src/main/resources/gravity_recipes.json
 * Java 侧在 JEI 注册配方时读它（见 GravityRecipeData）。
 *
 * ── 关键改动：把配置**真的跑一遍** ────────────────────────────────
 * 早先这里是拿正则去"读"配置文本的，结果是残缺的：
 *   · 文件末尾用循环生成的 32 条混凝土配方**一条都没导出**（只认字面量）
 *   · 落点标签（on: '#c:storage_blocks'）、容器插入池（insert.items）、
 *     动态产物（@landed）全部丢失
 * 于是 JEI 里只有最初手写的那两条，看起来就是"配方没进 JEI"。
 *
 * 现在改为 `new Function(src)` 直接执行配置脚本、取回 MIRROR_CONFIG。
 * mirror_config.js 本来就是**纯数据 + 一个循环**（不依赖任何游戏 API，
 * 这也是它当初能写成脚本的原因），所以在 Node 里跑得通，
 * 导出的内容与运行时**逐字段一致**。tools-build/check-recipes.mjs
 * 一直就是这么干的 —— 这里只是把同一招用在导出上。
 *
 * ── 用法 ─────────────────────────────────────────────────────────
 *     cd <实例目录>
 *     node tools/sync-jei-recipes.mjs
 *     # 然后重新构建模组，新配方才会进 JEI
 *
 * 改完 mirror_config.js 的配方记得跑一次。
 * 忘了也不会出危险：游戏逻辑始终以 mirror_config.js 为准，
 * 只是 JEI 里显示的内容会与实际的脱节。
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const instanceRoot = resolve(here, '..');

const CONFIG = join(instanceRoot, 'kubejs', 'startup_scripts', 'mirror_config.js');

/*
 * 模组工程的位置。
 *
 * 目录结构（相对本脚本）：
 *   <实例>/tools/sync-jei-recipes.mjs      ← 本脚本
 *   <实例>                                   ← 上一层
 *   <工程根>/.minecraft/versions/<实例>       ← 再上两层
 *   <工程根>/mirror-gravity-mod              ← 模组工程
 * 所以从实例根往上三层才是工程根。
 */
const PROJECT_ROOT = resolve(instanceRoot, '..', '..', '..');
const OUT = process.argv[2]
  ? resolve(process.argv[2])
  : join(PROJECT_ROOT, 'mirror-gravity-mod', 'src', 'main', 'resources', 'gravity_recipes.json');

if (!existsSync(CONFIG)) {
  console.error(`找不到配置文件：${CONFIG}`);
  process.exit(1);
}

mkdirSync(dirname(OUT), { recursive: true });

/* ------------------------------------------------------------------ */
/* 1) 执行配置脚本，拿到真正的配方表                                     */
/* ------------------------------------------------------------------ */

const src = readFileSync(CONFIG, 'utf8');

/**
 * 配置脚本最后一行是 `global.MIRROR_CONFIG = MIRROR_CONFIG;`。
 * Node 里没有那个 `global` 语义（会在严格模式下报错），
 * 也不该往真 global 上挂东西，所以去掉它、直接 return 变量。
 */
const cleaned = src.replace(/^\s*global\.MIRROR_CONFIG\s*=\s*MIRROR_CONFIG\s*;?\s*$/m, '');

let cfg;
try {
  cfg = new Function(cleaned + '\n; return MIRROR_CONFIG;')();
} catch (err) {
  console.error('执行 mirror_config.js 失败（它必须保持"纯数据 + 无游戏 API"）：');
  console.error('  ' + err.message);
  process.exit(1);
}

const gbr = cfg != null ? cfg.gravityBlockRecipes : null;
const list = Array.isArray(gbr) ? gbr : (gbr != null && Array.isArray(gbr.list) ? gbr.list : []);

if (list.length === 0) {
  console.error('⚠️  配置里没有解析出任何配方 —— 请检查 mirror_config.js 的 gravityBlockRecipes.list');
  process.exit(1);
}

/* ------------------------------------------------------------------ */
/* 2) 转成 JEI 展示用的形状                                             */
/* ------------------------------------------------------------------ */

/** 统一成"字符串数组"：on 允许写一条，也允许写一组。 */
function asList(v) {
  if (v == null) return [];
  if (Array.isArray(v)) return v.map(String);
  return [String(v)];
}

/** 去重（保持顺序）。 */
function uniq(arr) {
  const seen = new Set();
  const out = [];
  for (const x of arr) {
    if (!seen.has(x)) {
      seen.add(x);
      out.push(x);
    }
  }
  return out;
}

const recipes = [];
const warnings = [];

for (const spec of list) {
  if (spec == null || spec.input == null || spec.output == null) continue;

  const input = String(spec.input);
  const output = String(spec.output);
  const trigger = spec.trigger != null ? String(spec.trigger) : 'crossing';
  const landing = trigger === 'landing';
  const flips = Math.max(1, Number(spec.crossings != null ? spec.crossings : 1));
  const onList = asList(spec.on);
  const map = (spec.map != null && typeof spec.map === 'object') ? spec.map : null;
  const drop = spec.drop === true;

  /* 产物候选（JEI 要画成真实物品槽，所以必须是能解析的东西）：
   *   @landed          —— 产物就是落点，候选即落点那一组
   *   @mapped          —— 产物由 map 表决定，候选即表里的全部取值
   *   @same_material   —— 产物由**输入材质**决定（橡木栅栏 → 橡木台阶），
   *                       候选即 material_target（标签或一组 ID）
   *   其它             —— 就是产物本身
   * 以 '@' 开头的占位符不能直接当物品 ID 解析，所以这里必须换掉。 */
  let outputs;
  if (output === '@landed') {
    outputs = onList;
    if (onList.length === 0) {
      warnings.push(`${input}: 产物是 @landed 但没有 on，JEI 里产物槽会是空的`);
    }
  } else if (output === '@mapped') {
    if (map == null) {
      warnings.push(`${input}: 产物是 @mapped 但没有 map，JEI 里产物槽会是空的`);
      outputs = [];
    } else {
      /* ★ 一一对应的配方**每种落点单独出一条**（用户 2026-09-27 报的
       *   "在 JEI 里看，树苗没有写入产物一栏"）。
       *
       *   早先只出一条"落点一组 + 产物一组"的通用条目：JEI 里画出来就是
       *   "任意树叶 → 任意树苗"，两个槽都在轮播 —— 玩家看不到
       *   "橡树叶 → 橡树苗"这层对应关系，也很难确认产物到底是什么。
       *   现在按 map 表逐个落点展开：**输入 / 落点 / 产物都是具体方块**，
       *   一眼能对上；另外再补一条"落点写标签"的兜底条目，
       *   让模组树叶（Quark 之类，我们的表里没有）也能在 JEI 里搜到。 */
      for (const ground of Object.keys(map)) {
        const one = {
          input,
          output: String(map[ground]),          // 这一条里产物是确定的
          flips,
          outputs: [String(map[ground])],
        };
        if (landing) { one.landing = true; one.on = [String(ground)]; }
        if (drop) one.drop = true;
        recipes.push(one);
      }
      const fb = (spec.fallback_pool != null) ? asList(spec.fallback_pool) : [];
      if (fb.length === 0) {
        warnings.push(`${input}: @mapped 配方没有 fallback_pool —— 表外的落点`
          + '（模组树叶）在游戏里不会加工，JEI 里也没有兜底条目');
      }
      const generic = { input, output, flips, outputs: fb };
      if (landing) { generic.landing = true; generic.on = onList; }
      if (drop) generic.drop = true;
      recipes.push(generic);
      if (landing && onList.length === 0) {
        warnings.push(`${input}: landing 配方没有 on，永远不会触发`);
      }
      continue;                   // 这一条已经按落点拆完了，走通用流程会重复
    }
  } else if (output === '@same_material') {
    /* ⚠️ 这里**不**在 Node 里把标签展开成具体方块：JEI 侧
     *    （GravityRecipeItems.resolveAll）本来就会把 '#标签' 展开成全部成员，
     *    两处各展开一次迟早会漂移 —— 而漂移的表现是"JEI 里有、游戏里没有"，
     *    比没有 JEI 更糟。直接把标签交给它，顺带还有两个好处：
     *      · 模组木材（Quark / 暮色森林）跟着原版标签自动出现在 JEI 里；
     *      · 上游改了标签成员，JEI 跟着变，不需要重跑本脚本。 */
    const mt = (spec.material_target != null) ? spec.material_target : null;
    if (mt == null) {
      warnings.push(`${input}: 产物是 @same_material 但没有 material_target，JEI 里产物槽会是空的`);
      outputs = [];
    } else {
      outputs = asList(mt);
    }
  } else if (output === '@random') {
    /* @random：候选就是 pool。pool 元素可能是**物品堆对象**
     * （山羊角 8 种 = 同一物品 + 不同 instrument 组件），JEI 只能画物品，
     * 所以取它的 id 字段；重复的 id 会去重（JEI 里 8 个槽都画山羊角即可）。 */
    const pool = Array.isArray(spec.pool) ? spec.pool : null;
    if (pool == null || pool.length === 0) {
      warnings.push(`${input}: 产物是 @random 但没有 pool，JEI 里产物槽会是空的`);
      outputs = [];
    } else {
      outputs = uniq(pool
        .map((one) => (one != null && typeof one === 'object' ? String(one.id ?? '') : String(one)))
        .filter((x) => x !== ''));
    }
  } else {
    outputs = [output];
  }

  const r = { input, output, flips };
  if (outputs.length > 0) r.outputs = outputs;
  if (landing) {
    r.landing = true;
    if (onList.length > 0) r.on = onList;
  }
  if (drop) r.drop = true;
  if (spec.insert != null && Array.isArray(spec.insert.items)) {
    r.insert = {
      items: spec.insert.items.map(String),
      count: spec.insert.count != null ? Math.max(1, Number(spec.insert.count)) : 1,
      force: spec.insert.force === true,
    };
  }
  recipes.push(r);

  if (landing && onList.length === 0) {
    warnings.push(`${input}: landing 配方没有 on，永远不会触发`);
  }
}

/* ------------------------------------------------------------------ */
/* 3) 写文件                                                            */
/* ------------------------------------------------------------------ */

const payload = {
  _comment: [
    '本文件由 tools/sync-jei-recipes.mjs 从 kubejs/startup_scripts/mirror_config.js 生成。',
    '仅供 JEI 展示；实际加工逻辑以 mirror_config.js 为准。',
    '手工修改会在下次同步时被覆盖。',
    'input / on / outputs 里的元素可以是方块 ID，也可以是 #标签（JEI 侧会展开成全部成员）。',
    '产物写法 @landed / @mapped / @same_material 已经被换成真实候选，JEI 画得到。',
  ],
  recipes,
};

writeFileSync(OUT, JSON.stringify(payload, null, 2) + '\n', 'utf8');

/* ------------------------------------------------------------------ */
/* 2b) 顺带导出"波粒观测"的 JEI 数据                                    */
/* ------------------------------------------------------------------ */
/*
 * 波粒观测（四个波粒块围住靶心 + 望远镜右键）**复用全部引力配方**，
 * 所以它的 JEI 内容 = 这批引力配方（换个说法：穿越类只要放对靶心、
 * 接触类还要放对靶心正下方）+ 配置里的专用配方 + 染色方块随机换色。
 *
 * ⚠️ 为什么必须是"顺带"导在同一份数据源上：
 *    分开维护两份列表迟早漂移，而漂移的表现是"JEI 里有这条、游戏里没用"，
 *    这种不一致比没有 JEI 更糟。
 *
 * 实体产物（蛋糕→悦灵）在 JEI 里用**刷怪蛋**展示 —— JEI 的槽位只能放物品，
 * 生物没法画；刷怪蛋是原版对"会生成什么生物"最直接的表达。
 */
const OBS_OUT = join(dirname(OUT), 'observation_recipes.json');
const observation = [];

/* ------------------------------------------------------------------ */
/* JEI 版面宽度预算：note 只画一行，超了就会画到边框外面                  */
/* ------------------------------------------------------------------ */
/* 观测版面宽 160（文字从 x=4 起画），重力版面 170。
 * 宽度按 Minecraft 默认字体估：全角（汉字/全角标点）9px、半角 6px。
 * 预算留出余量：观测 144px、重力 156px。
 *
 * ⚠️ 用户 2026-09-27 报："波粒观测的脚手架变树苗的配方下的文本太长了，超出 jei 界面了"。
 *    原因是 note 是**按条件往上堆**的，堆到 4 段就有 387px。
 *    现在改成"按优先级往里放，放不下就跳过"—— 以后再加条件也不会溢出。 */
const NOTE_BUDGET = 144;
const textWidth = (s) => {
  let n = 0;
  for (const ch of String(s)) n += /[\u2e80-\uffef]/.test(ch) ? 9 : 6;
  return n;
};
/** 按优先级挑 note：放得下才收，最后用「；」连起来。 */
function pickNotes(cands) {
  const out = [];
  let w = 0;
  for (const c of cands) {
    if (c == null || c === '') continue;
    const add = textWidth(c) + (out.length > 0 ? 9 : 0);   // '；' 是全角
    if (w + add > NOTE_BUDGET) continue;                    // 放不下 → 跳过这一条
    out.push(c);
    w += add;
  }
  return out.join('；');
}

/* (1) 引力配方 → 观测配方 */
for (const r of recipes) {
  const outs = (r.outputs != null && r.outputs.length > 0)
    ? r.outputs
    : (String(r.output).startsWith('@') ? [] : [String(r.output)]);
  if (outs.length === 0) continue;      // 动态产物算不出候选的，观测里同样没得展示
  const isTag = (x) => String(x).startsWith('#');
  /* 兜底条目 = '@mapped' 且产物写成标签（"表外落点也能加工"那一条）。
   * ⚠️ 不能只看"产物里有标签"：@landed 的产物就是 on 列表，铁砧那条也带标签，
   *    以前会被误判成兜底条目、贴上一句"表外方块按同种取"（与它毫无关系）。 */
  const isFallbackEntry = String(r.output) === '@mapped' && (r.outputs || []).some(isTag);
  /* note 按**优先级**排：最要紧的放前面，放不下就自然丢掉后面的。
   * 只留两三条短句 —— 版面就那么宽，写满反而没人看。 */
  const cands = [];
  if (r.drop) cands.push('掉落物弹出');
  if (String(r.output) === '@landed') cands.push('产物＝下方方块');
  else if (isFallbackEntry) cands.push('表外树叶按同种');
  else if (String(r.output) === '@mapped') cands.push('产物随下方');
  else if (String(r.output) === '@same_material') cands.push('产物＝同材质');
  if (Array.isArray(r.on) && r.on.some(isTag)) cands.push('下方是整类');
  /* 标签：一一对应的那几条把"下方"写进标签里更好读
   *   minecraft:scaffolding + minecraft:oak_leaves → minecraft:oak_sapling
   * 比 "minecraft:scaffolding→minecraft:oak_sapling" 少一点歧义。 */
  let label = `${r.input}→${r.output}`;
  if (Array.isArray(r.on) && r.on.length === 1) {
    label = `${r.input} + ${r.on[0]} → ${(r.outputs || [r.output]).join('/')}`;
  }
  const entry = {
    inputs: [String(r.input)],
    outputs: outs.map(String),
    label,
  };
  if (r.landing === true && Array.isArray(r.on) && r.on.length > 0) {
    entry.below = r.on.map(String);
    entry.belowRequired = true;
  }
  const note = pickNotes(cands);
  if (note !== '') entry.note = note;
  observation.push(entry);
}

/* (2) 专用配方（配置 observation.recipes）*/
const obsCfg = (cfg != null && cfg.observation != null) ? cfg.observation : null;
const specials = (obsCfg != null && Array.isArray(obsCfg.recipes)) ? obsCfg.recipes : [];
for (const s of specials) {
  if (s == null || s.input == null) continue;
  const entry = {
    inputs: [String(s.input)],
    outputs: [],
    label: String(s.id != null ? s.id : s.input),
  };
  if (s.entity != null) {
    /* 生物 → 刷怪蛋。命名约定是原版的，check-observation.mjs 会核对它真的存在。 */
    entry.outputs = ['minecraft:' + String(s.entity).replace(/^minecraft:/, '') + '_spawn_egg'];
    entry.note = pickNotes(['生成实体', '靶心消失']);
  } else if (s.output != null) {
    entry.outputs = [String(s.output)];
    if (s.drop === true) entry.note = pickNotes(['掉落物弹出']);
  }
  if (s.on != null) {
    entry.below = [String(s.on)];
    entry.belowRequired = true;
    entry.note = pickNotes([entry.note, '需下方方块']);
  }
  if (entry.outputs.length > 0) observation.push(entry);
}

/* (3) 染色方块随机换色：一个族一条，输入与产物都是那一族的全部颜色。
 *     为什么按族拆而不是合成一条：换色**只在族内**发生（不会把羊毛变成混凝土），
 *     一条"输入 208 种、产物 208 种"的配方会让人误以为可以跨族。
 *
 *     ⚠️ 配色族有两个来源，**两个都要导**：
 *       color_family_members   生成区（16 色 × 后缀，13 个自动族）
 *       manual_family_members  手工族（蛙明灯三色 —— 名字里没有颜色词，生成器扫不出来）
 *     只导前者的话，用户 2026-09-27 报的"蛙明灯互转没在 JEI 里显示"就会重现：
 *     游戏里右键能换色，JEI 里却查不到这条规则。 */
const famSources = [obsCfg != null ? obsCfg.color_family_members : null,
  obsCfg != null ? obsCfg.manual_family_members : null];
const famMerged = {};
for (const src of famSources) {
  if (src == null || typeof src !== 'object') continue;
  for (const name of Object.keys(src)) famMerged[name] = src[name];
}
const famNames = Object.keys(famMerged);
if (famNames.length === 0) {
  warnings.push('配置里没有任何配色族（color_family_members / manual_family_members 都是空的）');
}
let recolorCount = 0;
for (const name of famNames) {
  const ids = (famMerged[name] || []).map(String).filter((x) => x !== '');
  if (ids.length < 2) {
    warnings.push(`配色族 ${name} 只有 ${ids.length} 个成员，换色无从发生，JEI 里跳过`);
    continue;
  }
  recolorCount++;
  observation.push({
    inputs: ids,
    outputs: ids,
    label: 'recolor:' + name,
    note: pickNotes(['同族随机换色']),
  });
}
console.log(`  配色族 ${recolorCount} 个（含手工族）：`
  + famNames.map((n) => `${n}(${(famMerged[n] || []).length})`).join(' '));

const obsPayload = {
  _comment: [
    '本文件由 tools/sync-jei-recipes.mjs 从 kubejs/startup_scripts/mirror_config.js 生成。',
    '仅供 JEI 展示"波粒观测"能加工出什么；实际判定在 MirrorObservation + mirror_n10_observation.js。',
    '手工修改会在下次同步时被覆盖。',
    '条目来自三处：引力配方（全部复用）、配置里的专用配方、染色方块随机换色。',
  ],
  recipes: observation,
};
writeFileSync(OBS_OUT, JSON.stringify(obsPayload, null, 2) + '\n', 'utf8');
console.log(`已导出 ${observation.length} 条观测配方 → ${OBS_OUT}`);
console.log(`  其中需要"下方方块"的 ${observation.filter((r) => r.belowRequired === true).length} 条，`
  + `随机换色 ${observation.filter((r) => String(r.label).startsWith('recolor:')).length} 条，`
  + `专用配方 ${specials.length} 条`);

const tagRefs = new Set();
for (const r of recipes) {
  for (const v of [...(r.on ?? []), ...(r.outputs ?? [])]) {
    if (String(v).startsWith('#')) tagRefs.add(v);
  }
}

console.log(`已导出 ${recipes.length} 条配方 → ${OUT}`);
console.log(`  其中 landing ${recipes.filter((r) => r.landing).length} 条，`
  + `掉落物形式 ${recipes.filter((r) => r.drop).length} 条，`
  + `往容器塞物品 ${recipes.filter((r) => r.insert).length} 条`);
console.log(`  用到的标签 ${tagRefs.size} 个：${[...tagRefs].join('  ')}`);

for (const w of warnings) {
  console.warn('⚠️  ' + w);
}

/* 抽样打印，方便一眼核对关键条目 */
const sampleKeys = ['minecraft:anvil', 'minecraft:scaffolding', 'minecraft:pointed_dripstone',
  'minecraft:suspicious_sand', 'minecraft:suspicious_gravel'];
console.log('\n关键条目:');
for (const r of recipes) {
  if (!sampleKeys.includes(r.input)) continue;
  const bits = [`${r.input} → ${r.output}`, `×${r.flips}`, r.landing ? 'landing' : 'crossing'];
  if (r.on) bits.push('on ' + r.on.join(' + '));
  if (r.outputs && r.output.startsWith('@')) bits.push(`产物候选 ${r.outputs.length} 项`);
  if (r.drop) bits.push('掉落物');
  if (r.insert) bits.push(`塞入 ${r.insert.items.length} 选 1${r.insert.force ? '（满也触发）' : ''}`);
  console.log('  · ' + bits.join('  '));
}

console.log('\n提示：需要重新构建模组（gradlew build）后，JEI 才会看到新配方。');
