package work.dsh.mirror.gravity.jei;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import work.dsh.mirror.gravity.MirrorGravity;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * 读取"重力方块加工"配方（仅用于 JEI 展示）。
 *
 * <h2>数据来源：模组 jar 内的资源文件</h2>
 * {@code /gravity_recipes.json}（见 src/main/resources）。
 *
 * <p>为什么用 jar 内资源而不是外部配置文件：
 * <ul>
 *   <li>JEI 的配方注册发生在**客户端启动期**，那时世界还没加载 ——
 *       任何需要"服务器先跑一遍"才知道的数据都来不及</li>
 *   <li>jar 内资源在编译期就位，读取必然成功，没有时序问题</li>
 *   <li>KubeJS 脚本**无法**写文件（classfilter 拦掉了 java.nio.file，
 *       且没有现成的 Path 入口），所以"脚本导出 JSON"这条路走不通</li>
 * </ul>
 *
 * <h2>与实际生效的加工逻辑如何保持一致</h2>
 * 真正决定加工行为的是 {@code kubejs/.../mirror_config.js} 里的
 * {@code gravityBlockRecipes}。本文件是一份**派生物**，
 * 用项目里的工具把那份配置<b>真的执行一遍</b>后导出：
 *
 * <pre>
 *   node tools/sync-jei-recipes.mjs
 * </pre>
 *
 * <p>⚠️ 早先这个脚本是用正则去"读"配置文本的，结果：
 * <ul>
 *   <li>循环生成的 32 条混凝土配方**一条都没导出**（它只认字面量）</li>
 *   <li>落点标签、容器插入池、动态产物同样丢失</li>
 * </ul>
 * 现在改成 {@code new Function(src)} 直接跑配置脚本（它本来就是纯数据 + 一个
 * 循环，没有游戏 API 依赖），导出内容与运行时**逐字段一致**。
 *
 * <p>改完配方记得跑一次；忘了不会出危险 —— 游戏逻辑始终以
 * mirror_config.js 为准，只是 JEI 会显示得少一些。
 */
public final class GravityRecipeData {

    private GravityRecipeData() {
    }

    /** jar 内资源路径（不带前导斜杠的写法见下方读取处）。 */
    private static final String RESOURCE = "/gravity_recipes.json";

    private static List<GravityRecipe> cached;

    public static List<GravityRecipe> load() {
        if (cached != null) {
            return cached;
        }
        cached = read();
        return cached;
    }

    private static List<GravityRecipe> read() {
        List<GravityRecipe> out = new ArrayList<>();
        try (InputStream in = GravityRecipeData.class.getResourceAsStream(RESOURCE)) {
            if (in == null) {
                MirrorGravity.LOGGER.warn(
                    "[镜维度·JEI] jar 内缺少 {}，JEI 里不会出现重力方块加工分类", RESOURCE);
                return out;
            }
            String raw = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            JsonElement root = JsonParser.parseString(raw);
            if (!root.isJsonObject()) {
                MirrorGravity.LOGGER.warn("[镜维度·JEI] {} 根节点不是对象，已忽略", RESOURCE);
                return out;
            }
            JsonArray arr = root.getAsJsonObject().getAsJsonArray("recipes");
            if (arr == null) {
                MirrorGravity.LOGGER.warn("[镜维度·JEI] {} 缺少 recipes 数组，已忽略", RESOURCE);
                return out;
            }
            for (JsonElement el : arr) {
                GravityRecipe r = parseOne(el);
                if (r != null) {
                    out.add(r);
                }
            }
            MirrorGravity.LOGGER.info("[镜维度·JEI] 已载入 {} 条重力方块加工配方用于展示", out.size());
        } catch (Throwable t) {
            MirrorGravity.LOGGER.warn("[镜维度·JEI] 读取 {} 失败: {}", RESOURCE, t.toString());
        }
        return out;
    }

    private static GravityRecipe parseOne(JsonElement el) {
        try {
            if (el == null || !el.isJsonObject()) {
                return null;
            }
            JsonObject o = el.getAsJsonObject();
            String input = str(o, "input");
            String output = str(o, "output");
            if (input == null || output == null) {
                return null;   // 缺必需字段的条目直接跳过
            }
            int flips = o.has("flips") ? o.get("flips").getAsInt() : 1;
            boolean landing = o.has("landing") && o.get("landing").getAsBoolean();
            boolean drop = o.has("drop") && o.get("drop").getAsBoolean();

            /* on / outputs 都允许写成"一条"或"一组"。
             * 写成字符串是历史写法（也是绝大多数配方的写法），
             * 写成数组是为了表达"落在任意一种…上"（铁砧 + AnvilCraft 粗矿块）。 */
            List<String> on = strList(o, "on");
            List<String> outputs = strList(o, "outputs");

            List<String> insertItems = List.of();
            int insertCount = 1;
            boolean insertForce = false;
            if (o.has("insert") && o.get("insert").isJsonObject()) {
                JsonObject ins = o.getAsJsonObject("insert");
                insertItems = strList(ins, "items");
                insertCount = ins.has("count") ? Math.max(1, ins.get("count").getAsInt()) : 1;
                insertForce = ins.has("force") && ins.get("force").getAsBoolean();
            }

            return new GravityRecipe(input, output, outputs, Math.max(1, flips),
                landing, on, drop, insertItems, insertCount, insertForce);
        } catch (Throwable t) {
            return null;
        }
    }

    private static String str(JsonObject o, String key) {
        if (!o.has(key) || o.get(key).isJsonNull()) {
            return null;
        }
        try {
            return o.get(key).getAsString();
        } catch (Throwable t) {
            return null;
        }
    }

    /** 取一个"字符串或字符串数组"字段，统一成列表。 */
    private static List<String> strList(JsonObject o, String key) {
        List<String> out = new ArrayList<>();
        if (o == null || !o.has(key) || o.get(key).isJsonNull()) {
            return out;
        }
        JsonElement el = o.get(key);
        try {
            if (el.isJsonArray()) {
                for (JsonElement item : el.getAsJsonArray()) {
                    if (!item.isJsonNull()) {
                        out.add(item.getAsString());
                    }
                }
            } else {
                out.add(el.getAsString());
            }
        } catch (Throwable t) {
            // 类型不对就当没写，展示层会自己留空
        }
        return out;
    }
}
