package work.dsh.mirror.gravity.internal;

import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.Vec3;
import work.dsh.mirror.gravity.MirrorGravity;
import work.dsh.mirror.gravity.MirrorGravityConfig;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 修补 Pondus 换向时**把速度整体清零**的缺陷。
 *
 * <h2>缺陷本身</h2>
 * Pondus 的 {@code applyGravityDirectionChange} 要保住"世界速度不变、只换参考系"，
 * 它靠 {@code getRealWorldVelocity()} 取换向前的速度。而该函数在**服务端**
 * 对非玩家实体走的是这条分支：
 * <pre>
 *   new Vec3(getX() - xo, getY() - yo, getZ() - zo)     // 位置差，不是 deltaMovement
 * </pre>
 * 换向发生在**实体 tick 内部**（Pondus 把 commonTick 注入在 Entity.tick() 上），
 * 此刻 {@code xo/yo/zo} 还没被本次移动更新，于是它算出 {@code (0,0,0)}。
 * 再经 {@code vecWorldToPlayer} 写回，速度就被清零了。
 *
 * <p>实测：
 * <pre>
 *   换向前 vel=(-0.1934, -0.1019, -0.2321)   水平 0.3022
 *   换向后 vel=( 0.0,     0.0,     0.0   )
 * </pre>
 * 垂直分量随后会被重力重新建立，但**水平分量再也回不来** ——
 * 表现为掉落物失去抛物线、原地升起、停在玩家脚下。
 *
 * <h2>为什么补回是安全的</h2>
 * 换向在 tick 内部发生，而移动已经用**换向前的**速度跑完了，
 * 所以补回的正是本该保留的那部分动量，不会造成重复位移。
 *
 * <h2>为什么只补水平分量</h2>
 * 垂直方向由 Pondus 的重力掌管，覆盖它会破坏重力反转本身。
 */
public final class VelocityFix {

    private VelocityFix() {
    }

    /** entityUUID → 换向前的速度（仅服务端填写） */
    private static final Map<UUID, Vec3> SAVED = new ConcurrentHashMap<>();

    /** 换向前登记速度。由 {@link DirectionWriter} 在调用 setter 之前调用。 */
    static void save(Entity entity) {
        if (entity == null) {
            return;
        }
        SAVED.put(entity.getUUID(), entity.getDeltaMovement());
    }

    /**
     * 实体 tick **之后**调用：若换向把水平速度清掉了，就补回。
     *
     * <p>必须在 tick 之后 —— 换向本身在 tick 内部发生，tick 之前补会被覆盖。
     */
    public static void restoreIfLost(Entity entity) {
        if (entity == null || entity.level().isClientSide()) {
            return;
        }
        Vec3 saved = SAVED.remove(entity.getUUID());
        if (saved == null) {
            return;
        }

        double savedH = Math.hypot(saved.x, saved.z);
        if (savedH < 1.0E-4D) {
            return;   // 换向前本来就没有水平速度，不必补
        }
        Vec3 now = entity.getDeltaMovement();
        double nowH = Math.hypot(now.x, now.z);
        if (nowH > savedH * 0.5D) {
            return;   // 没被清掉（或只轻微衰减），不要干预
        }

        /* 补回时必须**按新参考系**写回，而不是照抄换向前的值。
         *
         * Pondus 在 up/down 之间换向时用的变换是
         *     (x, y, z) → (-x, -y, z)      即 X 取反、Y 取反、Z 不变
         *
         * 症状完全对应（用户实测）：
         *   朝北/朝南丢 → 正常   （只涉及 Z，变换下不变）
         *   朝东丢 → 飞到西边
         *   朝西丢 → 飞到东边   （X 被取反）
         *
         * 所以 X 取反、Z 保持原值；Y 用 Pondus 算出来的。 */
        Vec3 fixed = new Vec3(-saved.x, now.y, saved.z);
        entity.setDeltaMovement(fixed);

        syncMotion(entity, fixed);
    }

    /**
     * 修正掉落物的重力量（不依赖 Pondus 的强度字段）。
     *
     * <h2>为什么需要它</h2>
     * KubeJS 侧的 {@code falling_gravity_scale = 0.2} 一路传到了 Pondus 的
     * {@code baseGravityStrength} 并写入成功，但**完全不生效**。实测三份
     * 互相印证的证据：
     * <ul>
     *   <li>读回 base/curr 强度都是 0.2</li>
     *   <li>读回 {@code entity.getGravity()} 却是 0.04（没被乘 0.2）</li>
     *   <li>用位置二阶差分算出的实际加速度 ≈ 0.038，就是满重力</li>
     * </ul>
     * 结论：那个字段对本实体是死字段。
     *
     * <h2>做法</h2>
     * 每次实体 tick 之后，把"多出来的那部分重力"从速度里扣掉：
     * <pre>
     *   扣除量 = getGravity() × (1 − scale)
     * </pre>
     * 净加速度于是从 0.04 变成 0.008。这与 {@link work.dsh.mirror.gravity.BlockPhysics}
     * 对下落的方块所做的抵消是同一套思路。
     *
     * <h2>三个实现细节</h2>
     * <ol>
     *   <li><b>本方法在所有实体 tick 之后调用</b>（含客户端）。
     *       两端都要做，否则客户端预测与服务端会发散。</li>
     *   <li><b>只对掉落物生效</b>：其它实体的数值没有实测依据，
     *       贸然套用会把它们的重力改错。</li>
     *   <li><b>方向用 deltaMovement 的分量符号推</b>，不查 Pondus 方向 ——
     *       少一次反射，而且对"方向尚未同步"的帧也安全。</li>
     * </ol>
     *
     * <p>已知副作用：若实体恰好被阻挡、速度被清零，向零调整是空操作，
     * 不会造成反向加速（见下面的零值判断）。
     */
    public static void applyItemGravityScale(Entity entity) {
        if (entity == null) {
            return;
        }
        double scale = MirrorGravityConfig.ITEM_GRAVITY_SCALE;
        if (scale >= 1.0D || scale < 0.0D) {
            return;   // 1.0 表示不做缩放
        }
        if (!(entity instanceof ItemEntity)) {
            return;   // 只处理掉落物
        }
        try {
            Vec3 v = entity.getDeltaMovement();
            double gravity = entity.getGravity();
            if (gravity <= 0.0D) {
                return;
            }
            /* 要扣掉的总量：原版给了 gravity，我们只想要 gravity × scale。 */
            double remove = gravity * (1.0D - scale);
            /* 方向：视频沿哪个轴有分量，就往"减少其绝对值"的方向调整。
             * 若该分量为 0（实体静止/被完全阻挡），不做调整。 */
            double out;
            if (v.y > 1.0E-6D) {
                out = v.y - remove;
            } else if (v.y < -1.0E-6D) {
                out = v.y + remove;
            } else {
                return;
            }
            /* ⚠️ 速度极小时**不要**调整。
             *
             * 这个修正的方向是靠 {@code v.y} 的**符号**推出来的，而在换向那一帧
             * 垂直速度恰好穿过 0：符号由"上一帧的残余"决定，两端可能并不一致
             * （客户端预测与服务端 tick 的先后不同）。一旦符号不同，两端就会
             * 朝相反方向各扣掉约 0.032 的速度 —— 那是持续发散，只能靠位置包
             * 拉回，表现正是"偶尔一小段瞬移"。
             *
             * 而速度接近 0 时这次修正本来就几乎不起作用（扣掉的总量远大于
             * 速度本身，会被下面的夹零逻辑吞掉），所以直接跳过最安全。 */
            if (Math.abs(v.y) < MirrorGravityConfig.GRAVITY_SCALE_MIN_SPEED) {
                return;
            }
            /* 不要越过零 —— 那会把"下落"变成"上浮"，引入反向加速。 */
            if (v.y > 0.0D) {
                out = Math.max(0.0D, out);
            } else {
                out = Math.min(0.0D, out);
            }
            entity.setDeltaMovement(v.x, out, v.z);

            /* 要求服务端每 tick 同步这个物品的位置。
             *
             * 放在这里而不是无条件执行：静止的物品其实走不到这一行 ——
             * 上面 v.y 接近 0 时已经 return，所以场景里躺在地上的掉落物
             * 不会被高频同步，只有真正在动的才会。 */
            requestPerTickSync(entity);
        } catch (Throwable t) {
            MirrorGravity.LOGGER.debug("[镜维度·重力] 重力量修正失败: {}", t.toString());
        }
    }

    /**
     * 让服务端按配置的间隔把这个实体同步给客户端。
     *
     * <h2>为什么必须做（这是"物体像被挪了一下"的根因）</h2>
     * {@code ServerEntity.sendChanges} 的门控是：
     * <pre>
     *   if (tickCount % updateInterval == 0 || entity.hasImpulse || data.isDirty())
     *       → 发送位置/速度包
     *   ...
     *   this.entity.hasImpulse = false;        // 每 tick 末尾清掉
     * </pre>
     * 而 {@code updateInterval} 由 {@code ChunkMap} 按实体类型给出，**物品走默认
     * 20 tick**。掉落物既不设 {@code hasImpulse}、数据也不 dirty，于是位置包
     * **每秒才发一次**。
     *
     * <p>这中间客户端只能靠本地预测，而它的预测与服务端存在持续偏差
     * （实测每个换向周期里约 18 tick、偏差从 0.04 累积到 0.13 格）。
     * 下一个位置包到达时，客户端位置被**一次性硬赋值**拉回
     * （1.21.1 的 {@code Entity.lerpTo} 就是直接 {@code setPos}，
     * {@code ItemEntity} 也没覆写它）—— 画面上就是"整段物体跳过去"。
     * 实测最坏一次是 1.30 格。
     *
     * <h2>做法</h2>
     * 把 {@code Entity.hasImpulse} 置 true，门控的第一个条件即被绕过，
     * 服务端就会在每个 tick 发位置包，客户端不再有机会累积漂移。
     * 这是原版自己的机制（玩家、被推力作用的实体都靠它提高同步频率），
     * 不是绕过协议的取巧。
     *
     * <h2>间隔可配置（{@link #setSyncInterval}）</h2>
     * 那个标志既然每 tick 会被清掉，发包节奏就完全等于"我们多久置一次"，
     * 于是把它做成可调：1 = 每 tick（默认，等于完全消除漂移），
     * N = 每 N tick 发一次（省 (N-1)/N 的包，代价是残留 N tick 的漂移），
     * 0 = 完全不置（退回原版节奏，闪现会回来）。
     *
     * <h2>代价有界</h2>
     * 只有**正在运动**的掉落物会走到这里（静止的在
     * {@link #applyItemGravityScale} 的速度门槛处就返回了），
     * 所以额外包量与"场上正在动的掉落物个数"成正比，而不是实体总数。
     */
    public static void requestPerTickSync(Entity entity) {
        if (entity == null || entity.level().isClientSide()) {
            return;   // 只有服务端才有 ServerEntity 在跟踪
        }

        int interval = syncInterval;
        if (interval <= 0) {
            return;   // 配置里关掉了：回到原版门控（物品默认 20 tick 一次）
        }
        /* 降频：只在"该同步的那一拍"置标志。
         * hasImpulse 每 tick 被 sendChanges 清掉，所以这里的判断
         * 就是最终的发包节奏。 */
        if (interval > 1 && Math.floorMod(entity.tickCount, interval) != 0) {
            return;
        }

        try {
            entity.hasImpulse = true;
        } catch (Throwable t) {
            MirrorGravity.LOGGER.debug("[镜维度·重力] 提高同步频率失败: {}", t.toString());
        }
    }

    /* ------------------------------------------------------------------ */
    /* 每 tick 同步的间隔                                                  */
    /* ------------------------------------------------------------------ */
    /* 由 KubeJS 侧推送（mirror_config.js → gravity.item_sync_interval），
     * 与分界线、迟滞带一样：**唯一真相在脚本配置里，模组只接收**。 */

    /** 默认 10 = 每 10 tick 补发一次位置包（2 包/秒，原版是 20 tick / 1 包）。
     *  与 mirror_config.js 的 gravity.item_sync_interval 保持一致；
     *  脚本推送失败时就用这个值 —— 它是"看得出效果"与"开销可接受"的折中，
     *  不是原来的 1（每 tick 都发，包量是原版 20 倍）。 */
    public static final int SYNC_INTERVAL_DEFAULT = 10;

    /** 上限。再大基本等于退回原版（物品原版 updateInterval 就是 20）。 */
    public static final int SYNC_INTERVAL_MAX = 40;

    private static volatile int syncInterval = SYNC_INTERVAL_DEFAULT;

    /**
     * 设置"运动中的掉落物"请求位置同步的间隔（tick）。
     *
     * @param ticks 1 = 每 tick（默认）；N = 每 N tick；0 = 关闭（退回原版节奏）
     */
    public static void setSyncInterval(int ticks) {
        int v = Math.max(0, Math.min(SYNC_INTERVAL_MAX, ticks));
        syncInterval = v;
        MirrorGravity.LOGGER.info(
            "[镜维度·重力] 掉落物位置同步间隔已设为 {} tick{}",
            v, v == 0 ? "（已关闭：退回原版 20 tick 的节奏，可能出现闪现）" : "");
    }

    /** 当前生效的同步间隔（诊断用）。 */
    public static int syncInterval() {
        return syncInterval;
    }

    /**
     * 把修正后的速度**主动广播**给追踪该实体的玩家。
     *
     * <h2>为什么必须补发</h2>
     * 服务端的实体追踪器（{@code ServerEntity.sendChanges}）会在本 tick 稍后
     * 发出速度包，但那时 {@code deltaMovement} 已被 Pondus 旋转过 ——
     * 客户端拿到的是**旋转前**的值，于是它自己再旋转一次，结果与服务端符号相反。
     *
     * <p>实测（同一 tick）：
     * <pre>
     *   服务端 vel=(-0.2896, -0.0078, 0.0208)
     *   客户端 vel=(+0.2837, +0.0545, 0.0203)   ← x/y 反号，即镜像
     * </pre>
     * 客户端于是朝相反方向飞，视觉上就是"传送到别处"。
     */
    private static void syncMotion(Entity entity, Vec3 vel) {
        try {
            if (!(entity.level() instanceof ServerLevel level)) {
                return;
            }
            ClientboundSetEntityMotionPacket packet =
                new ClientboundSetEntityMotionPacket(entity);
            for (ServerPlayer p : level.players()) {
                // 64 格：覆盖常规实体追踪范围，够用且不会给远处的玩家白发包
                if (p.distanceToSqr(entity) < 4096.0D) {
                    p.connection.send(packet);
                }
            }
        } catch (Throwable t) {
            MirrorGravity.LOGGER.debug("[镜维度·重力] 速度同步失败: {}", t.toString());
        }
    }

    /** 实体消失后清掉记录，避免 Map 随实体总数无限增长。 */
    public static void forget(UUID id) {
        if (id != null) {
            SAVED.remove(id);
        }
    }

    /**
     * 丢弃已消失实体的存档。
     *
     * <p>正常路径下存档在 {@link #restoreIfLost} 里就被取走了（remove），
     * 但若实体在换向与 tick 之间消失，存档会留下 —— 所以还需要一次兜底清理。
     */
    public static void retainOnly(java.util.Set<UUID> alive) {
        SAVED.keySet().removeIf(id -> !alive.contains(id));
    }
}
