// =====================================================================
// 镜维度 · 服务端逻辑（指令 + 进入提示）
// ---------------------------------------------------------------------
// 放在 server_scripts/ 下：每次进世界或 /reload 都会重新加载。
//
// ⚠️ 两个已经踩过的坑，别改回去：
//
// 1) **不要用 ServerEvents.command('mirror', ...) 做指令分发。**
//    它是 TargetedEventHandler<String>，匹配的是 event.commandName ——
//    而 commandName 来自 Brigadier 解析出的第一个节点。若 mirror 从未
//    注册进指令表，`/mirror tp` 连解析都过不去，commandName 就不是
//    'mirror'，处理器**永远不触发**，游戏里表现为「指令不存在」。
//    本项目因此白折腾了一轮。
//    → 正确做法：ServerEvents.commandRegistry，直接往 Brigadier 注册。
//
// 2) **不要在本文件里给 global 赋值。**
//    KubeJS 源码：非 startup 脚本拿到的是 GlobalUnmodifiableMap，
//    赋值会让**整个文件**加载失败，报
//       'global' cannot be assigned to in client or server scripts
//    后果：这里的指令和 PlayerEvents 全部静默失效。
//    需要跨脚本共享 → 在 startup 脚本里挂 global；服务端脚本只读不写。
//
// ⚠️ try 块内一律用 var，不用 const/let（Rhino 会抛 redeclaration，见 mirror_core.js）
// =====================================================================

const MirrorServer = (() => {

  const MD = global.MirrorDimension;

  if (MD === undefined || !MD.isLoaded) {
    console.error('[镜维度] 核心未就绪，服务端脚本未启用。');
    return { ready: false };
  }

  const DIM = MD.ids.dimension;
  const OVERWORLD = 'minecraft:overworld';

  /* ------------------------------------------------------------------ */
  /* 输出助手                                                            */
  /* ------------------------------------------------------------------ */
  /* ⚠️ 千万别写 ctx.getSource().sendSuccess(() => Text.xxx(), false)。
   *
   * Brigadier 的 CommandSourceStack.sendSuccess 有多个重载，其中一个是
   *   sendSuccess(Supplier<Component>, boolean)
   * 而 KubeJS 的 Text 恰好实现了 Supplier，Rhino 在重载消歧时又会退到
   * Object 那个重载，结果把你写的 lambda 直接 toString 发进聊天栏 ——
   * 玩家看到的就是一堆 "ArrowFunction (0) => {...}"。
   * （实测踩过：/mirror gravity 整屏都是这个。）
   *
   * ⚠️ 也别指望 Text.gray('x') + Text.white('y') 拼出来能正常上色。
   * KubeJS 的 Text 会走 MiniMessage 解析，这些工厂方法拼出来的东西
   * 送进聊天栏会变成 {style=color=white}literal{...} 这种**字面量**，
   * 玩家看到的是没渲染的标记，比纯文本还难读。实测踩过。
   *
   * ✅ 所以整条输出链都只用**原版文本组件**：
   *    Text.of(...) 不传样式，或用 Component.literal(...)，
   *    然后 Player.tell(Component) —— 参数唯一，无重载歧义。
   *    要颜色就只给整行一个颜色，不做富文本拼接。            */

  // 原版 Component 句柄（用于生成纯文本组件）
  const ComponentClass = (() => {
    try {
      return Java.loadClass('net.minecraft.network.chat.Component');
    } catch (e) {
      return null;
    }
  })();

  /** 生成一个纯文本组件（无样式）。 */
  function txt(s) {
    try {
      return ComponentClass.literal(String(s));
    } catch (e) {
      return Text.of(String(s));
    }
  }

  /** 带颜色的整行。color 用原版 ChatFormatting。 */
  function colored(colorName, s) {
    try {
      var CF = Java.loadClass('net.minecraft.ChatFormatting');
      var comp = ComponentClass.literal(String(s));
      var c = CF[String(colorName).toUpperCase()];
      if (c != null) comp = comp.copy().withStyle(c);
      return comp;
    } catch (e) {
      return txt(s);
    }
  }

  function tell(src, text) {
    try {
      src.getPlayerOrException().tell(text);
    } catch (e) {
      // 非玩家执行（命令方块/控制台）时退回原版输出
      try { src.sendSystemMessage(text); } catch (e2) { /* 忽略 */ }
    }
  }

  /** 一次说多行 */
  function tellAll(src, lines) {
    for (var i = 0; i < lines.length; i++) tell(src, lines[i]);
  }

  /** 配方分组键：把"每种颜色各一条"的成组配方收成一行。
   *  混凝土粉末有 32 条（16 色 × 2），全打出来会刷满聊天栏。 */
  function recipeFamilyOf(blockId) {
    if (String(blockId).indexOf('_concrete_powder') > 0) return '混凝土粉末（16 色）';
    return String(blockId);
  }

  /** 方向名 -> 中文，让输出是给真人看的而不是给日志看的 */
  function zhDir(name) {
    var n = String(name == null ? '' : name).toLowerCase();
    var pairs = [
      ['down', '下'], ['up', '上'],
      ['north', '北'], ['south', '南'], ['west', '西'], ['east', '东'],
    ];
    for (var i = 0; i < pairs.length; i++) {
      if (n === pairs[i][0]) return pairs[i][1];
    }
    return n === '' ? '未知' : n;
  }

  /** 下发状态码 -> 中文说明 */  function statusZh(status) {
    var s = String(status == null ? '' : status);
    if (s === 'applied') return '已写入';
    if (s === 'applied-mod') return '已写入（自研模组）';
    if (s === 'mod-failed') return '自研模组写入失败';
    if (s === 'no-mod') return '自研模组未加载';
    if (s === 'no-pondus') return 'Pondus 未加载';
    if (s === 'unchanged') return '无需改动';
    if (s === 'rejected') return 'Pondus 拒绝了这个实体';
    if (s === 'error') return '调用出错';
    if (s === 'cooldown') return '被防抖挡下，维持原方向';
    return s === '' ? '未知' : s;
  }

  /* ------------------------------------------------------------------ */
  /* 指令注册（Brigadier）                                                */
  /* ------------------------------------------------------------------ */

  try {
    ServerEvents.commandRegistry(event => {

      var Commands = Java.loadClass('net.minecraft.commands.Commands');
      var LiteralArgumentBuilder = Java.loadClass('com.mojang.brigadier.builder.LiteralArgumentBuilder');

      // ---- /mirror tp ：进入镜维度 ----
      function tpHandler(ctx) {
        var player = ctx.getSource().getPlayerOrException();
        var e = MD.raw.entry;
        // 不需要预先 forceload：/tp 在传送前会自动生成目标区块
        ctx.getSource().getServer().getCommands().performPrefixedCommand(
          ctx.getSource().withSuppressedOutput(),
          'execute in ' + DIM + ' run tp ' + player.getName().getString()
          + ' ' + e.x + ' ' + e.y + ' ' + e.z
        );
        tell(ctx.getSource(), colored('aqua', '镜面翻涌，你穿过了另一侧。'));
        tell(ctx.getSource(), txt('  /mirror back 返回'));
        return 1;
      }

      // ---- /mirror back ：返回主世界 ----
      function backHandler(ctx) {
        var player = ctx.getSource().getPlayerOrException();
        ctx.getSource().getServer().getCommands().performPrefixedCommand(
          ctx.getSource().withSuppressedOutput(),
          'execute in ' + OVERWORLD + ' run tp ' + player.getName().getString() + ' ~ ~ ~'
        );
        tell(ctx.getSource(), colored('aqua', '你退回了主世界。'));
        return 1;
      }

      // ---- /mirror portal ：搭一座 3×3×3 镜面传送门并点燃 ----
      /* 用途：这套结构要 27 格全对（底 3×3 磨制黑石、中间 8 格空气 + 中心玻璃、
       * 顶 3×3 平滑石英），手搭一次很费时间，验证时容易摆错一格然后怀疑代码。
       * 材料与点燃物品都从配置读，改配置这里跟着变。 */
      function portalHandler(ctx) {
        var s = ctx.getSource();
        var player = null;
        try { player = s.getPlayerOrException(); } catch (e) { player = null; }
        if (player == null) {
          tell(s, colored('red', '这个指令要玩家本人执行。'));
          return 0;
        }

        var mp = MD.raw.mirrorPortal != null ? MD.raw.mirrorPortal : {};
        var bottom = String(mp.bottom_block != null ? mp.bottom_block : 'minecraft:polished_blackstone');
        var top = String(mp.top_block != null ? mp.top_block : 'minecraft:smooth_quartz');
        /* 中心那格必须放一块真玻璃。配置里给的是**标签**
         * （center_tag，如 c:glass_blocks），标签不能直接 setblock，
         * 所以这里固定放 minecraft:glass —— 它本身就在 c:glass_blocks 里，
         * 能满足模组侧的标签校验。 */
        var centerBlock = 'minecraft:glass';

        var ox = Math.floor(player.getX());
        var oy = Math.floor(player.getY());
        var oz = Math.floor(player.getZ());
        var dim = String(player.level.dimension);
        var cmds = s.getServer().getCommands();

        for (var dx = -1; dx <= 1; dx++) {
          for (var dz = -1; dz <= 1; dz++) {
            cmds.performPrefixedCommand(s.withSuppressedOutput(),
              'execute in ' + dim + ' run setblock '
              + (ox + dx) + ' ' + (oy - 1) + ' ' + (oz + dz) + ' ' + bottom + ' replace');
            cmds.performPrefixedCommand(s.withSuppressedOutput(),
              'execute in ' + dim + ' run setblock '
              + (ox + dx) + ' ' + oy + ' ' + (oz + dz) + ' minecraft:air replace');
            cmds.performPrefixedCommand(s.withSuppressedOutput(),
              'execute in ' + dim + ' run setblock '
              + (ox + dx) + ' ' + (oy + 1) + ' ' + (oz + dz) + ' ' + top + ' replace');
          }
        }
        cmds.performPrefixedCommand(s.withSuppressedOutput(),
          'execute in ' + dim + ' run setblock ' + ox + ' ' + oy + ' ' + oz
          + ' ' + centerBlock + ' replace');

        var MG = global.MirrorDimension.modules.n0 != null
          ? global.MirrorDimension.modules.n0.selfModApi : null;
        var code = null;
        try {
          if (MG != null) {
            /* 用 BlockPos.containing(...) 这个静态工厂构造坐标 ——
             * 项目里 n3 一直这么用（比 new 一个 Java 类更稳）。 */
            var BPos = Java.loadClass('net.minecraft.core.BlockPos');
            code = String(MG.tryIgniteMirrorPortal(player.level,
              BPos.containing(ox, oy, oz)));
          }
        } catch (e2) {
          code = 'error:' + e2;
        }

        /* 回读模组里的映射设置（诊断惯例：能区分"配置写了"与"推送生效了"）。 */
        var target = null;
        try {
          if (MG != null) target = String(MG.mirrorPortalTarget());
        } catch (e3) {
          target = null;
        }

        tellAll(s, [
          colored('aqua', '已在脚下搭好 3×3×3：' + bottom + ' / 空气+玻璃 / ' + top),
          txt('  点燃结果  ' + (code == null ? '模组未接入' : String(code))),
          txt('  坐标映射  ' + (target == null ? '模组未接入' : target)),
          txt('  走进去即可传送；到达另一侧会自动生成一座同样的门'),
          txt('  也支持手动点燃：用 ' + String(mp.ignition_item) + ' 右键中心那块玻璃'),
        ]);
        return code != null && code === 'ok' ? 1 : 0;
      }

      // ---- /mirror info ----
      function infoHandler(ctx) {
        var player = ctx.getSource().getPlayerOrException();
        var s = ctx.getSource();
        tellAll(s, [
          colored('gold', '── 镜维度 ──'),
          txt('维度 ID        ' + DIM),
          txt('维度类型 ID    ' + MD.ids.dimensionType),
          txt('生物群系 ID    ' + MD.ids.biome),
          txt('当前所在       ' + String(player.level.dimension)),
          txt('传送门         '
            + ((global.MirrorDimension.modules.n8 != null
                && global.MirrorDimension.modules.n8.enabled()) ? '镜面传送门已启用' : '未启用')),
        ]);
        return 1;
      }

      // ---- /mirror gravity [方向] [秒数] ：查看/临时覆盖重力方向 ----
      /* 为什么要有手动覆盖：镜维度里每 tick 的重力都由脚本按坐标决定，
       * 想「临时试一下反方向」原本只能改脚本再重载。
       * 这个指令直接改内存里的 force_direction，方便做 A/B 对照。
       *   /mirror gravity                → 只看当前状态
       *   /mirror gravity up             → 强制向上，不过期
       *   /mirror gravity down 30        → 强制向下 30 秒
       *   /mirror gravity clear          → 清除覆盖，回到按坐标自动判定
       * 覆盖只活在内存：/reload 或重启后回到 mirror_config.js 里的值。 */
      function gravityHandler(ctx) {
        var s = ctx.getSource();
        var setting = MD.runtime ? MD.runtime.setting : null;

        if (setting == null || !setting.ready || !setting.gravity) {
          tell(s, colored('red', '设定逻辑没起来。'));
          tell(s, txt('请看 logs/kubejs/server.log 里的报错。'));
          return 0;
        }
        var g = setting.gravity;

        // ---- 可选参数：/mirror gravity up [秒数] ----
        var arg = null;
        try {
          arg = Java.loadClass('com.mojang.brigadier.arguments.StringArgumentType')
            .getString(ctx, 'dir');
        } catch (e) {
          arg = null;
        }
        if (arg != null) {
          var secs = -1;
          try {
            secs = Java.loadClass('com.mojang.brigadier.arguments.IntegerArgumentType')
              .getInteger(ctx, 'secs');
          } catch (e2) {
            secs = -1;
          }
          var applied = g.setForce(arg, secs);
          if (applied == null && String(arg) !== 'clear') {
            tell(s, colored('red', '没有这个方向：' + arg));
            tell(s, txt('可用的写法：down、up、north、south、west、east、clear'));
            return 0;
          }
          if (applied == null) {
            tell(s, colored('aqua', '已取消强制，恢复成按高度自动判断。'));
          } else {
            tell(s, colored('aqua', '已强制重力朝' + zhDir(applied) + '。'));
            tell(s, txt(secs >= 0
              ? ('  ' + secs + ' 秒后自动失效。')
              : '  一直有效，直到重载或重启。'));
          }
          tell(s, txt('  输入 /mirror gravity 可以查看当前状态。'));
          return 1;
        }

        // ---- 无参数：输出状态 ----
        var player = null;
        try { player = s.getPlayerOrException(); } catch (e3) { player = null; }

        var lines = [];
        lines.push(colored('gold', '═══ 镜维度 · 重力 ═══'));
        lines.push(txt(''));
        lines.push(txt('重力实现    Pondus（生物/玩家）+ 自研模组（下落的方块、掉落物）'));
        lines.push(txt('自研模组    ' + (g.selfModLoaded ? '已接入' : '未加载（非生物不会反转）')));

        var inMirror = false;
        if (player == null) {
          lines.push(txt('你的位置    （不是玩家在执行，跳过）'));
        } else {
          var y = Math.floor(player.y);
          inMirror = String(player.level.dimension) === DIM;
          if (!inMirror) {
            lines.push(txt('你的位置    y=' + y + '，不在镜维度（重力按原版走）'));
          } else {
            var want = g.dirNameAt(player.y);
            lines.push(txt('你的位置    y=' + y
              + '（分界线' + (player.y > setting.splitY ? '上方' : '下方') + '）'));
            lines.push(txt('应该朝向    ' + zhDir(want)
              + (want === 'up' ? '   ← 反转区，脚下应是天花板' : '   ← 正常区')));
          }
        }

        if (player != null && inMirror) {
          var dirs = g.readDirs(player);
          lines.push(txt('Pondus记着  ' + zhDir(dirs.base) + '（基础） / '
            + zhDir(dirs.cur) + '（当前）'));
        }
        var at = g.lastAttempt();
        lines.push(txt('最近一次下发  ' + (at == null
          ? '还没有下发过'
          : (at.type + ' 设为朝' + zhDir(at.dir) + '，结果：' + statusZh(at.status)))));

        var notes = [];
        if (!g.selfModLoaded) {
          notes.push('自研模组没加载，下落的方块与掉落物不会反转。');
          notes.push('请确认 mods 里有 mirror-gravity-1.0.0.jar。');
        }

        lines.push(txt(''));
        if (notes.length > 0) {
          lines.push(colored('yellow', '── 需要注意 ──'));
          for (var i = 0; i < notes.length; i++) lines.push(txt('· ' + notes[i]));
        } else {
          lines.push(colored('green', '一切正常。'));
        }

        var st = g.scanStats();
        var db = g.debounce();
        lines.push(txt(''));
        lines.push(colored('gray', '── 详细 ──'));
        lines.push(txt('重力分界线  y = ' + setting.splitY + '（上面朝下，下面朝上）'));
        lines.push(txt('手动强制    ' + (g.forced() == null ? '没有' : zhDir(g.forced()))));
        lines.push(txt('重力方块强度 ' + db.scale + ' 倍（越小落得越慢）'));
        lines.push(txt('防抖        玩家 ' + db.zone + ' 格迟滞 / 停留 '
          + Math.round(db.gap / 20 * 10) / 10 + ' 秒确认'));
        lines.push(txt('被防抖挡下  ' + g.blockedFlips() + ' 次'));
        lines.push(txt('实体扫描    非玩家每 ' + g.scanInterval + ' tick 一次'
          + '，掉落物每 ' + g.itemScanInterval + ' tick 一次'));
        lines.push(txt('  上次扫过  ' + (st.handled < 0
          ? '还没扫过'
          : ('处理 ' + st.handled + ' 个实体'
            + '，跳过 ' + (st.skipped != null && st.skipped >= 0 ? st.skipped : 0)
            + ' 个未到间隔的掉落物'))));

        /* 位置同步间隔：**从模组回读**，而不是读配置 ——
         * 这样能区分"配置写了但推送没生效"与"配置本身没写对"。 */
        var syncTicks = null;
        try {
          if (g.selfModApi != null) syncTicks = g.selfModApi.itemSyncInterval();
        } catch (e) {
          syncTicks = null;
        }
        lines.push(txt('位置同步    运动中掉落物每 '
          + (syncTicks == null ? '?（模组未接入）' : String(syncTicks) + ' tick')
          + ' 补发一次位置包'
          + (syncTicks === 0 ? '（已关闭，闪现会回来）' : '')));
        lines.push(txt('重力方块配方 ' + setting.recipes.count() + ' 条'));
        tellAll(s, lines);
        return 1;
      }

      // ---- /mirror recipes ：重力方块加工配方 ----
      /* 用途：确认开关状态、配方内容，以及"某个下落的方块已经穿越了几次"。
       * 加工机制是"穿越够次数才变方块"，没有这个视图就只能靠猜。 */
      function recipesHandler(ctx) {
        var s = ctx.getSource();
        var setting = MD.runtime ? MD.runtime.setting : null;
        if (setting == null || !setting.ready || !setting.recipes) {
          tell(s, colored('red', '设置模块尚未就绪，稍后再试。'));
          return 0;
        }
        var R = setting.recipes;
        var on = R.enabled();
        var list = R.list();

        /* 可选关键词：/mirror recipes sand —— 只看名字里带 sand 的条目。
         * 43 条配方全打出来会刷满聊天栏，所以默认只给分组摘要。 */
        var filter = null;
        try {
          filter = String(Java.loadClass('com.mojang.brigadier.arguments.StringArgumentType')
            .getString(ctx, 'key'));
        } catch (e) {
          filter = null;
        }

        var lines = [];
        lines.push(colored(on ? 'green' : 'yellow',
          '重力方块加工：' + (on ? '已启用' : '已关闭')));
        lines.push(txt('开关位置  mirror_config.js → gravityBlockRecipes.enabled'));
        lines.push(txt('配方数量  ' + list.length + ' 条'));

        if (list.length === 0) {
          lines.push(colored('gray', '（没有配置任何配方）'));
          tellAll(s, lines);
          return 1;
        }

        /* 把"每条颜色各一条"的配方归成一组，避免 43 行刷屏。
         * 归组键：混凝土粉末这类成组的按家族名，其余按输入方块 ID。 */

        if (filter == null || filter === '') {
          var groups = {};
          var order = [];
          for (var k = 0; k < list.length; k++) {
            var fam = recipeFamilyOf(String(list[k].input));
            if (groups[fam] == null) {
              groups[fam] = 0;
              order.push(fam);
            }
            groups[fam]++;
          }
          for (var m = 0; m < order.length; m++) {
            lines.push(txt('  · ' + order[m] + '  —  ' + groups[order[m]] + ' 条'));
          }
          lines.push(colored('gray', '看具体条目：/mirror recipes <关键词>（如 concrete / sand / anvil）'));
        } else {
          var key = String(filter).toLowerCase();
          var hit = 0;
          for (var i = 0; i < list.length; i++) {
            var r = list[i];
            /* 落点可以是一组（数组）—— 统一成一行文字展示与匹配。
             * 写成一组的原因见 mirror_config.js 铁砧那条：
             * AnvilCraft 的 6 种粗矿块不在 c:storage_blocks 父标签里。 */
            var wantText = (r.onList != null && r.onList.length > 0)
              ? r.onList.join(' / ') : String(r.on);
            var hay = (String(r.input) + ' ' + String(r.output) + ' '
              + wantText + ' ' + String(r.id)).toLowerCase();
            if (hay.indexOf(key) < 0) continue;
            hit++;
            if (hit > 20) continue;   // 最多列 20 条
            var sideZh = r.at === 'lower' ? '仅下界面'
              : (r.at === 'upper' ? '仅上界面' : '两侧都算');
            var trigZh = r.trigger === 'landing'
              ? ('落在 ' + wantText + ' 上时变')
              : '在交界处直接变';
            var extra = '';
            if (r.dynamicOutput) extra += '  [产物=落点]';
            if (r.mappedOutput) extra += '  [产物按落点查表]';
            /* 产物形态写清楚：是"弹出来的物品"还是"放下去的方块"。
             * 这套机制里两者都可能（地狱疣既能当物品、也能种成方块），
             * 只写"掉落物"会让人不确定到底是哪种。 */
            extra += r.drop ? '  [产物: 掉落物弹出，不放方块]' : '  [产物: 原地放成方块]';
            if (r.insert != null) {
              extra += '  [放入容器: ' + r.insert.items.length + ' 选 1'
                + (r.insert.force ? '，装不下也触发' : '') + ']';
            }
            lines.push(txt('  · ' + String(r.input) + ' → ' + String(r.output)
              + '  穿越 ' + r.crossings + ' 次（' + sideZh + '，' + trigZh + '）' + extra));
            /* 提示行：有些配方不生效的原因在方块的原版规则上，不在配置里
             * （例如脚手架下方 6 格内有支撑就不会掉）。这类前提必须能在
             * 游戏里查到，否则只能靠翻代码注释。 */
            if (r.hint != null) {
              lines.push(colored('aqua', '      ↳ ' + String(r.hint)));
            }
          }
          if (hit === 0) {
            lines.push(colored('gray', '（没有匹配 "' + filter + '" 的配方）'));
          } else if (hit > 20) {
            lines.push(colored('gray', '（共 ' + hit + ' 条匹配，只列了前 20 条）'));
          }
        }

        /* ── 引擎采样：配方"不生效"时先看这一段 ──────────────────────
         * 三种失效原因在游戏里长得一模一样（什么都不发生），靠这一段区分：
         *   · 某种方块**根本不出现** → 它从没变成过下落实体
         *     （典型：脚手架下方 6 格内有结实方块，原版不让它掉）
         *   · 出现了但"最高切换"上不去 → 摆幅不够 / 被夹住
         *   · "最高切换"够了却不变 → 落点没匹配上，看"相邻方块"实际是什么
         * 关键词过滤时只显示相关的那些。 */
        var stats = (typeof R.diagnostics === 'function') ? R.diagnostics() : [];
        if (stats.length > 0) {
          lines.push(colored('gray', '── 引擎采样（下落实体被处理的 tick / 最高切换）──'));
          var shownStats = 0;
          for (var si = 0; si < stats.length && shownStats < 6; si++) {
            var st = stats[si];
            if (filter != null && filter !== ''
              && String(st.id).toLowerCase().indexOf(String(filter).toLowerCase()) < 0) {
              continue;
            }
            shownStats++;
            lines.push(txt('  · ' + st.id + '  处理 ' + st.ticks
              + ' tick，最高切换 ' + st.maxFlips + ' 次'));
            /* 摆幅范围：落点方块必须落在这个区间里，否则"永远碰不到" */
            if (st.minY != null && st.maxY != null) {
              lines.push(colored('aqua', '      活动范围 y='
                + (Math.round(st.minY * 100) / 100) + ' ~ ' + (Math.round(st.maxY * 100) / 100)
                + '（落点方块必须在这段里，它才碰得到）'));
            }
            /* ★ 最近活动范围（约 3 秒）—— 这一行才是"现在该把落点摆哪儿"。
             * 历史极值常常混着"一开始从高处砸下来"的那一段，会误导。 */
            if (st.recentMinY != null && st.recentMaxY != null) {
              lines.push(colored('aqua', '      最近 3 秒在 y='
                + (Math.round(st.recentMinY * 100) / 100) + ' ~ '
                + (Math.round(st.recentMaxY * 100) / 100)
                + '（落点摆进这一段最稳）'));
            }
            if (st.lastProbe != null && st.lastProbe !== '') {
              lines.push(colored('gray', '      最近采样 ' + st.lastProbe));
            }
            /* ★★ 「落点该摆在哪」—— 排查"落点配方不生效"最有用的一行。
             * 下落实体**只在竖直方向动**：竖列（X/Z）错一格就永远碰不到，
             * 而现象与"配方坏了"完全一样。所以直接把坐标念出来。 */
            if (st.lastX != null && st.lastZ != null) {
              var lo2 = (st.recentMinY == null) ? null : Math.floor(st.recentMinY) - 1;
              var hi2 = (st.recentMaxY == null) ? null : Math.ceil(st.recentMaxY) + 1;
              lines.push(colored('aqua', '      落点该摆在哪: x=' + st.lastX + ', z=' + st.lastZ
                + (lo2 == null ? '' : ('，y=' + lo2 + ' ~ ' + hi2))
                + '（就是这一竖列；铺满整个水平面一层最省事）'));
            }
            /* ★ 探针在这个方块旁边**实际见过**哪些方块。
             * 落点配方的两种失效原因在这里一眼分开：
             *   列表里**有**你摆的那个方块 → ID 与位置都对，那是引擎的问题
             *   列表里**没有** → 要么 ID 不对（看列表里真正的 ID 是什么），
             *                  要么位置太远（对照上面的"活动范围"） */
            if (st.seen != null && st.seen.length > 0) {
              var seenTxt = [];
              for (var sj = 0; sj < st.seen.length; sj++) {
                seenTxt.push(st.seen[sj].id);
              }
              lines.push(colored('aqua', '      旁边出现过: ' + seenTxt.join('、')));
            }
          }
          if (shownStats === 0) {
            lines.push(colored('yellow', '  （过滤后没有匹配的采样）'));
          }
        } else {
          lines.push(colored('yellow',
            '── 引擎采样为空：还没见过任何下落实体 ──'));
        }

        /* 正在计数的实体。加工是"累计穿越次数"，看这个才知道
         * 沙砾为什么还没变 —— 次数没到，还是压根没被计数。 */
        var states = R.states();
        lines.push(colored('gray', '── 正在计数 ' + states.length + ' 个实体 ──'));
        var shown = 0;
        for (var j = 0; j < states.length && shown < 6; j++) {
          lines.push(txt('  ' + states[j].id.substring(0, 8)
            + '  已穿越 ' + states[j].crossings + ' 次'));
          shown++;
        }
        if (states.length === 0) {
          lines.push(colored('gray', '（放下沙砾后这里会出现记录）'));
        }
        tellAll(s, lines);
        return 1;
      }

      // ---- /mirror sound [叠加层数] ：就地试听一次"穿过镜面"的提示音 ----
      /* 为什么需要它：提示音只在真的跨维度那一下响一次，
       * 每调一次抽头参数就得穿一次门 —— 有了这个指令可以站在原地反复对比。
       * 带参数时按层数试播（只在这一次生效，不改配置），
       * 用来先把"叠几层才够响"试出来，再回去改 mirror_config.js。
       *
       * ⚠️ 参数是**叠加层数**（1~8），不是音量：
       *    原版客户端会把最终增益 clamp 到 1.0，音量调到 1 以上不会更响
       *    （SoundEngine.calculateVolume），只能靠同时播多份。 */
      function soundHandler(ctx) {
        var s = ctx.getSource();
        var player = null;
        try { player = s.getPlayerOrException(); } catch (e) { player = null; }

        var N7 = global.MirrorDimension.modules.n7;
        if (N7 == null || !N7.ready) {
          tell(s, colored('red', '音效模块（n7）未就绪 —— 看日志里的 [镜维度·音效]。'));
          return 0;
        }
        if (player == null) {
          tell(s, colored('red', '这个指令要玩家本人执行。'));
          return 0;
        }
        var info = N7.info();
        if (!info.enabled || !info.classesOk) {
          tell(s, colored('red', info.enabled
            ? '原版音效类加载失败，播不出来。'
            : '配置里关掉了音效（mirror_config.js → sound.enabled）。'));
          return 0;
        }

        var want = 0;
        try {
          want = Java.loadClass('com.mojang.brigadier.arguments.IntegerArgumentType')
            .getInteger(ctx, 'layers');
        } catch (e) {
          want = 0;
        }

        var ok = N7.cueFor(player, want);
        var layers = N7.stackOf(want);
        tellAll(s, [
          ok ? colored('aqua', '▶ ' + info.event + '（叠加 ' + layers + ' 层，'
            + info.taps + ' 个运行时回响抽头）')
            : colored('red', '播放调用失败了 —— 看日志里的 [镜维度·音效]。'),
          txt('  单份音量 ' + info.volume + '（>1 无效，原版会夹到 1）'
            + '，声道「' + info.sourceZh + '」'),
          txt('  受原版滑块控制：设置 → 音乐和声音 → ' + info.sourceZh
            + '（与地狱传送门同一根）'),
          txt('  响度 = 原版地狱门 +3.4 dB（原版 -25.0 / 本音效 -21.6 LUFS）'),
          txt('  还要更响：/mirror sound 2 试听（≈ +3 dB），然后告诉我重烘焙。'),
        ]);
        return ok ? 1 : 0;
      }

      // ---- /mirror crafting ：工作台配方（无序合成） ----
      /* 这条指令存在的理由：工作台配方出问题时游戏里**毫无表现**
       * （合不出来就是合不出来，JEI 里也没有），只有日志里一行字。
       * 所以这里做两件事：
       *   1) 列出配置里写了什么（配置是唯一真相）
       *   2) **回读服务端配方表**，确认它们真的进去了 ——
       *      这一条才是"能不能合出来"的决定性证据 */
      function craftingHandler(ctx) {
        var s = ctx.getSource();
        var setting = MD.runtime ? MD.runtime.setting : null;
        if (setting == null || !setting.ready) {
          tell(s, colored('red', '设置模块尚未就绪，稍后再试。'));
          return 0;
        }
        var C = (typeof setting.crafting === 'function') ? setting.crafting() : null;
        if (C == null || !C.ready) {
          tell(s, colored('red', '工作台配方模块（n9）未就绪 —— 看日志里有没有它的报错。'));
          return 0;
        }

        var list = C.list();
        var registered = C.registered();
        var failed = C.failed();

        /* 可选关键词：/mirror crafting sand —— 只看名字里带 sand 的。
         * 现在只有两条，但配方一多就需要（与 /mirror recipes 同一套做法）。 */
        var filter = null;
        try {
          filter = String(Java.loadClass('com.mojang.brigadier.arguments.StringArgumentType')
            .getString(ctx, 'key')).toLowerCase();
        } catch (e) {
          filter = null;
        }

        var lines = [];
        lines.push(colored(C.enabled ? 'green' : 'yellow',
          '工作台配方：' + (C.enabled ? '已启用' : '已关闭')));
        lines.push(txt('开关位置  mirror_config.js → craftingRecipes.enabled'));
        lines.push(txt('配方数量  ' + list.length + ' 条（无序合成，最多 '
          + C.maxIngredients + ' 种原料）'));

        if (filter == null || filter === '') {
          for (var i = 0; i < list.length; i++) {
            var r = list[i];
            var ings = Array.isArray(r.ingredients) ? r.ingredients.join(' + ') : '?';
            var cnt = r.count != null && Number(r.count) > 1 ? (' × ' + r.count) : '';
            lines.push(txt('  · ' + ings + '  →  ' + String(r.output) + cnt
              + (r.note != null ? ('   （' + String(r.note) + '）') : '')));
            lines.push(colored('gray', '      ID ' + (r.id != null ? String(r.id) : '(自动生成)')));
          }
        } else {
          var hit = 0;
          for (var j = 0; j < list.length; j++) {
            var r2 = list[j];
            var hay = (String(r2.output) + ' ' + String(r2.id) + ' '
              + (Array.isArray(r2.ingredients) ? r2.ingredients.join(' ') : '')).toLowerCase();
            if (hay.indexOf(filter) < 0) continue;
            hit++;
            var ings2 = Array.isArray(r2.ingredients) ? r2.ingredients.join(' + ') : '?';
            lines.push(txt('  · ' + ings2 + '  →  ' + String(r2.output)));
          }
          if (hit === 0) {
            lines.push(colored('gray', '（没有匹配 "' + filter + '" 的配方）'));
          }
        }

        /* 本次提交结果 + 运行时回读 */
        lines.push(colored('gray', '── 本次注册：提交 ' + registered.length
          + ' 条' + (failed.length > 0 ? ('，失败 ' + failed.length + ' 条') : '') + ' ──'));
        for (var k = 0; k < failed.length; k++) {
          lines.push(colored('red', '  ✗ ' + failed[k].id + '  ' + failed[k].error));
        }
        for (var m = 0; m < registered.length; m++) {
          var mark = registered[m].shape === 'mismatch' ? '（⚠ 参数顺序可疑）' : '';
          lines.push(txt('  ✓ ' + registered[m].ingredients.join(' + ')
            + ' → ' + registered[m].output + ' ' + mark));
        }

        var v = C.verify(s.getServer());
        if (v.available) {
          lines.push(colored(v.missing.length === 0 ? 'green' : 'red',
            '── 服务端配方表回读：找到 ' + v.found + ' / ' + list.length + ' 条'
            + '（当前世界共有 ' + v.total + ' 条配方）──'));
          for (var n = 0; n < v.missing.length; n++) {
            lines.push(colored('red', '  ✗ 配方表里没有 ' + v.missing[n]));
          }
          if (v.missing.length === 0) {
            lines.push(colored('gray', 'JEI 的工作台分类会自动显示它们（原版配方，无需额外导出）'));
          }
        } else {
          lines.push(colored('gray', '── 服务端配方表回读不可用：' + v.reason
            + '（只看上面的注册结果）──'));
        }
        tellAll(s, lines);
        return 1;
      }

      // ---- /mirror （无参数 → 帮助）----
      function helpHandler(ctx) {
        var s = ctx.getSource();
        tellAll(s, [
          colored('gold', '镜维度 · 用法'),
          txt('/mirror tp            进入镜维度'),
          txt('/mirror back          返回主世界'),
          txt('/mirror portal        搭一座 3×3×3 镜面传送门并点燃'),
          txt('/mirror info          查看维度信息'),
          txt('/mirror gravity       查看重力状态'),
          txt('/mirror gravity up    临时强制重力朝上'),
          txt('/mirror recipes       查看重力方块加工配方（分组摘要）'),
          txt('/mirror recipes sand  只列名字含 sand 的配方'),
          txt('/mirror crafting      查看工作台配方，并回读服务端配方表确认已生效'),
          txt('/mirror sound         就地试听进入镜维度的提示音'),
          txt('/mirror sound 5       同上，但这次叠加 5 层试播（1~8，越大越响）'),
        ]);
        return 1;
      }

      // 组装指令树：/mirror [tp|back|portal|info|gravity|recipes|crafting|sound]
      var root = LiteralArgumentBuilder.literal('mirror')
        .requires(src => src.hasPermission(0))
        .executes(helpHandler)
        .then(LiteralArgumentBuilder.literal('tp').executes(tpHandler))
        .then(LiteralArgumentBuilder.literal('back').executes(backHandler))
        .then(LiteralArgumentBuilder.literal('portal').executes(portalHandler))
        .then(LiteralArgumentBuilder.literal('info').executes(infoHandler))
        .then(LiteralArgumentBuilder.literal('recipes')
          .executes(recipesHandler)
          .then(Commands.argument('key',
            Java.loadClass('com.mojang.brigadier.arguments.StringArgumentType').string())
            .executes(recipesHandler)))
        .then(LiteralArgumentBuilder.literal('crafting')
          .executes(craftingHandler)
          .then(Commands.argument('key',
            Java.loadClass('com.mojang.brigadier.arguments.StringArgumentType').string())
            .executes(craftingHandler)))
        .then(LiteralArgumentBuilder.literal('sound')
          .executes(soundHandler)
          .then(Commands.argument('layers',
            Java.loadClass('com.mojang.brigadier.arguments.IntegerArgumentType').integer(1, 8))
            .executes(soundHandler)))
        .then(LiteralArgumentBuilder.literal('gravity')
          .executes(gravityHandler)
          .then(Commands.argument('dir', Java.loadClass('com.mojang.brigadier.arguments.StringArgumentType').string())
            .executes(gravityHandler)
            .then(Commands.argument('secs', Java.loadClass('com.mojang.brigadier.arguments.IntegerArgumentType').integer())
              .executes(gravityHandler))));

      event.register(root);

      // 顶层别名，少打几个字也算降低验证门槛
      event.register(LiteralArgumentBuilder.literal('mirrortp').executes(tpHandler));
      event.register(LiteralArgumentBuilder.literal('mirrorback').executes(backHandler));
      event.register(LiteralArgumentBuilder.literal('mirrorinfo').executes(infoHandler));

      console.info('[镜维度] 指令已注册: /mirror tp|back|portal|info|gravity|recipes|crafting|sound'
        + '（别名 /mirrortp /mirrorback /mirrorinfo）');
    });
  } catch (err) {
    console.error('[镜维度] 指令注册失败: ' + err);
  }

  /* ------------------------------------------------------------------ */
  /* 进世界自检：确认 /mirror 真的注册进了 Brigadier 指令表              */
  /* ------------------------------------------------------------------ */
  // 把「指令不存在」这类问题直接在日志里暴露，而不是等你敲了才发现。
  // ⚠️ 注意本事件只能在 SERVER 类型脚本里注册（放在 startup 脚本里会报
  //    invalid script type STARTUP）。
  ServerEvents.loaded(event => {
    var names = [];
    try {
      var dispatcher = event.server.getCommands().getDispatcher();
      var it = dispatcher.getRoot().getChildren().iterator();
      while (it.hasNext()) {
        var n = String(it.next().getName());
        if (n.indexOf('mirror') === 0) names.push(n);
      }
    } catch (e) {
      console.error('[镜维度] 指令表自检失败: ' + e);
    }
    if (names.length > 0) {
      console.info('[镜维度] 指令表自检通过，已注册: ' + names.join(', '));
    } else {
      console.error('[镜维度] 指令表里找不到 mirror* —— 指令注册失败，请看上面的报错');
    }
  });

  /* ------------------------------------------------------------------ */
  /* 进入镜维度时给一次提示                                               */
  /* ------------------------------------------------------------------ */

  /* 自增计数器：**不要用 player.age**。
   * KubeJS 的 ServerPlayer 包装上没有 age 属性（探针实测 undefined），
   * `undefined % 20` 得到 NaN，`NaN !== 0` 恒为 true ——
   * 整段逻辑每 tick 都在这里提前 return，等于从未执行。 */
  let entryNoticeTick = 0;

  PlayerEvents.tick(event => {
    entryNoticeTick++;
    if (entryNoticeTick % 20 !== 0) return;

    var player = event.player;

    var current = String(player.level.dimension);
    var last = player.persistentData.getString('mirror_last_dim');

    if (last === current) return;
    player.persistentData.putString('mirror_last_dim', current);

    if (current !== DIM) return;

    /* 只发聊天提示 —— **音效不在这里播**。
     *
     * 进入镜维度的提示音改由**模组**负责：
     *   MirrorGravity#onPlayerChangedDimension（监听"玩家进入镜维度"）
     *   → MirrorPortalBlock.playCueAt(...) → MirrorBlocks.MIRROR_ENTER
     * 放在模组里的好处是**所有入口都有声音**（传送门、/mirror tp、
     * /execute in …都会触发维度变化事件），而且不必在脚本里维护音效链路。
     *
     * ⚠️ 别在这里再调 N7.cueFor(...)：那条音效与模组播的是同一条，
     *    两处都播就会响两遍。
     *    脚本侧的 mirror_n7_echo.js 仍然保留，用途是 /mirror sound 试听
     *    与"把 event 换回原版音效"时的备用播放路径。 */
    player.tell(colored('aqua', '镜面翻涌，你穿过了另一侧。'));
  });

  console.info('[镜维度] 服务端脚本已启用 — ' + DIM);

  return { ready: true, dimension: DIM };
})();

// ⚠️ 不要在这里写 global.MirrorServer = ...（见文件头注释 2）
