package work.dsh.mirror.gravity;

import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import work.dsh.mirror.gravity.internal.DirectionWriter;
import work.dsh.mirror.gravity.internal.VelocityFix;

/**
 * 本模组暴露给 KubeJS 的**唯一**接口。
 *
 * <h2>契约（改动前务必读完）</h2>
 * KubeJS 侧只能按**类名**加载（脚本里无法编译期引用 Java 类）：
 * <pre>
 *   const MG_API = tryLoadClass('work.dsh.mirror.gravity.MirrorGravityApi');
 * </pre>
 * 所以本类的全限定名与方法签名是**不可破坏的契约**。
 * 改名或改签名会让脚本静默拿不到 API —— {@code tryLoadClass} 失败返回 null，
 * 表现为"重力反转整体失效"，而不是抛错。改完请核对 mirror_setting.js。
 *
 * <p>脚本实际调用的方法：
 * <ul>
 *   <li>{@link #setSplitY(double)}</li>
 *   <li>{@link #setHysteresis(double)}</li>
 *   <li>{@link #setFallingRefOffset(double)}</li>
 *   <li>{@link #setItemSyncInterval(int)}</li>
 *   <li>{@link #apply(Entity, String, double)}</li>
 *   <li>{@link #currentDirection(Entity)}</li>
 *   <li>{@link #clear(Entity)}</li>
 * </ul>
 *
 * <h2>职责边界</h2>
 * 本类只做"参数校验 + 转发"，实现分散在：
 * <ul>
 *   <li>{@link PondusReflect} —— 反射底座（唯一的 Pondus 访问点）</li>
 *   <li>{@link DirectionWriter} —— 方向与重力强度的写入</li>
 *   <li>{@link VelocityFix} —— 修补 Pondus 换向时清零速度的缺陷</li>
 *   <li>{@link BlockPhysics} —— 下落方块自己的物理</li>
 * </ul>
 */
public final class MirrorGravityApi {

    private MirrorGravityApi() {
    }

    /**
     * 设定实体的重力方向与强度。
     *
     * @param entity 目标实体
     * @param name   方向名（小写）：down / up / north / south / west / east
     * @param scale  重力强度倍数；1.0 = 原版，0.5 = 一半（落得慢），0 = 不受重力
     * @return 是否成功
     */
    public static boolean apply(Entity entity, String name, double scale) {
        Direction dir = MirrorDir.byNameOrNull(name);
        if (entity == null || dir == null) {
            return false;
        }

        boolean ok = DirectionWriter.apply(entity, dir, true);

        /* 重力强度：**只对非掉落物写**。
         *
         * ⚠️ 实测：Pondus 的强度字段对掉落物是**死字段** ——
         * KubeJS 侧的 falling_gravity_scale = 0.2 确实写进了
         * baseGravityStrength/currGravityStrength（读回确认 0.2），但
         * entity.getGravity() 仍返回 0.04，位置二阶差分算出的实际加速度
         * 也是满重力。没有任何代码读那个字段。
         *
         * 所以对掉落物写它属于**空操作**，只会让代码读起来像"缩放已生效"，
         * 是排查时的误导源。真正的缩放由
         * {@link VelocityFix#applyItemGravityScale} 每 tick 直接扣速度实现。
         *
         * 仍然对其它实体写，是因为生物等实体的行为没有实测依据，
         * 不排除对它们有效。 */
        if (scale >= 0.0D && !(entity instanceof ItemEntity)) {
            DirectionWriter.applyScale(entity, scale);
        }

        return ok;
    }

    /** 只改方向，强度保持原版 1.0。 */
    public static boolean apply(Entity entity, String name) {
        return apply(entity, name, 1.0D);
    }

    /**
     * 恢复原版：方向 down、强度 1.0。
     *
     * <p>⚠️ 强度必须**无条件**复位，不能跟着 {@link DirectionWriter#apply} 的
     * 返回值走 —— 它在"方向没变"时会提前返回 true 且什么都不写。
     * 若依赖它，强度就会残留，实体回到上界面后仍受缩放重力。
     */
    public static void clear(Entity entity) {
        if (entity == null) {
            return;
        }
        DirectionWriter.apply(entity, Direction.DOWN, true);
        DirectionWriter.applyScale(entity, 1.0D);
        VelocityFix.forget(entity.getUUID());
    }

    /**
     * 读实体**当前实际生效**的重力方向名（小写，如 "up"）。
     *
     * <p>这是 KubeJS 配方计数的真相来源。脚本靠"方向一变就计数"实现
     * 视觉与程序的统一，而不是自己按坐标推断翻转 ——
     * 推断会与模组的迟滞状态机形成两套不同的度量
     * （实测症状：视觉上来回好几次、计数只涨 1）。
     *
     * <p>它读的是 Pondus 的方向字段，**不管是谁设的**
     * （模组 BlockPhysics、KubeJS、Pondus 自己都算），
     * 所以对下落方块同样有效。
     *
     * @return 方向名；实体无效或 Pondus 不可用时返回 null
     */
    public static String currentDirection(Entity entity) {
        Direction d = PondusReflect.direction(entity);
        return d == null ? null : d.getName();
    }

    /**
     * 设置重力分界线。由 KubeJS 侧把 layout.split_y 推过来。
     *
     * <p>分界值仍然只有一处真相（mirror_config.js），模组只是接收 ——
     * 下落方块的物理必须知道分界在哪才能决定加速度方向。
     */
    public static void setSplitY(double y) {
        MirrorGravity.setSplitY(y);
    }

    /**
     * 设置下落方块参照线相对分界的偏移（格）。
     *
     * <p>由 KubeJS 侧推送，用于消除"分界线双重真相"：
     * 这个值同时被模组的方块物理与 KubeJS 的配方穿越计数使用，
     * 原先两处各写一遍、靠人工保持一致，改一处忘另一处就会让计数错位。
     * 现在布局（玻璃层位置）是 KubeJS 的职责，所以唯一真相也在那里
     * （{@code gravity.falling_ref_offset}），模组只接收。
     *
     * @param offset 偏移格数，通常为 -1.0（黑色玻璃占 y=-1/-2）
     */
    public static void setFallingRefOffset(double offset) {
        MirrorGravity.setFallingRefOffset(offset);
    }

    /**
     * 设置下落方块的方向迟滞带半径（格）。
     *
     * <p>它同时决定两件事：
     * <ul>
     *   <li><b>防抖</b>：带内维持原方向，避免在分界线上快速抽搐</li>
     *   <li><b>摆幅</b>：实体要越过 {@code splitY ± band} 才反向，
     *       所以带越宽、往复越远</li>
     * </ul>
     * 实测 band=0.75 时沙砾只在 y≈-2.31 ~ -0.63 之间摆动，够不到 y=0；
     * 调到 1.0 后上折点才落到 y=0 附近。
     *
     * <p>同样只有一处真相（mirror_config.js），模组只负责接收。
     */
    public static void setHysteresis(double band) {
        BlockPhysics.setHysteresis(band);
    }

    /**
     * 设置"运动中的掉落物"请求位置同步的间隔（tick）。
     *
     * <p>这是"物品在交界处换向时偶尔闪一下"那个问题的开关。
     * 原版给物品的位置包间隔是 20 tick，中间客户端只能靠本地预测，
     * 偏差累积到下一个包到达时被一次性硬赋值拉回 —— 画面上就是跳一下。
     * 置 {@code Entity.hasImpulse} 可以绕过那个门控。
     *
     * @param ticks 1 = 每 tick（漂移归零，包量是原版 20 倍）；
     *              10 = 默认（2 包/秒，残留漂移约 0.07 格）；
     *              N = 每 N tick 同步一次；20 = 退回原版节奏；
     *              0 = 关闭（闪现会回来）
     */
    public static void setItemSyncInterval(int ticks) {
        VelocityFix.setSyncInterval(ticks);
    }

    /**
     * 读回当前生效的同步间隔（诊断用）。
     *
     * <p>为什么专门提供一个回读口：脚本推参数是"单向"的，推失败时
     * （比如方法名写错、模组没加载）不会有任何提示。
     * {@code /mirror gravity} 直接回读这个值，就能区分
     * "配置写了但没生效"和"配置本身没写对"。
     *
     * @return 当前间隔（tick）；0 表示已关闭
     */
    public static int itemSyncInterval() {
        return VelocityFix.syncInterval();
    }

    /**
     * 启动时打印一次接入状态。
     *
     * <p>为什么专门打这个：脚本用 {@code tryLoadClass} 加载本类，
     * 一旦失败会**静默**降级（拿不到 API 就什么都不做，游戏照常启动）。
     * 这一行日志是判断"模组到底接上没有"的唯一依据。
     */
    static void logStatus(org.slf4j.Logger logger) {
        boolean pondus = PondusReflect.isAvailable();
        logger.info("[镜维度·重力] Pondus 数据接入: {}", pondus ? "成功" : "失败（非生物实体将无法反转）");
        if (pondus) {
            logger.info("[镜维度·重力] Pondus 旋转参数刷新: {}",
                PondusReflect.refreshRotationDefaults() ? "成功" : "失败");
        }
    }

    /* ------------------------------------------------------------------ */
    /* 传送门                                                              */
    /* ------------------------------------------------------------------ */

    /**
     * 尝试点燃镜维度传送门（KubeJS 侧右键玻璃时调用）。
     *
     * <p>结构校验与方块替换都在 {@link MirrorPortalShape} 里做 ——
     * 那两件事必须贴着方块与标签走；脚本只负责"什么物品、什么时候调用、
     * 给玩家说什么话"。
     *
     * @param level 世界（服务端事件里拿到的是 ServerLevel）
     * @param pos   被右键的玻璃的位置，也就是"中间层的中心"
     * @return 状态码：{@code ok} / {@code already}，或错误码
     *         （用 {@link #describePortalResult(String)} 转成中文）
     */
    public static String tryIgniteMirrorPortal(net.minecraft.world.level.Level level,
                                               net.minecraft.core.BlockPos pos) {
        if (level == null || pos == null) {
            return "bad_args";
        }
        if (!(level instanceof net.minecraft.server.level.ServerLevel serverLevel)) {
            return "not_server";
        }
        return MirrorPortalShape.tryIgnite(serverLevel, pos);
    }

    /** 状态码 → 中文说明（脚本直接用，避免文案两处维护）。 */
    public static String describePortalResult(String code) {
        if (code == null) {
            return "未知";
        }
        if ("bad_args".equals(code)) {
            return "参数不合法";
        }
        return MirrorPortalShape.describe(code);
    }

    /**
     * 推送传送门的目标维度与 **Y 坐标映射区间**。
     *
     * <p>与分界线一样：**唯一真相在 mirror_config.js，模组只接收**。
     * X/Z 的缩放不在这里 —— 那走原版机制
     * （{@code DimensionType.getTeleportationScale}，由 dimension_type 的
     * {@code coordinate_scale} 决定）。
     *
     * @param dimensionId   目标维度 ID，形如 {@code mirror:mirror}
     * @param owMinY        主世界最低可建高度（-64）
     * @param owMaxY        主世界最高可建高度（319）
     * @param mirrorMinY    镜维度境内最低（-64）
     * @param mirrorMaxY    镜维度境内最高（63）
     */
    public static void setMirrorPortalTarget(String dimensionId,
                                             double owMinY, double owMaxY,
                                             double mirrorMinY, double mirrorMaxY) {
        MirrorPortalBlock.setTarget(dimensionId, owMinY, owMaxY, mirrorMinY, mirrorMaxY);
    }

    /** 到达另一侧时是否自动建门。 */
    public static void setMirrorPortalBuildArrival(boolean value) {
        MirrorPortalBlock.setBuildArrival(value);
    }

    /**
     * 推送"建门时避开的 Y 值"（世界生成的玻璃层），逗号分隔。
     *
     * <p>为什么用字符串而不是数组：脚本侧传数组过 Rhino 有转换风险，
     * 而这里的数据就是一串整数，字符串最省事也最好在日志里核对。
     */
    public static void setMirrorPortalAvoidY(String csv) {
        MirrorPortalShape.setAvoidY(csv);
    }

    /** 回读当前目标与映射（诊断用，供 /mirror portal 显示）。 */
    public static String mirrorPortalTarget() {
        return MirrorPortalBlock.targetDescription();
    }

    /**
     * 推送传送门的结构材料（底层 / 顶层方块 + 中心玻璃标签）。
     *
     * <p>同 {@link #setMirrorPortalTarget}：唯一真相在 mirror_config.js。
     *
     * @param bottomBlock 底层方块 ID（3×3）
     * @param topBlock    顶层方块 ID（3×3）
     * @param glassTag    中心那一格要求的标签，如 {@code c:glass_blocks}
     */
    public static void setMirrorPortalStructure(String bottomBlock, String topBlock, String glassTag) {
        MirrorPortalShape.setStructure(bottomBlock, topBlock, glassTag);
    }

    /** 回读结构材料（诊断用）。 */
    public static String mirrorPortalStructure() {
        return MirrorPortalShape.structureDescription();
    }

    /* ------------------------------------------------------------------ */
    /* 容器：让落下来的方块把物品放进容器                                     */
    /* ------------------------------------------------------------------ */

    /**
     * 判断某个位置的方块**是不是**属于给定标签。
     *
     * <p>为什么要在模组里做：脚本侧构造 {@code TagKey} 再调
     * {@code BlockState#is(TagKey)} 这条链在 Rhino 里没有先例，
     * 而标签查询是配方"落在什么上面"这一条的核心需求
     * （例：铁砧要落在**任意**矿物块/金属块上，而不是某一个方块）。
     *
     * @param state 方块状态（脚本从 {@code level.getBlockState(pos)} 拿到）
     * @param tagId 标签 ID，可带或不带前导 {@code #}，如 {@code c:storage_blocks}
     * @return 属于该标签返回 true；参数非法或标签不存在返回 false
     */
    public static boolean blockStateHasTag(net.minecraft.world.level.block.state.BlockState state,
                                           String tagId) {
        if (state == null || tagId == null || tagId.isBlank()) {
            return false;
        }
        String raw = tagId.startsWith("#") ? tagId.substring(1) : tagId;
        net.minecraft.resources.ResourceLocation rl =
            net.minecraft.resources.ResourceLocation.tryParse(raw.trim());
        if (rl == null) {
            return false;
        }
        try {
            net.minecraft.tags.TagKey<net.minecraft.world.level.block.Block> key =
                net.minecraft.tags.TagKey.create(
                    net.minecraft.core.registries.Registries.BLOCK, rl);
            return state.is(key);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * 判断一个方块状态**就是不是**某个方块 ID。
     *
     * <h2>为什么专门加这个方法（踩过的坑）</h2>
     * 配方的落点有两种写法：{@code '#标签'} 与 {@code 'minecraft:xxx'}。
     * 标签那条走的是本类（纯 Java，拿 {@code BlockState#is(TagKey)} 判定），
     * 而具体 ID 那条原先走**脚本侧**：
     * <pre>
     *   blockIdOf(state) === 'minecraft:nether_wart_block'
     * </pre>
     * 其中 {@code blockIdOf} 要用 Rhino 调 {@code state.getBlock()}、
     * 再调 {@code BuiltInRegistries.BLOCK.getKey(...)}，最后把结果当字符串比较。
     *
     * <p>实测症状：**同一个位置**把树叶换成下界疣块，树叶那条（标签）能触发，
     * 下界疣块那条（具体 ID）永远不触发 —— 两条路径只差这一环。
     * 所以把具体 ID 的判定也搬进模组：{@code state.getBlock()} 与注册表查询
     * 全在 Java 里完成，脚本侧不再参与"是不是同一个方块"这个判断，
     * 两条路径的行为也就此对齐。
     *
     * @param state   方块状态
     * @param blockId 方块 ID，如 {@code minecraft:nether_wart_block}
     * @return 是同一个方块返回 true；参数非法或找不到该 ID 返回 false
     */
    public static boolean blockStateHasId(net.minecraft.world.level.block.state.BlockState state,
                                          String blockId) {
        if (state == null || blockId == null || blockId.isBlank()) {
            return false;
        }
        net.minecraft.resources.ResourceLocation want =
            net.minecraft.resources.ResourceLocation.tryParse(blockId.trim());
        if (want == null) {
            return false;
        }
        try {
            net.minecraft.resources.ResourceLocation actual =
                net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(state.getBlock());
            return actual != null && actual.equals(want);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * 某个方块 ID 在方块注册表里存在吗（配置体检用）。
     *
     * <p>落点写错 ID 的表现是"方块一直往复、什么都不发生"，
     * 与"摆错位置"完全一样且没有任何报错。加载期核对一次就能把它
     * 变成一条明确的 error。
     */
    public static boolean blockIdExists(String blockId) {
        if (blockId == null || blockId.isBlank()) {
            return false;
        }
        net.minecraft.resources.ResourceLocation rl =
            net.minecraft.resources.ResourceLocation.tryParse(blockId.trim());
        if (rl == null) {
            return false;
        }
        try {
            return net.minecraft.core.registries.BuiltInRegistries.BLOCK.containsKey(rl);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * 目标位置的容器**装得下**这个物品吗（不做修改）。
     *
     * <p>配方侧应当"先问后做"：容器满了就别把下落的方块换成产物，
     * 否则那一个物品就白扔了。规则见 {@link MirrorContainerInsert}。
     */
    public static boolean canInsertIntoContainer(net.minecraft.world.level.Level level,
                                                 net.minecraft.core.BlockPos pos,
                                                 String itemId, int count) {
        if (!(level instanceof net.minecraft.server.level.ServerLevel serverLevel)) {
            return false;
        }
        return MirrorContainerInsert.canInsert(serverLevel, pos,
            MirrorContainerInsert.resolveStack(itemId, count));
    }

    /**
     * 把物品放进容器（陶罐会晃动 + 播原版的放入音效与粒子）。
     *
     * @return 是否成功放入
     */
    public static boolean tryInsertIntoContainer(net.minecraft.world.level.Level level,
                                                 net.minecraft.core.BlockPos pos,
                                                 String itemId, int count) {
        if (!(level instanceof net.minecraft.server.level.ServerLevel serverLevel)) {
            return false;
        }
        return MirrorContainerInsert.insert(serverLevel, pos,
            MirrorContainerInsert.resolveStack(itemId, count));
    }

    /* ------------------------------------------------------------------ */
    /* 掉落物：产物以物品形式弹出                                             */
    /* ------------------------------------------------------------------ */

    /**
     * 在指定位置弹出一个掉落物。
     *
     * <p>用途是少数"产物不该原地放成方块"的配方 —— 例如脚手架落在树叶上
     * 变成**树苗**。树苗与地狱疣虽然都能当方块放，但设定要的是"加工出来的
     * 东西可以捡走"，直接种在原地会把落点（树叶/灵魂沙）盖掉。
     *
     * <p>实现见 {@link MirrorItemDrop}；这里只做参数转发与类型收窄。
     *
     * @param level  世界（非服务端直接返回 false）
     * @param x      生成点 X（建议方块中心，即整数 + 0.5）
     * @param y      生成点 Y
     * @param z      生成点 Z
     * @param itemId 物品 ID，如 {@code minecraft:oak_sapling}
     * @param count  数量
     * @return 是否成功生成
     */
    public static boolean dropItem(net.minecraft.world.level.Level level,
                                   double x, double y, double z,
                                   String itemId, int count) {
        if (!(level instanceof net.minecraft.server.level.ServerLevel serverLevel)) {
            return false;
        }
        return MirrorItemDrop.drop(serverLevel, x, y, z,
            MirrorContainerInsert.resolveStack(itemId, count));
    }
}
