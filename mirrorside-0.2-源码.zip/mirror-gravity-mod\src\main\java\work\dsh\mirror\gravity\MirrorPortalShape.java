package work.dsh.mirror.gravity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/**
 * 镜维度 · 传送门结构（3×3×3）。
 *
 * <h2>结构（设定）</h2>
 * <pre>
 *     y+1   平滑石英块 ×9          ← 顶层
 *     y     空气 ×8 + 中心玻璃      ← 中间层（中心就是"传送门位置"）
 *     y-1   磨制黑石 ×9            ← 底层
 * </pre>
 * 中心那一格必须是**玻璃**（任意玻璃都可以，判定用通用标签
 * {@code c:glass_blocks}，见 {@link #GLASS_TAG}）。
 *
 * <h2>点燃之后</h2>
 * 中心玻璃被替换成 {@code mirrorgravity:mirror_portal}，
 * **上下两层就不再是必需的** —— 传送门方块一旦放下就独立存在，
 * 不像地狱门那样靠 {@code updateShape} 检查框架。
 *
 * <h2>为什么结构校验放在 Java 而不是脚本里</h2>
 * 三件事都必须在这里：方块实例（{@link MirrorBlocks#MIRROR_PORTAL}）、
 * 方块标签判定（{@code BlockState#is(TagKey)}）、以及"把玻璃换成传送门"这个
 * 服务端世界写操作。脚本侧只负责"什么物品、什么时候触发、给玩家说什么"。
 */
public final class MirrorPortalShape {

    private MirrorPortalShape() {
    }

    /* ------------------------------------------------------------------ */
    /* 结构材料（由 KubeJS 推送）                                            */
    /* ------------------------------------------------------------------ */

    /** 底层方块：磨制黑石。 */
    public static net.minecraft.world.level.block.Block BOTTOM_BLOCK =
        Blocks.POLISHED_BLACKSTONE;

    /** 顶层方块：平滑石英块。 */
    public static net.minecraft.world.level.block.Block TOP_BLOCK =
        Blocks.SMOOTH_QUARTZ;

    /**
     * 中心方块所属的标签：NeoForge 通用标签 {@code c:glass_blocks}。
     *
     * <p>用通用标签而不是"写死 minecraft:glass"，是按设定里的
     * 「任意，只需要有玻璃标签」来的，也符合 NeoForge 的惯例 ——
     * 该标签聚合了 {@code colorless / cheap / tinted} 三组，
     * 原版所有玻璃（含染色玻璃、遮光玻璃）以及其它模组登记的玻璃都在里面。
     */
    public static TagKey<net.minecraft.world.level.block.Block> GLASS_TAG =
        TagKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath("c", "glass_blocks"));

    /**
     * 由 KubeJS 侧推送结构材料。
     *
     * <p>与分界线、迟滞带同样的约定：**唯一真相在 mirror_config.js，
     * 模组只接收**。上面那些默认值只在"脚本还没推过来"时生效。
     *
     * @param bottomBlock 底层方块 ID，如 {@code minecraft:polished_blackstone}
     * @param topBlock    顶层方块 ID，如 {@code minecraft:smooth_quartz}
     * @param glassTag    中心方块所属标签，如 {@code c:glass_blocks}
     */
    public static void setStructure(String bottomBlock, String topBlock, String glassTag) {
        net.minecraft.world.level.block.Block bottom = resolveBlock(bottomBlock);
        net.minecraft.world.level.block.Block top = resolveBlock(topBlock);
        if (bottom != null) {
            BOTTOM_BLOCK = bottom;
        }
        if (top != null) {
            TOP_BLOCK = top;
        }
        ResourceLocation tagId = glassTag == null ? null : ResourceLocation.tryParse(glassTag);
        if (tagId != null) {
            GLASS_TAG = TagKey.create(Registries.BLOCK, tagId);
        }
        MirrorGravity.LOGGER.info("[镜维度·传送门] 结构材料已设为 底={} 顶={} 中心标签=#{}",
            net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(BOTTOM_BLOCK),
            net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(TOP_BLOCK),
            GLASS_TAG.location());
    }

    /** 结构材料回读（诊断用）。 */
    public static String structureDescription() {
        return net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(BOTTOM_BLOCK)
            + " / #" + GLASS_TAG.location()
            + " / " + net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(TOP_BLOCK);
    }

    @Nullable
    private static net.minecraft.world.level.block.Block resolveBlock(String id) {
        ResourceLocation rl = id == null ? null : ResourceLocation.tryParse(id);
        if (rl == null) {
            return null;
        }
        net.minecraft.world.level.block.Block block =
            net.minecraft.core.registries.BuiltInRegistries.BLOCK.get(rl);
        if (block == null || block == Blocks.AIR) {
            MirrorGravity.LOGGER.warn("[镜维度·传送门] 结构材料 ID 解析失败: {}", id);
            return null;
        }
        return block;
    }

    /** 结构校验结果：全部正确。 */
    public static final String OK = "ok";

    /** 结构校验结果：中心那一格是传送门方块，已经点燃过了。 */
    public static final String ALREADY = "already";

    /**
     * 校验以 {@code center} 为「中间层中心」的 3×3×3 结构。
     *
     * @return {@link #OK} / {@link #ALREADY}，或一个错误码
     *         （{@code not_glass} / {@code middle_not_air} /
     *          {@code bottom_wrong} / {@code top_wrong}）
     */
    public static String validate(Level level, BlockPos center) {
        BlockState mid = level.getBlockState(center);

        /* 已经点燃过：幂等，不当作错误 —— 免得玩家反复右键时刷一堆报错。 */
        if (mid.is(MirrorBlocks.MIRROR_PORTAL.get())) {
            return ALREADY;
        }
        if (!mid.is(GLASS_TAG)) {
            return "not_glass";
        }

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) {
                    continue;   // 中心那格已经查过
                }
                if (!level.getBlockState(center.offset(dx, 0, dz)).isAir()) {
                    return "middle_not_air";
                }
                if (!level.getBlockState(center.offset(dx, -1, dz)).is(BOTTOM_BLOCK)) {
                    return "bottom_wrong";
                }
                if (!level.getBlockState(center.offset(dx, 1, dz)).is(TOP_BLOCK)) {
                    return "top_wrong";
                }
            }
        }
        return OK;
    }

    /** 错误码 → 给玩家看的中文说明（脚本直接取用，避免两处维护文案）。 */
    public static String describe(String code) {
        return switch (code) {
            case OK -> "结构正确";
            case ALREADY -> "这里已经是传送门了";
            case "not_glass" -> "中心那一格必须是玻璃";
            case "middle_not_air" -> "中间层的其余 8 格必须是空气";
            case "bottom_wrong" -> "最下面一层 3×3 必须是磨制黑石";
            case "top_wrong" -> "最上面一层 3×3 必须是平滑石英块";
            case "not_server" -> "只能在服务端点燃";
            default -> code;
        };
    }

    /**
     * 尝试点燃：校验通过就把中心那格换成传送门方块。
     *
     * @return {@link #OK} 表示点燃成功；{@link #ALREADY} 表示早就点过了；
     *         其余为错误码
     */
    public static String tryIgnite(ServerLevel level, BlockPos center) {
        String code = validate(level, center);
        if (!OK.equals(code)) {
            return code;
        }

        level.setBlockAndUpdate(center, MirrorBlocks.MIRROR_PORTAL.get().defaultBlockState());

        /* 点燃反馈：用原版自己的两个音效（玻璃碎裂 + 传送门触发），
         * 不新增自定义音效 —— 这一步只是"玻璃变成门"，用现成的最稳。 */
        level.playSound(null, center, net.minecraft.sounds.SoundEvents.GLASS_BREAK,
            net.minecraft.sounds.SoundSource.BLOCKS, 0.7F, 1.4F);
        level.playSound(null, center, net.minecraft.sounds.SoundEvents.PORTAL_TRIGGER,
            net.minecraft.sounds.SoundSource.AMBIENT, 0.6F, 1.2F);

        MirrorGravity.LOGGER.info("[镜维度·传送门] 已在 {} 点燃传送门（结构 3×3×3）", center);
        return OK;
    }

    /* ------------------------------------------------------------------ */
    /* 到达侧自动建门                                                       */
    /* ------------------------------------------------------------------ */

    /**
     * 建门时要避开的 Y 值（世界生成的玻璃层）。
     *
     * <p>结构占 {cy-1, cy, cy+1} 三层，压到玻璃层上会在"上下界面 /
     * 镜内外分界"那几层玻璃上开个洞。由 KubeJS 侧用
     * {@code layout.glass_layers} 收集后推过来（唯一真相在配置里）。
     */
    private static volatile int[] avoidYs = new int[0];

    /** 设置"建门时避开的 Y 值"，参数是逗号分隔的整数串，如 {@code "63,62,1,0,-1,-2"}。 */
    public static void setAvoidY(String csv) {
        if (csv == null || csv.isBlank()) {
            avoidYs = new int[0];
            return;
        }
        String[] parts = csv.split(",");
        int[] ys = new int[parts.length];
        int n = 0;
        for (String p : parts) {
            try {
                ys[n++] = Integer.parseInt(p.trim());
            } catch (NumberFormatException ignored) {
                // 单个值写错就跳过，不影响其它
            }
        }
        avoidYs = java.util.Arrays.copyOf(ys, n);
        MirrorGravity.LOGGER.info("[镜维度·传送门] 建门避让层已设为 {}", java.util.Arrays.toString(avoidYs));
    }

    /** 该 Y 放 3×3×3 会不会压到玻璃层。 */
    private static boolean conflicts(int cy) {
        for (int y : avoidYs) {
            if (y >= cy - 1 && y <= cy + 1) {
                return true;
            }
        }
        return false;
    }

    /** 从 {@code wantY} 出发，向上/向下找最近的、不会压到玻璃层的高度。 */
    public static int safeCenterY(int wantY) {
        if (!conflicts(wantY)) {
            return wantY;
        }
        for (int d = 1; d <= 16; d++) {
            if (!conflicts(wantY + d)) {
                return wantY + d;
            }
            if (!conflicts(wantY - d)) {
                return wantY - d;
            }
        }
        return wantY;   // 实在找不到就照原样（宁可压玻璃也别把玩家扔进虚空）
    }

    /**
     * 在 {@code center} 处**直接造一座完整的传送门**（不管原来是什么方块）。
     *
     * <p>与 {@link #tryIgnite} 的区别：那个是"玩家搭好结构、我验证并点燃"，
     * 这个是"到达侧什么都没有，我从零盖一座"。
     *
     * <p>盖完的形状与玩家自己搭的一模一样：下 3×3 底块、中间 8 格空气 +
     * 中心传送门、上 3×3 顶块。
     *
     * @return 实际使用的中心坐标（Y 可能因为避让玻璃层被挪过）
     */
    public static BlockPos buildPortal(ServerLevel level, BlockPos center) {
        int cy = safeCenterY(center.getY());
        BlockPos c = new BlockPos(center.getX(), cy, center.getZ());
        try {
            BlockState bottomState = BOTTOM_BLOCK.defaultBlockState();
            BlockState topState = TOP_BLOCK.defaultBlockState();
            BlockState airState = Blocks.AIR.defaultBlockState();
            BlockState portalState = MirrorBlocks.MIRROR_PORTAL.get().defaultBlockState();

            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    level.setBlock(c.offset(dx, -1, dz), bottomState, 3);
                    level.setBlock(c.offset(dx, 1, dz), topState, 3);
                    boolean isCentre = (dx == 0 && dz == 0);
                    level.setBlock(c.offset(dx, 0, dz), isCentre ? portalState : airState, 3);
                }
            }

            level.playSound(null, c, net.minecraft.sounds.SoundEvents.PORTAL_TRIGGER,
                net.minecraft.sounds.SoundSource.AMBIENT, 0.7F, 1.0F);
            MirrorGravity.LOGGER.info("[镜维度·传送门] 已在 {} 自动建门（到达侧）", c);
        } catch (Throwable t) {
            /* 建门失败**不能**把传送本身也毁掉：宁可让玩家落在空地上，
             * 也不能因为写方块出错就不传送（那会让人卡在门里来回触发）。 */
            MirrorGravity.LOGGER.warn("[镜维度·传送门] 到达侧建门失败（仍会传送）: {}", t.toString());
        }
        return c;
    }

    /** 传送门的"站立等待时间"：与地狱门共用同一组 gamerule。 */
    public static int transitionTime(ServerLevel level, Entity entity) {
        if (entity instanceof Player player) {
            return Math.max(1, level.getGameRules().getInt(
                player.getAbilities().invulnerable
                    ? GameRules.RULE_PLAYERS_NETHER_PORTAL_CREATIVE_DELAY
                    : GameRules.RULE_PLAYERS_NETHER_PORTAL_DEFAULT_DELAY));
        }
        return 0;   // 非玩家立即传送（与地狱门一致）
    }
}
