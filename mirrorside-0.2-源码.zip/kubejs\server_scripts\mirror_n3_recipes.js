// =====================================================================
// 镜维度 · 重力方块配方（"靠反复坠落加工"的机制）
// =====================================================================
// 玩法设想：
//   把重力方块（沙砾/沙子）放在上半区，它会落下、在交界处反转、升回上界、
//   再次反转……来回切换够次数后变成另一种方块。
//
// 两类触发方式（配置项 trigger）：
//   'crossing' —— 切换够次数的**那一刻**在交界处直接变
//   'landing'  —— 切换够次数后，还要**接触**到指定方块才变
//                 （例如沙子要落在黑色玻璃上才变石英块）
//
// 本模块只负责"配方"这一件事：
//   · 配方注册表与匹配
//   · 方向切换的计数（两种计数方式）
//   · 把下落的方块替换成产物
// 它**不做**方向下发（那是 n4），也不做实体扫描（那是 n5 的调用方）。
//
// 配方的三种产物形态（详见 addRecipe）：
//   写死的 ID      —— 变成那个方块
//   '@landed'      —— 变成"落在的那个方块"（铁砧落在矿物块上 → 变成那一块）
//   '@mapped'      —— 按 map 表把落点翻成产物（脚手架落在树叶上 → 对应树苗）
// 其中 drop:true 的配方产物以**掉落物**形式弹出，而不是原地放成方块。
//
// 落点（on）可以写**一组**（数组，元素是方块 ID 或 '#标签'）：
// 因为父标签不一定聚合得到 —— 实测 AnvilCraft 的 c:storage_blocks 只收了
// raw_zinc_block，另外 6 种粗矿块只在 c:storage_blocks/raw_xxx 子标签里。
//
// ⚠️ 所有 try 块内只用 var（Rhino 对 try 里的 const/let 会抛
//    InternalError: TypeError: redeclaration of var xxx）
// =====================================================================

const MirrorRecipes = (() => {

  const N0 = global.MirrorDimension.modules.n0;
  const N1 = global.MirrorDimension.modules.n1;
  if (N0 === undefined || !N0.ready || N1 === undefined || !N1.ready) {
    console.error('[镜维度] 依赖模块未就绪，配方模块未启用。');
    return { ready: false };
  }

  const MD = global.MirrorDimension;
  const cfg = N0.cfg;
  const MG_API = N0.selfModApi;
  const entityKey = N0.entityKey;
  const tryLoadClass = N0.tryLoadClass;
  const blockIdOf = N0.blockIdOf;
  const isFallingBlock = N0.isFallingBlock;

  /* 状态表（由 n1 集中持有 —— 不要在本模块里另建一份，
   * 否则会出现"同一个概念两个副本、只有一个被清理"） */
  const recipeState = N1.recipeState;
  const lastHalf = N1.lastHalf;
  const lastFlipDir = N1.lastFlipDir;
  const swingRange = N1.swingRange;

  /* ------------------------------------------------------------------ */
  /* 配方注册表                                                          */
  /* ------------------------------------------------------------------ */
  /* 配方形状与 KubeJS 的其它配方一致（一个对象 + 一个注册接口），便于扩展：
   *
   *   MirrorSetting.recipes.add({
   *     id: 'gravel_to_iron',
   *     input: 'minecraft:gravel',        // 下落的方块原始方块
   *     output: 'minecraft:iron_block',   // 变成什么
   *     crossings: 2,                     // 需要切换几次
   *     trigger: 'crossing',              // 或 'landing'
   *     on: 'minecraft:black_stained_glass',  // 仅 landing 需要
   *     at: 'lower',                      // 可选：只算下界面/上界面
   *   });
   *
   * 也可以在初始化时注册：
   *   MirrorSetting.onRegisterRecipes(e => e.add({...}))
   */

  const recipes = [];
  const recipeListeners = [];

  /**
   * 解析配方的 `insert` 段：「落在容器上时往容器里塞物品」。
   *
   * <pre>
   *   insert: {
   *     items: ['minecraft:arms_up_pottery_sherd', ...],  // 随机取一个
   *     count: 1,        // 放几个（默认 1）
   *     force: false,    // 容器装不下时是否仍然触发（默认 false = 不触发）
   *   }
   * </pre>
   *
   * ⚠️ 默认 `force: false` 是刻意的：容器满时若照样把下落的方块换成产物，
   * 那一个物品就白扔了。默认行为是"继续往复，等容器腾出位置"。
   */
  function parseInsert(spec) {
    if (spec == null) return null;
    const items = Array.isArray(spec.items) ? spec.items.map(String) : [];
    if (items.length === 0) {
      console.error('[镜维度] 配方的 insert 段没有写 items（随机候选列表），它永远不生效。');
      return null;
    }
    return {
      items: items,
      count: spec.count != null ? Math.max(1, spec.count) : 1,
      force: spec.force === true,
    };
  }

  function addRecipe(spec) {
    if (spec == null || spec.input == null || spec.output == null) {
      console.error('[镜维度] 配方无效，必须同时有 input 与 output: ' + JSON.stringify(spec));
      return null;
    }
    /* 产物写法三种：
     *   'minecraft:iron_block'  写死的方块 / 物品
     *   '@landed'               变成"落在的那个方块"
     *                           （铁砧落在矿物块上 → 变成那一块）
     *   '@mapped'               按 map 表把**落点**翻译成产物
     *                           （脚手架落在树叶上 → 对应树苗）
     *                           map 里没有的落点**不触发**，方块继续往复；
     *                           刻意不让它退化成"变成落点本身"（那会变成树叶） */
    const rawOutput = String(spec.output);
    const dynamicOutput = (rawOutput === '@landed');
    const mappedOutput = (rawOutput === '@mapped');

    /* on 可以写**一条**，也可以写**一组**。
     *
     * 写一组是为了表达"落在任意一种…上"，而且有时父标签聚合不到：
     * 实测 AnvilCraft 的 c:storage_blocks 父标签里只有 raw_zinc_block，
     * 另外 6 种粗矿块（raw_lead / raw_silver / raw_tin / raw_titanium /
     * raw_tungsten / raw_uranium）只登记在 c:storage_blocks/raw_xxx 子标签里，
     * 所以铁砧那条配方必须把子标签一并列上，否则那 6 种粗矿块永远没反应。 */
    const rawOnList = Array.isArray(spec.on)
      ? spec.on.map(String)
      : (spec.on != null ? [String(spec.on)] : []);

    /* map：'落点方块 ID' → '产物 ID'。只有 output 写 '@mapped' 时才用。
     * 键必须是**具体方块 ID**（不能写标签）：它的语义是查表，
     * 而"哪些落点算数"已经由 on 负责了。 */
    const mapSpec = (spec.map != null && typeof spec.map === 'object') ? spec.map : null;

    const r = {
      id: spec.id != null ? String(spec.id) : (String(spec.input) + '->' + rawOutput),
      input: String(spec.input),
      output: rawOutput,
      dynamicOutput: dynamicOutput,
      mappedOutput: mappedOutput,
      crossings: spec.crossings != null ? Math.max(1, spec.crossings) : 1,
      trigger: spec.trigger != null ? String(spec.trigger) : 'crossing',
      /* on 保留"第一条"给日志与老代码看，真正判定用 onList。 */
      on: rawOnList.length > 0 ? rawOnList[0] : null,
      onList: rawOnList,
      /* on 以 # 开头 = 标签查询（例：'#c:storage_blocks' = 任意矿物块/金属块）。
       * 标签判定放在模组侧做（见 MirrorGravityApi.blockStateHasTag）。 */
      onIsTag: rawOnList.length > 0 && rawOnList[0].charAt(0) === '#',
      map: mapSpec,
      /* drop:true = 产物以**掉落物**形式弹出，而不是原地放成方块。
       * 用于树苗 / 地狱疣这类"要能捡走"的产物。 */
      drop: spec.drop === true,
      /* hint：可选的一句话提示，只在 `/mirror recipes <关键词>` 里显示。
       *
       * 为什么需要它：有些配方"不生效"的原因**不在配置里**，而在方块自己的
       * 原版规则上 —— 最典型的是脚手架：`ScaffoldingBlock` 只在下方 6 格内
       * 没有任何结实支撑时才变成下落实体，所以"把脚手架摆在灵魂土上方"
       * 这种最自然的摆法它压根不会掉，而且没有任何报错。
       * 这类前提写在代码注释里没人看得到，放进这个字段就能在游戏里查到。 */
      hint: spec.hint != null ? String(spec.hint) : null,
      insert: parseInsert(spec.insert),
      minY: spec.min_y != null ? spec.min_y : null,
      maxY: spec.max_y != null ? spec.max_y : null,
      // 判定发生在哪一侧交界：'lower'（下界面）/ 'upper'（上界面）/ null（两侧都算）
      at: spec.at != null ? String(spec.at) : null,
    };
    /* landing 而不写 on 是**静默失效**的典型：它永远不会触发，
     * 而且没有任何报错。这里主动提示。 */
    if (r.trigger === 'landing' && r.onList.length === 0) {
      console.error('[镜维度] 配方 ' + r.id + ' 是 landing 触发，但没有写 on（落在哪种方块上），'
        + '它永远不会生效。');
    }
    /* '@mapped' 而不写 map 同样是静默失效：查不到产物，永远不触发。 */
    if (r.mappedOutput && r.map == null) {
      console.error('[镜维度] 配方 ' + r.id + ' 的产物是 @mapped，但没有写 map（落点 → 产物 的对照表），'
        + '它永远不会生效。');
    }
    if (MG_API != null && MG_API.blockStateHasTag == null) {
      var wantsTag = false;
      for (var ti = 0; ti < r.onList.length; ti++) {
        if (r.onList[ti].charAt(0) === '#') wantsTag = true;
      }
      if (wantsTag) {
        console.error('[镜维度] 配方 ' + r.id + ' 用了标签 ' + r.on
          + '，但模组没有提供 blockStateHasTag —— 请更新 mirrorside jar。');
      }
    }
    /* 落点写的是**具体方块 ID** 时，当场核对它到底存不存在。
     *
     * 为什么值得做：落点 ID 写错（少个下划线、把 nether_wart 写成
     * nether_wart_block 之类）的表现是"方块一直往复、什么都不发生"，
     * 与"摆错位置"完全一样，而且没有任何报错 —— 这个项目已经在这上面
     * 栽过两次。在这里核对一次，就能把这类错误变成**加载期的一条 error**。
     *
     * 用 try 包住：注册表在某些早期时机可能还拿不到，拿不到就跳过核对，
     * 绝不能因为"体检"把配方本身弄失效。 */
    for (var ci = 0; ci < r.onList.length; ci++) {
      var chk = r.onList[ci];
      if (chk.charAt(0) === '#') continue;
      try {
        /* 优先用模组的 blockIdExists（纯 Java 查注册表，最可靠）；
         * 模组是旧版时退回脚本侧查法。 */
        var exists;
        if (MG_API != null && MG_API.blockIdExists != null) {
          exists = MG_API.blockIdExists(chk);
        } else {
          var BIR = tryLoadClass('net.minecraft.core.registries.BuiltInRegistries');
          var rlOn = (MD != null && MD.id != null) ? MD.id(chk) : null;
          exists = (BIR == null || rlOn == null || BIR.BLOCK == null)
            ? null : (BIR.BLOCK.containsKey(rlOn) === true);
        }
        if (exists === false) {
          console.error('[镜维度] 配方 ' + r.id + ' 的落点方块 ID 不存在: ' + chk
            + ' —— 这条配方永远不会触发。请核对方块 ID（用 F3 看世界里的真实 ID）。');
        }
      } catch (errChk) {
        // 注册表不可用时跳过核对
      }
    }
    recipes.push(r);
    return r;
  }

  /** 开发者入口：其它脚本/模组可以在这里注册配方。 */
  function onRegisterRecipes(fn) {
    recipeListeners.push(fn);
  }

  /* 装载配置里的配方，然后跑监听器。
   * 配置结构（见 mirror_config.js）：
   *   gravityBlockRecipes: { enabled: true, list: [ {...} ] }
   * 兼容旧写法：顶层直接是数组。 */
  const GBR = cfg.gravityBlockRecipes;
  const recipeSpecs = Array.isArray(GBR) ? GBR
    : (GBR != null && Array.isArray(GBR.list) ? GBR.list : []);
  for (const spec of recipeSpecs) {
    addRecipe(spec);
  }
  for (const fn of recipeListeners) {
    try {
      fn({ add: addRecipe, list: () => recipes.slice() });
    } catch (err) {
      console.error('[镜维度] 配方注册回调失败: ' + err);
    }
  }

  /* 配方总开关：关掉时下落的方块只做纯重力往复，不会变方块。
   * 调"运动是否干净"时应该关掉，否则配方会在半途把实体换掉、干扰观察。 */
  const RECIPES_ON = (GBR != null && GBR.enabled === true);
  if (RECIPES_ON && recipes.length > 0) {
    console.info('[镜维度] 重力方块配方已启用 ' + recipes.length + ' 条: '
      + recipes.map(r => r.input + '→' + r.output + '(×' + r.crossings + ')').join('，'));
  } else if (recipes.length > 0) {
    console.info('[镜维度] 重力方块配方已加载 ' + recipes.length
      + ' 条，但当前**已关闭**（gravityBlockRecipes.enabled = false）');
  }

  /**
   * 找一个匹配的配方。
   *
   * @param side 本次切换发生在哪一侧（'lower' / 'upper'），仅 crossing 用
   * @param mode 'crossing' 或 'landing'
   *
   * ⚠️ 次数比较对两种触发方式是**不同语义**的，这点踩过坑：
   *
   *   · crossing —— 必须**精确等于**。它就在切换那一瞬间发生，
   *     等号两边天然对齐。
   *
   *   · landing —— 必须**大于等于**。曾经误用精确等于，结果：
   *     沙子达到 3 次时未必正贴着黑玻璃（那一刻多半在分界线上方空中），
   *     等它下次回到玻璃附近，计数已经涨到 4 —— 条件再也不成立，
   *     于是永远等不到。实测现象："已达 3 次，正在等待落在黑玻璃上"
   *     之后再无下文。 */
  /**
   * 找**所有**匹配的配方（按配置里的顺序）。
   *
   * <p>为什么要返回一组而不是一条：同一个输入可以有多条 landing 配方，
   * 区别只在**落在什么上面** —— 脚手架 4 次切换后落在树叶上出树苗、
   * 落在灵魂沙上出地狱疣，就是这种形状。
   * 而"落点"必须到实体旁边去查方块才知道，本函数拿不到那个信息。
   * 早先这里只返回第一条，于是**第二条永远不会被考虑**：
   * 表现是"其中一种落点完全没反应"，且没有任何报错。
   *
   * @param side 本次切换发生在哪一侧（'lower' / 'upper'），仅 crossing 用
   * @param mode 'crossing' 或 'landing'
   */
  function matchRecipeAll(blockId, crossings, side, mode) {    const out = [];
    for (const r of recipes) {
      if (r.input !== blockId) continue;
      if (mode === 'landing') {
        if (crossings < r.crossings) continue;
      } else {
        if (crossings !== r.crossings) continue;
      }
      if (r.trigger !== mode) continue;
      if (r.at != null && r.at !== side) continue;
      out.push(r);
      /* crossing 是"切换那一刻"发生的，一次只能变一种方块；
       * 同输入同次数写了多条属于配置冲突，第一条生效并提示。 */
      if (mode !== 'landing') {
        if (out.length > 1) {
          console.error('[镜维度] ' + blockId + ' 有 ' + out.length
            + ' 条 crossing 配方都要求切换 ' + crossings + ' 次，只有第一条会生效：'
            + out.map(x => x.id).join(' / '));
        }
        break;
      }
    }
    return out;
  }

  /** 只取第一条（crossing 用；语义上它就该是唯一的）。 */
  function matchRecipe(blockId, crossings, side, mode) {
    const all = matchRecipeAll(blockId, crossings, side, mode);
    return all.length > 0 ? all[0] : null;
  }

  /* ------------------------------------------------------------------ */
  /* 计数方式一：读模组实际方向（推荐）                                    */
  /* ------------------------------------------------------------------ */
  /* 为什么以模组方向为准：
   * 另一套计数（下面的 trackCrossing）靠"y 是否越过一条线"来**推断**
   * 实体有没有换边，而模组实际是按"带迟滞的状态机"翻转的：
   *
   *   模组：出带才翻 → 下折点 splitY-band，上折点 splitY+band
   *   脚本：y > line 就算换边
   *
   * 两套判定的参考线不同，于是出现"视觉上来回好几次、计数只涨 1"。
   * 更糟的是迟滞带一调、上折点就移动，而那条线是写死的 ——
   * 每次为了摆幅去改 falling_hysteresis，计数行为都会跟着漂。
   *
   * 改成直接读方向之后：
   *   · 计数 == 实际的方向切换，视觉与程序天然统一
   *   · falling_hysteresis 可以随意调幅度，不再牵动计数
   *   · 对所有实体通用（掉落物 / 玩家 / 生物同一套） */

  /* ------------------------------------------------------------------ */
  /* 计数用的"身份键"：**一个下落实体一个键**                              */
  /* ------------------------------------------------------------------ */
  /* ⚠️⚠️ 这一节是一次**回归事故**的结论，动它之前先读完 ⚠️⚠️
   *
   * 起因：脚手架这类方块"碰一下就会重生"（原版把它放回世界，下一 tick 再掉，
   * 是**新实体、新 UUID**），按实体计的次数会归零。于是曾经把它的计数键
   * 从"实体 id"改成"**竖列**"（方块 ID + X/Z），想让进度跨重生延续。
   *
   * 结果（2026-09-22 15:22 实测）出现两个致命后果：
   *
   *   ① 同一竖列里的多个脚手架**共用一个计数器** —— 谁翻一下都算进同一个数。
   *   ② 更糟：连"上一次方向"也跟着共用。两个实体方向相反，
   *      于是脚本每处理一个，就与另一个留下的方向不同 → **每 tick 记一次假翻转**。
   *
   *   日志现场（同一竖列里两个脚手架）：
   *      15:22:28.274  已切换 4 次 … y=14.1   方向=down
   *      15:22:28.323  已切换 5 次 … y=-1.99  方向=up    ← 49ms 后 y 差 16 格 = 另一个实体
   *      15:22:28.338  已切换 6 次 … y=13.64  方向=down
   *      15:22:28.373  已切换 8 次，触发交界处加工（y=13.1）→ 蜘蛛网
   *   0 → 8 只用了一秒；用户连放 10 个脚手架后，蜘蛛网每 100ms 出一个。
   *   而"4 次切换 + 落在灵魂沙上 → 下界疣"永远抢不到那 4 次 ——
   *   计数早就被推到 8，crossing 配方先把实体收走了。
   *
   * ⇒ 结论：**计数键必须是实体 id（一个实体一份）**，原因：
   *     · 每个脚手架各算各的，互不干扰（这正是不共用状态的意义）
   *     · "上一次方向"这种状态天然只能属于一个实体，共用必然是错的
   *     · 玩家另放一个也不再需要任何特殊处理：新实体天然就是新键
   *
   * ⇒ 那"重生丢进度"呢？当时还配套做了 sticky（"这一趟碰到过就算数"）。
   *    两者都已随那条 "脚手架 → 地狱疣" 配方一起**删除**（2026-09-22 放弃，见 README 14.22）：
   *    为一条配方维护两套专用机制不划算，而脚手架剩下的两条配方
   *    只依赖"次数"与"落点"，不需要它们。
   */
  function stateKeyOf(entity) {
    return entityKey(entity);
  }

  /* ------------------------------------------------------------------ */
  /* ⛔ 「sticky（这一趟碰到过落点就算数）」的机制已删除。                  */
  /* ------------------------------------------------------------------ */
  /* 它原本只为一条配方服务：「脚手架 + 4 次切换 + 碰到灵魂沙 → 地狱疣」。
   * 2026-09-22 那条配方被放弃，机制随之整段移除 —— 不留只服务一条配方的
   * 专用路径（它会让 landing 的语义变成"只要蹭过一次"，而且需要配合
   * "跨重生继承计数"，而后者一旦按位置共用状态就会出大问题）。
   *
   * 这条配方的完整复盘见 README 14.17 / 14.21 / 14.22。 */


  /**
   * 读模组当前方向，与上次不同则计一次"重力切换"。
   * @returns 本次是否发生了切换；读不到方向时返回 false
   */
  function trackDirectionFlip(entity) {
    if (MG_API == null || MG_API.currentDirection == null) return false;
    const key = stateKeyOf(entity);
    var dir = null;
    try {
      dir = MG_API.currentDirection(entity);
    } catch (err) {
      return false;
    }
    if (dir == null) return false;

    const prev = lastFlipDir[key];
    lastFlipDir[key] = dir;
    if (prev == null || prev === dir) return false;   // 首次见到只记基线

    const st = recipeState[key] || (recipeState[key] = { crossings: 0 });
    st.crossings++;
    return true;
  }

  /* 计数方式总开关（配置项 gravity.count_mode）：
   *   'flip'     —— 以模组实际方向变化为准（推荐，视觉与程序统一）
   *   'crossing' —— 旧的"跨过一条线"判定（保留以便对比/回退）
   * 两者只能有一个生效，否则同一次翻转会被计两次。 */
  const COUNT_MODE = (cfg.gravity.count_mode != null)
    ? String(cfg.gravity.count_mode) : 'flip';
  const USE_FLIP_COUNT = (COUNT_MODE === 'flip') && MG_API != null
    && MG_API.currentDirection != null;

  /* ------------------------------------------------------------------ */
  /* 计数方式二：跨过参考线（旧方案，保留可回退）                          */
  /* ------------------------------------------------------------------ */

  /**
   * 实体是否跨过了参考线所分的半区。
   * @returns 计数是否 +1
   */
  function trackCrossing(entity) {
    const key = stateKeyOf(entity);
    /* ⚠️ 下落的方块用 FALLING_SPLIT（= -1.0），其余实体用 GLASS_SPLIT（= 0）。
     *
     * 为什么必须分开：模组只对下落的方块把参考线下移了一格。
     * 沙砾因此永远到不了 y=0，若这里统一用 GLASS_SPLIT，
     * 它的穿越计数就永远停在 1。 */
    const line = isFallingBlock(entity) ? N0.fallingSplit : N0.splitY;
    const half = entity.y > line ? 'upper' : 'lower';
    const prevHalf = lastHalf[key];

    if (prevHalf == null) {
      lastHalf[key] = half;      // 首次见到只记基线，否则生成瞬间就会计一次
      return false;
    }
    if (prevHalf === half) return false;

    lastHalf[key] = half;
    const st = recipeState[key] || (recipeState[key] = { crossings: 0 });
    st.crossings++;
    return true;
  }

  /* ------------------------------------------------------------------ */
  /* 摆幅统计（诊断）                                                     */
  /* ------------------------------------------------------------------ */
  /* 用途：回答"沙砾到底有没有越过某条线、摆幅多大"。
   * 这是唯一能替代肉眼观察的数据来源 —— 用户无法用眼睛判断
   * 一个高速往复的方块有没有跨过 0 高度。 */

  const SWING_LOG_EVERY = 20;

  function trackSwing(entity) {
    const key = stateKeyOf(entity);
    const y = entity.y;
    const s = swingRange[key] || (swingRange[key] = { min: y, max: y, n: 0, crossings: 0 });
    if (y < s.min) s.min = y;
    if (y > s.max) s.max = y;
    s.n++;
    /* 上一 tick 的世界 y —— 给接触判定的"预判"用（见 groundBlockAt）。
     * 这里拿到的是**世界**位移，天然绕开了 Pondus 的本地坐标约定。 */
    const prevY = s.prevY;
    s.prevY = y;
    s.vy = (prevY == null) ? 0 : (y - prevY);
    const crossings = recipeState[key] != null ? recipeState[key].crossings : 0;
    if (s.n % SWING_LOG_EVERY !== 0 && crossings === s.crossings) return;
    s.crossings = crossings;
    console.info('[镜维度·摆幅] ' + fallingBlockIdOf(entity)
      + ' 最高 y=' + Math.round(s.max * 100) / 100
      + ' 最低 y=' + Math.round(s.min * 100) / 100
      + ' 摆幅=' + Math.round((s.max - s.min) * 100) / 100
      + ' 格，切换 ' + crossings + ' 次，反转线 y=' + N0.fallingSplit);
  }

  /* ------------------------------------------------------------------ */
  /* 方块 ID 读取                                                        */
  /* ------------------------------------------------------------------ */

  /** 读下落的方块携带的方块 ID。失败返回 null。 */
  function fallingBlockIdOf(entity) {
    try {
      return blockIdOf(entity.getBlockState());
    } catch (err) {
      return null;
    }
  }

  /* ------------------------------------------------------------------ */
  /* landing 触发：靠"接触指定方块"加工                                    */
  /* ------------------------------------------------------------------ */
  /* ⚠️ 判定用的是"**接触**"，不是"停稳"，也不是"接近"。
   *
   * 四代判定的取舍（都被实测检验过）：
   *   ① "停稳" —— 不行。模组的着陆补丁只连续确认 3 tick 就把方块放回世界，
   *      停稳后只剩 1 帧窗口去抢在它前面替换，极易错过。
   *   ② "接近"（窗口 4 格）—— 用户实测否掉了：
   *      "沙子哪怕跟黑色玻璃隔着三四格空气也会变成石英块"，
   *      看起来不像加工，像隔空取物。
   *   ③ "接触"（脚下/头上那一格）—— 方向对了，但**几何算错了**：
   *      getY() 是碰撞箱底面，于是"向上贴天花板"那一侧只剩 0.02 格宽的窗口，
   *      从下方靠近的整段全部漏判（脚手架 + 灵魂土就是这么失效的）。
   *   ④ "接触"（现在）—— 按**碰撞箱实际占的格子**取上下相邻格，
   *      两侧都是完整的 1 格窗口；再加上运动方向的 1 格预判，
   *      专门对付"原生重力下最快 2 格/tick、一帧跨过接触瞬间"。
   *
   * 竞态说明：本函数在实体 tick **之前**运行，因此一定早于模组放回方块，
   * 不会出现"先变回沙砾、再想加工"的情况。
   * （但**上半区**是原版在管，它落地当帧就把方块放回世界、没有 3 tick 宽限，
   *  所以那一侧完全靠上面那条 1 格预判兜住。） */

  /** 运动方向上的预判格数（配置项 gravity.landing_lookahead，默认 1）。
   *  1 = 再认"下一 tick 一定会贴上"的那一格，专治高速下落一帧跳过接触瞬间。
   *
   *  「接触」本身的窗口不再是可调项：它固定为**碰撞箱实际占的格子的上下相邻格**。
   *  见 groundBlockAt 顶部说明。 */
  const LANDING_LOOKAHEAD = (cfg.gravity != null && cfg.gravity.landing_lookahead != null)
    ? Math.max(0, Math.min(2, Number(cfg.gravity.landing_lookahead)))
    : 1;

  /** 找实体**碰撞箱上下相邻**的那两格，以及运动方向上的预判格，
   *  看有没有满足配方要求的方块。
   *
   * ⚠️ 为什么上下都查，而不是按重力方向猜：
   * 模组在**上半区完全不介入**（交给原版，落点在下方），
   * 只在**下半区**接管（反重力朝上，落点在上方）。
   * 脚本这边拿不到模组的半区状态，猜错一侧就会永远匹配不上。
   * 两侧都查最简单也最可靠。
   *
   * 支持两种写法（onList 里可以混着写，逐条试）：
   *   on: 'minecraft:furnace'     —— 比对具体方块 ID
   *   on: '#c:storage_blocks'     —— 标签查询（把状态交给模组判定，
   *                                  因为脚本侧构造 TagKey 这条路没有先例）
   *   on: ['#c:storage_blocks', '#c:storage_blocks/raw_tin', ...]  —— 一组
   *
   * @returns 命中的目标方块信息 { id, x, y, z }；没有返回 null */
  function groundBlockAt(entity, recipe) {
    try {
      var BlockPos = tryLoadClass('net.minecraft.core.BlockPos');
      if (BlockPos == null) return null;
      var x = entity.getX();
      var y = entity.getY();
      var z = entity.getZ();
      var level = entity.level;
      if (level == null) return null;
      var wants = recipe.onList != null ? recipe.onList : [];
      if (wants.length === 0) return null;

      /* ⚠️⚠️ 探针怎么放，决定了这个机制可不可靠（这一版重写过）⚠️⚠️
       *
       * 旧写法是 BlockPos.containing(x, y±1, z)，也就是"脚下那一格和头上那一格"。
       * 它有个**致命的几何偏差**：`entity.getY()` 是碰撞箱的**底面**，不是格子中心。
       * 拿"向上贴天花板"这一侧算（镜维度下半区正是这种情况）：
       *     天花板在 y=S，实体贴上时碰撞箱是 [S-0.98, S]，
       *     于是 y+1 = S+0.02 → floor 才是 S。
       *   也就是说**只有实体完全贴住的那 0.02 格内才判得到**，
       *   从下方一点点靠近的整段（S-1.98 ~ S-1.00）全部漏掉。
       *   加上模组的着陆补丁只连续确认 3 tick 就把方块放回世界，
       *   窗口本来就窄 —— 合起来就是"看着明明贴上了，配方却一次都不触发"。
       *
       * 现在改成按**碰撞箱实际占的格子**来算上下相邻格：
       *     minB = floor(box.minY)，maxB = floor(box.maxY - ε)
       *     下方相邻格 = minB - 1，上方相邻格 = maxB + 1
       * 天花板那一侧于是变成整整 1 格宽的窗口（y ∈ [S-1.98, S-0.98)），
       * 靠近的过程中必然被采到，不再依赖"刚好停住"。
       *
       * ε 是必须的：贴着时 box.maxY 正好等于 S，不减一点点就会算成 S+1。 */
      var height = 0.98;
      try {
        var h = entity.getBbHeight();
        if (h != null && h > 0) height = Number(h);
      } catch (errH) {
        // 取不到就用下落实体的默认高度
      }
      var EPS = 0.0001;
      var minB = Math.floor(y);
      var maxB = Math.floor(y + height - EPS);
      if (maxB < minB) maxB = minB;

      /* 预判：下落实体在原生重力下最快约 2 格/tick，可能一帧之内从
       * "还差两格"直接变成"已落地并被原版放回方块"，中间那个接触瞬间
       * **没有任何一帧采到过**。所以再往**运动方向**多看 landing_lookahead 格。
       *
       * ⚠️ 但**必须按实际速度开关**：固定多探 1 格会让慢速靠近时提前两格触发，
       * 那就成了用户明确否掉过的"隔空取物"。所以只有在"这一帧真的会跨过
       * 接触窗口"时才预判：速度越大，才允许多看越多格（上限 = 配置值）。
       * 速度取的是**上一 tick 的世界位移**（trackSwing 记的），
       * 因此不受 Pondus 本地坐标约定的影响。 */
      var look = LANDING_LOOKAHEAD;
      var vy = 0;
      try {
        var swing = swingRange[stateKeyOf(entity)];
        if (swing != null && swing.vy != null) vy = Number(swing.vy);
      } catch (errV) {
        vy = 0;
      }
      var speed = vy < 0 ? -vy : vy;
      /* 0.5 格/tick 是"一个 tick 内可能跳过 1 格接触窗口"的量级门槛。 */
      var lookEff = (look > 0 && speed > 0.5) ? Math.min(look, Math.ceil(speed)) : 0;

      var moveDir = null;
      if (lookEff > 0 && MG_API != null && MG_API.currentDirection != null) {
        try {
          moveDir = MG_API.currentDirection(entity);
        } catch (errD) {
          moveDir = null;
        }
      }

      /* 待查格子：① 碰撞箱**自己占的**格子 → ② 上下相邻 → ③ 运动方向预判。
       *
       * ⚠️ ① 是必须的：目标方块**不一定有碰撞箱**。地狱疣植株、火把、草、
       *    告示牌……这些方块没有碰撞，下落的方块会**直接从它中间穿过去**，
       *    只探"上下相邻"就会漏掉 —— 表现同样是"明明摆在那儿却匹配不上"。
       *    重叠是最强的接触，一定要算。 */
      var probes = [];
      for (var oy = minB; oy <= maxB; oy++) probes.push(oy);
      probes.push(minB - 1);
      probes.push(maxB + 1);
      if (moveDir != null) {
        if (moveDir === 'up') {
          for (var u = 1; u <= lookEff; u++) probes.push(maxB + 1 + u);
        } else if (moveDir === 'down') {
          for (var dn = 1; dn <= lookEff; dn++) probes.push(minB - 1 - dn);
        }
      }

      for (var p = 0; p < probes.length; p++) {
        var probeY = probes[p];
        var pos = BlockPos.containing(x, probeY, z);
        var state = level.getBlockState(pos);
        if (state == null) continue;
        var id = blockIdOf(state);
        /* 记一笔"探针在这条配方旁边见过什么方块"（见 probeSeen 的说明）。
         * 这一句是**排查用**的，不影响匹配。 */
        noteProbeSeen(recipe.input, id);
        for (var k = 0; k < wants.length; k++) {
          var want = wants[k];
          /* 两种写法都交给模组判定，脚本侧不碰 TagKey、也不做字符串比较：
           *   '#标签'        → blockStateHasTag（state.is(TagKey)）
           *   'minecraft:xx' → blockStateHasId（注册表比对）
           * 判定逻辑留在 Java 里只有一种语义，不会受 Rhino 的
           * 方法解析/字符串包装影响。 */
          var matched;
          if (want.charAt(0) === '#') {
            matched = (MG_API != null && MG_API.blockStateHasTag != null)
              && MG_API.blockStateHasTag(state, want);
          } else {
            matched = (MG_API != null && MG_API.blockStateHasId != null)
              ? MG_API.blockStateHasId(state, want)
              : (id != null && id === want);   // 模组是旧版时的兜底
          }
          if (matched) {
            return { id: id, x: pos.getX(), y: pos.getY(), z: pos.getZ() };
          }
        }
      }
      /* 没命中：把探针这一轮看到的方块留给 landingMissOnce 打日志。
       * 这是"落点对不上"唯一的现场证据（探针看到了什么 vs 配方要什么）。 */
      lastProbeDetail = lastProbeDetailOf(entity, probes);
      return null;
    } catch (err) {
      return null;
    }
  }

  /** 最近一次探针的详细现场（只给日志用）：每一格的坐标与方块 ID。 */
  var lastProbeDetail = null;

  function lastProbeDetailOf(entity, probes) {
    try {
      var BlockPos = tryLoadClass('net.minecraft.core.BlockPos');
      var level = entity.level;
      if (BlockPos == null || level == null) return null;
      var x = entity.getX();
      var z = entity.getZ();
      var parts = [];
      for (var i = 0; i < probes.length && i < 6; i++) {
        var pos = BlockPos.containing(x, probes[i], z);
        var state = level.getBlockState(pos);
        var bid = (state == null) ? '?' : blockIdOf(state);
        parts.push(probes[i] + '=' + (bid == null ? '?' : bid));
      }
      return parts.join('  ');
    } catch (err) {
      return null;
    }
  }

  /* ------------------------------------------------------------------ */
  /* 「探针旁边出现过哪些方块」—— 排查落点问题时最有用的一个表             */
  /* ------------------------------------------------------------------ */
  /* 为什么非要有它：landing 配方不生效只有两种可能，而它们在游戏里一样安静：
   *   ① 世界里那个方块**不是**配置里写的 ID（摆错了/名字相近的另一种方块）
   *   ② 它**不在下落实体的活动范围内**，根本碰不到
   * 只靠"没生效"分不出是哪一种。而把**探针实际见过的方块**列出来就一目了然：
   *   · 列表里**有**你摆的那个方块 → ID 对得上、也碰得到 → 那就是引擎的问题
   *   · 列表里**没有** → 要么 ID 不对（看看列表里真正的 ID 是什么），
   *     要么位置太远（对照"活动范围"那一行）
   * 上限 MAX 种，只记非空气（空气永远占满，记它没意义）。 */
  const probeSeen = {};
  const PROBE_SEEN_MAX = 8;

  function noteProbeSeen(input, blockId) {
    if (input == null || blockId == null || blockId === 'minecraft:air') return;
    var m = probeSeen[input] || (probeSeen[input] = {});
    m[blockId] = (m[blockId] || 0) + 1;
  }

  /** 取某个输入方块"旁边见过"的方块列表（按出现次数降序，最多 MAX 种）。 */
  function probeSeenList(input) {
    const m = probeSeen[input];
    if (m == null) return [];
    const out = [];
    for (const k in m) {
      if (Object.prototype.hasOwnProperty.call(m, k)) out.push({ id: k, n: m[k] });
    }
    out.sort(function (a, b) { return b.n - a.n; });
    return out.slice(0, PROBE_SEEN_MAX);
  }

  /* ------------------------------------------------------------------ */
  /* 「它这一列到底有什么」+「你要的方块是不是就差一格」                    */
  /* ------------------------------------------------------------------ */
  /* ★★ 为什么非要有它（一次真实事故）：
   *
   *   用户摆了一片灵魂沙（2×3 共 5 格，y=-4），下界疣配方**一次都不触发**，
   *   而同一层的树叶配方每次都触发。日志当时只有一句
   *   「全程探针一个方块都没见过」—— 看不出任何原因。
   *
   *   读存档量出来的真相：
   *     下落实体那一列 = x=-35, z=4   （它在 (-34.5, …, 4.5)，即 (-35, …, 4)）
   *     树叶摆在 (-35, -4, 4) ← 正好在这一列 ✓
   *     灵魂沙摆在 (-35,-4,2) (-34,-4,2) (-35,-4,3) (-34,-4,3) (-34,-4,4)
   *                          ← **一格都没落在这一列里** ✗
   *
   *   探针只扫**实体自己这一列**（`BlockPos.containing(x, y±n, z)`），
   *   所以差一格 = 永远碰不到，而现象与"配方坏了"完全一样。
   *
   *   于是这里补两件事，让日志自己把话说完：
   *     ① 报出它这一列实际有什么（答案往往是"一格方块都没有"）
   *     ② 在 3×3 水平邻域里找配方要的方块 —— 找得到就是"就差一格"，
   *        并把它离得多远一起说出来
   *   两者都是**只在打总结日志时**调用一次，不在每 tick 主循环里。
   */
  const COLUMN_SCAN_MAX = 64;      // 一次最多扫多少格（防止扫整个世界高度）
  const NEARBY_REPORT_MAX = 6;     // 邻域里最多报几条

  /**
   * 扫描"下落实体那一竖列"以及它的 3×3 水平邻域。
   *
   * @param entity 下落实体
   * @param y0     扫描起点（含）
   * @param y1     扫描终点（含）
   * @param wants  关心的方块（字面 ID 或 #标签）；给空数组就只报"这一列有什么"
   * @returns {{x,z,y0,y1,column:Array,nearby:Array}} 取不到世界时返回 null
   */
  function probeColumnOf(entity, y0, y1, wants) {
    try {
      var BlockPos = tryLoadClass('net.minecraft.core.BlockPos');
      var level = entity.level;
      if (BlockPos == null || level == null) return null;
      var ex = entity.getX();
      var ez = entity.getZ();
      var cx = Math.floor(ex);
      var cz = Math.floor(ez);
      var lo = Math.floor(y0);
      var hi = Math.ceil(y1);
      if (hi - lo > COLUMN_SCAN_MAX) {
        /* 摆幅特别大时只扫实体附近这一段，否则一次要查几百格 */
        var mid = Math.floor(entity.getY());
        lo = mid - Math.floor(COLUMN_SCAN_MAX / 2);
        hi = lo + COLUMN_SCAN_MAX;
      }
      var wantList = (wants == null) ? [] : wants;
      var column = [];
      var nearby = [];
      for (var y = lo; y <= hi; y++) {
        for (var dx = -1; dx <= 1; dx++) {
          for (var dz = -1; dz <= 1; dz++) {
            var st = level.getBlockState(BlockPos.containing(ex + dx, y, ez + dz));
            if (st == null) continue;
            var id = blockIdOf(st);
            if (id == null || id === 'minecraft:air') continue;
            if (dx === 0 && dz === 0) {
              column.push({ y: y, id: id });
            } else if (wantList.length > 0) {
              for (var k = 0; k < wantList.length; k++) {
                var want = wantList[k];
                var hit = false;
                if (want.charAt(0) === '#') {
                  hit = (MG_API != null && MG_API.blockStateHasTag != null)
                    && MG_API.blockStateHasTag(st, want);
                } else {
                  hit = (MG_API != null && MG_API.blockStateHasId != null)
                    ? MG_API.blockStateHasId(st, want)
                    : (id === want);
                }
                if (hit) {
                  nearby.push({ x: cx + dx, y: y, z: cz + dz, id: id, dx: dx, dz: dz });
                  break;
                }
              }
            }
          }
        }
      }
      nearby.sort(function (a, b) {
        var da = Math.abs(a.dx) + Math.abs(a.dz);
        var db = Math.abs(b.dx) + Math.abs(b.dz);
        if (da !== db) return da - db;
        return Math.abs(a.y - entity.getY()) - Math.abs(b.y - entity.getY());
      });
      return {
        x: cx, z: cz, y0: lo, y1: hi,
        column: column, nearby: nearby.slice(0, NEARBY_REPORT_MAX),
        nearbyTotal: nearby.length,
      };
    } catch (err) {
      return null;
    }
  }

  /** 把 probeColumnOf 的结果拼成一句人话（日志用）。 */
  function columnReportText(rep, wants) {
    if (rep == null) return null;
    if (rep.column.length === 0) {
      return '它这一列 x=' + rep.x + ' z=' + rep.z + '（y=' + rep.y0 + ' ~ ' + rep.y1
        + '）**一格方块都没有** —— 落点方块不在这' + '一列里；'
        + '下落实体只在竖直方向动，X/Z 差 1 格就永远碰不到';
    }
    var parts = [];
    for (var i = 0; i < rep.column.length && i < 6; i++) {
      parts.push('y=' + rep.column[i].y + '=' + rep.column[i].id);
    }
    var txt = '它这一列 x=' + rep.x + ' z=' + rep.z + '（y=' + rep.y0 + ' ~ ' + rep.y1
      + '）实际有: ' + parts.join('、');
    if (rep.column.length > 6) txt += '…共 ' + rep.column.length + ' 格';
    if (wants != null && wants.length > 0 && rep.nearby.length > 0) {
      var near = [];
      for (var j = 0; j < rep.nearby.length; j++) {
        var nb = rep.nearby[j];
        near.push('(' + nb.x + ',' + nb.y + ',' + nb.z + ')=' + nb.id
          + '（差 ' + (nb.dx !== 0 ? ('x ' + Math.abs(nb.dx) + ' 格 ') : '')
          + (nb.dz !== 0 ? ('z ' + Math.abs(nb.dz) + ' 格') : '') + '）');
      }
      txt += '；★ 你要的「' + wants.join(' 或 ') + '」**就在隔壁**：' + near.join('、')
        + (rep.nearbyTotal > rep.nearby.length ? ('…共 ' + rep.nearbyTotal + ' 格') : '')
        + ' —— 挪进 x=' + rep.x + ' z=' + rep.z + ' 这一列即可';
    }
    return txt;
  }

  /**
   * 探针位置的现状（**只给日志用**）。
   *
   * <p>为什么值得单独写一个：这条机制的失败是"静默"的 ——
   * 方块照常往复、什么都没有发生。要区分"摆错位置了"和"引擎有 bug"，
   * 唯一的办法是把**探针实际看到的方块**打出来。
   * 用户报告"灵魂土上不出下界疣"时，这一行就能直接说明
   * 探针上下到底是空气、玻璃还是别的什么。
   */
  function probeSnapshot(entity) {    try {
      var BlockPos = tryLoadClass('net.minecraft.core.BlockPos');
      if (BlockPos == null) return '';
      var level = entity.level;
      if (level == null) return '';
      var y = entity.getY();
      var below = blockIdOf(level.getBlockState(BlockPos.containing(entity.getX(), y - 1, entity.getZ())));
      var here = blockIdOf(level.getBlockState(BlockPos.containing(entity.getX(), y, entity.getZ())));
      var above = blockIdOf(level.getBlockState(BlockPos.containing(entity.getX(), y + 1, entity.getZ())));
      var dir = null;
      if (MG_API != null && MG_API.currentDirection != null) {
        try { dir = MG_API.currentDirection(entity); } catch (errD) { dir = null; }
      }
      return 'y=' + (Math.round(y * 100) / 100)
        + ' 方向=' + (dir == null ? '?' : dir)
        + '，相邻方块 下/本/上 = '
        + (below == null ? '?' : below) + ' / '
        + (here == null ? '?' : here) + ' / '
        + (above == null ? '?' : above);
    } catch (err) {
      return '';
    }
  }

  /**
   * 去重提示：**按配方**去重，不是按方块种类。但只去重到一定次数。
   *
   * <p>⚠️ 曾经按方块 ID 去重 —— 脚手架有两条 landing 配方（树叶 / 泥土），
   * 于是日志永远只提示**第一条**的落点，玩家明明在测泥土，日志却在说树叶。
   *
   * <p>⚠️ 后来又发现"只打第一条"也不够：landing 判定发生在**特定的位置**
   * （下落实体往返的两端），只采一帧完全看不出实体到底经过了哪里。
   * 所以现在每个配方最多打 MISS_LOG_MAX 条，每条都带**实体当前 y 与探针逐格**，
   * 于是一次测试就能从日志里读出实体的完整轨迹。
   */
  const landingMissSeen = {};
  /** 每个配方最多打几条 MISS 日志。
   *  3 条足够看出"实体在哪、探针看到什么"（第 1 条 + 最后 1 条带汇总）；
   *  再多就只是刷屏 —— 同一列放两个脚手架时日志会翻倍。 */
  const MISS_LOG_MAX = 3;

  function landingMissOnce(recipe, entity, crossings) {
    const key = recipe.id;
    const n = (landingMissSeen[key] || 0) + 1;
    landingMissSeen[key] = n;
    if (n > MISS_LOG_MAX) return;
    const blockId = fallingBlockIdOf(entity);
    console.info('[镜维度·配方] ' + blockId + ' 已切换 ' + crossings
      + ' 次，正在等待接触 ' + recipe.onList.join(' 或 ')
      + '（' + recipe.id + '）；' + probeSnapshot(entity));
    /* 探针逐格看到的方块（y=方块ID）—— "落点对不上"唯一的现场证据：
     * 它直接说明探针看到了什么、而配方要的是什么。 */
    if (lastProbeDetail != null) {
      console.info('[镜维度·配方]   ↑ 探针逐格: ' + lastProbeDetail);
    }
    /* 最后一条时把"探针全程见过什么 + 实体最近在哪儿晃"汇总出来，让日志自足：
     *   · 列表里**有**落点方块 → 探针确实碰到过它（看得见 ×N），问题在别处
     *   · 列表里**没有**，或只见过一两次 → 落点方块**根本不在实体够得到的范围**，
     *     照着下面的"最近活动范围"把方块挪进去即可
     * 这一行是本项目排查"落点不生效"最有用的一句话，所以两种配方都要打。 */
    if (n === MISS_LOG_MAX) {
      const seen = probeSeenList(recipe.input);
      const st = seenStats[recipe.input];
      const colTxt = (st == null || st.lastX == null || st.lastZ == null)
        ? '（坐标未知）' : ('x=' + st.lastX + ' z=' + st.lastZ);
      if (seen.length > 0) {
        const parts = [];
        for (let i = 0; i < seen.length; i++) {
          parts.push(seen[i].id + '×' + seen[i].n);
        }
        console.info('[镜维度·配方]   ↑ ' + recipe.input
          + ' 全程探针见过: ' + parts.join('、'));
      } else {
        /* ★ 这一句是"落点摆了但没生效"最常见的原因，必须说透：
         * 探针只扫**实体所在的那一竖列**，而竖井通常有好几格宽。
         * 方块摆在隔壁列 = 永远碰不到，且与"配方坏了"长得一模一样。 */
        console.info('[镜维度·配方]   ↑ ' + recipe.input
          + ' 全程探针**一个方块都没见过** —— 它待的这一列（' + colTxt
          + '）整列都是空气：落点方块不在这一列里。');
      }
      if (st != null && st.recent != null && st.recent.length > 0) {
        const lo = Math.round(Math.min.apply(null, st.recent) * 100) / 100;
        const hi = Math.round(Math.max.apply(null, st.recent) * 100) / 100;
        console.info('[镜维度·配方]   ↑ ' + recipe.input + ' 最近 ' + st.recent.length
          + ' tick 在 y=' + lo + ' ~ ' + hi + ' 之间晃动');
        /* ★★ 直接扫"它这一列到底有什么" + "你要的方块是不是就差一格"。
         * 这一段是本项目排查落点问题**最终的那一句**：
         * 真实事故里用户摆的 5 格灵魂沙**一格都没落在实体那一列**，
         * 而日志当时只有"探针一个方块都没见过"，谁也看不出原因。
         * 现在它会直接说出：这一列有什么 / 你要的在隔壁第几格。 */
        const rep = probeColumnOf(entity, Math.floor(lo) - 2, Math.ceil(hi) + 2, recipe.onList);
        const repTxt = columnReportText(rep, recipe.onList);
        if (repTxt != null) {
          console.info('[镜维度·配方]   ↑ ' + repTxt);
        }
        /* 把"该摆在哪"写成一句可以直接照做的话：竖列 + 高度段。
         * 下落实体只在竖直方向动 —— 竖列错一格就永远碰不到，高度错开还能碰上。 */
        console.info('[镜维度·配方]   ★ 要把「' + recipe.onList.join(' 或 ')
          + '」摆在 ' + (st.lastX == null ? '（先靠近它，让它跑起来）'
            : (colTxt + ' 这一列'))
          + '，y=' + (Math.floor(lo) - 1) + ' ~ ' + (Math.ceil(hi) + 1)
          + ' 之间（上下各留 1 格）才会被扫到；'
          + '贴着分界线的那一层最保险，'
          + '**最省事的做法是把目标方块铺满整个水平面的一层** —— 谁掉下来都碰得到。');
      }
    }
  }

  /** landing 判定：接触到了目标方块就返回一条"命中记录"，否则 null。
   *
   * 命中记录的形状：{ recipe, ground, insertItem }
   *   · ground     —— 落在的那个方块 { id, x, y, z }（动态产物与容器插入都要用）
   *   · insertItem —— 这次要塞进容器的物品 ID（随机抽好的，没配 insert 就是 null）
   *
   * ⚠️ 随机物品是在**这里**就抽定的，不是等应用配方时才抽 ——
   * 因为"容器装不装得下"要先拿这个物品去问模组；装不下就不触发，
   * 让方块继续往复。若等到应用时再抽，就会出现"方块变了、物品却没进去"。 */
  function matchLanding(entity, recipe, crossings) {
    const ground = groundBlockAt(entity, recipe);
    if (ground == null) {
      landingMissOnce(recipe, entity, crossings);
      return null;
    }

    var insertItem = null;
    if (recipe.insert != null) {
      insertItem = pickInsertItem(recipe.insert);
      if (insertItem == null) return null;
      /* 先问容器装不装得下（除非 recipe.insert.force 要求无论如何都触发）。 */
      if (!recipe.insert.force && !canInsertAt(entity, ground, insertItem, recipe.insert.count)) {
        insertMissOnce(recipe, ground, insertItem);
        return null;
      }
    }
    return { recipe: recipe, ground: ground, insertItem: insertItem };
  }


  /** 从候选列表里随机抽一个（列表里重复写同一个物品就等于给它加权）。 */
  function pickInsertItem(ins) {
    const list = ins.items;
    if (list == null || list.length === 0) return null;
    return String(list[Math.floor(Math.random() * list.length)]);
  }

  /** 问模组：那个位置的容器装得下这个物品吗。 */
  function canInsertAt(entity, ground, itemId, count) {
    try {
      if (MG_API == null || MG_API.canInsertIntoContainer == null) return false;
      var BlockPos = tryLoadClass('net.minecraft.core.BlockPos');
      if (BlockPos == null) return false;
      return MG_API.canInsertIntoContainer(entity.level,
        BlockPos.containing(ground.x, ground.y, ground.z), itemId, count) === true;
    } catch (err) {
      return false;
    }
  }

  /** 去重提示：容器装不下时只提示一次，避免每 tick 刷屏。 */
  const insertMissSeen = {};
  function insertMissOnce(recipe, ground, itemId) {
    const key = recipe.id + '@' + ground.id;
    if (insertMissSeen[key]) return;
    insertMissSeen[key] = true;
    console.info('[镜维度·配方] ' + recipe.input + ' 已落在 ' + ground.id
      + ' 上，但容器放不下 ' + itemId + '（或里面是别的物品）—— 继续往复等待');
  }

  /* ------------------------------------------------------------------ */
  /* 去重提示                                                            */
  /* ------------------------------------------------------------------ */

  /** 这个方块有 crossing 配方但次数未到。 */
  const crossingWaitSeen = {};
  function crossingWaitOnce(blockId, crossings) {
    if (blockId == null || crossingWaitSeen[blockId]) return;
    for (const r of recipes) {
      if (r.input === blockId && r.trigger === 'crossing') {
        crossingWaitSeen[blockId] = true;
        console.info('[镜维度·配方] ' + blockId + ' 已切换 ' + crossings
          + ' 次，配方要求 ' + r.crossings + ' 次，继续等待');
        return;
      }
    }
  }

  /* ------------------------------------------------------------------ */
  /* 把下落的方块换成产物                                                 */
  /* ------------------------------------------------------------------ */

  /** 在实体所在位置放目标方块并移除实体。
   *
   * 不用命令拼接（setblock ...）——那样每 tick 都要走一遍命令解析，
   * 而且字符串拼接容易在方块 ID 上出错。
   *
   * @param match process() 返回的命中记录 { recipe, ground, insertItem }；
   *              也兼容直接传配方对象（老接口，没有落点信息）
   */
  function applyRecipe(entity, match) {
    try {
      var BlockPos = tryLoadClass('net.minecraft.core.BlockPos');
      var BuiltInRegistries = tryLoadClass('net.minecraft.core.registries.BuiltInRegistries');
      if (BlockPos == null || BuiltInRegistries == null) return false;

      /* 兼容两种入参：命中记录，或直接给配方对象。 */
      var isMatch = (match != null && match.recipe != null);
      var recipe = isMatch ? match.recipe : match;
      var ground = isMatch ? match.ground : null;
      var insertItem = isMatch ? match.insertItem : null;
      if (recipe == null) return false;

      var level = entity.level;
      if (level == null) return false;

      /* 产物 ID：
       *   写死的 ID  —— 原样使用
       *   '@landed'  —— 变成"落在的那个方块"（铁砧 → 落点那一块）
       *   '@mapped'  —— 按 map 表把落点翻成产物（脚手架 + 树叶 → 对应树苗）
       *                 map 里没有的落点直接放弃、继续往复，
       *                 刻意**不退化成**"变成落点本身"（那会变成一片树叶）。 */
      var outputId = recipe.output;
      if (recipe.mappedOutput) {
        if (ground == null || ground.id == null) {
          console.error('[镜维度] 配方 ' + recipe.id + ' 的产物是 @mapped，但没有记录落到哪个方块上');
          return false;
        }
        var mapped = (recipe.map != null) ? recipe.map[ground.id] : null;
        if (mapped == null) {
          console.error('[镜维度] 配方 ' + recipe.id + ' 的 map 表里没有落点 '
            + ground.id + ' 对应的产物，本次不加工。');
          return false;
        }
        outputId = String(mapped);
      } else if (recipe.dynamicOutput) {
        if (ground == null || ground.id == null) {
          console.error('[镜维度] 配方 ' + recipe.id + ' 的产物是 @landed，但没有记录落到哪个方块上');
          return false;
        }
        outputId = ground.id;
      }

      /* ⚠️ 位置必须在 discard() **之前**取。
       * 实体被移除后再读 entity.y 拿不到值，日志会印出 undefined。 */
      var pos = BlockPos.containing(entity.getX(), entity.getY(), entity.getZ());
      var where = Math.floor(pos.getY());
      var via = recipe.trigger === 'landing'
        ? ('接触 ' + recipe.onList.join(' / '))
        : '交界处';
      /* ⚠️ 这里的键必须与 process/计数用的键**完全一致**（见 stateKeyOf）：
       * 按竖列计数的方块如果在这里用实体 id，forget 就清不掉它的进度。 */
      var key = stateKeyOf(entity);

      if (recipe.drop) {
        /* drop:true —— 产物以**掉落物**形式弹出，不原地放方块。
         * 树苗 / 地狱疣这类"加工出来要能捡走"的东西走这条路；
         * 原地放成方块会把落点（树叶 / 灵魂沙）盖掉，等于白加工。 */
        var dropped = false;
        try {
          dropped = (MG_API != null && MG_API.dropItem != null)
            && MG_API.dropItem(level,
              pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
              outputId, 1) === true;
        } catch (errDrop) {
          dropped = false;
        }
        if (!dropped) {
          /* 生成失败时**不要** discard：让方块继续往复，
           * 总好过"东西凭空没了"。 */
          console.error('[镜维度] 配方 ' + recipe.id + ' 的产物要弹成掉落物，但生成失败（'
            + outputId + '）—— 检查物品 ID 是否存在、模组是否为最新版。');
          return false;
        }
        /* ★ 触发之后回头看一眼：**落点方块还在不在？**
         *
         * 为什么值得查：本项目出现过"配方明明触发过，世界里却再也找不到落点方块"
         * 的怪事（灵魂沙、树叶都在触发后从存档里消失）—— 排查时无法区分
         * "玩家自己挖掉了"还是"有代码/原版把它盖掉了"。
         * drop 配方**自己绝不写方块**（这一支只调 dropItem），所以一旦发现它没了，
         * 就是**别的东西**干的，这一行日志就是那条线索。 */
        try {
          var gPos = BlockPos.containing(ground.x, ground.y, ground.z);
          var nowId = blockIdOf(level.getBlockState(gPos));
          if (nowId !== ground.id) {
            console.error('[镜维度·配方] ⚠ 触发后落点方块变了：' + ground.id
              + '（' + ground.x + ',' + ground.y + ',' + ground.z + '）→ ' + nowId
              + ' —— drop 配方自己不写方块，说明有**别的东西**在覆盖/移除它。'
              + '如果这个方块是你刚摆的，请把这个坐标记下来报给开发者。');
          }
        } catch (errGroundChk) {
          // 查不到就算了，绝不影响加工本身
        }
      } else {
        var rl = MD.id(outputId);
        if (rl == null) {
          console.error('[镜维度] 配方产物 ID 非法: ' + outputId);
          return false;
        }
        var block = BuiltInRegistries.BLOCK.get(rl);
        if (block == null) {
          console.error('[镜维度] 找不到配方产物方块: ' + outputId);
          return false;
        }

        /* 保留朝向：**铁砧有 facing 属性**，下落实体带着它原来的朝向。
         * 一律用 defaultBlockState() 的话，所有铁砧落地后都会朝同一个方向 ——
         * 摆一排加工铁砧时会明显看出来是"复制出来的"。
         * 两边都有该属性时才搬运；混凝土粉末这类没有朝向的方块自动跳过。 */
        var newState = block.defaultBlockState();
        try {
          var srcState = entity.getBlockState();
          var Props = tryLoadClass('net.minecraft.world.level.block.state.properties.BlockStateProperties');
          if (srcState != null && Props != null) {
            var prop = Props.HORIZONTAL_FACING;
            if (prop != null && srcState.hasProperty(prop) && newState.hasProperty(prop)) {
              newState = newState.setValue(prop, srcState.getValue(prop));
            }
          }
        } catch (errFacing) {
          // 朝向搬运失败不影响加工本身
        }

        level.setBlockAndUpdate(pos, newState);
      }

      /* 落上容器：把物品塞进去。**在放方块之后做** ——
       * 顺序反过来的话，容器那一格可能被新方块覆盖掉。
       * 位置用的是 ground（目标方块自己的坐标），不是实体坐标。
       * drop 类配方没有容器，跳过。 */
      var inserted = null;
      if (!recipe.drop && insertItem != null && ground != null) {
        try {
          inserted = (MG_API != null && MG_API.tryInsertIntoContainer != null)
            && MG_API.tryInsertIntoContainer(level,
              BlockPos.containing(ground.x, ground.y, ground.z),
              insertItem, recipe.insert.count) === true;
        } catch (err2) {
          inserted = false;
        }
      }

      entity.discard();
      N1.forget(key);
      /* 去重提示的键是**配方 id**（见 landingMissOnce 的说明），不是方块 ID */
      delete landingMissSeen[recipe.id];
      delete crossingWaitSeen[recipe.input];

      console.info('[镜维度·配方生效] ' + recipe.input + ' → ' + outputId
        + (recipe.drop ? '（掉落物形式）' : '')
        + '（切换 ' + recipe.crossings + ' 次后，于' + via + '，y=' + where + '）'
        + (insertItem != null
          ? ('；' + (inserted ? '并往 ' + ground.id + ' 里放入了 ' + insertItem
            : '但**没能**往 ' + ground.id + ' 里放入 ' + insertItem))
          : ''));
      return true;
    } catch (err) {
      console.error('[镜维度] 配方应用失败: ' + err);
      return false;
    }
  }

  /* ------------------------------------------------------------------ */
  /* 处理编排                                                            */
  /* ------------------------------------------------------------------ */

  /**
   * 排查用的采样表：**按方块种类**记"引擎到底见过它几次"。
   *
   * <p>为什么必须有这个：配方不生效有三个完全不同的原因，而它们在游戏里
   * 长得一模一样（什么都不发生）：
   * <ol>
   *   <li><b>那个方块根本没变成下落实体</b> —— 例如脚手架要求下方 6 格内
   *       没有结实方块才肯掉。这种情况下 {@code ticks} 恒为 0</li>
   *   <li><b>它掉了，但切换次数到不了要求值</b> —— 例如被夹住、
   *       或摆幅够不到落点。这时 {@code ticks} 在涨、{@code maxFlips} 却停在阈值下</li>
   *   <li><b>次数够了，但落点没匹配上</b> —— 这时看 {@code lastProbe}
   *       里"相邻方块"实际是什么即可</li>
   * </ol>
   * 三者一眼可分。没有这张表就只能靠猜 —— 而这一轮已经猜错两次了。
   *
   * <p>采样行按固定节流更新（每 SEEN_PROBE_EVERY 次处理采一次），
   * 不给每 tick 的主循环加负担；且只在真有实体时才会建立条目。
   */
  const seenStats = {};
  const SEEN_PROBE_EVERY = 20;
  /** 最近活动范围的采样窗口（tick）。60 ≈ 3 秒，足够覆盖一两次往返。 */
  const RECENT_WINDOW = 60;

  function noteSeen(blockId, entity, crossings) {
    var st = seenStats[blockId];
    if (st == null) {
      st = seenStats[blockId] = {
        id: blockId, ticks: 0, maxFlips: 0,
        minY: null, maxY: null, lastY: null, lastProbe: null,
        recent: [], lastX: null, lastZ: null,
      };
      st.lastProbe = probeSnapshot(entity);   // 首次见到立刻采一次
    }
    st.ticks++;
    if (crossings > st.maxFlips) st.maxFlips = crossings;
    /* ★ 摆幅范围：这是回答"落点该摆在哪儿"的关键数据 ——
     * 落点方块**必须在这个范围内**（必须是实体真的会撞上的东西），
     * 摆在范围外就是"永远碰不到"，而且什么提示都没有。 */
    var y = entity.y;
    if (y != null) {
      if (st.minY == null || y < st.minY) st.minY = y;
      if (st.maxY == null || y > st.maxY) st.maxY = y;
      /* ★ 最近的**竖列坐标**。落点方块必须摆在**这一格所在的那一竖列**里
       * —— 下落实体只在竖直方向动，水平方向一格都不会挪。
       * 所以"落点摆错一列"是永远碰不到的，而现象与"配方坏了"一模一样。
       * 把 x/z 打在日志与 /mirror recipes 里，玩家照着摆就行。 */
      if (entity.x != null) st.lastX = Math.floor(entity.x);
      if (entity.z != null) st.lastZ = Math.floor(entity.z);
      /* ★ 最近活动范围：上面那对 min/max 是**历史极值**（永不回落），
       * 而实体常常一开始从高处砸下来、之后就在分界线附近小幅抖动 ——
       * 历史极值会把这两段混在一起，看不出"现在到底在哪儿晃"。
       * 所以再留最近 RECENT_WINDOW 次采样的区间，
       * 落点方块应当摆进**最近**这个区间里。 */
      st.recent.push(y);
      if (st.recent.length > RECENT_WINDOW) st.recent.shift();
    }
    if (st.ticks % SEEN_PROBE_EVERY === 1) {
      st.lastProbe = probeSnapshot(entity);
      st.lastY = Math.round(entity.y * 100) / 100;
    }
  }

  /**
   * 下落方块的完整处理：先更新计数，再按两类触发方式判定配方。
   *
   * 两种计数方式在这里收口，保证同一 tick 只用其中一种
   * （同时用会把一次切换计成两次）。
   *
   * @returns 命中的配方对象，或 null
   */
  function process(entity) {
    const key = stateKeyOf(entity);
    const blockId = fallingBlockIdOf(entity);
    if (blockId == null) {
      console.info('[镜维度·配方] 读不到下落的方块的 ID，配方无法判定');
      return null;
    }

    // ---- 1) 计数 ----
    if (USE_FLIP_COUNT) {
      trackDirectionFlip(entity);
    } else {
      trackCrossing(entity);
    }
    const crossings = recipeState[key] != null ? recipeState[key].crossings : 0;

    /* ---- 1.5) 排查采样（只为诊断，见 noteSeen） ---- */
    noteSeen(blockId, entity, crossings);

    /* ---- 2) landing 触发 ----
     * landing 是"大于等于"语义，所以达标后会持续尝试，
     * 直到某次恰好接触到目标方块。
     * ⚠️ 必须把**所有**候选都试一遍：同一次数下不同配方只差"落在什么上面"，
     * 而落点要现场查方块才知道（见 matchRecipeAll 的说明）。
     *
     * ⚠️ **landing 要排在 crossing 前面**（这里踩过一次）：
     *    landing 的条件更**具体**（除了次数还要求贴着某个方块），
     *    crossing 只要求次数。同一次数下两者都可能满足时，应当让更具体的赢。
     *    实例：脚手架 4 次切换 ——
     *      · 正贴着树叶 → 树苗（landing）
     *      · 没贴着任何东西 → 地狱疣（crossing）
     *    若先判 crossing，4 次一到就直接变地狱疣，树苗那条**永远不会触发**。
     */
    const landedList = matchRecipeAll(blockId, crossings, null, 'landing');
    for (const landed of landedList) {
      const ok = matchLanding(entity, landed, crossings);
      if (ok != null) return ok;
    }

    // ---- 3) crossing 触发 ----
    const crossed = matchRecipe(blockId, crossings, null, 'crossing');
    if (crossed != null) {
      console.info('[镜维度·配方] ' + blockId + ' 已切换 ' + crossings
        + ' 次，触发交界处加工（y=' + Math.round(entity.y * 10) / 10 + '）');
      return { recipe: crossed, ground: null, insertItem: null };
    }
    crossingWaitOnce(blockId, crossings);
    return null;
  }

  /**
   * 非下落方块（掉落物/TNT）的计数。
   *
   * 它们**不做加工** —— 掉落物应当能被捡起，不该烧成方块。
   * 这里只是保留计数供诊断查看。
   */
  function trackNonBlock(entity) {
    if (!RECIPES_ON) return;
    if (USE_FLIP_COUNT) {
      trackDirectionFlip(entity);
    } else {
      trackCrossing(entity);
    }
  }

  /* ------------------------------------------------------------------ */
  /* 对外导出                                                            */
  /* ------------------------------------------------------------------ */

  const api = {
    ready: true,
    enabled: RECIPES_ON,
    countMode: COUNT_MODE,
    useFlipCount: USE_FLIP_COUNT,

    add: addRecipe,
    onRegisterRecipes: onRegisterRecipes,
    list: function () { return recipes.slice(); },
    count: function () { return recipes.length; },

    process: process,
    trackNonBlock: trackNonBlock,
    trackSwing: trackSwing,
    applyRecipe: applyRecipe,

    /** 正在计数的实体快照，用于 /mirror recipes 展示"某个沙砾切换了几次"。 */
    states: function () {
      const out = [];
      for (const k in recipeState) {
        if (Object.prototype.hasOwnProperty.call(recipeState, k)) {
          out.push({ id: k, crossings: recipeState[k].crossings });
        }
      }
      return out;
    },

    /**
     * 排查采样：每种方块被当过多少次"下落实体"、最高切换次数、最近一次探针。
     *
     * <p>用法：配方不生效时先看这里。
     * 某种方块**根本不出现** = 它从来没变成过下落实体（前置条件问题，
     * 例如脚手架下方 6 格内有结实方块）；
     * 出现了但 maxFlips 一直上不去 = 摆幅/卡住问题；
     * maxFlips 够了却不变 = 落点没匹配上，看 lastProbe 里的相邻方块。
     */
    diagnostics: function () {
      const out = [];
      for (const k in seenStats) {
        if (Object.prototype.hasOwnProperty.call(seenStats, k)) {
          const st = seenStats[k];
          out.push({
            id: st.id, ticks: st.ticks, maxFlips: st.maxFlips,
            minY: st.minY, maxY: st.maxY,
            /* 最近活动范围（最后 RECENT_WINDOW 次采样）——
             * 落点方块应当摆进**这个**区间，历史极值常常包含早期从高处
             * 砸下来的那一段，会误导人。 */
            recentMinY: st.recent && st.recent.length ? Math.min.apply(null, st.recent) : null,
            recentMaxY: st.recent && st.recent.length ? Math.max.apply(null, st.recent) : null,
            lastY: st.lastY, lastProbe: st.lastProbe,
            /* ★ 最近待过的那一竖列。落点方块必须摆在这里 —— 见 noteSeen。 */
            lastX: st.lastX, lastZ: st.lastZ,
            /* 探针在这个方块旁边**实际见过**的方块（非空气，按次数降序）。
             * 落点对不上时，这一项直接区分"ID 摆错了"和"位置太远碰不到"。 */
            seen: probeSeenList(st.id),
          });
        }
      }
      out.sort(function (a, b) { return b.ticks - a.ticks; });
      return out;
    },

    /**
     * 某个下落实体当前用的**计数键**（实体 id，或按竖列的键）。
     *
     * <p>为什么对外暴露：键的规则是引擎的私事，但模拟器要用同一把钥匙去读
     * 计数 —— 与其在别处复刻一遍（那必然会随引擎改动而漂移），
     * 不如直接问引擎。诊断与测试专用，不参与配方逻辑。
     */
    keyOf: function (entity) {
      try {
        return stateKeyOf(entity);
      } catch (err) {
        return null;
      }
    },

    /**
     * 诊断：扫"这个下落实体那一竖列 + 3×3 邻域"，报出实际有哪些方块。
     *
     * <p>用法与 {@code keyOf} 同理：这是引擎的私事（探针只扫实体自己那一列），
     * 与其在别处复刻一遍扫描逻辑，不如直接问引擎。命令层与模拟器都用它。
     *
     * @param entity 下落实体
     * @param y0/y1  扫描的 y 范围
     * @param wants  关心的方块（字面 ID 或 #标签），用来挑出"就在隔壁"的那些
     */
    probeColumn: function (entity, y0, y1, wants) {
      try {
        return probeColumnOf(entity, y0, y1, wants);
      } catch (err) {
        return null;
      }
    },

    /** 诊断：把 probeColumn 的结果拼成一句人话（与日志里那句完全一致）。 */
    columnReportText: function (rep, wants) {
      try {
        return columnReportText(rep, wants);
      } catch (err) {
        return null;
      }
    },
  };

  global.MirrorDimension.modules.n3 = api;
  return api;
})();
