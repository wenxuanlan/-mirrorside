/** 校验模组资源 JSON 与 PNG（用 Node 显式按 UTF-8 读，避免 shell 编码干扰）。 */
import { readFileSync, existsSync } from 'node:fs';

const BASE = 'D:/DSHwork/MC镜维度/mirror-gravity-mod/src/main/resources/assets/mirrorgravity/';
const files = [
  'blockstates/mirror_portal.json',
  'models/block/mirror_portal.json',
  'lang/zh_cn.json',
  'lang/en_us.json',
  'textures/block/mirror_portal.png.mcmeta',
  'sounds.json',
];

let bad = 0;
for (const f of files) {
  const p = BASE + f;
  if (!existsSync(p)) {
    console.log('  ✗ 缺失 ' + f);
    bad++;
    continue;
  }
  try {
    const o = JSON.parse(readFileSync(p, 'utf8'));
    const keys = Object.keys(o).join(', ');
    console.log('  ✓ ' + f + '   keys=' + (keys.length > 60 ? keys.slice(0, 60) + '…' : keys));
  } catch (e) {
    console.log('  ✗ ' + f + ' : ' + e.message);
    bad++;
  }
}

/* 方块状态文件里那个空字符串键是原版规范（"没有属性"的方块就这么写），
 * PowerShell 5.1 的 ConvertFrom-Json 会误报，这里单独确认一次。 */
const bs = JSON.parse(readFileSync(BASE + 'blockstates/mirror_portal.json', 'utf8'));
const variantKeys = Object.keys(bs.variants);
console.log('  · blockstate 变体键 = [' + variantKeys.map((k) => JSON.stringify(k)).join(', ')
  + ']，模型 = ' + bs.variants[variantKeys[0]].model);

/* 中文语言文件：确认没有解码失败留下的替换字符 */
const zh = readFileSync(BASE + 'lang/zh_cn.json', 'utf8');
const replacement = (zh.match(/\uFFFD/g) || []).length;
console.log('  · zh_cn.json 替换字符数 = ' + replacement + '（应为 0）');
if (replacement > 0) bad++;

console.log(bad === 0 ? '\n✓ 资源全部合法' : `\n✗ ${bad} 个问题`);
if (bad > 0) process.exitCode = 1;
