// =====================================================================
// 镜维度 · 镜外区域、关卡查找、玻璃层
// =====================================================================
// 三件事放在一起，因为它们都属于"世界结构"而不是"实体物理"：
//
//   1) 镜维度关卡的查找（带缓存）—— 重力扫描与玻璃铺设都要用
//   2) 镜外区域与游戏模式（越过镜面边界后的表现）
//   3) 玻璃层的兜底铺设（世界生成已负责，默认关闭）
//
// ⚠️ 所有 try 块内只用 var（Rhino 对 try 里的 const/let 会抛
//    InternalError: TypeError: redeclaration of var xxx）
// =====================================================================

const MirrorOuter = (() => {

  const N0 = global.MirrorDimension.modules.n0;
  const N2 = global.MirrorDimension.modules.n2;
  if (N0 === undefined || !N0.ready || N2 === undefined || !N2.ready) {
    console.error('[镜维度] 依赖模块未就绪，镜外/玻璃模块未启用。');
    return { ready: false };
  }

  const cfg = N0.cfg;
  const L = N0.layout;
  const GameType = N2.GameType;

  /* ------------------------------------------------------------------ */
  /* 一、镜维度关卡的查找（带缓存）                                        */
  /* ------------------------------------------------------------------ */
  /* 原先每 tick 都遍历玩家列表去找镜维度的 ServerLevel。
   * 这在没有玩家处于镜维度时是纯浪费 —— 每 tick 一次遍历 + 一次
   * 字符串比较，而结果几乎从不变化。
   *
   * 改为缓存 + 低频刷新：最多每 40 tick 真的去查一次
   * （玩家可能刚进/刚离开镜维度）。查不到时缓存 null，下次复查重试。
   *
   * ⚠️ 为什么不能"缓存永久有效"：玩家退出镜维度后 ServerLevel 引用虽然还在，
   *    但没有玩家时继续跑重力逻辑没有意义，而且长期持有引用不利于回收。
   *
   * ⚠️ 为什么不用 server.getLevel(ResourceKey)：Rhino 报重载歧义。
   *    也不能遍历 getAllLevels() + lv.dimension().location()：
   *    那条链会抛异常并被上层 catch 吞掉，表现为"整个扫描器一次都没跑成"。
   *    从玩家身上取是唯一验证过可靠的路径。详见 README §11.6。 */

  let cachedMirrorLevel = null;
  let mirrorLevelCheckedAt = -9999;
  const MIRROR_LEVEL_RECHECK = 40;

  /**
   * @param server   ServerLevel 之外的服务器句柄（event.server）
   * @param nowTick  当前 tick（由 n1 提供），用于判断缓存是否过期
   */
  function mirrorLevelOf(server, nowTick) {
    if (server == null) return null;
    if (cachedMirrorLevel != null
        && (nowTick - mirrorLevelCheckedAt) < MIRROR_LEVEL_RECHECK) {
      return cachedMirrorLevel;
    }
    mirrorLevelCheckedAt = nowTick;
    cachedMirrorLevel = null;
    try {
      var players = server.getPlayerList().getPlayers();
      var it = players.iterator();
      while (it.hasNext()) {
        var p = it.next();
        if (p == null) continue;
        if (String(p.level.dimension) === N0.dim) { cachedMirrorLevel = p.level; break; }
      }
    } catch (err) {
      cachedMirrorLevel = null;
    }
    return cachedMirrorLevel;
  }

  /* ------------------------------------------------------------------ */
  /* 二、镜外区域与游戏模式                                               */
  /* ------------------------------------------------------------------ */
  /* 设定文件（镜维度设定.txt 第 6 条）：
   *   "玩家在进入镜外时，随机将玩家改为旁观者模式或冒险模式。
   *    当玩家回到镜内时，将玩家切换为原来的模式。注意，当玩家在镜外
   *    传送到其他世界时，也将玩家切换回原来的模式。
   *    玩家原来的模式就是服务端设置的玩家模式。"
   *
   * 区域判定在 n4（PlayerEvents.tick，每 20 tick 一次），
   * 通过 n2.notifyRegionChange 通知到本模块的 onRegionChanged。
   *
   * ⚠️ KubeJS 对 ServerPlayer 做了包装，原版方法名不一定可用。实测：
   *      ✗ player.getGameModeForPlayer()        -> Cannot find function
   *      ✗ player.setGameModeForPlayer(gt)      -> Cannot find function
   *      ✓ player.setGameMode(GameType)
   *      ✓ player.gameMode.getGameModeForPlayer()
   *    写错会让 PlayerEvents.tick 处理器中断，后续逻辑全部失效。 */

  /** 玩家持久化数据键：进镜外前保存的模式 */
  const PD_KEY_MODE = 'mirror_saved_gamemode';

  function currentModeName(player) {
    try {
      var gt = player.gameMode.getGameModeForPlayer();
      return gt == null ? 'unknown' : String(gt.getName());
    } catch (err) {
      return 'unknown';
    }
  }

  function randomOuterMode() {
    const list = cfg.outerRegion.random_modes || ['spectator', 'adventure'];
    const pick = list[Math.floor(Math.random() * list.length)];
    const gt = GameType.byName(String(pick));
    return gt == null ? GameType.SPECTATOR : gt;
  }

  /**
   * 进入镜外：记下原模式，随机切成旁观者或冒险，提示玩家。
   *
   * <p>只在"尚未保存过原模式"时保存，所以从上半镜外走到下半镜外
   * 不会把已保存的原模式覆盖掉。每次进入镜外都重新随机一次。
   */
  function enterOuter(player) {
    const saved = player.persistentData.getString(PD_KEY_MODE);
    if (saved === '' || saved == null) {
      player.persistentData.putString(PD_KEY_MODE, currentModeName(player));
    }
    player.setGameMode(randomOuterMode());
    if (cfg.outerRegion.notify_enter) {
      player.tell(Text.aqua('你越过了镜面边界。')
        .append(Text.gray(' 游戏模式：' + currentModeName(player))));
    }
  }

  /**
   * 离开镜外：恢复原模式。
   *
   * <p>只有**确实保存过原模式**（即玩家真的在镜外待过）才恢复并提示。
   * 否则首次登录、或从别处传送进镜内时，区域会从 'none' 变为 'inner'，
   * 那并不是"回到镜内"，不该弹提示。
   */
  function leaveOuter(player) {
    const saved = player.persistentData.getString(PD_KEY_MODE);
    if (saved === '' || saved == null) {
      return;   // 本来就不在镜外，无事可做
    }
    const back = GameType.byName(String(saved));
    if (back != null) player.setGameMode(back);
    player.persistentData.putString(PD_KEY_MODE, '');
    if (cfg.outerRegion.notify_leave) {
      player.tell(Text.aqua('你回到了镜内。').append(Text.gray(' 已恢复原游戏模式。')));
    }
  }

  /**
   * 区域变化时的处理（由 n2 的钩子调用）。
   *
   * @param newRegion  'inner' / 'upper' / 'lower'
   * @param prevRegion 上一次的区域（'none' 表示之前不在镜维度）
   */
  function onRegionChanged(player, newRegion, prevRegion) {
    /* 设定：进入镜外 → 随机旁观者/冒险；回到镜内 → 恢复原模式。
     *
     * 镜外有**两个**（上界面之上 'upper' 与下界面之下 'lower'），
     * 对模式切换而言二者等价 —— 只要不是 'inner' 就算镜外。
     *
     * ⚠️ 幂等性由 enterOuter/leaveOuter 自己保证：
     *    enterOuter 只在"尚未保存过原模式"时保存，所以从 upper 走到 lower
     *    不会把已保存的原模式覆盖成 spectator/adventure；
     *    leaveOuter 恢复后会把存档清空，重复调用无害。 */
    if (newRegion === 'inner') {
      leaveOuter(player);
    } else {
      enterOuter(player);
    }
    void prevRegion;
  }

  /* 注册到 n2 的钩子。这样重力模块只调用 notifyRegionChange，
   * 完全不需要知道镜外处理的存在（断开循环依赖）。 */
  N2.onRegionChange(onRegionChanged);

  /* ------------------------------------------------------------------ */
  /* 三、玻璃层兜底铺设                                                   */
  /* ------------------------------------------------------------------ */
  /* 世界生成已经铺好了玻璃层，所以这个功能**默认关闭**（layout.maintain_glass）。
   * 它存在的意义是"万一世界生成没铺到（比如手改了维度配置），
   * 可以打开它兜底补上"。
   *
   * 做法：玩家周围一定范围内的区块排队，每 tick 处理少量（预算可配），
   * 避免一次性遍历大量方块造成卡顿。 */

  /** 已经排过队的区块，避免重复入队（字符串 'cx,cz'） */
  const doneChunks = new Set();
  /** 待处理区块队列，元素为 [cx, cz] */
  const queue = [];

  /** 把玩家周围 radius 个区块范围内的区块加入队列（每个区块只入队一次）。 */
  function enqueueAround(player) {
    if (!N2.maintainGlass) return;
    const ccx = Math.floor(player.x) >> 4;
    const ccz = Math.floor(player.z) >> 4;
    const r = L.glass_radius_chunks != null ? L.glass_radius_chunks : 10;
    for (let dx = -r; dx <= r; dx++) {
      for (let dz = -r; dz <= r; dz++) {
        const key = (ccx + dx) + ',' + (ccz + dz);
        if (!doneChunks.has(key)) {
          doneChunks.add(key);
          queue.push([ccx + dx, ccz + dz]);
        }
      }
    }
  }

  if (N2.maintainGlass) {
    ServerEvents.tick(event => {
      if (queue.length === 0) return;
      const budget = L.glass_chunks_per_tick != null ? L.glass_chunks_per_tick : 1;

      const N1 = N0.moduleRef('n1');
      const nowTick = N1 != null ? N1.now() : 0;
      const level = mirrorLevelOf(event.server, nowTick);
      if (level == null) return;

      try {
        var BlockPosCls = Java.loadClass('net.minecraft.core.BlockPos');
        var Blocks = Java.loadClass('net.minecraft.world.level.block.Blocks');
        /* 方块状态缓存：同一层只查一次注册表，不要每个坐标都查。 */
        var blockStateCache = {};
        for (var i = 0; i < budget && queue.length > 0; i++) {
          var c = queue.shift();
          var baseX = c[0] << 4;
          var baseZ = c[1] << 4;
          var glassYs = N0.glassYs;
          var glass = N0.glassLayers;
          for (var gi = 0; gi < glassYs.length; gi++) {
            var y = glassYs[gi];
            var id = glass[y];
            if (!blockStateCache[id]) {
              blockStateCache[id] =
                Blocks[id.replace('minecraft:', '').toUpperCase()].defaultBlockState();
            }
            var state = blockStateCache[id];
            for (var x = 0; x < 16; x++) {
              for (var z = 0; z < 16; z++) {
                var pos = new BlockPosCls(baseX + x, y, baseZ + z);
                // 只填空气 —— 不要覆盖玩家已经放下的方块
                if (!level.getBlockState(pos).isAir()) continue;
                level.setBlockAndUpdate(pos, state);
              }
            }
          }
        }
      } catch (err2) {
        console.error('[镜维度] 玻璃层铺设失败: ' + err2);
      }
    });
  }

  /* ------------------------------------------------------------------ */
  /* 对外导出                                                            */
  /* ------------------------------------------------------------------ */

  const api = {
    ready: true,
    mirrorLevelOf: mirrorLevelOf,
    enqueueAround: enqueueAround,
    pendingGlassChunks: function () { return queue.length; },

    // 镜外（尚未接入，导出以便将来实现与调试）
    enterOuter: enterOuter,
    leaveOuter: leaveOuter,
    currentModeName: currentModeName,
    onRegionChanged: onRegionChanged,
  };

  global.MirrorDimension.modules.n5 = api;
  return api;
})();
