/**
 * 把 mirror_config.js 的配方表在沙箱里跑一遍，打印摘要 —— 用来确认
 * 循环生成的 32 条混凝土配方、标签目标、动态产物、容器插入都写对了。
 *
 * 用法: node tools-build/check-recipes.mjs
 */
import { readFileSync } from 'node:fs';

const CONFIG = 'D:/DSHwork/MC镜维度/.minecraft/versions/镜维度/kubejs/startup_scripts/mirror_config.js';
const src = readFileSync(CONFIG, 'utf8').replace('global.MIRROR_CONFIG = MIRROR_CONFIG;', '');
const cfg = new Function(src + '; return MIRROR_CONFIG;')();

const list = cfg.gravityBlockRecipes.list;
console.log('配方总数: ' + list.length);
console.log('启用: ' + cfg.gravityBlockRecipes.enabled);

const kinds = new Set(list.map((r) => r.input));
console.log('涉及方块种类: ' + kinds.size);

/* 重复 id 检查 */
const ids = new Map();
for (const r of list) {
  ids.set(r.id, (ids.get(r.id) ?? 0) + 1);
}
const dup = [...ids.entries()].filter(([, n]) => n > 1);
console.log('重复 id: ' + (dup.length ? JSON.stringify(dup) : '无 ✓'));

/* 混凝土 32 条自检 */
const concrete = list.filter((r) => r.input.includes('_concrete_powder'));
console.log('\n混凝土粉末配方: ' + concrete.length + ' 条（应为 32）');
const COLORS = ['white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink',
  'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black'];
let concreteOk = true;
for (const c of COLORS) {
  const terracotta = concrete.find((r) => r.id === c + '_concrete_powder_to_terracotta');
  const glazed = concrete.find((r) => r.id === c + '_concrete_powder_to_glazed_terracotta');
  const ok = terracotta && terracotta.output === 'minecraft:' + c + '_terracotta'
    && terracotta.trigger === 'crossing' && terracotta.crossings === 8
    && glazed && glazed.output === 'minecraft:' + c + '_glazed_terracotta'
    && glazed.trigger === 'landing' && glazed.on === 'minecraft:furnace'
    && glazed.crossings === 4;
  if (!ok) {
    concreteOk = false;
    console.log('  ✗ ' + c + ' 没配对: ' + JSON.stringify([terracotta, glazed]));
  }
}
console.log(concreteOk ? '  ✓ 16 色 × 2 条全部对齐（陶瓦 8 次 / 熔炉上带釉陶瓦 4 次）' : '  ✗ 有颜色没配对');

/* 特殊机制抽样 */
console.log('\n特殊机制:');
for (const id of ['minecraft:suspicious_gravel', 'minecraft:suspicious_sand',
  'minecraft:anvil', 'minecraft:red_sand', 'minecraft:scaffolding',
  'minecraft:pointed_dripstone']) {
  for (const r of list.filter((x) => x.input === id)) {
    const bits = [r.input + ' -> ' + r.output, '×' + r.crossings, r.trigger];
    const wants = Array.isArray(r.on) ? r.on : (r.on ? [r.on] : []);
    if (wants.length) bits.push('on ' + wants.join(' + '));
    if (r.output === '@landed') bits.push('[产物=落点]');
    if (r.output === '@mapped') bits.push('[产物按落点查表]');
    if (r.drop) bits.push('[掉落物形式]');
    if (r.insert) {
      bits.push('insert(' + r.insert.items.length + ' 项随机'
        + (r.insert.force ? '，满也触发' : '') + ')');
    }
    console.log('  ' + bits.join('  '));
  }
}

/* 标签与动态产物 */
const onListOf = (r) => (Array.isArray(r.on) ? r.on : (r.on ? [r.on] : []));
const tagRecipes = list.filter((r) => onListOf(r).some((t) => t.startsWith('#')));
const dynRecipes = list.filter((r) => r.output === '@landed');
const mappedRecipes = list.filter((r) => r.output === '@mapped');
const dropRecipes = list.filter((r) => r.drop === true);
const insRecipes = list.filter((r) => r.insert);
console.log('\n用标签判定落点: ' + tagRecipes.length + ' 条');
for (const r of tagRecipes) {
  console.log('  · ' + r.input + ' → ' + r.output + '  ' + onListOf(r).join(' + '));
}
console.log('动态产物 @landed: ' + dynRecipes.length + ' 条');
console.log('查表产物 @mapped: ' + mappedRecipes.length + ' 条');
console.log('掉落物形式: ' + dropRecipes.length + ' 条 → '
  + JSON.stringify(dropRecipes.map((r) => r.input + '→' + r.output)));
console.log('落上容器塞物品: ' + insRecipes.length + ' 条 → '
  + JSON.stringify(insRecipes.map((r) => r.input)));

/* --- 逐条自检：这几条是本次新增的机制，写错了不会有任何报错，只能靠这里 --- */
console.log('\n本次新增机制自检:');
let bad = 0;
const fail = (msg) => { bad++; console.log('  ✗ ' + msg); };

/* 1) 陶罐两条必须 force:true（用户要求"罐子满了也照样加工"） */
for (const id of ['minecraft:suspicious_gravel', 'minecraft:suspicious_sand']) {
  const r = list.find((x) => x.id === id.replace('minecraft:', '') + '_to_coal_block');
  if (!r) fail(id + ' 的陶罐配方不见了');
  else if (!r.insert || r.insert.force !== true) fail(r.id + ' 没有 force:true');
  else if (r.on !== 'minecraft:decorated_pot') fail(r.id + ' 的落点不是陶罐');
}
console.log('  ✓ 陶罐两条都 force:true（满罐也触发）');

/* 2) 铁砧必须覆盖 AnvilCraft 的 6 种粗矿块子标签
 *    （父标签 c:storage_blocks 里只有 raw_zinc_block，实测确认） */
const anvil = list.find((r) => r.id === 'anvil_to_landed_block');
const ANVIL_RAW = ['raw_lead', 'raw_silver', 'raw_tin', 'raw_titanium', 'raw_tungsten', 'raw_uranium'];
if (!anvil) fail('铁砧配方不见了');
else {
  const wants = onListOf(anvil);
  if (!wants.includes('#c:storage_blocks')) fail('铁砧没写 c:storage_blocks');
  for (const raw of ANVIL_RAW) {
    if (!wants.includes('#c:storage_blocks/' + raw)) fail('铁砧少了粗矿块子标签 ' + raw);
  }
  console.log('  ✓ 铁砧覆盖 c:storage_blocks + ' + ANVIL_RAW.length + ' 个粗矿块子标签');
}

/* 3) 脚手架（**只有两条**）
 *    8 次 crossing     → 蜘蛛网
 *    树叶落点 + 4 次   → @mapped + map 表（对应树苗）
 *
 * ⛔ 第三条「4 次 + 落在灵魂沙上 → 地狱疣」2026-09-22 **放弃并整条删除**。
 *    它是脚手架唯一需要"专用机制"的配方：为了它写过 sticky（碰到过就算数）
 *    与"跨重生继承计数"；后者一旦按位置（竖列）共用状态，同一列的多个脚手架
 *    就会互相污染 —— 实测 0→8 只用 1 秒，全变蜘蛛网。
 *    前后十几轮、三套机制仍然时灵时不灵 ⇒ 判定性价比不成立。
 *    完整复盘见 README 14.17 / 14.21 / 14.22。
 *    下面两条反向断言防止它（或它的专用机制）被重新加回来。 */
const scaffold = list.filter((r) => r.input === 'minecraft:scaffolding');
const cob = scaffold.find((r) => r.output === 'minecraft:cobweb');
const sap = scaffold.find((r) => r.id === 'scaffolding_to_sapling');
if (!cob || cob.trigger !== 'crossing' || cob.crossings !== 8) fail('脚手架 → 蜘蛛网 不是 8 次 crossing');
if (!sap || sap.trigger !== 'landing' || sap.crossings !== 4 || !sap.drop
  || sap.output !== '@mapped') {
  fail('脚手架 → 树苗（@mapped）不见了或写错了 —— 对照实验结束后应已恢复');
}
if (sap && onListOf(sap)[0] !== '#minecraft:leaves') fail('脚手架 → 树苗 的落点不是 #minecraft:leaves');
if (scaffold.length !== 2) {
  fail('脚手架应有且仅有 2 条配方（蜘蛛网 / 树苗），实际 ' + scaffold.length + ' 条：'
    + scaffold.map((r) => r.id).join('、'));
}
/* ⛔ 反向断言一：地狱疣那条配方不该再出现（已放弃）。 */
if (scaffold.some((r) => r.output === 'minecraft:nether_wart')) {
  fail('脚手架 → 地狱疣 已于 2026-09-22 放弃并删除，不该再出现（见 README 14.22）');
}
/* ⛔ 反向断言二：不许再出现"按竖列计数"那套配置。
 *   实测：同一竖列的多个脚手架共用计数 + 共用"上一次方向"
 *   → 每 tick 记假翻转 → 0 到 8 只用 1 秒 → 全变蜘蛛网。 */
if (cfg.gravity != null && cfg.gravity.position_count_blocks != null) {
  fail('gravity.position_count_blocks 已删除（会让同列多个脚手架互相污染计数），不该再出现');
}
/* ⛔ 反向断言三：不许再出现 sticky —— 它只为上面那条配方存在，已随它删除。
 *   （留着它会让 landing 的语义变成"蹭过一次就算"，且没有配方需要这种语义。） */
if (scaffold.some((r) => r.sticky === true)) {
  fail('sticky 机制已随「脚手架 → 地狱疣」一起删除，不该有配方再用它');
}
/* 泥巴那条按用户要求已删除 —— 留着断言防止它哪天又被加回来 */
if (scaffold.some((r) => r.output === 'minecraft:mangrove_propagule')) {
  fail('脚手架 → 红树幼苗（泥巴）已经按要求删除，不该再出现');
}
/* 脚手架/滴水石锥有"原版才有的前置条件"，必须带 hint 提示玩家 */
for (const r of [...scaffold, ...list.filter((x) => x.input === 'minecraft:pointed_dripstone')]) {
  if (r.hint == null || String(r.hint).length < 6) fail(r.id + ' 缺少 hint（脚手架/滴水石锥的掉落前提必须能查到）');
}
const LEAVES = ['oak', 'spruce', 'birch', 'jungle', 'acacia', 'dark_oak',
  'mangrove', 'cherry', 'azalea', 'flowering_azalea'];
if (sap && sap.output === '@mapped') {
  const map = sap.map ?? {};
  for (const leaf of LEAVES) {
    if (!map['minecraft:' + leaf + '_leaves']) fail('树叶对照表缺 ' + leaf);
  }
  const extra = Object.keys(map).filter((k) => !LEAVES.some((l) => k === 'minecraft:' + l + '_leaves'));
  if (extra.length) console.log('  · 对照表另有 ' + extra.length + ' 项（模组树叶）：' + extra.join(', '));
  console.log('  ✓ 树叶对照表覆盖全部 ' + LEAVES.length + ' 种原版树叶');
}
console.log('  ✓ 脚手架 ' + scaffold.length + ' 条（地狱疣那条已放弃，见 README 14.22）：'
  + '8 次→蜘蛛网 / 4 次+树叶→对应树苗（@mapped，掉落物）');

/* 3b) 接触判定参数（本该在 gravity 段里） */
const look = cfg.gravity?.landing_lookahead;
if (look !== 0 && look !== 1 && look !== 2) fail('gravity.landing_lookahead 应为 0/1/2，实际 ' + JSON.stringify(look));
else console.log('  ✓ gravity.landing_lookahead = ' + look + '（高速下落时按运动方向预判 1 格）');

/* 4) 滴水石锥 16 次 */
const drip = list.find((r) => r.input === 'minecraft:pointed_dripstone');
if (!drip || drip.output !== 'minecraft:dripstone_block' || drip.crossings !== 16
  || drip.trigger !== 'crossing') fail('滴水石锥配方写错了');

/* 5) 同一输入 + 同一次数的多条 landing 配方是允许的（引擎会全试一遍），
 *    但同一次数的多条 crossing 只有第一条生效 —— 那才是配置冲突。 */
const clash = new Map();
for (const r of list.filter((x) => x.trigger === 'crossing')) {
  const k = r.input + '@' + r.crossings;
  clash.set(k, (clash.get(k) ?? 0) + 1);
}
const conflicts = [...clash.entries()].filter(([, n]) => n > 1);
if (conflicts.length) fail('crossing 冲突（同输入同次数多条）: ' + JSON.stringify(conflicts));
else console.log('  ✓ 没有 crossing 冲突');

if (bad === 0) console.log('  ✓ 全部通过');
else console.log('  ✗ ' + bad + ' 项不通过');

const lootG = list.find((r) => r.insert && r.insert.items.includes('minecraft:music_disc_relic'));
const lootS = list.find((r) => r.insert && r.insert.items.includes('minecraft:sniffer_egg'));
console.log('  可疑沙砾战利品池: ' + (lootG ? lootG.insert.items.length + ' 项 ✓' : '✗ 缺失'));
console.log('  可疑沙子战利品池: ' + (lootS ? lootS.insert.items.length + ' 项 ✓' : '✗ 缺失'));

/* ------------------------------------------------------------------ */
/* 工作台配方（无序合成）—— 与重力配方同一份配置，一起自检               */
/* ------------------------------------------------------------------ */
/* 这些配方由 mirror_n9_crafting.js 用 ServerEvents.recipes 注册进
 * 服务端 RecipeManager（原版配方），JEI 的工作台分类自动可见。
 * 这里只做**配置层**的自检：产物/原料写没写对、ID 有没有重复、
 * 原料数量是否超上限。注册是否真的成功，由游戏内 /mirror crafting 回读。 */

const craft = cfg.craftingRecipes ?? {};
const craftList = Array.isArray(craft) ? craft : (craft.list ?? []);
console.log('\n工作台配方（无序合成）: ' + craftList.length + ' 条，启用: ' + craft.enabled);

const EXPECTED_CRAFT = [
  { output: 'minecraft:suspicious_sand', ingredients: ['minecraft:sand', 'minecraft:glow_lichen'] },
  { output: 'minecraft:suspicious_gravel', ingredients: ['minecraft:gravel', 'minecraft:glow_lichen'] },
];
let craftBad = 0;
const craftFail = (m) => { craftBad++; console.log('  ✗ ' + m); };

for (const want of EXPECTED_CRAFT) {
  const r = craftList.find((x) => x.output === want.output);
  if (!r) { craftFail('缺少配方 ' + want.output); continue; }
  const got = [...(r.ingredients ?? [])].sort().join(',');
  const exp = [...want.ingredients].sort().join(',');
  if (got !== exp) craftFail(want.output + ' 的原料是 [' + got + ']，期望 [' + exp + ']');
  if (r.count != null && r.count !== 1) craftFail(want.output + ' 的 count 应为 1');
  if (r.id == null || !String(r.id).includes(':')) craftFail(want.output + ' 的 id 没写全（应形如 mirror:xxx）');
}
/* id 重复 = 后者覆盖前者，表现是"某条配方凭空消失" */
const craftIds = new Map();
for (const r of craftList) craftIds.set(r.id, (craftIds.get(r.id) ?? 0) + 1);
const craftDup = [...craftIds.entries()].filter(([, n]) => n > 1);
if (craftDup.length) craftFail('id 重复: ' + JSON.stringify(craftDup));
/* 原料种数上限 9（原版 3×3） */
for (const r of craftList) {
  const n = (r.ingredients ?? []).length;
  if (n < 1 || n > 9) craftFail(r.output + ' 的原料种数是 ' + n + '，应在 1~9');
}

if (craftBad === 0) {
  console.log('  ✓ 沙子 + 发光地衣 → 可疑的沙子');
  console.log('  ✓ 沙砾 + 发光地衣 → 可疑的沙砾');
  console.log('  ✓ 无重复 id、原料数量都在 1~9');
} else {
  console.log('  ✗ ' + craftBad + ' 项不通过');
}

/* ⚠️ 必须让"发现问题"变成非零退出码。
 *    之前这里没有 exit：打出 ✗ 也返回 0，调用方只看退出码就会把问题放过去。 */
const totalBad = bad + craftBad;
if (totalBad > 0) {
  console.log(`\n共 ${totalBad} 项不通过（重力配方 ${bad} + 工作台配方 ${craftBad}）`);
  process.exit(1);
}