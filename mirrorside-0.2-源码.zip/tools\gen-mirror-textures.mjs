#!/usr/bin/env node
/**
 * 生成"镜面"方块贴图。
 *
 * ── 为什么要用脚本生成，而不是手画的图片 ──────────────────────────
 * 贴图要是**确定性的**：颜色、明暗、网格位置全都由代码写死，
 * 任何时候重跑都能得到完全一样的文件。手画的 PNG 一旦丢了或想微调，
 * 就只能重画一遍；脚本改一个数字就能重新生成。
 *
 * ── 画法依据（对齐铁砧工艺 AnvilCraft 的风格）────────────────────
 * 用 tools/inspect-texture.mjs 解码该模组的方块贴图后得到的事实：
 *   · 尺寸 16x16，索引调色板 10 色
 *   · 8x8 网格重复（整张图是 2x2 个 8px 子块）
 *   · 每个子块内部是**斜角明暗**：左上最亮，向右下逐级变暗
 *     （其 royal_steel 的亮度序列为 #**** → ++ → == → ::）
 *   · 冷调灰蓝，饱和度低，色相略偏蓝紫
 * 本脚本沿用这套结构：同样的 8x8 斜角网格 + 低饱和冷色调，
 * 只是把色相推到"银蓝抛光金属"，并叠一层镜面高光。
 *
 * ── 产出 ────────────────────────────────────────────────────────
 *   mirror_surface_side.png  侧面：抛光板 + 网格斜角
 *   mirror_surface_top.png   顶面：完整镜面 + 对角高光
 *   mirror_surface_bottom.png 底面：暗色磨砂
 *
 * 纯手工编码 PNG（zlib + CRC32），不依赖任何第三方库。
 */

import { writeFileSync, mkdirSync } from 'node:fs';
import { deflateSync } from 'node:zlib';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* ------------------------------------------------------------------ */
/* PNG 编码                                                            */
/* ------------------------------------------------------------------ */

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c;
  }
  return t;
})();

/* ⚠️ 名字不能叫 crc32 —— 上面那个数组如果也叫 crc32，会把它遮蔽掉，
 * 调用时直接 TypeError。 */
function crcOf(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crcOf(Buffer.concat([typeBuf, data])));
  return Buffer.concat([len, typeBuf, data, crc]);
}

/**
 * 把 RGBA 像素数组编码成 PNG。
 *
 * 用 colorType=6（真彩 + alpha）、bitDepth=8。
 * 也许成索引调色板更省体积，但那要额外做量化，
 * 而这几张贴图只有 16x16，体积差异可以忽略。
 *
 * @param {number} w 宽
 * @param {number} h 高
 * @param {(x:number,y:number)=>number[]} get 返回 [r,g,b,a]
 */
function encodePng(w, h, get) {
  const stride = w * 4;
  const raw = Buffer.alloc(h * (stride + 1));
  let p = 0;
  for (let y = 0; y < h; y++) {
    raw[p++] = 0;                                  // 滤波类型 0（None）
    for (let x = 0; x < w; x++) {
      const [r, g, b, a] = get(x, y);
      raw[p++] = r & 0xff;
      raw[p++] = g & 0xff;
      raw[p++] = b & 0xff;
      /* ⚠️ alpha 必须原样写入。这几张贴图完全不透明（a=255），
       * 但这里绝不能写 `a & 0xff` 之类的裁剪 —— 那会把 255 变成 0，
       * 结果是贴图在游戏里全透明（实测踩过：解码出来全是 "."）。 */
      raw[p++] = a;
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;    // bitDepth
  ihdr[9] = 6;    // colorType: RGBA
  ihdr[10] = 0;   // compression
  ihdr[11] = 0;   // filter
  ihdr[12] = 0;   // interlace

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/* ------------------------------------------------------------------ */
/* 配色：低饱和冷调银蓝，10 个色阶（对齐 AnvilCraft 的色板规模）        */
/* ------------------------------------------------------------------ */

// 从最亮到最暗。数值刻意压低饱和度（R≈G≈B，B 略高），
// 这样在游戏里不会显得比原版方块"艳"，但与 AnvilCraft 的冷灰蓝同调。
const PALETTE = [
  [0xf2, 0xf6, 0xfa],   // 0 镜面高光（最亮，略偏蓝）
  [0xdf, 0xe6, 0xee],   // 1
  [0xc9, 0xd3, 0xde],   // 2
  [0xb2, 0xbe, 0xcb],   // 3
  [0x9b, 0xa9, 0xb8],   // 4
  [0x84, 0x93, 0xa4],   // 5
  [0x6e, 0x7d, 0x8e],   // 6
  [0x59, 0x68, 0x78],   // 7
  [0x46, 0x53, 0x61],   // 8
  [0x34, 0x3f, 0x4b],   // 9 描边/缝隙（最暗）
];

const SIZE = 16;

/**
 * 取调色板颜色，补上不透明 alpha，返回完整 RGBA。
 *
 * ⚠️ 必须走这个函数，不能直接把 PALETTE[i] 当像素返回。
 * PALETTE 的条目是三元组 [r,g,b]。若直接返回它，编码器解构出的 a 是
 * undefined，写进 Buffer 时会被强转成 0 —— 结果是**整张贴图全透明**。
 * 实测踩过：游戏里看不到方块，而解码出来是清一色的透明点。
 */
function rgba(index) {
  const [r, g, b] = PALETTE[index];
  return [r, g, b, 255];
}

/**
 * 8x8 子块内的斜角明暗索引。
 *
 * 对齐参照贴图（AnvilCraft cut_*_block）的规律：**明暗沿对角线单调递减** ——
 * 左上最亮，越往右下越暗。它那张 16x16 的亮度序列就是
 * `#**** → ++ → == → ::` 一路走暗，没有回跳。
 *
 * ⚠️ 早先的写法用 `1 + round((d/14)*6)` 再叠一层"每隔 4 个像素减一档"的
 * 交错，结果亮度不再单调（出现 `#` 紧挨 `+` 然后又变亮），看起来像
 * 每块瓷砖各自凸起，与参照的"整块金属斜向渐变"完全不像。已改掉。
 *
 * @param x 子块内 x（0..7）
 * @param y 子块内 y（0..7）
 */
function bevelIndex(x, y) {
  // 对角线距离 0..14，线性映射到调色板中段 1..6。
  // 中段留出 0（高光）与 7/8/9（暗部、缝隙），方便别处强调。
  const d = x + y;
  return 1 + Math.round((d / 14) * 5);
}

/** 侧面：整块抛光面 + 8x8 板缝 + 斜向渐变明暗。 */
function sideTexture() {
  return (x, y) => {
    const lx = x % 8, ly = y % 8;

    /* 板缝：只在子块的右/下边留一条暗线，模拟"拼起来的镜面板"。
     * 参照贴图同样是 8x8 重复，但它靠明暗跳变暗示拼缝；
     * 这里用一条明确的暗线，方块在远处也能看出是拼接结构。 */
    if (lx === 7 || ly === 7) return rgba(9);

    return rgba(bevelIndex(lx, ly));
  };
}

/** 顶面：完整镜面 + 一道对角高光带。 */
function topTexture() {
  return (x, y) => {
    // 外圈描边，让方块在物品栏里轮廓清晰
    if (x === 0 || y === 0 || x === SIZE - 1 || y === SIZE - 1) return rgba(9);
    if (x === 1 || y === 1 || x === SIZE - 2 || y === SIZE - 2) return rgba(7);

    // 对角高光带（左上 → 右下）：|x-y| 越小越亮，形成一道斜向反光
    const diag = Math.abs(x - y);
    if (diag === 0) return rgba(0);
    if (diag === 1) return rgba(1);
    if (diag === 2) return rgba(2);

    // 其余部分按斜角渐变，整体比侧面亮一档（镜面更"平"）
    return rgba(Math.max(2, bevelIndex(x, y) - 1));
  };
}

/** 底面：磨砂暗色，只有轻微网格。 */
function bottomTexture() {
  return (x, y) => {
    const lx = x % 8, ly = y % 8;
    if (lx === 7 || ly === 7) return rgba(9);
    return rgba(6 + (bevelIndex(lx, ly) % 2));
  };
}

/* ------------------------------------------------------------------ */
/* 输出                                                                */
/* ------------------------------------------------------------------ */

const here = dirname(fileURLToPath(import.meta.url));

/*
 * 定位模组资源目录。
 *
 * 目录层级（相对本脚本）：
 *   tools/                                  ← 本脚本所在
 *   <实例>/                                  ← 上溯 1 层
 *   versions/                                ← 上溯 2 层
 *   .minecraft/                              ← 上溯 3 层
 *   <工程根>/                                 ← 上溯 4 层
 *   <工程根>/mirror-gravity-mod/src/main/resources/...
 *
 * ⚠️ 是 **4 层**不是 3 层。曾经写成 3 层，结果文件被写进了
 *    <工程根>/.minecraft/mirror-gravity-mod/ —— 一个并不存在的工程副本目录。
 *    当时没报错（目录被自动创建了），但贴图永远不会被打进 jar，
 *    表现是"贴图没生效"。手算层数很容易错，改这里时请对着上面的层级数一遍。
 */
const PROJECT_ROOT = join(here, '..', '..', '..', '..');
const OUT_DIR = join(PROJECT_ROOT,
  'mirror-gravity-mod', 'src', 'main', 'resources',
  'assets', 'mirrorgravity', 'textures', 'block');

mkdirSync(OUT_DIR, { recursive: true });

const targets = [
  ['mirror_surface_side.png', sideTexture()],
  ['mirror_surface_top.png', topTexture()],
  ['mirror_surface_bottom.png', bottomTexture()],
];

for (const [name, fn] of targets) {
  const png = encodePng(SIZE, SIZE, fn);
  const out = join(OUT_DIR, name);
  writeFileSync(out, png);
  console.log(`${name}  ${png.length}B  → ${out}`);
}

console.log('\n已生成 3 张贴图（16x16，RGBA）。');
console.log('记得：方块模型要引用 mirrorgravity:block/mirror_surface_* 这几张。');
