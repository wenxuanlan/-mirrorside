// =====================================================================
// 镜维度 · 工作台配方（无序合成）
// =====================================================================
// 玩法：**发光地衣**当作"镜面的碎屑" —— 和沙子 / 沙砾揉在一起就得到
// 对应的可疑方块，玩家因此不必去废墟找考古点也能造出加工原料。
//
// 配置来源：mirror_config.js → craftingRecipes（唯一真相在那里）
//
// ── 为什么单独开一个模块（n9）而不是塞进 n3 ────────────────────────
// n3 管的是"重力方块在交界处反复坠落"的加工配方，那是本模组自己的机制；
// 这里管的是**原版工作台配方**，注册入口、生效时机、排查手段都不同：
//   · 进的是服务端 RecipeManager，改完 /reload 就生效
//   · 出问题时 KubeJS 只往日志里写一行，游戏里没有任何表现
// 混在一起会让"配方不生效"这种问题无从下手。
//
// ── JEI 为什么不用管 ───────────────────────────────────────────────
// KubeJS 注册的是**真正的原版配方对象**（进 RecipeManager），
// 会随原版机制（ClientboundUpdateRecipesPacket）同步到客户端，
// JEI 的工作台分类直接读客户端的配方表，所以**自动**就能看到。
// 这与重力方块加工配方不同 —— 那种不是原版配方类型，
// 必须自己导出数据 + 写 JEI 分类（见 README §14.8）。
//
// ── 三条硬规矩（都踩过）────────────────────────────────────────────
// ⚠️ 1. ServerEvents.recipes 只能注册在 **server_scripts** 里。
//       写在 startup 脚本会报 "invalid script type STARTUP"，
//       而且会让整个 startup 脚本失败。
// ⚠️ 2. 所有 try 块内只用 var（Rhino 对 try 里的 const/let 会抛
//       InternalError: TypeError: redeclaration of var xxx）。
// ⚠️ 3. 事件处理器**嵌套块**里也只用 var（同上，且更隐蔽：
//       每次回调都抛，但脚本加载显示 0 errors）。
// =====================================================================

const MirrorCrafting = (() => {

  const N0 = global.MirrorDimension.modules.n0;
  if (N0 === undefined || !N0.ready) {
    console.error('[镜维度] 依赖模块未就绪，工作台配方模块未启用。');
    return { ready: false };
  }

  const MD = global.MirrorDimension;
  const cfg = N0.cfg;

  /* 配置结构（见 mirror_config.js）：
   *   craftingRecipes: { enabled: true, list: [ {...} ] }
   * 兼容"顶层直接是数组"的简写。 */
  const CR = cfg.craftingRecipes;
  const specs = Array.isArray(CR) ? CR
    : (CR != null && Array.isArray(CR.list) ? CR.list : []);
  const enabled = (CR != null && CR.enabled === true);

  /** 无序合成的原料上限（原版 3×3 工作台）。 */
  const MAX_INGREDIENTS = 9;

  /* 诊断表：本次事件里提交成功 / 失败的配方。
   * ⚠️ 每次事件触发（含 /reload）都要清空，否则会越攒越多。 */
  const registered = [];
  const failed = [];

  /** 把配置里的 output + count 转成 KubeJS 的写法：'3x minecraft:xxx'。 */
  function outputSpecOf(spec) {
    const n = spec.count != null ? Math.max(1, Math.floor(Number(spec.count))) : 1;
    const out = String(spec.output);
    return n > 1 ? (n + 'x ' + out) : out;
  }

  /**
   * 建完配方后立刻回读它的序列化结果，确认**参数落在了正确的字段上**。
   *
   * <p>为什么要这一步：KubeJS 的配方接口是**位置参数**，
   * 官方文档给的顺序是 `shapeless(产物, 原料数组)`。万一这个约定在本版本
   * 变了（或者我们把顺序写反），后果是"配方看起来注册成功、
   * 游戏里却永远合不出来、JEI 里也没有"—— 而且没有任何报错。
   * 这里直接读回 `result.id` 比一比，就把这种静默错位变成一条 error 日志。
   *
   * @returns 'ok' / 'mismatch' / 'unavailable'（读不到序列化结果时不算错）
   */
  function verifyShape(recipe, spec) {
    try {
      if (recipe == null) return 'unavailable';
      recipe.serializeChanges();
      var json = recipe.json;
      if (json == null || !json.has('ingredients') || !json.has('result')) {
        return 'unavailable';
      }
      var result = json.getAsJsonObject('result');
      var got = (result != null && result.has('id')) ? String(result.get('id').getAsString()) : null;
      return (got != null && got === String(spec.output)) ? 'ok' : 'mismatch';
    } catch (err) {
      return 'unavailable';
    }
  }

  /* ------------------------------------------------------------------ */
  /* 注册                                                                */
  /* ------------------------------------------------------------------ */
  /* KubeJS 的配方事件：服务器启动与每次 /reload 都会触发一次。 */

  ServerEvents.recipes(event => {
    /* 每次触发都重来一遍，避免 /reload 之后诊断数字虚高。 */
    registered.length = 0;
    failed.length = 0;

    if (!enabled) {
      console.info('[镜维度] 工作台配方已关闭（craftingRecipes.enabled = false）');
      return;
    }
    if (specs.length === 0) {
      return;
    }

    for (var i = 0; i < specs.length; i++) {
      var spec = specs[i];
      if (spec == null || spec.output == null) {
        console.error('[镜维度] 工作台配方无效（缺 output）: ' + JSON.stringify(spec));
        continue;
      }
      var rawInputs = Array.isArray(spec.ingredients) ? spec.ingredients : [];
      if (rawInputs.length === 0) {
        console.error('[镜维度] 工作台配方 ' + spec.output + ' 没有写 ingredients，跳过。');
        continue;
      }
      if (rawInputs.length > MAX_INGREDIENTS) {
        console.error('[镜维度] 工作台配方 ' + spec.output + ' 的原料有 ' + rawInputs.length
          + ' 种，超过工作台上限 ' + MAX_INGREDIENTS + '，跳过。');
        continue;
      }

      var label = spec.id != null ? String(spec.id) : ('(' + spec.output + ')');
      try {
        var inputs = [];
        for (var k = 0; k < rawInputs.length; k++) {
          inputs.push(String(rawInputs[k]));
        }
        /* ⚠️ 位置参数顺序：**产物在前、原料数组在后**（KubeJS 官方约定）。
         * 顺序写反不会报错，只会得到一条永远合不出来的配方 ——
         * 所以紧接着用 verifyShape 回读确认。 */
        var recipe = event.shapeless(outputSpecOf(spec), inputs);
        if (spec.id != null) {
          recipe.id(String(spec.id));
        }
        var shape = verifyShape(recipe, spec);
        if (shape === 'mismatch') {
          console.error('[镜维度] 工作台配方 ' + label
            + ' 的参数顺序可能写错了：回读到的产物不是 ' + spec.output
            + '。请核对 KubeJS 版本对 event.shapeless 的参数约定。');
        }
        registered.push({
          id: label,
          output: String(spec.output),
          count: spec.count != null ? Number(spec.count) : 1,
          ingredients: inputs.slice(),
          shape: shape,
          note: spec.note != null ? String(spec.note) : null,
        });
      } catch (err) {
        failed.push({ id: label, error: String(err) });
        console.error('[镜维度] 工作台配方 ' + label + ' 注册失败: ' + err);
      }
    }

    console.info('[镜维度] 工作台配方已注册 ' + registered.length + ' / ' + specs.length + ' 条'
      + (failed.length > 0 ? ('，失败 ' + failed.length + ' 条（见上面的 error）') : ''));
  });

  /* 加载期提示（与 n3 的配方提示同一风格，方便一眼确认配置读到了） */
  if (enabled && specs.length > 0) {
    var names = [];
    for (var si = 0; si < specs.length; si++) {
      var one = specs[si];
      names.push(String(one.output) + ' ← '
        + (Array.isArray(one.ingredients) ? one.ingredients.join(' + ') : '?'));
    }
    console.info('[镜维度] 工作台配方已加载 ' + specs.length + ' 条: ' + names.join('，'));
  } else if (specs.length > 0) {
    console.info('[镜维度] 工作台配方已加载 ' + specs.length
      + ' 条，但当前**已关闭**（craftingRecipes.enabled = false）');
  }

  /* ------------------------------------------------------------------ */
  /* 运行时回读：这些配方真的进服务端配方表了吗                            */
  /* ------------------------------------------------------------------ */
  /* 上面那些只说明"我们调了 KubeJS 的接口"。真正决定玩家能不能合出来的，
   * 是服务端 RecipeManager 里有没有这个 ID —— 这里查的就是它。
   * 拿不到（API 变化 / 权限）时返回 available:false，让指令层降级显示，
   * 而不是抛错。 */
  function verify(server) {
    const out = { available: false, reason: null, found: 0, total: 0, missing: [] };
    if (server == null) {
      out.reason = '拿不到服务器实例';
      return out;
    }
    try {
      var rm = server.getRecipeManager();
      if (rm == null) {
        out.reason = '拿不到 RecipeManager';
        return out;
      }
      out.total = rm.getRecipes().size();
      var missing = [];
      var found = 0;
      for (var i = 0; i < specs.length; i++) {
        var spec = specs[i];
        if (spec == null || spec.id == null) continue;
        var rl = MD.id(String(spec.id));
        if (rl == null) {
          missing.push(String(spec.id) + '（ID 非法）');
          continue;
        }
        var opt = rm.byKey(rl);
        if (opt != null && opt.isPresent() === true) found++;
        else missing.push(String(spec.id));
      }
      out.available = true;
      out.found = found;
      out.missing = missing;
      return out;
    } catch (err) {
      out.reason = String(err);
      return out;
    }
  }

  /* ------------------------------------------------------------------ */
  /* 对外导出                                                            */
  /* ------------------------------------------------------------------ */

  const api = {
    ready: true,
    enabled: enabled,
    maxIngredients: MAX_INGREDIENTS,

    list: function () { return specs.slice(); },
    count: function () { return specs.length; },
    /** 本次事件提交成功的配方（诊断用） */
    registered: function () { return registered.slice(); },
    /** 本次事件提交失败的配方（诊断用） */
    failed: function () { return failed.slice(); },
    verify: verify,
  };

  global.MirrorDimension.modules.n9 = api;
  return api;
})();
