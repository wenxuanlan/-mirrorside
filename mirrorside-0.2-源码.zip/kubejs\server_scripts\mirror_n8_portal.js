// =====================================================================
// 镜维度 · 镜面传送门（3×3×3 结构 + 望远镜点燃）
// =====================================================================
// 这个模块只做三件事，其余全在原版/模组里：
//
//   1) 监听"用某物品右键某个方块" → 判断物品是不是望远镜
//   2) 把这次右键转交给模组的 MirrorGravityApi.tryIgniteMirrorPortal(...)
//   3) 把返回的状态码翻成给玩家看的话
//
// ⚠️ 为什么结构校验与方块替换**不在脚本里**：
//    那两件事必须贴着方块实例与方块标签走 ——
//    3×3×3 的 27 格判定、`BlockState#is(TagKey)`、以及
//    "把玻璃换成传送门方块"这个服务端世界写操作，都在
//    `work.dsh.mirror.gravity.MirrorPortalShape` 里。
//    脚本这里写不出来的东西（自定义方块、标签）就别硬写。
//
// ⚠️ 事件来源说明（查过 KubeJS 实现）：
//    KubeJS 的 BlockEvents.rightClicked 挂的是 NeoForge 的
//    `PlayerInteractEvent.RightClickBlock`，它在
//    `ServerPlayerGameMode#useItemOn` 的**最开始**触发，
//    所以**手持望远镜右键方块同样会触发**（望远镜的"开镜"是物品的
//    use 行为，发生在方块交互之后，不影响这个事件）。
//
// ⚠️ 所有 try 块内只用 var（Rhino 对 try 里的 const/let 会抛
//    InternalError: TypeError: redeclaration of var xxx）
// =====================================================================

const MirrorPortalIgnition = (() => {

  const MD = global.MirrorDimension;
  const N0 = MD.modules.n0;
  if (N0 === undefined || !N0.ready) {
    console.error('[镜维度] 基础层未就绪，镜面传送门模块未启用。');
    return { ready: false };
  }

  const cfg = N0.cfg;
  const P = cfg.mirrorPortal != null ? cfg.mirrorPortal : {};

  /** 事件里拿到的物品 ID（去掉可能的命名空间差异，统一成完整形式）。 */
  function itemIdOf(stack) {
    try {
      return String(stack.id);
    } catch (err) {
      return '';
    }
  }

  /** 给玩家发一条提示（拿不到玩家就安静跳过，不当成错误）。 */
  function tell(player, text) {
    try {
      player.tell(Text.gold(text));
    } catch (err) {
      // 提示失败不影响玩法
    }
  }

  BlockEvents.rightClicked(event => {
    if (P.enabled === false) return;

    var want = String(P.ignition_item != null ? P.ignition_item : 'minecraft:spyglass');
    if (itemIdOf(event.item) !== want) return;

    var MG = N0.selfModApi;
    if (MG == null) {
      /* 模组没接入时不要静默 —— 这一条是"踩了没反应"的典型场景。 */
      if (P.notify !== false) {
        tell(event.player, '镜面传送门需要自研模组（mirrorside-0.1.jar），当前未加载。');
      }
      return;
    }

    var code;
    try {
      /* ⚠️ 传的是 event.block 的位置与所在世界。
       *    客户端那一侧的事件也会进来，模组侧会返回 not_server，
       *    下面按"静默忽略"处理，所以不会有重复提示。 */
      code = String(MG.tryIgniteMirrorPortal(event.block.level, event.block.pos));
    } catch (err) {
      console.error('[镜维度·传送门] 点燃调用失败: ' + err);
      return;
    }

    if (code === 'not_server' || code === 'bad_args') return;   // 客户端/参数问题：静默
    if (code === 'already') {
      if (P.notify !== false) tell(event.player, '这里已经是镜面传送门了。');
      return;
    }

    if (code === 'ok') {
      if (P.notify !== false) {
        tell(event.player, '镜面翻涌 —— 传送门已开启。');
      }
      console.info('[镜维度·传送门] ' + event.player.username + ' 在 '
        + String(event.block.pos) + ' 点燃了传送门');
      return;
    }

    /* 其余都是结构错误码，把中文说明回给玩家。
     * 文案由模组侧统一提供（describePortalResult），避免两处维护。 */
    if (P.notify !== false) {
      var zh;
      try {
        zh = String(MG.describePortalResult(code));
      } catch (err2) {
        zh = code;
      }
      tell(event.player, '镜面没有反应：' + zh);
    }
  });

  /* ------------------------------------------------------------------ */
  /* 对外导出                                                            */
  /* ------------------------------------------------------------------ */

  const api = {
    ready: true,
    enabled: function () { return P.enabled !== false; },
    ignitionItem: function () {
      return String(P.ignition_item != null ? P.ignition_item : 'minecraft:spyglass');
    },
    /** 结构说明（供 /mirror portal 回显，唯一真相在配置里）。 */
    structure: function () {
      return {
        bottom: String(P.bottom_block),
        top: String(P.top_block),
        centerTag: String(P.center_tag),
        arrivalY: P.arrival_y,
      };
    },
  };

  global.MirrorDimension.modules.n8 = api;

  console.info('[镜维度·传送门] 点燃已就绪 — 用 ' + api.ignitionItem()
    + ' 右键中心玻璃（结构 ' + P.bottom_block + ' / 玻璃标签 #' + P.center_tag
    + ' / ' + P.top_block + '，' + (P.enabled === false ? '**配置里关掉了**' : '已启用') + '）');

  return api;
})();
