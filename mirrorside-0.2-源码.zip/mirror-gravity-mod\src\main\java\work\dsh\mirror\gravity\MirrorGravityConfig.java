package work.dsh.mirror.gravity;

/**
 * 本模组的物理参数。
 *
 * <p>刻意**不使用** NeoForge 的配置系统（ModConfigSpec 等）：
 * 那些 API 在 1.21.1 各小版本之间有变动，写错就是编译失败。
 * 这里只有几个数值，直接写常量最稳，也便于阅读与调参。
 */
public final class MirrorGravityConfig {

    /** 原版重力加速度（下落的方块与掉落物都是 0.04），仅作参考。 */
    public static final double VANILLA_GRAVITY = 0.04D;

    /* ------------------------------------------------------------------ */
    /* BlockPhysics 接管实体的往复参数                                       */
    /* ------------------------------------------------------------------ */

    /**
     * 下落的方块（沙砾/沙子）的重力加速度（格/tick²）。
     *
     * <p>用户的核心诉求是"**看得清力的变化过程**"——所以刻意远低于原版 0.04。
     *
     * <h2>为什么调得这么小</h2>
     * 用户反馈"速度越来越快，看不出重力加速度的变换过程"。
     * 那说明速度很快就撞上阻尼形成的终端速度，加速段一闪而过。
     * 终端速度 v_t = accel/(1-damping)，把 accel 降到 0.003、
     * damping 保持 0.99 时 v_t ≈ 0.3 格/tick，需要约 40 tick
     * （2 秒）才接近，加速过程因此清晰可见。
     */
    public static final double REBOUND_ACCEL = 0.003D;

    /**
     * 掉落物的重力加速度（格/tick²）。
     * 用户要求"掉落物重力调回正常"，所以用原版量级 0.04。
     */
    public static final double ITEM_ACCEL = 0.04D;

    /** 该实体使用哪个加速度。 */
    public static double accelFor(net.minecraft.world.entity.Entity entity) {
        return (entity instanceof net.minecraft.world.entity.item.FallingBlockEntity)
            ? REBOUND_ACCEL : ITEM_ACCEL;
    }

    /**
     * 沙砾的速度阻尼（每 tick 乘这个系数）。用户要的"略微阻力"。
     *
     * <p>终端速度 v_t = accel / (1 - damping)。
     * 0.003 / (1 - 0.99) = 0.3 格/tick —— 速度缓慢逼近它，
     * 加速过程因此**可见**（这是用户最在意的一点）。
     * 阻尼比 0.995 更明显，收敛更快、更容易看出"趋于稳定"。
     */
    public static final double REBOUND_DAMPING_PER_TICK = 0.99D;

    /**
     * 掉落物的阻尼（比沙砾轻得多）。
     *
     * <p>用户要求掉落物"重力调回正常"——正常的抛物线不该被明显拖慢。
     * 几乎不衰减，只在极端情况下起一点收敛作用。
     */
    public static final double ITEM_DAMPING_PER_TICK = 0.999D;

    /**
     * 掉落物的**实际**重力缩放（由本模组自己实现，不依赖 Pondus）。
     *
     * <h2>为什么必须自己实现</h2>
     * KubeJS 侧配置了 {@code falling_gravity_scale = 0.2}，期望物品的重力
     * 只有原版的 1/5（往复变慢、看得清）。那个值一路传到了 Pondus 的
     * {@code baseGravityStrength} 字段并被写入成功 —— 但**完全不生效**。
     *
     * <p>实测三份互相印证的证据：
     * <ul>
     *   <li>读回 {@code baseGravityStrength/currGravityStrength} 都是 0.2</li>
     *   <li>读回 {@code entity.getGravity()} 却是 **0.04**（未被乘 0.2）</li>
     *   <li>用位置二阶差分算出的实际加速度 ≈ **0.038**（就是满重力）</li>
     * </ul>
     * 也就是说 Pondus 的强度字段在本版本对掉落物是个**死字段**
     * （它的 EntityMixin 虽然对 getGravity() 做了乘法注入，但实际没作用到）。
     *
     * <h2>本模组的替代做法</h2>
     * 每次实体 tick 之后，把"多出来的那部分重力"从速度里扣掉：
     * <pre>
     *   扣除量 = getGravity() × (1 − scale)
     * </pre>
     * 于是净加速度从 0.04 变成 0.04 × 0.2 = 0.008。
     * 这与 {@link BlockPhysics} 对下落的方块所做的抵消是同一套思路。
     *
     * <p>⚠️ 只对掉落物生效。其它实体（生物/玩家）的数值没有实测依据，
     * 不要贸然套用。
     */
    public static final double ITEM_GRAVITY_SCALE = 0.2D;

    /**
     * 应用 {@link #ITEM_GRAVITY_SCALE} 时，垂直速度的**最小可分辨量**。
     *
     * <p>低于这个值时不做修正。原因见
     * {@link work.dsh.mirror.gravity.internal.VelocityFix#applyItemGravityScale}：
     * 那个修正的方向靠 {@code deltaMovement.y} 的符号推断，而在换向那一帧
     * 垂直速度恰好穿过 0，符号由上一帧残余决定、**两端可能不一致** ——
     * 一旦不一致，服务端与客户端就会朝相反方向各扣掉约 0.032 的速度，
     * 形成持续发散，只能靠位置包拉回，表现就是"偶尔一小段瞬移"。
     *
     * <p>取 0.05：正常往复中物品的垂直速度在换向附近远小于此
     * （实测换向前一帧约 0.06、换向后 0.04），而离开换向区后迅速增大，
     * 所以这个阈值只会在"符号不可信"的窗口里跳过修正。
     */
    public static final double GRAVITY_SCALE_MIN_SPEED = 0.05D;

    /**
     * 速度上限（格/tick）。**只用于下落的方块**，仅作兜底防止失控。
     *
     * <p>用户反馈"加速过程拖长了，但最终速度还是太快看不清"，
     * 所以这里主动压低到 0.12（约每秒 2.4 格）——足够慢、看得清。
     * 它低于终端速度 0.3，于是成为实际生效的速度上限。
     *
     * <p>⚠️ 千万不要把它用在掉落物上：物品投掷初速约 0.4~0.5，
     * 一削抛物线就会压扁（实测踩过）。掉落物已不经过本模组的物理。
     */
    public static final double REBOUND_MAX_SPEED = 0.12D;

    private MirrorGravityConfig() {
    }
}
