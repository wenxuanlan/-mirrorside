// =====================================================================
// 镜维度 · 运行时配置
// ---------------------------------------------------------------------
// 这个文件就是运行时配置本身 —— 它同时是「文档」和「数据」。
//
// 为什么不用 .json：KubeJS 7.2 的类过滤器（jar 内 kubejs.classfilter.txt）
// 明确拒绝 java.io / java.nio / java.lang（只逐个放行少数类），
// java.nio.file.Path 和 java.io.File 都拿不到，脚本**没有读文件的手段**。
// 所以配置只能写在脚本里。世界侧配置见 kubejs/config/mirror_dimension.json。
//
// 生效方式：/kubejs reload_startup_scripts，或重启游戏
// =====================================================================

/* =====================================================================
 * 考古战利品表：刷子能刷出来的物品（给"落在陶罐上"的配方用）
 * ---------------------------------------------------------------------
 * 数据来源：原版 1.21.1 的 `VanillaArchaeologyLoot` —— 考古战利品表在
 * 1.21 是**代码生成**的（不是 data/ 里的 JSON），所以直接读的源码。
 *
 * 按方块对应关系整理：
 *   可疑的沙砾 → 古迹废墟：TRAIL_RUINS_ARCHAEOLOGY_COMMON + _RARE
 *   可疑的沙子 → 沙漠水井 DESERT_WELL / 沙漠神殿 DESERT_PYRAMID
 *                + 海底废墟 OCEAN_RUIN_WARM / OCEAN_RUIN_COLD
 *
 * ⚠️ 游戏里具体用哪张表由**方块实体里存的战利品表**决定（取决于这个
 *    可疑方块是在哪个结构里生成的）。一旦它变成下落的方块，这份数据就没了，
 *    所以这里取的是"这种方块**可能**刷出的全部物品"，当作一个池子随机抽。
 *
 * ⚠️ 想给某个物品加权：把它的 ID 在列表里重复写几次即可。
 * ===================================================================== */

/** 可疑的沙砾：古迹废墟（trail ruins） */
const MIRROR_GRAVEL_BRUSH_LOOT = [
  // --- TRAIL_RUINS_ARCHAEOLOGY_COMMON ---
  'minecraft:emerald', 'minecraft:wheat', 'minecraft:wooden_hoe', 'minecraft:clay',
  'minecraft:brick', 'minecraft:yellow_dye', 'minecraft:blue_dye',
  'minecraft:light_blue_dye', 'minecraft:white_dye', 'minecraft:orange_dye',
  'minecraft:red_candle', 'minecraft:green_candle', 'minecraft:purple_candle',
  'minecraft:brown_candle',
  'minecraft:magenta_stained_glass_pane', 'minecraft:pink_stained_glass_pane',
  'minecraft:blue_stained_glass_pane', 'minecraft:light_blue_stained_glass_pane',
  'minecraft:red_stained_glass_pane', 'minecraft:yellow_stained_glass_pane',
  'minecraft:purple_stained_glass_pane',
  'minecraft:spruce_hanging_sign', 'minecraft:oak_hanging_sign',
  'minecraft:gold_nugget', 'minecraft:coal', 'minecraft:wheat_seeds',
  'minecraft:beetroot_seeds', 'minecraft:dead_bush', 'minecraft:flower_pot',
  'minecraft:string', 'minecraft:lead',
  // --- TRAIL_RUINS_ARCHAEOLOGY_RARE ---
  'minecraft:burn_pottery_sherd', 'minecraft:danger_pottery_sherd',
  'minecraft:friend_pottery_sherd', 'minecraft:heart_pottery_sherd',
  'minecraft:heartbreak_pottery_sherd', 'minecraft:howl_pottery_sherd',
  'minecraft:sheaf_pottery_sherd',
  'minecraft:wayfinder_armor_trim_smithing_template',
  'minecraft:raiser_armor_trim_smithing_template',
  'minecraft:shaper_armor_trim_smithing_template',
  'minecraft:host_armor_trim_smithing_template',
  'minecraft:music_disc_relic',
];

/** 可疑的沙子：沙漠水井 / 沙漠神殿 / 海底废墟（暖 + 冷） */
const MIRROR_SAND_BRUSH_LOOT = [
  // --- DESERT_WELL_ARCHAEOLOGY ---
  'minecraft:arms_up_pottery_sherd', 'minecraft:brewer_pottery_sherd',
  'minecraft:brick', 'minecraft:emerald', 'minecraft:stick', 'minecraft:suspicious_stew',
  // --- DESERT_PYRAMID_ARCHAEOLOGY ---
  'minecraft:archer_pottery_sherd', 'minecraft:miner_pottery_sherd',
  'minecraft:prize_pottery_sherd', 'minecraft:skull_pottery_sherd',
  'minecraft:diamond', 'minecraft:tnt', 'minecraft:gunpowder', 'minecraft:emerald',
  // --- OCEAN_RUIN_WARM_ARCHAEOLOGY ---
  'minecraft:angler_pottery_sherd', 'minecraft:shelter_pottery_sherd',
  'minecraft:snort_pottery_sherd', 'minecraft:sniffer_egg', 'minecraft:iron_axe',
  'minecraft:emerald', 'minecraft:wheat', 'minecraft:wooden_hoe',
  'minecraft:coal', 'minecraft:gold_nugget',
  // --- OCEAN_RUIN_COLD_ARCHAEOLOGY ---
  'minecraft:blade_pottery_sherd', 'minecraft:explorer_pottery_sherd',
  'minecraft:mourner_pottery_sherd', 'minecraft:plenty_pottery_sherd',
  'minecraft:iron_axe', 'minecraft:emerald', 'minecraft:wheat',
  'minecraft:wooden_hoe', 'minecraft:coal', 'minecraft:gold_nugget',
];

/* =====================================================================
 * 树叶 → 对应树苗（给"脚手架落在树叶上"的配方用）
 * ---------------------------------------------------------------------
 * ⚠️ 为什么必须手写这张表，而不能靠"把 _leaves 换成 _sapling"猜：
 *    原版 10 种树叶里有两种**不按这个规律命名**：
 *      minecraft:mangrove_leaves        → minecraft:mangrove_propagule（繁殖体）
 *      minecraft:azalea_leaves          → minecraft:azalea（不是 *_sapling）
 *      minecraft:flowering_azalea_leaves → minecraft:flowering_azalea
 *    猜名字的写法在遇到它们时会静默失效（配方永不触发、也没有报错）。
 *
 * 表里的键是**方块 ID**，值是**产物 ID**。落点在这个表里查不到时，
 * 配方不会触发（方块继续往复），不会退化成"变成树叶本身"。
 * ===================================================================== */
const MIRROR_LEAVES_TO_SAPLING = {
  'minecraft:oak_leaves': 'minecraft:oak_sapling',
  'minecraft:spruce_leaves': 'minecraft:spruce_sapling',
  'minecraft:birch_leaves': 'minecraft:birch_sapling',
  'minecraft:jungle_leaves': 'minecraft:jungle_sapling',
  'minecraft:acacia_leaves': 'minecraft:acacia_sapling',
  'minecraft:dark_oak_leaves': 'minecraft:dark_oak_sapling',
  'minecraft:mangrove_leaves': 'minecraft:mangrove_propagule',
  'minecraft:cherry_leaves': 'minecraft:cherry_sapling',
  'minecraft:azalea_leaves': 'minecraft:azalea',
  'minecraft:flowering_azalea_leaves': 'minecraft:flowering_azalea',
};

const MIRROR_CONFIG = {

  // ---- 命名空间与路径（要与 tools/generate-mirror-pack.mjs 一致）----
  namespace: 'mirror',
  dimension_path: 'mirror',
  dimension_type_path: 'mirror',
  biome_path: 'mirror',
  // 空地形用的 noise_settings 文件名
  noise_settings_path: 'mirror_void',

  /* ==================================================================
   * 世界结构（对应 镜维度设定.txt）
   * ================================================================== */
  layout: {
    // 可建造高度 -192 ~ 191（共 384 格）
    min_y: -192,
    height: 384,

    // 镜内范围 -64 ~ +63；此外为镜外（y >= 64 或 y <= -65）
    inner_min_y: -64,
    inner_max_y: 63,

    // 重力分界线：y > split_y 重力向下，y <= split_y 重力向上。
    // 取 0 正好落在下半块黑色玻璃（y = 0 / 1）上，
    // 即「穿过镜面中心后脚下变成另一边」。
    split_y: 0,

    // 玻璃层。每项可带多个 y（设定里的「两层」）。
    // 注意这些层同时是镜内/镜外的边界：站在 +63 顶层之上即进入镜外。
    glass_layers: [
      { name: '镜外上界', ys: [63, 62],   block: 'minecraft:white_stained_glass' },
      { name: '镜外下界', ys: [-64, -65], block: 'minecraft:white_stained_glass' },
      { name: '上下界面', ys: [-1, -2],   block: 'minecraft:black_stained_glass' },
      { name: '上下界面', ys: [0, 1],     block: 'minecraft:black_stained_glass' },
    ],

    // 玻璃由**世界生成**负责：生成器会为每个 y 产出一个
    // minecraft:fill_layer 地物并挂进群系，区块生成时自动铺满整层，
    // 无遗漏、不覆盖玩家已放的方块，也不需要玩家靠近。
    // 因此脚本侧的动态铺设默认关闭 —— 它只作为兜底保留。
    maintain_glass: false,
    // 仅当 maintain_glass = true 时才用到
    glass_chunks_per_tick: 1,
    glass_radius_chunks: 10,
  },

  /* ==================================================================
   * 重力方向反转（Pondus 模组）
   * ------------------------------------------------------------------
   * 为什么需要模组：原版只有 minecraft:generic.gravity 属性，
   * 把它设成负数只会让「下落」变成「上浮」，**视角和模型不会跟着转**，
   * 玩家看到的还是一个上下颠倒的世界，手感完全不对。
   * Pondus 用 mixin 重写了 Entity#getUpVector / LivingEntity#travel /
   * 碰撞盒朝向，并在客户端提供 CameraMixin + GameRendererMixin +
   * PlayerEntityRendererMixin，所以重力方向、相机、第三人称模型会一起转。
   *
   * 依赖：mods/pondus-1.0.1.jar（NeoForge 1.21.1，自足，内嵌 cloth-config）
   * 可用范围（Pondus 的 EntityTags.canChangeGravity）：
   *   · 生物（LivingEntity）      —— 玩家、怪物、动物全部
   *   · 弹射物（Projectile）      —— 箭、雪球、末影珍珠等
   *   · 矿车（Minecart）
   *   · 白名单非生物：掉落物、下落的方块（沙/砾/混凝土粉末）、TNT、
   *     末影之眼、经验球     ← 这正好覆盖「重力方块」的需求
   * ================================================================== */
  gravity: {
    // 总开关
    enabled: true,

    // 是否用 Pondus 做「方向 + 视角」的真实反转
    // false = 退回旧的原版属性方案（物理向上，但视角不转）
    use_pondus: true,

    /* 是否用自研模组处理**非生物**实体（下落的方块、掉落物、TNT……）。
     * 为什么需要：Pondus 的 canChangeGravity 白名单在本实例上没有生效，
     * 实测下落的方块与掉落物 100% 被拒绝（394 条日志全是 rejected），
     * 而脚本层无法绕过（反射也不行，Rhino 拿不到 getClass()）。
     * 自研模组直接写 Pondus 的数据字段（base + curr），绕开白名单。
     * 模组源码：D:\DSHwork\MC镜维度\mirror-gravity-mod
     * 关掉它 → 沙砾/掉落物退回原版行为（正常下落，不反转）。 */
    use_self_mod: true,

    // 分界线上下的重力方向（Pondus 的 Direction 名，小写）
    //   down = 原版正常重力；up = 反转
    // 想要水平重力也可以写 north / south / west / east
    region_directions: {
      inner: 'down',       // 镜内 -64 ~ +63：正常
      outer_upper: 'down', // 上半镜外（y > 0 那侧，含 y>=64）：正常
      outer_lower: 'up',   // 下半镜外（y <= 0）：反转
    },

    // 非玩家实体的扫描间隔（tick）。
    // 默认 1 = 每 tick 都扫。为什么不用更大值：沙子/沙砾下落很快，
    // 间隔大了会「还没扫到就已经落地」，表现就是重力方块不反转。
    // getEntities() 只是返回一个已维护的列表，每 tick 遍历开销极小
    // （而且只有方向不一致时才会真的下发）。
    entity_scan_interval: 1,

    /* **掉落物（minecraft:item）的方向检测间隔**（tick）。默认 4 = 0.2 秒一次。
     *
     * 作用：决定"每隔多久**重新**判定一次地上的掉落物该受哪个方向的重力"。
     * 掉落物在分界线附近是来回振荡的（这是"纯看坐标"规则的固有结果），
     * 这个值就是它多久被重新判定一次：
     *     1  → 每 tick 都判，越过分界线几乎立刻反向，贴着界线小幅抖动
     *     4  → **默认**。0.2 秒复判一次，滞后带来的额外位移是亚格级的，
     *          观感与每 tick 判定基本一致，但省掉了 3/4 的重复判定
     *     20 → 一秒才复判一次，越界后会明显多飞一段才被扭回来，摆幅显著变大
     *
     * 多飞的距离 ≈ 越界那一刻的速度 × 这个间隔，所以间隔越大越明显；
     * 实体是静止起落时还有 ½·a·间隔² 那一项（a = 0.04 × falling_gravity_scale）。
     *
     * ⚠️ **首次判定不受这个值限制**：刚丢出来的掉落物会立刻判一次方向，
     *    否则在下半镜外（本该朝上）它会先朝下掉一段才被扭回来。
     *    也就是说这个参数管的是"稳态下的重复判定频率"，不是"多久才开始管它"。
     *
     * 为什么单独给掉落物开这个参数，而不直接调大上面的
     * entity_scan_interval：
     *   · 下落的方块（沙子/沙砾）**必须**每 tick 判 —— 它的配方计数
     *     （gravityBlockRecipes）与往复物理都建立在"每 tick 都知道当前方向"
     *     之上，间隔一大就会出现"还没扫到就已经落地"、配方不再触发。
     *   · 掉落物**不做加工、不参与配方**，它的方向判定只影响自己的运动，
     *     所以可以低频处理，省掉每个掉落物每 tick 一次的
     *     KubeJS → 自研模组的调用。
     *
     * ⚠️ 副作用（想调大之前先看这条）：间隔等价于"越过分界线之后还能
     *    继续朝原方向飞多久"，调大了摆幅会变大。想最贴近原手感就设 1~2。
     *
     * 只影响掉落物（minecraft:item）。
     * TNT / 末影之眼 / 经验球 仍然按 entity_scan_interval 处理。
     * （若哪天把 entity_scan_interval 也调大，掉落物的实际间隔会变成
     *   两者的公倍数 —— 因为它是叠在扫描节拍之上的第二层节流。） */
    item_scan_interval: 4,

    /* **掉落物在运动中"位置同步"的间隔**（tick）。默认 10 = 每秒补发 2 次。
     *
     * 这是"物品在交界处反复坠落时偶尔闪一下"那个问题的开关。
     *
     * ── 问题根因（已查清，别再重新排查一遍）──────────────────────────
     * 原版把实体位置发给客户端是**门控**的（ServerEntity.sendChanges）：
     *
     *     if (tickCount % updateInterval == 0 || entity.hasImpulse || data.isDirty())
     *         → 发位置/速度包
     *     entity.hasImpulse = false;      // 每 tick 末尾清掉
     *
     * 其中 updateInterval 由 ChunkMap 按实体类型给出，**物品走默认 20 tick**。
     * 掉落物既不设 hasImpulse、数据也不 dirty，于是位置包**每秒才发一次**。
     * 这中间客户端只能靠本地预测，而它的预测与服务端存在持续偏差
     * （实测每个换向周期约 18 tick，偏差从 0.04 累积到 0.13 格）；
     * 下一个包到达时客户端位置被一次性硬赋值拉回
     * （1.21.1 的 Entity.lerpTo 就是直接 setPos）——
     * 画面上就是"这个物品忽然跳了一下"。实测最坏一次 1.30 格。
     *
     * ── 这个参数做什么 ────────────────────────────────────────────
     * 模组把 Entity.hasImpulse 置 true，绕过上面那个门控，让服务端
     * 按这个间隔把位置补发出去。那个标志每 tick 会被清掉，
     * 所以"多久置一次"就等于最终的发包节奏。
     *
     *     1  → 每 tick 都发（20 包/秒/实体）。漂移彻底归零，最干净，
     *          但包量是原版的 20 倍
     *     10 → **默认**。每 10 tick 发一次 = 2 包/秒（原版是 1 包/秒），
     *          残留漂移约 0.07 格 —— 只有原版的一半，包量只有原版的 2 倍，
     *          是"看不出来"与"开销"之间的折中
     *     20 → 就等于退回原版节奏（漂移 0.13 格 + 最坏 1.30 格的跳变）
     *     0  → 完全不置，等于关掉这个修正，回到原版行为
     *
     *     （漂移数值由实测外推：原版 20 tick 累积到 0.13 格，
     *       按间隔线性缩小 → 4 tick 约 0.03 格、10 tick 约 0.07 格。）
     *
     * 开销与范围：只有**正在运动**的掉落物会走到这里（静止的在模组的速度
     * 门槛处就返回了），所以额外包量与"场上正在动的掉落物个数"成正比，
     * 而不是实体总数。若哪天要堆几百个掉落的物品做视觉奇观，
     * 把它调到 10 以上（或直接回到 20）可以把同步包量再压下去。
     *
     * ⚠️ 这个值由脚本推给模组（MirrorGravityApi.setItemSyncInterval），
     *    改完要 /reload 或重启才生效；日志里会打印
     *    「掉落物位置同步间隔已设为 N tick」，/mirror gravity 里也能回读。 */
    item_sync_interval: 10,

    /* 下落的方块的**反转参考线**相对分界的偏移（格）。
     *
     * 为什么需要它：黑色玻璃占据 y=-1/-2，沙砾落在它下沿、包围盒顶到 y=-2 时
     * 就该反转，所以模组给下落的方块单独把参考线下移了一格：
     *     BlockPhysics.tick(fb, splitY + FALLING_REF_OFFSET)   // FALLING_REF_OFFSET = -1.0
     *
     * ⚠️ 这个值必须与模组里的 FALLING_REF_OFFSET 保持一致。
     * 实测踩过：KubeJS 的配方穿越计数原本用 y=0，而沙砾实际在
     * y≈-2.31 ~ -0.63 之间往复（受 -1.0 那条线控制），永远碰不到 y=0，
     * 于是计数停在 1、需要多次穿越的配方一次都不触发。
     *
     * 改了这里记得同步改 mirror-gravity-mod 里的 FALLING_REF_OFFSET。 */
    falling_ref_offset: -1.0,

    /* 下落的方块的方向迟滞带半径（格）—— **控制摆幅的旋钮**。
     *
     * 实体要越过 split 参考线 ± 该值才反向，所以带越宽、摆得越远。
     * 实测对照（参考线 y=-1.0）：
     *   0.75 → 沙砾在 y≈-2.31 ~ -0.63 之间摆动，摆幅约 1.7 格，
     *          上折点距 y=0 还差 0.63 格（够不到分界线）
     *   1.0  → 上折点正好落在 y=0 附近，摆幅约 2 格
     *
     * ⚠️ 别调得过大：带太宽时两侧的切换条件都难满足，
     * 实体可能被"锁"在带内不再往复。
     * 设 0 会让实体在分界线上疯狂抽搐，模组会直接拒绝。 */
    falling_hysteresis: 1.0,

    /* 重力方块配方的**计数方式**。
     *
     *   'flip'     —— 读模组当前实际生效的重力方向，方向一变就计 1 次。
     *                 **推荐**：与视觉/物理同源，迟滞带怎么调都不影响计数。
     *   'crossing' —— 旧的"y 是否跨过一条线"判定。
     *                 它与模组的迟滞状态机是两套不同度量，会出现
     *                 "视觉上来回好几次、计数只涨 1"，仅保留用于对比回退。
     *
     * 两者只能生效一个，否则同一次翻转会被计两次。 */
    count_mode: 'flip',

    /* 接触判定的**预判格数**（格）—— 修"下落的方块太快、一帧就落地"用的。
     *
     * landing 类配方要求"贴着目标方块"，判定发生在实体 tick **之前**、
     * 每 tick 只看一次。而原生重力下的下落实体最快可到约 2 格/tick，
     * 它会在一帧之内从"还差两格"直接变成"已经落地并被原版放回方块"，
     * 中间那个"贴着"的瞬间**根本没有任何一帧看到过** → 配方静默失效。
     *
     *   1（默认）—— 除了当前碰撞箱上下相邻的那一格，再往**运动方向**多看 1 格
     *                （也就是"下一 tick 一定会贴上"的那一格）。
     *   0        —— 关掉预判，只认当前这一帧真的贴着。
     *
     * ⚠️ 别调大：1 格已经是"下一帧就接触"的物理事实，
     *    再大就变成用户明确否掉过的"隔空取物"。 */
    landing_lookahead: 1,

    /* ⚠️ 这里曾经有一个 `position_count_blocks`（让脚手架按**竖列**计数），
     *    2026-09-22 实测证明它是错的，**已删除**。原因记在这里，别再走一遍：
     *
     *   动机是好的：脚手架碰一下方块就会重生（新实体、新 UUID），
     *   按实体计的次数会归零、攒不到 4 次。
     *   但按竖列计数带来两个致命后果：
     *     ① 同一竖列里的多个脚手架**共用一个计数器**，谁翻一下都算进去；
     *     ② 连"上一次方向"也跟着共用 —— 两个实体方向相反，脚本每处理一个
     *        就与另一个留下的方向不同，于是**每 tick 记一次假翻转**。
     *
     *   日志现场（同一竖列里两个脚手架）：
     *     15:22:28.274  已切换 4 次 … y=14.1   方向=down
     *     15:22:28.323  已切换 5 次 … y=-1.99  方向=up    ← 49ms 后 y 差 16 格
     *     15:22:28.338  已切换 6 次 … y=13.64  方向=down
     *     15:22:28.373  已切换 8 次 → 蜘蛛网
     *   0→8 只用 1 秒；连放 10 个脚手架时蜘蛛网每 100ms 出一个，
     *   而"4 次 + 落在灵魂沙上 → 下界疣"永远抢不到那 4 次。
     *
     *   ⇒ 现在一律**按实体 id 计数**（一个实体一份状态），互不干扰。
     *     至于"重生丢进度"：当时配套做的 `sticky` 与这条按列计数，
     *     都已随「脚手架 + 灵魂沙 → 地狱疣」那条配方一起**删除**
     *     （2026-09-22 放弃，见 README 14.17 / 14.22）。 */

    /* --- 交界处防抖（站在分界线附近时相机不要来回翻）---
     * 迟滞带：已朝上时要离开 split_y + 该值 才切回朝下，反之亦然。
     *         带内维持原方向，所以站在线上不会抖。
     * 确认停留：想翻到对面，必须在对面**连续停留**这么多 tick。
     *         中途回到原来那边就重新计时、不翻。
     *         ← 这样「来回快速穿越」根本不会翻，只有真正走过去并留下才翻。
     *         （早先用的是「两次反向至少隔 N tick」，管不住慢速来回穿越，
     *           结果变成每秒翻一次，实测被挡下次数为 0。已改掉。） */
    player_dead_zone: 1.5,    // 玩家：1.5 格迟滞（防鼠标微抖；来回穿越靠下面的"确认停留"挡）
    player_flip_gap: 20,      // 玩家：需连续停留 1 秒才允许翻转
    /* 其它生物（羊、牛这类）。它们不像玩家那样受鼠标抖动影响，
     * 原来 2 秒太重、反应迟钝，收到 0.5 秒。 */
    entity_dead_zone: 0.5,    // 其它生物：0.5 格
    entity_flip_gap: 10,      // 其它生物：需连续停留 0.5 秒
    /* 快速移动的实体（下落的方块、掉落物、TNT 等）单独配。
     * 沙砾、沙子这类下落很快，用生物的确认时间会导致它还没确认完
     * 就已经穿过分界线飞走了 —— 表现就是「重力方块从不反转」。
     * 判断方式是**按实体类型名匹配**（不是查属性，那招在 Rhino 里不可靠）。 */
    /* 下落/掉落类实体（下落的方块、掉落物、TNT 等）。
     *
     * ⚠️ 这两个值必须够大，否则会在分界线附近**永久弹跳**。
     *
     * 机理（这一点很反直觉，踩了很久才想明白）：
     *   物体在哪一侧就受那一侧的重力，所以靠近分界线时它天然会来回振荡。
     *   要让它**停下来**，必须让重力变成"恢复力"：
     *     迟滞带够宽 → 物体在带内时两侧的切换条件都不满足 → 维持原方向
     *   → 它被推向带中心并最终静止（叠在镜面玻璃上）。
     *
     *   之前的 0.3 格带 = 几乎没有带，物体每次都冲到对面才反向，
     *   于是永远弹跳 —— 表现就是"反复下落、一直不变"，
     *   而且穿越计数恒为 0（从未真正"穿过"）。
     *
     * 3.0 格的含义：
     *   已朝下时，要落到 y < -3 才切朝上；
     *   已朝上时，要升到 y > +3 才切朝下。
     *   于是它会在 [-3, +3] 之间减速、停住。
     *
     * 注意不能太大：黑色玻璃在 y=0/1 与 y=-1/-2，若带太宽，
     * 物体够不到切换点就撞在玻璃上，就不会反向也不会有配方。 */
    falling_dead_zone: 3.0,   // 迟滞带半径（格）
    falling_flip_gap: 4,      // 反向还需连续确认 4 tick
    /* 重力方块的重力强度倍数（1.0 = 原版）。
     * 调小可以让沙砾落得**更慢**，便于观察"减速—静止—反向加速"的完整过程。
     * ⚠️ 太小会显得像浮空；0.15~0.3 之间比较适合观察。 */
    falling_gravity_scale: 0.2,

    /* --- 手动覆盖（对照测试用，游戏里用 /mirror gravity 改）---
     * force_direction != null 时，镜维度内所有实体都用这个方向，
     * 直到 force_until_tick 到点（-1 = 一直有效，重启或再改一次才失效）。 */
    force_direction: null,
    force_until_tick: -1,

    /* --- 以下两项只在 use_pondus = false 时有意义（降级方案）--- */
    // 是否改原版 minecraft:generic.gravity 属性值
    manage_attribute: false,
    // 正常 / 反转的属性值。注意：Pondus 生效时**必须**保持 0.08，
    // 否则属性反向 + 重力方向反向会叠加成双倍上浮。
    normal: 0.08,
    inverted: -0.08,
  },

  /* ==================================================================
   * 重力方块配方
   * ------------------------------------------------------------------
   * 玩法：重力方块（沙砾/沙子）来回穿越重力交界处，穿越够次数后
   * 变成另一种方块 —— 一种靠"反复坠落"加工的机制。
   *
   * 字段说明（每条配方）：
   *   id         可选，唯一标识；不写则由 input->output 自动生成
   *   input      下落的方块的原始方块 ID
   *   output     达成后变成的方块 ID。另外三种写法见下面「产物形态」
   *   crossings  需要穿越几次重力交界处（1 = 只穿一次）
   *   trigger    触发方式，二选一：
   *                'crossing'（默认）穿越交界处的那一刻直接变
   *                'landing'         来回穿越够次数后，落在指定方块上才变
   *   on         仅 trigger='landing' 时有效：要求落在哪种方块上。
   *                可以写**一条**，也可以写**一组**（数组）：
   *                  方块 ID：'minecraft:furnace'
   *                  标签   ：'#c:storage_blocks'（# 开头 = 标签查询，
   *                           判定交给模组的 blockStateHasTag，脚本侧不碰 TagKey）
   *                  一组   ：['#c:storage_blocks', '#c:storage_blocks/raw_tin', ...]
   *                           写一组是必要的：父标签不一定聚合得到子标签
   *                           （实测 AnvilCraft 的 6 种粗矿块就不在父标签里）
   *   map        仅 output='@mapped' 时必填：'落点方块 ID' → '产物 ID' 的对照表。
   *                表里查不到的落点**不触发**（方块继续往复），
   *                刻意不退化成"变成落点本身"。
   *   drop       可选，true = 产物以**掉落物**形式弹出，不原地放成方块。
   *                用于树苗 / 地狱疣这类"要能捡走"的产物 ——
   *                原地放方块会把落点（树叶 / 灵魂沙）盖掉。
   *   insert     可选，落在容器上时往容器里塞物品：
   *                { items: [物品 ID...], count: 1, force: false }
   *                · items 是随机候选列表（重复写同一个 ID = 给它加权）
   *                · force=false（默认）时**容器装不下就不触发**，
   *                  方块继续往复等位置 —— 不会白扔一个物品
   *                · force=true 时容器满了也触发，那一个物品放不进去就丢掉
   *                · 判定与放入都走模组的容器接口（见经验总结第十九章）
   *   at         可选，'lower'（只算下界面）/ 'upper'（只算上界面）/ 不写=两侧都算
   *
   * 「产物形态」四种（对应 output 字段）：
   *   'minecraft:iron_block'  写死的方块 / 物品
   *   '@landed'               变成"落在的那个方块"
   *                             （铁砧落在任意矿物块/金属块上 → 变成那一块）
   *   '@mapped'               按 map 表把**落点**翻成产物
   *                             （脚手架落在树叶上 → 对应树苗）
   *   以上任意一种 + drop:true  = 产物弹成掉落物而不是放成方块
   *
   * trigger='landing' 的时机说明：下落的方块停住后，模组会连续确认 3 tick
   * 才把它放回世界；本脚本在实体 tick 之前扫描，所以在"停稳第 1 帧"就完成
   * 替换，一定早于模组放回方块。
   *
   * 其它开发者也可以在自己的脚本里注册，接口与 KubeJS 其它配方一致：
   *
   *   MirrorSetting.recipes.add({ input: 'minecraft:sand', output: 'minecraft:glass' });
   *   // 或
   *   MirrorSetting.onRegisterRecipes(e => e.add({ ... }));
   * ================================================================== */
  gravityBlockRecipes: {
    /* ---- 总开关 ----
     * false：重力方块只做纯重力往复，穿越交界处时不会变方块。
     *        调"运动是否干净"时应该关掉，否则配方会在半途把实体换掉、
     *        干扰对轨迹的观察。
     * true ：满足触发条件后，下落的方块当场变成产物方块。 */
    enabled: true,

    list: [
      /* 沙砾：在交界处加工 —— 穿越 2 次后直接变成铁块。
       * 变化点就在分界线上（y≈0 的空中）。 */
      {
        id: 'gravel_to_iron_block',
        input: 'minecraft:gravel',
        output: 'minecraft:iron_block',
        crossings: 2,
        trigger: 'crossing',
      },

      /* 沙子：靠"落在镜面上"加工 —— 穿越 3 次后，落在黑色玻璃上变成石英块。
       * 会一直往复，直到某次停稳在黑玻璃上才完成加工。 */
      {
        id: 'sand_to_quartz_block',
        input: 'minecraft:sand',
        output: 'minecraft:quartz_block',
        crossings: 3,
        trigger: 'landing',
        on: 'minecraft:black_stained_glass',
      },

      /* ============================================================
       * 红沙
       * ============================================================ */
      {
        id: 'red_sand_to_gold_block',
        input: 'minecraft:red_sand',
        output: 'minecraft:gold_block',
        crossings: 8,
        trigger: 'crossing',
      },
      {
        id: 'red_sand_to_glowstone',
        input: 'minecraft:red_sand',
        output: 'minecraft:glowstone',
        crossings: 4,
        trigger: 'landing',
        on: 'minecraft:glowstone',
      },

      /* ============================================================
       * 可疑的沙砾
       * ------------------------------------------------------------
       * 8 次切换 → 绿宝石块
       * 4 次切换 + 落在**陶罐**上 → 煤炭块，并往陶罐里塞一个
       *   古迹废墟考古战利品（刷子能刷出来的东西，见开头那两张表）
       * 陶罐不限纹饰 —— 这里只按方块 ID 'minecraft:decorated_pot' 判定，
       * 纹饰是方块实体的数据，不影响方块类型。
       * ============================================================ */
      {
        id: 'suspicious_gravel_to_emerald_block',
        input: 'minecraft:suspicious_gravel',
        output: 'minecraft:emerald_block',
        crossings: 8,
        trigger: 'crossing',
      },
      {
        id: 'suspicious_gravel_to_coal_block',
        input: 'minecraft:suspicious_gravel',
        output: 'minecraft:coal_block',
        crossings: 4,
        trigger: 'landing',
        on: 'minecraft:decorated_pot',
        /* force:true —— 陶罐**装满时也照样触发**：方块仍变成煤炭块，
         * 只是那一个战利品放不进去（丢掉）。默认的 force:false 是
         * "装不下就继续往复、等罐子腾出位置"，实测观感是"罐子满了以后
         * 沙砾再也不加工了"，所以这两条改成强制。
         * 代价：满罐时确实会白扔一个物品（日志里有 insertMissOnce 提示）。 */
        insert: { items: MIRROR_GRAVEL_BRUSH_LOOT, count: 1, force: true },
      },

      /* ============================================================
       * 可疑的沙子
       * ------------------------------------------------------------
       * 8 次切换 → TNT
       * 4 次切换 + 落在陶罐上 → 煤炭块，并塞入沙漠/海底废墟的考古战利品
       * ============================================================ */
      {
        id: 'suspicious_sand_to_tnt',
        input: 'minecraft:suspicious_sand',
        output: 'minecraft:tnt',
        crossings: 8,
        trigger: 'crossing',
      },
      {
        id: 'suspicious_sand_to_coal_block',
        input: 'minecraft:suspicious_sand',
        output: 'minecraft:coal_block',
        crossings: 4,
        trigger: 'landing',
        on: 'minecraft:decorated_pot',
        // force:true —— 同"可疑的沙砾"那条（说明见上面）
        insert: { items: MIRROR_SAND_BRUSH_LOOT, count: 1, force: true },
      },

      /* ============================================================
       * 铁砧三态：损坏 → 开裂 → 铁砧（各 4 次）
       * ============================================================ */
      {
        id: 'damaged_anvil_to_chipped_anvil',
        input: 'minecraft:damaged_anvil',
        output: 'minecraft:chipped_anvil',
        crossings: 4,
        trigger: 'crossing',
      },
      {
        id: 'chipped_anvil_to_anvil',
        input: 'minecraft:chipped_anvil',
        output: 'minecraft:anvil',
        crossings: 4,
        trigger: 'crossing',
      },
      /* 铁砧：8 次切换 + 落在**矿物块/金属块**上 → 变成落在的那一块。
       * 产物写 '@landed'，因为落点决定产物（不能写死）。
       *
       * on 写的是**一组标签**，这是必要的而不是偷懒：
       *
       *   · '#c:storage_blocks' 是 NeoForge 通用标签，聚合了原版的
       *     coal / copper / diamond / emerald / gold / iron / lapis /
       *     netherite / redstone / raw_* 这些"储量块"，也是绝大多数模组
       *     登记金属块的地方。
       *
       *   · ⚠️ 但它**聚合不到 AnvilCraft 的全部粗矿块**。实测（读
       *     anvilcraft-neoforge-1.21.1-1.6.0 的 data/c/tags/block/
       *     storage_blocks.json）：父标签里只写了 raw_zinc_block，
       *     另外 6 种粗矿块只登记在 storage_blocks/raw_xxx 子标签里，
       *     而子标签并没有被挂回父标签。所以这里必须逐个列上 ——
       *     少一个，对应的粗矿块就永远"落上去没反应"，且没有任何报错。
       *
       *   · 这 6 条读的是 AnvilCraft 自己写的子标签，所以它的方块 ID
       *     改了、或者以后补齐了父标签，这里都不用改。
       *
       * 另外 c:storage_blocks 里还包含 bone_meal / dried_kelp / slime /
       * wheat 四种非矿物储量块。想让铁砧对它们也生效就保持现状；
       * 要严格只要矿物与金属，得自己建一个标签再替换掉第一条。 */
      {
        id: 'anvil_to_landed_block',
        input: 'minecraft:anvil',
        output: '@landed',
        crossings: 8,
        trigger: 'landing',
        on: [
          '#c:storage_blocks',
          '#c:storage_blocks/raw_lead',
          '#c:storage_blocks/raw_silver',
          '#c:storage_blocks/raw_tin',
          '#c:storage_blocks/raw_titanium',
          '#c:storage_blocks/raw_tungsten',
          '#c:storage_blocks/raw_uranium',
        ],
      },

      /* ============================================================
       * 脚手架
       * ------------------------------------------------------------
       * 脚手架在原版就是**重力方块**（拆掉支撑会整段落下），所以它能
       * 进入这套往复加工。
       *
       *   8 次切换              → 蜘蛛网（交界处直接变）
       *   4 次切换 + 落在树叶上 → **对应树苗**，以掉落物形式弹出
       *
       * ⛔ 这里原本还有第三条「4 次切换 + 落在灵魂沙上 → 地狱疣」，
       *    2026-09-22 **放弃并整条删除**（连同为它写的 sticky / 跨重生计数机制）。
       *    原因与判断依据见 README 14.22。
       *
       * ⚠️ 脚手架有个**原版机制上的前提**，不满足时它压根不会变成下落实体：
       *    ScaffoldingBlock 只在「下方 6 格内没有任何**结实支撑面**」时
       *    才调用 FallingBlockEntity.fall（字节码确认：tick() 里连比两次
       *    DISTANCE == 7）。而落点方块、黑色玻璃**都是**结实方块 ——
       *    所以"把脚手架摆在落点上方几格"这种做法它永远不会掉，
       *    表现就是"配方没生效"，且没有任何报错。
       *    正确摆法见 README §14.4；游戏里用 /mirror recipes scaffolding 看采样。
       *
       * ⚠️ drop:true 的意义：树苗能当方块放，但产物原地放成
       *    方块会把落点盖掉，玩家也捡不走。所以让它以物品形式弹出来。
       *
       * ⚠️ 树叶用原版标签 #minecraft:leaves（10 种全含）；具体变成哪种
       *    树苗由 map 表按落点查（见文件开头 MIRROR_LEAVES_TO_SAPLING）。
       *    表里查不到的树叶（比如其它模组新增的）不会触发，方块继续往复。
       * ============================================================ */
      {
        id: 'scaffolding_to_cobweb',
        input: 'minecraft:scaffolding',
        output: 'minecraft:cobweb',
        crossings: 8,
        trigger: 'crossing',
        hint: '脚手架下方 6 格内不能有结实方块（落点方块、玻璃都算），否则原版不让它掉',
      },
      {
        id: 'scaffolding_to_sapling',
        input: 'minecraft:scaffolding',
        output: '@mapped',
        crossings: 4,
        trigger: 'landing',
        on: '#minecraft:leaves',
        map: MIRROR_LEAVES_TO_SAPLING,
        drop: true,
        hint: '脚手架要朝上飘着贴上树叶；它下方 6 格内不能有结实方块，否则不会掉',
      },
      /* ⛔ 这里原本还有第三条「脚手架 + 4 次切换 + 落在灵魂沙上 → 地狱疣（掉落物）」，
       *    2026-09-22 放弃，**整条删除**。它需要两套专用机制才可能成立：
       *      · `sticky`（这一趟碰到过落点就算数）—— 让 landing 的语义从
       *        "达标那一瞬间正贴着"放宽成"蹭过一次"；
       *      · 跨重生的计数身份 —— 因为脚手架一碰方块就重生（新实体、新 UUID）。
       *    而后者一旦按位置（竖列）共用状态，同一列的两个脚手架就会互相污染：
       *    实测 0→8 只用 1 秒（每 tick 记假翻转），全变蜘蛛网。
       *    前后十几轮、三套机制，仍然时灵时不灵 ⇒ 判定性价比不成立。
       *
       *    完整复盘见 README 14.17 / 14.21 / 14.22。
       *    脚手架现在只剩两条，都只依赖"次数"与"落点"：
       *      8 次 → 蜘蛛网 ／ 4 次 + 贴着树叶 → 树苗
       */

      /* ============================================================
       * 滴水石锥
       * ------------------------------------------------------------
       * 16 次切换 → 滴水石块。次数给得多，是因为它是唯一一条"纯靠往复
       * 次数"就能拿到的石类产物，慢一点才配得上它的用途（装饰石材）。
       * ============================================================ */
      {
        id: 'pointed_dripstone_to_dripstone_block',
        input: 'minecraft:pointed_dripstone',
        output: 'minecraft:dripstone_block',
        crossings: 16,
        trigger: 'crossing',
        hint: '滴水石锥要挖掉它上面那一格才会变成下落实体',
      },

      /* ============================================================
       * 16 色混凝土粉末
       * ------------------------------------------------------------
       * 8 次切换 → 对应颜色的陶瓦
       * 4 次切换 + 落在熔炉上 → 对应颜色的带釉陶瓦
       * 这 32 条在文件末尾用循环生成（手抄 16 色极易写错一个字母，
       * 而写错的表现只是"某两种颜色没反应"，很难查）。
       * ============================================================ */
    ],
  },

  /* ==================================================================
   * 工作台配方（无序合成）
   * ------------------------------------------------------------------
   * 玩法：**发光地衣**当作"镜面的碎屑" —— 把它和沙子 / 沙砾揉在一起，
   * 就得到对应的**可疑方块**（可疑的沙子 / 可疑的沙砾）。
   * 这样玩家不必去废墟找考古点，也能自己造出可加工的原料。
   *
   * 字段说明（每条配方）：
   *   id           配方 ID（写全 'mirror:xxx'；不写则由 KubeJS 自动生成，
   *                但自动 ID 不可预测，诊断指令里就认不出来）
   *   output       产物物品 ID
   *   count        产物数量，默认 1
   *   ingredients  原料列表（**无序** = 摆放位置随便）。
   *                可以写 'minecraft:sand'、'3x minecraft:sand'，
   *                也可以写 '#minecraft:planks' 这种标签。总数最多 9 个。
   *   note         可选，只用于 /mirror crafting 的人话说明
   *
   * ⚠️ 这里**只有无序合成**。要加有序合成（event.shaped）得先在
   *    mirror_n9_crafting.js 里加一种 kind，不要直接往这个表里塞形状字段。
   *
   * 生效方式：这些是**服务端配方**，注册脚本放在 kubejs/server_scripts 下，
   * 改完 /reload 即可（但改本文件的启动脚本部分仍需重启游戏）。
   *
   * JEI：KubeJS 注册的是**真正的原版配方**（进 RecipeManager），
   * 会随原版机制同步到客户端，所以 JEI 的工作台分类里**自动**就能看到，
   * 不需要像重力方块配方那样额外导出数据（详见 README §15）。
   * ================================================================== */
  craftingRecipes: {
    enabled: true,

    list: [
      {
        id: 'mirror:suspicious_sand_from_glow_lichen',
        output: 'minecraft:suspicious_sand',
        count: 1,
        ingredients: ['minecraft:sand', 'minecraft:glow_lichen'],
        note: '沙子 + 发光地衣 → 可疑的沙子',
      },
      {
        id: 'mirror:suspicious_gravel_from_glow_lichen',
        output: 'minecraft:suspicious_gravel',
        count: 1,
        ingredients: ['minecraft:gravel', 'minecraft:glow_lichen'],
        note: '沙砾 + 发光地衣 → 可疑的沙砾',
      },
    ],
  },

  /* ==================================================================
   * 镜外游戏模式：随机切旁观者/冒险，回镜内或离开维度时恢复
   * ================================================================== */
  outerRegion: {
    enabled: true,
    // 进入镜外时随机选取的模式（GameType 名，小写）
    random_modes: ['spectator', 'adventure'],
    notify_enter: true,
    notify_leave: true,
  },

  /* ==================================================================
   * 音效：穿过镜面时的提示音
   * ==================================================================
   * 默认用**模组自带、已烘焙好的**音效：
   *     mirrorgravity:block.mirror_enter
   * 它放在 mirrorside-0.1.jar 里（assets/mirrorgravity/sounds/mirror/enter_echo.ogg），
   * 由 tools/gen-enter-sound.mjs 用 ffmpeg 生成：
   *     · 4 层合唱（原版紫水晶钟声复制 4 份、各调 ±3% 音高、错开 0~34ms）
   *     · 8 抽头多抽头延迟混响，左右两路不同抽头时间 → 立体声宽度
   *     · 总长约 8 秒，最后 2 秒淡出
   *     · **响度对齐到原版地狱传送门**（见下面的实测数据）
   *
   * 为什么要烘焙而不是运行时叠加 —— 实测数据（ffmpeg ebur128）：
   *     原版紫水晶钟声 shimmer.ogg     -44.7 LUFS，真峰值 -29.3 dBFS
   *     原版地狱门 portal/travel.ogg   -13.0 LUFS，真峰值  -0.7 dBFS
   *   钟声文件本身比传送门轻 32 dB，而且原版 sounds.json 还给钟声写了
   *   "volume": 0.2（再压 14 dB）；传送门则是 1.0 文件音量 × 0.25 播放音量
   *   = 有效 **-25.0 LUFS**。
   *   运行时"叠 4 层"最多补 12 dB，补不上 30+ dB 的差距 —— 必须动文件。
   *
   * 响度定标：**-21.6 LUFS = 原版地狱门 +3.4 dB**。
   *   这个数是量出来的：用户用 /mirror sound 2 试听后要求"就按这个大小"，
   *   而"叠两份"的实际提升取决于两份拷贝的音高差（完全相干 +6 dB，
   *   带 ±3% 抖动去相关则 +3 dB），按分布加权约 +3.5 dB。
   *   成品实测 -21.6 LUFS、真峰值 -11.0 dBFS，与目标差 0.1 dB。
   *
   * 音量受哪根滑块控制：source = 'ambient' → 设置 → 音乐和声音 → **环境**
   *   （与地狱传送门完全同一根滑块：原版是用
   *    SimpleSoundInstance.forLocalAmbience(PORTAL_TRAVEL, pitch, 0.25F) 播的，
   *    forLocalAmbience 内部就是 SoundSource.AMBIENT）
   *
   * 就地试听：/mirror sound（不必真的穿一次门）。
   * 想改响度：改 tools/gen-enter-sound.mjs 顶部的 TARGET_LUFS 后重跑，
   *          或临时用 /mirror sound 的层数参数试（那条只对原版音效路径有效）。
   *
   * ⚠️ **进入提示音现在由模组播放，不由脚本播放**：
   *      · 从传送门回主世界 → 模组在落地后处理里播
   *      · 任何方式进入镜维度（传送门 / /mirror tp / /execute in …）
   *        → 模组监听"玩家进入镜维度"事件后播
   *    两者用的都是模组注册的 mirrorgravity:block.mirror_enter，
   *    音量/音高固定 1.0（音频文件本身已按 -21.6 LUFS 标定）。
   *    所以下面这一段**不再影响游戏里的提示音**，它只作用于：
   *      1) /mirror sound 试听指令
   *      2) 把 event 换回原版音效时的备用播放路径
   *    下面这些字段仍然保留，是因为调试与备用路径需要它们。 */
  sound: {
    enabled: true,
    enter: {
      /* 烘焙音效的事件 ID（模组 jar 里的 sounds.json 提供） */
      event: 'mirrorgravity:block.mirror_enter',
      /* 声道 = SoundSource 枚举名。地狱传送门用的是 AMBIENT（环境滑块），
       * 这里保持一致 —— 玩家调"环境"就能一起调。
       * ⚠️ 脚本会把它转成枚举再传给 playSound。直接把字符串传进去
       *    会**静默失败**（Rhino 不会把字符串转枚举）。 */
      source: 'ambient',
      /* 单份拷贝的音量，取值 0 ~ 1（脚本会把 >1 压回 1）。
       *
       * ⚠️ 为什么不写 2.4：客户端 SoundEngine.play 里是
       *      f2 = Mth.clamp(volume * 分类音量, 0.0F, 1.0F)   ← 实际增益，夹到 1
       *      f1 = Math.max(volume, 1.0F) * 衰减距离           ← 只决定"能听多远"
       *    所以 volume > 1 **不会更响**（近处响度封顶，写 2.4 与写 1.0 一样），
       *    唯一的实际效果是把可听半径从 16 格拉到 volume×16 格；
       *    而且它会把"环境"滑块架空 —— 滑块要拉到 1/volume 以下才开始起作用。
       *    想变响只能改音频文件（见上）。 */
      volume: 1.0,
      /* ---- 以下四项只在 event 换回原版音效时才有意义 ---- */
      /* 起始叠加层数：1 ~ 8。烘焙音效已含 4 层，运行时**必须**保持 1，
       * 否则会在成品上再叠一遍，直接过响。
       * 若 event 换成 'minecraft:block.amethyst_block.chime'，这里改成 4。 */
      stack: 1,
      /* 叠加层之间的音高差（±），避免几份完全同相叠成一个怪音 */
      stack_jitter: 0.03,
      /* 音高。1.0 = 原版钟声原调；1.2 = 更亮更短。
       * （响度对齐是在 1.0 下测的，改这个值响度会有一点变化） */
      pitch: 1.0,
      /* 每个抽头的音高随机抖动（±），避免几层叠成一个"更响的音" */
      pitch_jitter: 0.02,
      /* 每个抽头的随机位置偏移（格），原版按方位做声像 → 制造立体声宽度 */
      spread: 0.6,
      /* 运行时回响抽头：烘焙音效把回响做进文件了，所以这里留空。
       * 换回原版钟声时把这组恢复（每项 = [延迟tick, 音量倍率, 音高增量]）：
       *   [5, 0.55, 0.00], [12, 0.42, -0.03], [21, 0.32, 0.02],
       *   [32, 0.25, -0.05], [45, 0.19, 0.03], [60, 0.15, -0.07],
       *   [78, 0.11, 0.04], [99, 0.085, -0.10], [124, 0.06, -0.13], [152, 0.045, -0.16]
       * 想更悠长 → 往后继续加；想更干净 → 从后面删、或把音量倍率调小。 */
      taps: [],
    },
  },

  /* ==================================================================
   * 镜面传送门（3×3×3 结构 + 望远镜点燃）
   * ==================================================================
   * 结构（中间层的高度就是"传送门位置"）：
   *     y+1   平滑石英块 ×9          ← 顶层
   *     y     空气 ×8 + 中心玻璃      ← 中间层
   *     y-1   磨制黑石 ×9            ← 底层
   * 结构成形后，用**望远镜右键中心那格玻璃**，玻璃就变成传送门方块。
   * 之后上下两层不再是必需的（传送门一旦生成就独立存在）。
   *
   * ⚠️ 结构材料在这里改**会真的生效** —— 脚本启动时会把三项推给模组
   *    （MirrorGravityApi.setMirrorPortalStructure），模组只接收。
   *    日志里会回一行「结构材料已设为 底=… 顶=… 中心标签=#…」。 */
  mirrorPortal: {
    enabled: true,
    // 点燃用的物品（设定：望远镜）
    ignition_item: 'minecraft:spyglass',
    // 底层 3×3
    bottom_block: 'minecraft:polished_blackstone',
    // 顶层 3×3
    top_block: 'minecraft:smooth_quartz',
    /* 中心那一格要求的**方块标签**。设定原文是"任意，只需要有玻璃标签"，
     * 所以用 NeoForge 通用标签 c:glass_blocks —— 它聚合了
     * colorless / cheap / tinted 三组，原版所有玻璃（含染色玻璃、
     * 遮光玻璃）以及其它模组登记的玻璃都在里面，不需要自己维护清单。 */
    center_tag: 'c:glass_blocks',

    /* ------------------------------------------------------------------
     * 坐标映射：两个维度怎么对应
     * ------------------------------------------------------------------
     * X/Z：**镜维度 1 格 = 主世界 16 格**，与地狱门"1 : 8"是同一套机制 ——
     *      原版靠 dimension_type 的 coordinate_scale 实现
     *      （NetherPortalBlock 用 DimensionType.getTeleportationScale 拿到比值）。
     *      镜维度的 coordinate_scale 见 kubejs/config/mirror_dimension.json，
     *      传送门换算自动按那个值来，这里不用写。
     *
     * Y：镜维度的高度不能照搬主世界 —— 主世界 -64~319，而镜维度
     *      **境内**只有 -64~63（再往外就是镜外，会被切成冒险/旁观模式，
     *      玩家会回不来）。所以按比例把主世界的高度压进境内：
     *
     *          主世界 -64  ~  319   →   镜维度 -64  ~  63
     *          (384 格)                  (128 格)
     *
     *      线性映射，两端对齐；y=70（典型地面高度）会落到镜维度约 y=-20，
     *      稳稳在境内。反过来也一样成立，所以来回是自洽的。
     * ------------------------------------------------------------------ */
    overworld_y_range: [-64, 319],
    mirror_y_range: [-64, 63],

    /* 到达另一侧时**自动生成一座同样的传送门**。
     *
     * 为什么要生成：只把玩家丢过去的话，镜维度那一侧没有门，玩家回不来。
     * 生成位置就是上面的映射坐标；为避免 3×3×3 结构压在世界生成的玻璃层上
     * （上下界面/镜内外分界），生成时会自动把 Y 挪开几格，
     * 挪开依据是 layout.glass_layers 里那些层的高度（不用另外配置）。 */
    build_arrival: true,

    // 点燃成功/失败是否给玩家提示
    notify: true,
  },

  // ---- /mirror tp 的落点：镜内、分界线正上方 ----
  entry: {
    x: 0.5, y: 20.0, z: 0.5,
  },
};

/* =====================================================================
 * 16 色混凝土粉末的配方（循环生成 32 条）
 * ---------------------------------------------------------------------
 * 颜色顺序就是原版染料顺序。每条颜色生成两条：
 *   · 8 次重力切换           → <色>_terracotta（陶瓦）
 *   · 4 次切换 + 落在熔炉上  → <色>_glazed_terracotta（带釉陶瓦）
 *
 * ⚠️ 用 var 不用 const/let：这段虽然写在函数里（Rhino 的 const/let
 *    在函数里是安全的），但保持与文件其它地方一致的写法，
 *    免得将来被挪到顶层时踩「顶层块内 const/let 抛 redeclaration」的坑。
 * ===================================================================== */
(function () {
  var COLORS = [
    'white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink',
    'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black',
  ];
  var list = MIRROR_CONFIG.gravityBlockRecipes.list;
  for (var i = 0; i < COLORS.length; i++) {
    var c = COLORS[i];
    list.push({
      id: c + '_concrete_powder_to_terracotta',
      input: 'minecraft:' + c + '_concrete_powder',
      output: 'minecraft:' + c + '_terracotta',
      crossings: 8,
      trigger: 'crossing',
    });
    list.push({
      id: c + '_concrete_powder_to_glazed_terracotta',
      input: 'minecraft:' + c + '_concrete_powder',
      output: 'minecraft:' + c + '_glazed_terracotta',
      crossings: 4,
      trigger: 'landing',
      on: 'minecraft:furnace',
    });
  }
})();

global.MIRROR_CONFIG = MIRROR_CONFIG;
