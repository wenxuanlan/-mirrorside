#!/usr/bin/env node
/**
 * 生成"镜维度传送门"方块的**动态贴图**。
 * =====================================================================
 * 产出两个文件（放在模组资源里）：
 *   assets/mirrorgravity/textures/block/mirror_portal.png
 *       —— 动画条纹图：16 宽 × (16×32) 高，即 32 帧纵向排开
 *   assets/mirrorgravity/textures/block/mirror_portal.png.mcmeta
 *       —— 告诉游戏这是动画贴图、每帧停几 tick
 *
 * ── 为什么用脚本生成而不是画一张图 ─────────────────────────────────
 * 设定要的是"黑白光彩变换的透明状态"：
 *   · 黑白  → 只有亮度，不带颜色
 *   · 光彩变换 → 要有流动的干涉条纹，帧与帧之间必须**严丝合缝地循环**
 *   · 透明  → 需要 alpha 通道（渲染类型用 translucent）
 * 这种"参数化的流动图案"手画几乎不可能做到无缝循环，而脚本只要保证
 * 相位是 2π 的整数倍就天然循环，且任何时候重跑都得到完全一样的文件。
 *
 * ── 图案怎么来的 ──────────────────────────────────────────────────
 * 三束不同方向/频率的正弦波叠加（干涉），再映射成黑白与 alpha：
 *     a = sin(2π(x/8 + y/8 + t/T))        斜向波
 *     b = sin(2π(x/8 - y/8 - t/T·0.7))    反斜向波（两者交叉出菱形光带）
 *     c = sin(2π(x/4 + t/T·1.5))          细横纹（让光带"闪"起来）
 *     m = (a + b + 0.5c) / 2.5 ∈ [-1,1]
 *     n = (m+1)/2            → 亮度 = 255·n²，暗带更黑、亮带更亮
 *     alpha = 90 + 165·n     → 0.35 ~ 1.0，整体半透明，亮处更实
 * 所有相位都写成 2π·k·t/T，所以第 T 帧与第 0 帧完全对齐。
 *
 * ── 纯手工编码 PNG（zlib + CRC32），不依赖任何第三方库 ──────────────
 *
 * 用法:  node tools/gen-portal-texture.mjs
 * =====================================================================
 */

import { writeFileSync, mkdirSync } from 'node:fs';
import { deflateSync } from 'node:zlib';

const OUT_DIR = 'D:\\DSHwork\\MC镜维度\\mirror-gravity-mod\\src\\main\\resources'
  + '\\assets\\mirrorgravity\\textures\\block';
const NAME = 'mirror_portal';

const SIZE = 16;        // 贴图边长（与原版方块贴图一致）
const FRAMES = 32;      // 帧数
const FRAMETIME = 1;    // 每帧停几 tick（1 tick = 1/20 秒 → 32 帧 = 1.6 秒一轮）

/* ------------------------------------------------------------------ */
/* PNG 编码                                                            */
/* ------------------------------------------------------------------ */

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c;
  }
  return t;
})();

function crcOf(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crcOf(Buffer.concat([typeBuf, data])));
  return Buffer.concat([len, typeBuf, data, crc]);
}

/**
 * RGBA 像素数组 → PNG（colorType 6，bitDepth 8）。
 * @param {number} w 宽
 * @param {number} h 高
 * @param {(x:number,y:number)=>number[]} get 返回 [r,g,b,a]
 */
function encodePng(w, h, get) {
  const stride = w * 4;
  const raw = Buffer.alloc(h * (stride + 1));
  let p = 0;
  for (let y = 0; y < h; y++) {
    raw[p++] = 0;                       // 滤波类型 0（None）
    for (let x = 0; x < w; x++) {
      const [r, g, b, a] = get(x, y);
      raw[p++] = r & 0xff;
      raw[p++] = g & 0xff;
      raw[p++] = b & 0xff;
      /* ⚠️ alpha 必须原样写入，不能做任何裁剪 —— 写成 a & 0xff 之类
       * 会把 255 变成 0，贴图在游戏里会整块消失（同类坑踩过）。 */
      raw[p++] = a & 0xff;
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;     // bit depth
  ihdr[9] = 6;     // color type: RGBA
  ihdr[10] = 0;    // compression
  ihdr[11] = 0;    // filter
  ihdr[12] = 0;    // interlace
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/* ------------------------------------------------------------------ */
/* 图案                                                                */
/* ------------------------------------------------------------------ */

const TAU = Math.PI * 2;

/** 取某一帧某一像素的 [r,g,b,a]。条纹图的 y 要换算到帧内坐标。 */
function pixel(x, y) {
  const frame = Math.floor(y / SIZE);
  const ly = y % SIZE;
  const u = frame / FRAMES;          // 0..1 的循环相位

  const a = Math.sin(TAU * (x / 8 + ly / 8 + u));
  const b = Math.sin(TAU * (x / 8 - ly / 8 - u * 0.7));
  const c = Math.sin(TAU * (x / 4 + u * 1.5));
  const m = (a + b + 0.5 * c) / 2.5;      // [-1, 1]
  const n = (m + 1) / 2;                  // [0, 1]

  /* 增益 + 平方：
   *   k = min(1, n·1.22) 把波峰推到饱和 —— 波峰处是**纯白**，
   *   平方让暗带更沉 —— 波谷处是**纯黑**，中间过渡很窄。
   * 只走亮度、三通道同值，所以是纯黑白（"光彩"靠流动而不靠颜色）。 */
  const k = Math.min(1, n * 1.22);
  const lum = Math.round(255 * k * k);
  /* alpha：波谷 0.24、波峰 1.0 —— 整体能透出后面的方块，
   * 符合设定里的"透明状态"；亮带更实，暗带几乎只是薄薄一层灰。 */
  const alpha = Math.round(60 + 195 * Math.min(1, n * 1.3));

  return [lum, lum, lum, alpha];
}

/* ------------------------------------------------------------------ */
/* 输出                                                                */
/* ------------------------------------------------------------------ */

mkdirSync(OUT_DIR, { recursive: true });

const pngPath = OUT_DIR + '\\' + NAME + '.png';
writeFileSync(pngPath, encodePng(SIZE, SIZE * FRAMES, pixel));

const meta = {
  animation: {
    frametime: FRAMETIME,
    interpolate: true,
    frames: Array.from({ length: FRAMES }, (_, i) => i),
  },
};
const metaPath = pngPath + '.mcmeta';
writeFileSync(metaPath, JSON.stringify(meta, null, 2) + '\n', 'utf8');

/* ------------------------------------------------------------------ */
/* 自检：把生成结果再解回来量一遍                                        */
/* ------------------------------------------------------------------ */

console.log('=== 生成动态贴图 ===');
console.log(`  图幅   ${SIZE} × ${SIZE * FRAMES}（${FRAMES} 帧，每帧 ${SIZE}×${SIZE}）`);
console.log(`  帧率   frametime=${FRAMETIME} tick → 一轮 ${(FRAMES * FRAMETIME / 20).toFixed(2)} 秒`);
console.log(`  输出   ${pngPath}`);
console.log(`         ${metaPath}`);

/* 采样统计：确认"黑白都有、且有透明" */
let minL = 255;
let maxL = 0;
let minA = 255;
let maxA = 0;
let sumA = 0;
let count = 0;
for (let f = 0; f < FRAMES; f++) {
  for (let y = 0; y < SIZE; y++) {
    for (let x = 0; x < SIZE; x++) {
      const [r, , , a] = pixel(x, y + f * SIZE);
      minL = Math.min(minL, r);
      maxL = Math.max(maxL, r);
      minA = Math.min(minA, a);
      maxA = Math.max(maxA, a);
      sumA += a;
      count++;
    }
  }
}
console.log('=== 自检 ===');
console.log(`  亮度范围 ${minL} ~ ${maxL}（要同时有纯黑与纯白）`);
console.log(`  alpha 范围 ${minA} ~ ${maxA}，平均 ${(sumA / count / 255).toFixed(2)}（要明显小于 1 = 透明）`);
const ok = minL === 0 && maxL === 255 && minA <= 80 && maxA === 255;
console.log(ok ? '  ✓ 黑白对比与透明度都符合预期' : '  ✗ 图案不符合预期，检查上面的公式');
if (!ok) process.exitCode = 1;
