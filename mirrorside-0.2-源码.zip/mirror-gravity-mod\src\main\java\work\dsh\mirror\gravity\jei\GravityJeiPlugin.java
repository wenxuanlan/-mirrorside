package work.dsh.mirror.gravity.jei;

import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import work.dsh.mirror.gravity.MirrorBlocks;
import work.dsh.mirror.gravity.MirrorGravity;

import java.util.List;

/**
 * 镜维度 · JEI 集成：把"重力方块加工"配方展示到 JEI 里。
 *
 * <h2>JEI 插件的装载方式</h2>
 * JEI 在启动时扫描所有模组 jar 的注解，凡带 {@link JeiPlugin} 且实现
 * {@link IModPlugin} 的类都会被自动实例化并回调整册方法。所以这里
 * **不需要**向 NeoForge 注册任何东西，加注解即可 —— 这也是 JEI 官方文档
 * 规定的接入方式。
 *
 * <h2>JEI 不存在时会怎样（重要）</h2>
 * JEI 在本模组里是**可选**依赖（见 neoforge.mods.toml）。为了让缺少 JEI 时
 * 也不炸，本类的定位是"只在 JEI 扫描到它时才会被加载"：
 * <ul>
 *   <li>类上只有 JEI 的注解，没有任何地方在模组构造期 new 它</li>
 *   <li>JEI 不存在 → 没有任何代码引用本类 → JVM 不加载它 →
 *       里面的 JEI 类型引用也不会触发 NoClassDefFoundError</li>
 * </ul>
 * 反过来说，**不要在模组主类里 import 本包的任何类**，否则这条保证就断了。
 *
 * <h2>配方数据从哪来</h2>
 * 不在这里硬编码，而是读 KubeJS 导出的 JSON（见 {@link GravityRecipeData}），
 * 保证展示内容与实际生效的加工逻辑同源。
 */
@JeiPlugin
public class GravityJeiPlugin implements IModPlugin {

    /** 插件唯一 ID，JEI 要求全局唯一。 */
    private static final ResourceLocation UID =
        ResourceLocation.fromNamespaceAndPath(MirrorGravity.MOD_ID, "jei_plugin");

    @Override
    public ResourceLocation getPluginUid() {
        return UID;
    }

    /** 注册分类。这一步只决定"JEI 里有这么一个页面"。 */
    @Override
    public void registerCategories(IRecipeCategoryRegistration registration) {
        registration.addRecipeCategories(
            new GravityRecipeCategory(registration.getJeiHelpers().getGuiHelper()));
    }

    /** 把实际配方塞进对应分类。 */
    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        List<GravityRecipe> recipes = GravityRecipeData.load();
        if (recipes.isEmpty()) {
            return;   // 没有配方就不注册空分类，JEI 里不会出现空页面
        }
        registration.addRecipes(GravityRecipeCategory.TYPE, recipes);
    }

    /**
     * 注册"催化剂"：告诉 JEI 右键哪些物品时该显示这个分类。
     *
     * <p><b>只登记镜面</b>（本模组注册的占位方块）。
     *
     * <p>曾经同时把每个配方的输入方块（沙砾/沙子）也登记为催化剂，
     * 想着"对着输入按用途键就能看到它能变成什么"。实测效果是反的：
     * JEI 会在左侧把**所有催化剂**列成一竖排，于是镜面下面又冒出
     * 沙砾和沙子两格，看起来像本模组的方块，实际上它们只是原版物品。
     * 用户报告"左侧还是有沙子和沙砾"，指的就是这个。
     *
     * <p>重力方块加工只有**一个**工作方块（镜面），催化剂也只该有它一个。
     * 输入方块与配方的关联由 {@code setRecipe} 里的输入槽表达，
     * 不需要靠催化剂建立。
     */
    @Override
    public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
        try {
            var mirror = MirrorBlocks.MIRROR_SURFACE_ITEM.get();
            if (mirror != null) {
                registration.addRecipeCatalyst(new ItemStack(mirror), GravityRecipeCategory.TYPE);
            } else {
                MirrorGravity.LOGGER.warn("[镜维度·JEI] 镜面方块尚未就绪，分类将没有催化剂");
            }
        } catch (Throwable t) {
            MirrorGravity.LOGGER.warn("[镜维度·JEI] 镜面方块不可用，跳过催化剂: {}", t.toString());
        }
    }
}
