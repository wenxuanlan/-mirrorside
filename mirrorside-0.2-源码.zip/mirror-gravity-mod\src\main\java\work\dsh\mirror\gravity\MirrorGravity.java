package work.dsh.mirror.gravity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import work.dsh.mirror.gravity.internal.VelocityFix;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * 镜维度 · 重力补丁模组入口。
 *
 * <h2>本模组做什么</h2>
 * 让"重力方向反转"对**非生物实体**也能生效。Pondus 提供了重力方向的概念，
 * 但它的白名单在本实例上从未生效（标签目录名写成了复数），
 * 所以掉落物、下落的方块等一律被拒。本模组绕开白名单直接写入方向，
 * 并修补了 Pondus 换向时会把速度清零的缺陷。
 *
 * <h2>职责划分（重要）</h2>
 * 玩法逻辑几乎全在 KubeJS 侧，本模组只提供"能力"：
 * <table border="1">
 *   <tr><th>实体类别</th><th>方向由谁决定</th><th>物理由谁算</th></tr>
 *   <tr><td>下落的方块</td><td>本模组（固定 up/down 状态机）</td>
 *       <td>本模组 {@link BlockPhysics}</td></tr>
 *   <tr><td>掉落物 / TNT</td><td>KubeJS 迟滞</td><td>原版 + Pondus</td></tr>
 *   <tr><td>生物 / 玩家</td><td>KubeJS 迟滞</td><td>原版 + Pondus</td></tr>
 * </table>
 *
 * <p>这样划分是实测结论：早先让本模组接管所有非生物的物理，
 * 引入了"交界处抽搐 / 幅度过大 / 偶尔传送 / 回脚下"等一连串退化；
 * 而交给 KubeJS + Pondus 的那部分反而是用户确认过的稳定形态。
 *
 * <h2>与 KubeJS 的接口</h2>
 * 只有 {@link MirrorGravityApi}。脚本按类名加载它，所以那个类的
 * 全限定名与方法签名是不可破坏的契约。
 */
@Mod(MirrorGravity.MOD_ID)
public class MirrorGravity {

    public static final String MOD_ID = "mirrorgravity";
    public static final Logger LOGGER = LoggerFactory.getLogger("MirrorGravity");

    /** 已消失实体记录的清理周期（tick）。20 秒一次足够。 */
    private static final int CLEANUP_INTERVAL = 400;

    private int tickCounter = 0;

    public MirrorGravity(IEventBus modBus) {
        MirrorGravityApi.logStatus(LOGGER);

        /* 注册方块/物品/创造标签。
         * 目前只有一个"镜面"占位方块，用途是给 JEI 当分类图标与催化剂 ——
         * 重力方块加工没有工作方块，需要一个东西代表"加工发生在镜面上"。 */
        MirrorBlocks.register(modBus);

        NeoForge.EVENT_BUS.addListener(this::onEntityTick);
        NeoForge.EVENT_BUS.addListener(this::onServerTick);
        NeoForge.EVENT_BUS.addListener(this::onClientTick);
        NeoForge.EVENT_BUS.addListener(this::onPlayerChangedDimension);

        LOGGER.info("[镜维度·重力] 已加载：下落的方块支持重力方向反转。"
            + "掉落物与生物的方向由 KubeJS 侧下发。");
    }

    /**
     * 玩家**进入镜维度**时播一次提示音（那条烘焙好的黑白钟声）。
     *
     * <h2>为什么放在维度的"变化事件"上，而不是放在传送门里</h2>
     * 传送门只是进入镜维度的方式之一，还有 {@code /mirror tp}、
     * {@code /execute in mirror:mirror run tp}、以及将来的其它入口。
     * 监听"维度变化"这一件事，所有入口自动都有声音，
     * 而且不依赖任何脚本 —— 音效这条链路现在完全由模组负责。
     *
     * <p>⚠️ 传送门**回主世界**那一下的声音不在这里，在
     * {@link MirrorPortalBlock} 的落地后处理里（那次维度变化的方向相反）。
     * 两边各管一个方向，不会重复播。
     */
    private void onPlayerChangedDimension(
        net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerChangedDimensionEvent event) {
        try {
            if (event.getTo().equals(MirrorPortalBlock.mirrorDimension())) {
                MirrorPortalBlock.playCueAt(event.getEntity());
            }
        } catch (Throwable t) {
            LOGGER.debug("[镜维度·传送门] 进入提示音失败: {}", t.toString());
        }
    }

    /**
     * 客户端每 tick：只给下落的方块**设置渲染方向**，绝不碰物理。
     *
     * <h2>为什么客户端要单独扫</h2>
     * {@code FallingBlockEntity.tick()} 完全重写了 tick、**从不调用
     * {@code super.tick()}**（逐条字节码确认：方法内 0 次 invokespecial 到
     * {@code Entity.tick}）。而 {@code EntityTickEvent} 与 Pondus 的
     * {@code commonTick} 都注入在 {@code Entity.tick()} 上 ——
     * 所以它们对下落的方块**永远不会触发**。
     *
     * <p>所以两端都必须主动扫描。但**职责严格不同**：
     * <ul>
     *   <li>服务端（{@link #tickFallingBlocksOnServer}）—— 跑物理，唯一权威</li>
     *   <li>客户端（本方法）—— 只写方向供渲染用</li>
     * </ul>
     * {@link BlockPhysics#tick} 内部自己按 {@code isClientSide()} 分流，
     * 客户端分支只调 {@code DirectionWriter.apply} 就返回。
     *
     * <h2>⚠️ 踩过的坑：把物理搬到客户端</h2>
     * 曾经误判"事件不触发 ⇒ 服务端没人调它"，把这条扫描当成唯一入口，
     * 于是客户端成了权威、服务端反而停了。症状：
     *   · 振幅暴涨（两端各跑一套迟滞状态机，方向互相打架）
     *   · 方块落在下界面"挡住它的方块上"并变成实体方块
     *   · 放置后瞬移到很深的负坐标
     *   · 重力方块配方失效（配方计数依赖模组上报的真实方向）
     * 教训：**物理永远只在服务端算**，这是本模组的第一原则。
     */
    private void onClientTick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event) {
        try {
            net.minecraft.client.multiplayer.ClientLevel level =
                net.minecraft.client.Minecraft.getInstance().level;
            if (level == null) {
                return;
            }
            /* ⚠️ 参照线必须与服务端**完全一致**：服务端用
             * splitY() + fallingRefOffset()（默认 -1.0，因为黑色玻璃占
             * y=-1/-2）。两端差 1 格就会对"方块在哪半区"判断不一致。 */
            double split = splitY() + fallingRefOffset();
            for (Entity e : level.entitiesForRendering()) {
                if (e instanceof FallingBlockEntity) {
                    BlockPhysics.tick(e, split);
                }
            }
        } catch (Throwable t) {
            LOGGER.debug("[镜维度·重力] 客户端下落方块方向设置失败: {}", t.toString());
        }
    }

    /**
     * 实体 tick **之后**的处理：掉落物与生物的补丁。
     *
     * <p>⚠️ 下落的方块**不走这条事件** —— {@code FallingBlockEntity}
     * 不调用 {@code super.tick()}，所以 {@code EntityTickEvent} 对它不触发。
     * 它们由 {@link #tickFallingBlocksOnServer}（服务端，权威物理）与
     * {@link #onClientTick}（客户端，只设渲染方向）两条扫描路径处理。
     */
    private void onEntityTick(EntityTickEvent.Post event) {
        Entity e = event.getEntity();

        /* 客户端：只做重力量修正，**不做**下落的方块的物理。
         *
         * ⚠️ 重力量修正**两端都必须做**：客户端若少扣那部分重力，
         * 它自己预测的位置就会比服务端多走一截，表现为持续的位置回拉。 */
        if (e.level().isClientSide()) {
            try {
                VelocityFix.applyItemGravityScale(e);
            } catch (Throwable t) {
                LOGGER.debug("[镜维度·重力] 客户端处理失败: {}", t.toString());
            }
            return;
        }

        /* 其余实体（掉落物、生物……）：方向由 KubeJS 下发，物理交给 KubeJS + Pondus。
         * 这里做两件事：修正重力缩放、修补换向时被清零的水平速度。 */
        try {
            VelocityFix.applyItemGravityScale(e);
            VelocityFix.restoreIfLost(e);
        } catch (Throwable t) {
            LOGGER.debug("[镜维度·重力] 速度修补失败: {}", t.toString());
        }
    }

    /**
     * 服务端每 tick：驱动下落的方块的物理 —— **唯一的权威执行点**。
     *
     * <h2>为什么必须主动扫描，而不是靠事件或 KubeJS</h2>
     * <ul>
     *   <li>{@code FallingBlockEntity.tick()} 不调用 {@code super.tick()}，
     *       所以 {@code EntityTickEvent} 对它不触发（逐条字节码确认：
     *       该方法内 0 次 invokespecial 到 {@code Entity.tick}）。</li>
     *   <li>KubeJS 侧也**不**调用它：{@code applyGravityTo} 对下落的方块
     *       只做配方判定就 {@code return null}（见 mirror_n4_gravity.js）。</li>
     * </ul>
     * 所以这里是唯一入口，删掉它整个往复物理就停了。
     *
     * <p>⚠️ 这条扫描曾经被误删：当时误判"事件不触发 ⇒ 服务端没人调它，
     * 那就在客户端补上"，于是把 {@link BlockPhysics#tick} 挪进了客户端扫描。
     * 结果客户端成了权威、服务端反而停了，症状为：
     *   · 振幅暴涨（两端各跑一套迟滞状态机，方向互相打架）
     *   · 方块落在下界面"挡住它的方块上"并变成实体方块
     *   · 放置后瞬移到很深的负坐标
     *   · 重力方块配方失效（配方计数依赖模组上报的真实方向）
     * <b>物理永远只在服务端算</b>，这是本模组的第一原则
     * （见 {@link BlockPhysics} 类注释"只在服务端施力"）。
     */
    private void tickFallingBlocksOnServer(net.minecraft.server.MinecraftServer server) {
        try {
            double split = splitY() + fallingRefOffset();
            for (ServerLevel level : server.getAllLevels()) {
                /* getAll() 返回快照，遍历中实体被移除是安全的。 */
                level.getEntities().getAll().forEach(e -> {
                    if (e instanceof FallingBlockEntity) {
                        BlockPhysics.tick(e, split);
                    }
                });
            }
        } catch (Throwable t) {
            LOGGER.debug("[镜维度·重力] 下落方块处理失败: {}", t.toString());
        }
    }

    /**
     * 重力分界线。由 KubeJS 侧在启动后通过 {@link MirrorGravityApi#setSplitY}
     * 推过来；未设置时退回 0（与设定文件一致）。
     */
    static volatile double SPLIT_Y = 0.0D;

    static double splitY() {
        return SPLIT_Y;
    }

    /**
     * 下落方块的参照线相对分界的偏移（格），由 KubeJS 侧推送。
     *
     * <h2>为什么改成可配置</h2>
     * 分界 y=0，但黑色玻璃占 y=-1/-2。沙砾落在这层玻璃顶面时约在 y=-1.0，
     * 仍属"上侧"→ 受向下重力 → 继续往负坐标沉 → 最终被原版超时判定成掉落物。
     * 把参照线下移 1 格后，沙砾一碰到下界面就进入"下侧"、受向上重力，
     * 被压在玻璃面上停住，从而变回方块。
     *
     * <h2>为什么不再写死成常量</h2>
     * 这个值同时被两处使用：模组的方块物理、KubeJS 的配方穿越计数。
     * 原先它是本文件里的常量 + KubeJS 配置里的一个字段，**两处手工保持一致** ——
     * 改一处忘另一处就会让计数错位（实测症状：沙砾"视觉上来回十几次才变"）。
     *
     * <p>现在改为：布局（玻璃在哪一层）本就是 KubeJS 侧的职责，
     * 所以**唯一真相在那里**（{@code gravity.falling_ref_offset}），
     * 由脚本通过 {@link MirrorGravityApi#setFallingRefOffset(double)} 推过来。
     * 本字段只是接收结果，默认值仅用于"脚本还没推过来"的极早期。
     */
    static volatile double FALLING_REF_OFFSET = -1.0D;

    static double fallingRefOffset() {
        return FALLING_REF_OFFSET;
    }

    /** 由 {@link MirrorGravityApi#setFallingRefOffset} 调用。 */
    static void setFallingRefOffset(double offset) {
        FALLING_REF_OFFSET = offset;
        LOGGER.info("[镜维度·重力] 下落方块参照线偏移已设为 {}（实际反转线 y={}）",
            offset, SPLIT_Y + offset);
    }

    static void setSplitY(double y) {
        SPLIT_Y = y;
        LOGGER.info("[镜维度·重力] 重力分界已设为 y={}", y);
    }

    /**
     * 定期清理已消失实体的记录。
     *
     * <p>为什么必须做：接管记录与速度存档都以实体 UUID 为键。
     * 若只在实体存活时写入、消失后不清理，这些表会随实体总数无限增长
     * （长期挂机时会持续吃内存）。
     */
    private void onServerTick(ServerTickEvent.Post event) {
        tickCounter++;

        /* 下落的方块的物理 —— 每 tick 都要跑，与清理间隔无关。
         * 它们不触发 EntityTickEvent（见 tickFallingBlocksOnServer 的说明），
         * 所以必须在这里主动扫。 */
        tickFallingBlocksOnServer(event.getServer());

        if (tickCounter % CLEANUP_INTERVAL != 0) {
            return;
        }
        try {
            Set<UUID> alive = new HashSet<>();
            for (ServerLevel level : event.getServer().getAllLevels()) {
                level.getEntities().getAll().forEach(e -> alive.add(e.getUUID()));
            }
            VelocityFix.retainOnly(alive);
            BlockPhysics.retainOnly(alive);
        } catch (Throwable t) {
            LOGGER.debug("[镜维度·重力] 实体记录清理失败: {}", t.toString());
        }
    }
}
